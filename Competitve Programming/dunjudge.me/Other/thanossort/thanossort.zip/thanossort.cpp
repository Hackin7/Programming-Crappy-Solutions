#include "thanossort.h"

int thanosSort(int N){
    int curr;
    for (int x=1;x<=N;x++){
        curr=nextInt();
    }

    return N;
}
