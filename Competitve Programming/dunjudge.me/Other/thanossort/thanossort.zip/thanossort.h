#ifndef THANOSSORT_H_INCLUDED
#define THANOSSORT_H_INCLUDED

int thanosSort(int N);
int nextInt();

#endif // THANOSSORT_H_INCLUDED
