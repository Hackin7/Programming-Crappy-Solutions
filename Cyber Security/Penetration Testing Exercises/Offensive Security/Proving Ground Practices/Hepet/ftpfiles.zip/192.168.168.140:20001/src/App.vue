<template>
  <router-view id="app"/>
</template>

<script>
export default { name: 'app' }
</script>

<style lang="scss">
@import './sass/app';
</style>
