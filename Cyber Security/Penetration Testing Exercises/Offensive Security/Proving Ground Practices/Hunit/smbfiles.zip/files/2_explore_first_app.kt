
// Explore First App

fun main(args: Array<String>) {

    println("Hello World")

    println(10)

    println(true)

    println(10 / 2)

    println(94.2f)

    println(9 - 3)

}
