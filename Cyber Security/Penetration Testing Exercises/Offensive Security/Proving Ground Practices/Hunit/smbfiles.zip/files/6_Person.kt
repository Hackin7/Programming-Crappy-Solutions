
class Persson(var name: String ) {

    fun display() {
        print("The name of the person is ${name}")
    }
}
