
// Hello World App

fun main(args: Array<String>) {
    print("Hello World")
}
