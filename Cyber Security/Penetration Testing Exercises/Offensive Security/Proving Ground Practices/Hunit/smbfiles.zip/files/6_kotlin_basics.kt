
/*
* This is main function. Entry point of the application.
* */
fun main(args: Array<String>) {

    var personObj = Persson("Steve")

    personObj.display()
}
