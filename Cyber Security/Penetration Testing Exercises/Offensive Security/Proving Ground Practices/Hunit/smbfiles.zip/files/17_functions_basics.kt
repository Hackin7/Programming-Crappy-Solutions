
/*
*   FUNCTIONS Basics
* */
fun main(args: Array<String>) {


    var sum = add(2, 4)

    println("Sum is " + sum)
}

fun add(a: Int, b: Int): Int {
    return a + b
}
