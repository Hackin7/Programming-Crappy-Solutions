
/*
* Explore Data Types in Kotlin
* */

fun main(args: Array<String>) {

    var name: String
    name = "Kevin"

    var age: Int = 10
    var myAge = 10

    var isAlive: Boolean = true
    var marks: Float = 97.4F
    var percentage: Double = 90.78
    var gender: Char = 'M'

    print(marks)
}

