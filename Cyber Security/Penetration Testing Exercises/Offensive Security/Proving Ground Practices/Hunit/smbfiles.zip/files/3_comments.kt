


/*
* This is comment line 1
*
* This is comment line 2
*
* This is main function. Entry point of the application. 
* */

fun main(args: Array<String>) {     // This is inline comment ...
    print("Hello World")
}
