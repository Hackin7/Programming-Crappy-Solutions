<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cookie;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $isAdmin = Cookie::get('SPLODGESESSION');
        if ($isAdmin === '1') {
            $settings = DB::table('settings')->first();
            return view('admin', ['settings' => $settings]);
        } else {
            return redirect('login');
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $settings = DB::table('settings')->first();

        $title = $request->input('title') ?: $settings->title;
        $filter = $request->input('filter') ?: $settings->filter;
        $replacement = $request->input('replacement') ?: $settings->replacement;
        $password = $request->input('password') ?: $settings->password;

        $isAdmin = Cookie::get('SPLODGESESSION');
        if ($isAdmin === '1') {
            DB::table('settings')->update(['title' => $title, 'filter' => $filter, 'replacement' => $replacement, 'password' => $password]);
            $settings = DB::table('settings')->first();
            return view('admin', ['settings' => $settings]);
        } else {
            return redirect('login');
        }
    }

    public function login(Request $request)
    {
        return view('login');
    }

    public function postLogin(Request $request)
    {
        $settings = DB::table('settings')->first();
        $username = $request->input('username');
        $password = $request->input('password');

        if ($username === 'admin' && $password === $settings->password) {
            Cookie::queue(Cookie::make('SPLODGESESSION', '1', 60));
            return redirect('admin');
        }
        return view('login');
    }
}
