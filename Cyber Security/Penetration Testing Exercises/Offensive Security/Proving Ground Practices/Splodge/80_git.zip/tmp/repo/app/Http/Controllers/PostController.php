<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = DB::table('posts')->get();
        return view('index', ['posts' => $posts]);
    }
    
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        $comments = DB::table('comments')->where('post_id', '=', $post->id)->get();
        return view('post', ['post' => $post, 'comments' => $comments]);
    }

    /**
     * Comment on a post
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function comment(Request $request, Post $post)
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
        $author = $request->input('commentAuthor');
        $message = $request->input('commentMessage');
        $settings = DB::table('settings')->first();
        $message = preg_replace($settings->filter, $settings->replacement, $message);
        DB::table('comments')->insert(['post_id' => $post->id, 'author' => $author, 'message' => $message]);
        $comments = DB::table('comments')->where('post_id', '=', $post->id)->get();
        return view('post', ['post' => $post, 'comments' => $comments]);
    }
}
