```bash
nbtscan -rvh 192.168.58.70 2>&1
```

[/root/autorecon/results/192.168.58.70/scans/tcp139/nbtscan.txt](file:///root/autorecon/results/192.168.58.70/scans/tcp139/nbtscan.txt):

```
Doing NBT name scan for addresses from 192.168.58.70



```
