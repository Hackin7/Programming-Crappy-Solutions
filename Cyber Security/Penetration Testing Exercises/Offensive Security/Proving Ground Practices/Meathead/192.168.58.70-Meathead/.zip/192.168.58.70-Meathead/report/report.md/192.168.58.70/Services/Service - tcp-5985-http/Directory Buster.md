```bash
feroxbuster -u http://192.168.58.70:5985/ -t 10 -w /root/.config/AutoRecon/wordlists/dirbuster.txt -x "txt,html,php,asp,aspx,jsp" -v -k -n -q -e -o "/root/autorecon/results/192.168.58.70/scans/tcp5985/tcp_5985_http_feroxbuster_dirbuster.txt"
```

[/root/autorecon/results/192.168.58.70/scans/tcp5985/tcp_5985_http_feroxbuster_dirbuster.txt](file:///root/autorecon/results/192.168.58.70/scans/tcp5985/tcp_5985_http_feroxbuster_dirbuster.txt):

```

```
