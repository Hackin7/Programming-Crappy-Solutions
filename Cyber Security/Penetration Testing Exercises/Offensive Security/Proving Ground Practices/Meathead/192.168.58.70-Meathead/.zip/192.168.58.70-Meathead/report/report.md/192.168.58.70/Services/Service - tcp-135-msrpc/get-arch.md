```bash
getArch.py -target 192.168.58.70
```

[/root/autorecon/results/192.168.58.70/scans/tcp135/tcp_135_rpc_architecture.txt](file:///root/autorecon/results/192.168.58.70/scans/tcp135/tcp_135_rpc_architecture.txt):

```
Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation

[*] Gathering OS architecture for 1 machines
[*] Socket connect timeout set to 2 secs
192.168.58.70 is 64-bit


```
