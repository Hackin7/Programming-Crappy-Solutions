```bash
curl -sSik http://192.168.58.70:5985/
```

[/root/autorecon/results/192.168.58.70/scans/tcp5985/tcp_5985_http_curl.html](file:///root/autorecon/results/192.168.58.70/scans/tcp5985/tcp_5985_http_curl.html):

```
HTTP/1.1 404 Not Found
Content-Type: text/html; charset=us-ascii
Server: Microsoft-HTTPAPI/2.0
Date: Wed, 19 Jan 2022 10:48:57 GMT
Connection: close
Content-Length: 315

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN""http://www.w3.org/TR/html4/strict.dtd">
<HTML><HEAD><TITLE>Not Found</TITLE>
<META HTTP-EQUIV="Content-Type" Content="text/html; charset=us-ascii"></HEAD>
<BODY><h2>Not Found</h2>
<hr><p>HTTP Error 404. The requested resource is not found.</p>
</BODY></HTML>


```
