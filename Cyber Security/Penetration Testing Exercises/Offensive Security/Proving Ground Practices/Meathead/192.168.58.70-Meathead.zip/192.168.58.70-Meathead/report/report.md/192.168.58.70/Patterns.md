Matched Pattern: Powered-By: ASP.NET

Identified Architecture: 64-bit

Identified HTTP Server: Microsoft-IIS/10.0

Identified HTTP Server: Microsoft-HTTPAPI/2.0

