```bash
curl -sSikf http://192.168.58.70:5985/.well-known/security.txt
```