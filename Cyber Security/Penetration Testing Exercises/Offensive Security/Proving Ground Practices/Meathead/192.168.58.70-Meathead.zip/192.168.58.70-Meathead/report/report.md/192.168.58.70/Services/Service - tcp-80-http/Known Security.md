```bash
curl -sSikf http://192.168.58.70:80/.well-known/security.txt
```