```bash
wkhtmltoimage --format png http://192.168.58.70:80/ /root/autorecon/results/192.168.58.70/scans/tcp80/tcp_80_http_screenshot.png
```