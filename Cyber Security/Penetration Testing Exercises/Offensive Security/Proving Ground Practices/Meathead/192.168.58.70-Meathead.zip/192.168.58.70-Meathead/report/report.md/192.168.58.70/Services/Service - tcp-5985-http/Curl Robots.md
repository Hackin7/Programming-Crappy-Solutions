```bash
curl -sSikf http://192.168.58.70:5985/robots.txt
```