```bash
wkhtmltoimage --format png http://192.168.58.70:5985/ /root/autorecon/results/192.168.58.70/scans/tcp5985/tcp_5985_http_screenshot.png
```