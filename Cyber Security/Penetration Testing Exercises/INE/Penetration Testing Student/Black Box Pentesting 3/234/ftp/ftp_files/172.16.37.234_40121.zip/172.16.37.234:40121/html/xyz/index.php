<?php

echo "<!-- cmd: " . $_GET["cmd"] . "-->";
echo "<hr />";

system("ifconfig");

?>
