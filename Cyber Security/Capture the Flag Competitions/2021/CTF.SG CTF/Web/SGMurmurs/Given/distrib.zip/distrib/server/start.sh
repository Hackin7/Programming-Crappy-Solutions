#!/bin/bash
npm start