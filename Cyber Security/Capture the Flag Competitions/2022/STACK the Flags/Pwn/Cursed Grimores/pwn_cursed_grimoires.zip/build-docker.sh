#!/bin/bash
docker build -t pwn_cursed_grimoires .
docker run  --name=pwn_cursed_grimoires  --rm -p1337:1337 -it pwn_cursed_grimoires
