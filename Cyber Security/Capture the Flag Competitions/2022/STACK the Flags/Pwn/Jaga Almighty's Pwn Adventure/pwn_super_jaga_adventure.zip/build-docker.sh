#!/bin/sh
docker build --tag=jaga .
docker run -it -p 8080:8080 --rm --name=jaga jaga