#!/usr/bin/env python
import sqlite3
import uuid

def get_db_connection():
    conn = sqlite3.connect('sqlitedb/database.db')
    conn.row_factory = sqlite3.Row
    return conn

def getuser(uid):
    '''purpose: get user object'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('select id, username, isadmin, deactivated, vip from flaskusers where id=?', (uid,))
        flaskuser = result.fetchone()
    finally:
        conn.close()
    return flaskuser

def userexist(username):
    '''purpose: get user object'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('select id, username, isadmin, deactivated, vip from flaskusers where username=?', (username,))
        flaskuser = result.fetchone()
    finally:
        conn.close()
    return flaskuser

def login(username, password):
    '''purpose: login'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('SELECT id,isadmin FROM flaskusers WHERE username=? AND password=? AND deactivated=0', (username, password))
        flaskuser = result.fetchone()
    finally:
        conn.close()
    return flaskuser

def adduser(username, password):
    '''purpose: sign up'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        key = str(uuid.uuid4())
        cur.execute("INSERT INTO flaskusers (username, password, isadmin, deactivated, vip, key) VALUES (?, ?, ?, ?, ?, ?)", (username, password, 0, 0, 0, key))

    finally:
        conn.commit()
        conn.close()

def listusers():
    '''purpose: list of user ids and username that are not admin'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('select id, username, vip, deactivated from flaskusers where isadmin=0')
        users = result.fetchall()
    finally:
        conn.close()
    return users

def getuserviakey(key):
    '''purpose: check if key matches any user in db'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('SELECT id,username,vip FROM flaskusers WHERE key=?', (key,))
        flaskuser = result.fetchone()
    finally:
        conn.close()
    return flaskuser

def retrievemsgs(key):
    '''purpose: retrieve content via key'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('SELECT securenote.id,securenote.created,username,message,unlock FROM securenote JOIN flaskusers ON securenote.key=flaskusers.key WHERE securenote.key=? ORDER BY securenote.id ASC', (key,))
        msg = result.fetchall()
    finally:
        conn.close()
    return msg

def authmsg(nid, dpin):
    '''purpose: retrieve content via key'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('SELECT id,message,unlock FROM securenote WHERE id=? AND unlock=? ', (nid, dpin))
        msg = result.fetchone()
    finally:
        conn.close()
    return msg

def addmsg(key, message, unlock):
    '''purpose: Add message'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("INSERT INTO securenote (key, message,unlock) VALUES (?, ?, ?)", (key, message, unlock))
    finally:
        conn.commit()
        conn.close()

def deletemsg(nid, unlock):
    '''purpose: Delete message'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM securenote WHERE id=? AND unlock=?", (nid, unlock))
    finally:
        conn.commit()
        conn.close()
