#!/usr/bin/env python
import sqlite3

def get_db_connection():
    conn = sqlite3.connect('sqlitedb/database.db')  # shared db with flask
    conn.row_factory = sqlite3.Row
    return conn

def getkey(uid):
    '''purpose: extract the key'''
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        result = cur.execute('select key from flaskusers where id=?', (uid,))
        msg = result.fetchone()
    finally:
        conn.close()
    return msg

