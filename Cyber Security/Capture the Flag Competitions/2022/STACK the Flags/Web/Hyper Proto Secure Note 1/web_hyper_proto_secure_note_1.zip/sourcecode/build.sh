#!/bin/bash
docker image build -t hyperprotosecurenote1 .
