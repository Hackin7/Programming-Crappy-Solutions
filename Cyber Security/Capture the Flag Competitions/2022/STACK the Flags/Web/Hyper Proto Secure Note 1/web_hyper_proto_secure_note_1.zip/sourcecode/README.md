# Set up

1. Run `./build.sh`
2. Run `./start.sh`
