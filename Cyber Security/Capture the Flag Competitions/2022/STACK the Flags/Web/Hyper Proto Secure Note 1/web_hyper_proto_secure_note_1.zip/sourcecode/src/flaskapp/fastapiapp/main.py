#!/usr/bin/env python3
from fastapi import FastAPI
from fastapiapp import db

# Just a simple backend service
app = FastAPI()

@app.get("/")
async def root():
    return {"message": "FastAPI 0.1.0"}

@app.get("/retrievekey")
async def hpp(uid: str):
    r = db.getkey(uid)
    if(r and r['key']):
        location = "/securenote/" + r['key']
        result = 'You will redirect to your secure URL within 3 seconds or click <a href="' + location + '">here</a>.<br>'
        html = """
        <html>
            <head><meta http-equiv="refresh" content="3;URL='""" +location+ """'" /></head><body>"""+ result +"""</body>
        </html>"""
    else:
        html = 'No secure URL.'
    return {"message": html}
