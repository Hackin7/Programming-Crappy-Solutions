#!/bin/bash
echo "The following command can assist you with debugging..."
echo "$ tail -f ./logs/flask_stderr.log"
echo "----------------"
echo "Starting docker container..."
docker container run -it -p 5000:5000 -p 8000:8000 -v $(pwd)/logs:/tmp --rm hyperprotosecurenote1
# proceed to clean up logs directory.
echo ""
echo "----------------"
echo "Cleaning up logs directory..."
rm ./logs/*
echo "exiting... goodbye."
