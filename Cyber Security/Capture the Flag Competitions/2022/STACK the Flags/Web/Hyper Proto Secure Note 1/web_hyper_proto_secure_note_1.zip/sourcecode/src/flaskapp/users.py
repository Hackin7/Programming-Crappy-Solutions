#!/usr/bin/env python
from flask_login import UserMixin
# --- custom ---
from sqlitedb import db

# user (dictionary) - id, username, isadmin, deactivated, vip
# depends on db.py

# User model
class User(UserMixin):
    def __init__(self):
        self.user = None
        self.authenticated = False

    def __init__(self, user_dict):
        self.user = user_dict
        self.authenticated = False

	# ------ must implement ---------
    def is_authenticated(self):
        return self.authenticated
	
    def is_active(self):
        if(self.user):
            return self.user['deactivated']
        return True
	
    def is_anonymous(self):
        return not self.authenticated

    def get_id(self):
        return str(self.user['id'])
	
	# -------- Class function ---------
    def auth(username, password):
        '''Authenticate and return user'''
        user = db.login(username, password)
        if (user): # found inside db
            return User(user)
        return None # cannot find inside db return anonymous
