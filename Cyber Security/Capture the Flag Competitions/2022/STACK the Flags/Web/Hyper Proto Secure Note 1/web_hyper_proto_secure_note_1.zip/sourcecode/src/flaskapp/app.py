#!/usr/bin/env python
__author__ = "hloverflow"   # please credit me if you wanna use my code :)

import flask
from base64 import b64decode, b64encode 
from flask import Flask, request, render_template, redirect, url_for, Response
from flask_login import LoginManager, login_required, login_user, logout_user, current_user
from flask import session
from functools import wraps
import requests
from urllib.parse import urlparse

# ---- custom --- 
from users import User      # for flask_login
from sqlitedb import db     # interface to database

app = Flask(__name__)

# --- CONFIGURATION ---
app.secret_key = b'#yhhhaoof222dfdfa4fsssssQ8z\n\xec]/'     # NOT THE SAME AS CHALLENGE OF COURSE!
app.config['SESSION_COOKIE_HTTPONLY'] = False
APP_NAME = "Hyper-Proto-Secure-Note"
APP_VERSION = "Dev-0.1"
CONFIG = {
    "app_name": APP_NAME,
}

# --- AUTHENTICATION ---
login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    '''Return None if no match.'''
    user = db.getuser(user_id)
    if (user):                      # found inside db
        return User(user)
    return None

# --- APPLICATION ---

def skiptoprofile(func):
    '''This is a decorator to run before login/signup.'''
    @wraps(func)
    def inner(*a, **ka):
        if current_user.is_authenticated:   # already authenticated
            if current_user.user['isadmin']:
                app.logger.info("Skiptoadmin")
                return redirect(url_for('adminhome'))
            app.logger.info("Skiptoprofile")
            return redirect(url_for('profile', uid=current_user.user['id']))
        return func(*a, **ka)
    return inner

# --- Unauthenticated pages ---
@app.route("/", methods=["GET"])
@skiptoprofile
def index():
    return render_template("index.html", appname=CONFIG['app_name'])

@app.route("/signup", methods=["GET", "POST"])
@skiptoprofile
def signup():
    err = ""
    if request.method == "POST":	
        u = request.form['username']
        p = request.form['passwd']
        # Check if user exists. Do not allow overwrite of user. 
        if db.userexist(u):
            err = "Username is not available" # Yes, this is not good but enumeration is not required for this challenge.
        else:
            db.adduser(u, p)
            user = User.auth(u, p)
            login_user(user)
            return redirect(url_for('profile', uid=current_user.user['id']))
    return render_template("signup.html", error=err)

@app.route("/login", methods=["POST"])
@skiptoprofile
def login():
    err = ""
    u = request.form['username']
    p = request.form['passwd']
    user = User.auth(u, p)

    if(user):   # correct username and password
        login_user(user) 
        if(current_user.user['isadmin']):
            return redirect(url_for('adminhome'))
        return redirect(url_for('profile', uid=current_user.user['id']))
    err = "Invalid credentials"
    return render_template("index.html", error=err)

@app.route("/health", methods=["GET"])
def health():
    '''A very simple health check. Log current user identity as well.'''
    if current_user.is_authenticated:   # already authenticated
        app.logger.info("User " + current_user.user['username'] + " visited /health")
    else:
        app.logger.info("Anonymous visited /health")
    return "healthy"

# --- Authenticated pages ---
@app.route("/logout", methods=["GET"])
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route("/admin", methods=["GET"])
@login_required
def adminhome():
    if not current_user.user['isadmin']:
        return Response("ACCESS DENIED", 401)
    err = "Not available for this challenge."
    return Response(err, 404)

@app.route("/list", methods=["GET"])
@login_required
def listings():
    '''Allow users to see non-admin users'''
    users = db.listusers()
    return render_template("listing.html", users=users)

@app.route("/profile/<uid>", methods=["GET"])
@login_required
def profile(uid):
    user = db.getuser(uid)
    if(user):
        return render_template("profile.html", user=user)
    return render_template("profile-404.html"), 404

@app.route("/fastapi/", methods=["GET"])
@app.route("/fastapi/<apiname>", methods=["GET"], strict_slashes=False)
@login_required
def retrievekey(apiname=''):
    '''Obtain a secure note key from backend API. 
    Update: Remediated IDOR attack from recent PT report.'''
    if (request.args.get("uid")):
        uid = request.args.get("uid")  

        if(not uid.isnumeric()):    # input validation - data type
            return "Invalid Data Type: only numeric uid is accepted."
            
        if(uid == str(current_user.user["id"]) or current_user.user["isadmin"]):    # Authorisation check to prevent IDOR.

            # pass the url behind to fastapi
            fullurl = request.url 
            path = fullurl.replace(request.url_root, "").replace("fastapi", "")
            forwardurl = "http://localhost:8000" + path
            app.logger.debug("Forwarded URL to Fastapi: %s", forwardurl)
            r = requests.get(forwardurl)
            if(r.ok):
                try:
                    j = r.json()
                    msg = j['message']
                    return Response(msg, status=200)
                except requests.exceptions.JSONDecodeError:
                    return Response(r.text, status=200)
                except KeyError:
                    return r.json()
                except:
                    return Response("An unknown error occurred", status=500)
            else:
                return "HTTP "+ str(r.status_code) +": An error occurred"
        else:
            # authorisation check - failed
            html = "Unauthorised: You cannot retrieve the key of another user!"
            html += "\n<!-- uid="+uid+" current_user.user['id']="+str(current_user.user["id"])+" -->"
            return html
    else:
        return "Missing uid parameter."

@app.route("/securenote/<key>", methods=["GET", "POST"])
@login_required
def securenote(key):
    '''Remediated IDOR problem by making this not predictable with UUID.'''
    VIPLIMIT = 5
    NORMALLIMIT = 1
    u = db.getuserviakey(key)
    err = ""
    if(u):
        messages = db.retrievemsgs(key)
        if request.method == "POST":
            if(len(messages) < VIPLIMIT):
                if(current_user.user["vip"] or len(messages) < NORMALLIMIT):
                    newmessage = request.form["message"]
                    dpin = request.form["deletionpin"]
                    if(dpin==''):
                        dpin='1234'     # default
                    db.addmsg(key, newmessage, dpin)
                    return redirect(request.referrer)
            err = "Limit reached. Request for more limits from admin."
        return render_template("secure-note.html", msg=messages, author=u, error=err)
    return render_template("secure-note-404.html"), 404   # no user with this key.

@app.route("/securenote/<key>/<noteid>", methods=["POST"])
@login_required
def deletesecurenote(key, noteid):
    '''Not part of the challenge. 
    Avoid wasting your time creating new accounts when hit limits on writing notes.'''
    u = db.getuserviakey(key)
    err = ""
    if(u):
        dpin = request.form["deletionpin"]
        message = db.authmsg(noteid, dpin)  # ensure challenge is not deleted by trolls
        if(message):
            db.deletemsg(noteid, dpin)
            return Response("Deleted.", status=200)
        else:
            return Response("Invalid delete pin.", status=401)
    return Response("Does not exist", status=404)

@app.route("/admin-notified", methods=["GET"])
@login_required
def notifyadmin():
    err = "Not available for this challenge."
    return Response(err, 404)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0") # debug=True is only for this copy.

