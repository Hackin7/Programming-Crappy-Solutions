#!/usr/bin/env python
import sqlite3
import uuid

# password are made simple only for this copy but not the same on the actual challenge.
def init():
    with open("flag.txt", "r") as f:
        flag = f.read().strip()

    connection = sqlite3.connect('sqlitedb/database.db')

    with open('sqlitedb/schema.sql') as f:
        script = f.read()
        connection.executescript(script)

    bobuuid = str(uuid.uuid4())
    deletepin = "password"

    cur = connection.cursor()
    cur.execute("INSERT INTO flaskusers (username, password, isadmin, deactivated, vip) VALUES (?, ?, ?, ?, ?)",('admin', 'admin', 1, 0, 1))
    cur.execute("INSERT INTO flaskusers (username, password, isadmin, deactivated, vip, key) VALUES (?, ?, ?, ?, ?, ?)",('bob', 'bob', 0, 0, 1, bobuuid))
    cur.execute("INSERT INTO securenote (key, message, unlock) VALUES (?, ?, ?)",(bobuuid, 'Being VIP is pretty C00L', deletepin))
    cur.execute("INSERT INTO securenote (key, message, unlock) VALUES (?, ?, ?)",(bobuuid, 'Volunteered to help report broken feature to admin. (This is for another challenge)',deletepin))
    cur.execute("INSERT INTO securenote (key, message, unlock) VALUES (?, ?, ?)",(bobuuid, 'RDP Creds (flag): ' + flag, deletepin))
    connection.commit()
    connection.close()

if __name__ == "__main__":
    init()
