#!/bin/bash
docker build -t web_the_blacksmith .
docker run  --name=web_the_blacksmith  --rm -p8000:8000 -it web_the_blacksmith