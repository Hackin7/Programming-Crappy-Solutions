const mongoose = require('mongoose');

const Order = mongoose.model('Order', { 
    paymentAddress: String,
    publicKey: String,
    isClaimed: Boolean
});

module.exports = Order;