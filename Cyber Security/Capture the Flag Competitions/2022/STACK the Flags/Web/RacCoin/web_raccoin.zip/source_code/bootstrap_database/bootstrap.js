const mongoose = require('mongoose');
const { BIP32Factory } = require('bip32');
const bip39 = require('bip39');
const tinysecp = require('tiny-secp256k1');
const fs = require('fs');
const bitcoin = require('bitcoinjs-lib');

const raccoinServerConn = mongoose.createConnection('mongodb://localhost:27017/raccoin_server');
const flagShopConn = mongoose.createConnection('mongodb://localhost:27017/flag_shop');

const Wallet = raccoinServerConn.model('Wallet', { 
    address: String,
    balance: Number
});

const Order = flagShopConn.model('Order', { 
    paymentAddress: String,
    publicKey: String,
    isClaimed: Boolean
});

const bip32 = BIP32Factory(tinysecp);
const mnemonic = fs.readFileSync('/run/secrets/mnemonic').toString()
const seed = bip39.mnemonicToSeedSync(mnemonic);
const root = bip32.fromSeed(seed).neutered()

function getAddress(node) {
    return bitcoin.payments.p2pkh({ pubkey: node.publicKey }).address;
}

async function bootstrap() {
    console.log('bootstrapping database...')

    // bootstrap previous orders
    await Order.deleteMany({});
    await new Order({ paymentAddress: getAddress(root), publicKey: root.toBase58(), isClaimed: true }).save();
    for (let i = 0; i < 20; i++) {
        // Save public keys
        let child = root.derive(i).neutered();
        
        await new Order({ paymentAddress: getAddress(child), publicKey: child.toBase58(), isClaimed: true }).save();
    }  
    
    // bootstrap previous wallets
    await Wallet.deleteMany({});
    await new Wallet({ address: getAddress(root), balance: 0 }).save();
    for (let i = 0; i < 20; i++) {
        let child = root.derive(i).neutered();
        await new Wallet({ address: getAddress(child), balance: 15 }).save();
    }
}

setInterval(bootstrap, 60*1000);