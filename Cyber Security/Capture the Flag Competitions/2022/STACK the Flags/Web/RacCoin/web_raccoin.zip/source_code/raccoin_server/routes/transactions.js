const express = require('express');
const router = express.Router();
const bitcoinMessage = require('bitcoinjs-message')
const Wallet = require('../models/wallet.js');

// TODO: implement an actual blockchain, currently using a mock endpoint that actually uses a database

/* POST transaction */
router.post('/', async function (req, res, next) {
  // extract body values
  const { message, address, signature } = req.body;
  try {
    // verify bitcoin message
    if (bitcoinMessage.verify(message, address, signature)) {
      const senderWallet = await Wallet.findOne({ address: address }).sort({ _id: 1 }).exec();
      if (senderWallet !== null) {
        // parse message as JSON string e.g. "{\"amount\":15,\"receiverAddress\":\"<ADDRESS>\"}"
        const data = JSON.parse(message);
        // check if wallet has sufficient balance
        if (senderWallet.balance >= data.amount && data.amount > 0) {
          // retrieve receiving wallet and update balance, create new wallet if doesn't exist
          let receiverWallet = await Wallet.findOne({ address: data.receiverAddress }).sort({ _id: 1 }).exec();
          if (receiverWallet === null) {
            receiverWallet =  await new Wallet({ address: data.receiverAddress, balance: data.amount }).save();
          } else {
            await Wallet.findOneAndUpdate({ address: address }, { $inc: { 'balance': -(data.amount) } }).exec();
            receiverWallet = await Wallet.findOneAndUpdate({ address: data.receiverAddress }, { $inc: { 'balance': data.amount } }).exec();
          }
          res.send(receiverWallet);
        } else {
          res.status(403).send({ error: 'invalid transaction amount!' })
        }
      } else {
        res.status(404).send({ error: 'sender wallet does not exist!' })
      }
    } else {
      res.status(403).send({ error: 'failed to verify signature!' })
    }
  } catch (error) {
    console.log(error);
    res.status(400).send({ error: 'invalid input!' });
  }
});

/* GET wallet balance */
router.get('/balance', async function (req, res, next) {
  const wallet = await Wallet.findOne({ address: req.param('address') }).sort({ _id: 1 }).exec();
  res.send({balance: wallet ? wallet.balance : 0});
});

module.exports = router;
