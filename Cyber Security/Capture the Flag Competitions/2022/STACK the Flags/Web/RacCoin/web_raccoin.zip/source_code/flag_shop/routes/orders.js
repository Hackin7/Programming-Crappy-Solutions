const express = require('express');
const router = express.Router();
const Order = require('../models/order.js');
const fs = require('fs')
const { BIP32Factory } = require('bip32');
const bip39 = require('bip39');
const tinysecp = require('tiny-secp256k1');
const path = require('node:path');
const bitcoin = require('bitcoinjs-lib');

// generate parent
const bip32 = BIP32Factory(tinysecp);
const mnemonic = fs.readFileSync('/run/secrets/mnemonic').toString()
const seed = bip39.mnemonicToSeedSync(mnemonic);
const publicKey = bip32.fromSeed(seed)

// load flag
const flag = fs.readFileSync('/run/secrets/flag').toString()

// generate bitcoin payments address
function getAddress(node) {
  return bitcoin.payments.p2pkh({ pubkey: node.publicKey }).address;
}

/* POST orders */
router.post('/', async function(req, res, next) {
  // get next index of child wallet
  const i = await Order.countDocuments().exec() + 1;
  // derive child wallet at index
  let child = publicKey.derive(i);
  // create new order
  const order = await new Order({ paymentAddress: getAddress(child), publicKey: child.toBase58(), isClaimed: false }).save();
  res.send(order);
});

/* GET order */
router.get('/', async function(req, res, next) {
  // extract parameters
  const paymentAddress = req.param('paymentAddress')
  const publicKey = req.param('publicKey')
  try {
    if (paymentAddress == undefined && publicKey == undefined) {
      res.status(400).send({ error: 'please provide paymentAddress or publicKey!' })
    } else {
      // retrieve order based on parameter
      const order = publicKey === undefined ? 
        await Order.findOne({ paymentAddress: paymentAddress }).sort({ _id: 1 }).exec() :
        await Order.findOne({ publicKey: publicKey }).sort({ _id: 1 }).exec();
      if (order === null) {
        res.status(404).send({ error: 'order not found!' })
      } else {
        if (order.isClaimed === true) {
          res.status(403).send({ error: 'order is already claimed!' })
        } else {
          // fetch balance of payment wallet from raccoin server
          const response = await fetch(`http://localhost:4000/transactions/balance?address=${paymentAddress}`);
          const data = await response.json();
          if (data && data.balance >= 15) {
            // return flag if wallet has sufficient balance
            await Order.findOneAndUpdate({ paymentAddress: paymentAddress }, { isClaimed: true }).exec();
            res.send({'flag': flag})
          } else {
            res.render('pending', {
              order
            });
          }
        }
      }
    }
  } catch (error) {
    console.log(error);
    res.status(400).send({ error: 'invalid input!' });
  }
});

module.exports = router;