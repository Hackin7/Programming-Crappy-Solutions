# Level 4

Builds on [level 3](https://github.com/Caesurus/how2fsb/tree/master/level3)...

This introduces the concept of using the write primitive learned in the previous levels to update the Global Offset Table to redirect code code execution to the `hidden` function that will print out the flag.

---
Explaination of how to exploit this:
