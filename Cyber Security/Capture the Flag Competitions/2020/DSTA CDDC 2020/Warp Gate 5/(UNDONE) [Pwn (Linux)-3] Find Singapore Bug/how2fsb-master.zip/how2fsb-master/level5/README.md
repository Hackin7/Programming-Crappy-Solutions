# Level 5

Builds on [level 4](https://github.com/Caesurus/how2fsb/tree/master/level4)...

You need to utilize all the knowledge gained on levels 1-4 to get the flag. This requires multiple writes to various locations in memory, but the `main()` funcion calls `exit()`. So how can we get make the code let us give multiple inputs?

---
Explaination of how to exploit this:

