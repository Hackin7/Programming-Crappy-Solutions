# Level 2

This level require you to find the address of the `denyFlag` global variable and update its value to something that is non-zero.

---
Explaination of how to exploit this:
