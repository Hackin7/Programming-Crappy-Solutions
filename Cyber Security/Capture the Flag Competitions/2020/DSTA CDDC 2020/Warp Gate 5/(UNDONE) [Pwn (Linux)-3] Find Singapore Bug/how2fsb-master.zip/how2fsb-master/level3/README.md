# Level 3

Builds on [level 2](https://github.com/Caesurus/how2fsb/tree/master/level2)...

This level require you to find the address of the `denyFlag` global variable and update its value to a very specific value.

---
Explaination of how to exploit this:
