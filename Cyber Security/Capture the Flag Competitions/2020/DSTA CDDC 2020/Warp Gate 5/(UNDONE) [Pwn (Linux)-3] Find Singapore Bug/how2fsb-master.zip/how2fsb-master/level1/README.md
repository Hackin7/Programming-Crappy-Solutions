# Level 1 - I've got a secret
Description from PicoCTF2017
```
Ive Got A Secret
Hopefully you can find the right format for my secret! Source. Connect on shell2017.picoctf.com:42684.

HINTS
  This is a beginning format string attack.
```

If you have not played PicoCTF2017 please consider it: https://2017game.picoctf.com
It has excellent challenges that are well thought out and highly enjoyable.

This challenge requires you to leak the 'secret' random value by using FSB.
