package org.codehaus.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.h;

public class Type
  extends Label
{
  public int a;
  public h o;
  public int type;
  
  public Type(Context paramContext)
  {
    super(paramContext);
    super.setVisibility(8);
  }
  
  public void a(AttributeSet paramAttributeSet)
  {
    super.a(paramAttributeSet);
    o = new h();
    if (paramAttributeSet != null)
    {
      paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, IpAddress.ConstraintLayout_Layout);
      int j = paramAttributeSet.getIndexCount();
      int i = 0;
      while (i < j)
      {
        int k = paramAttributeSet.getIndex(i);
        if (k == IpAddress.ConstraintLayout_Layout_barrierDirection)
        {
          setType(paramAttributeSet.getInt(k, 0));
        }
        else if (k == IpAddress.ConstraintLayout_Layout_barrierAllowsGoneWidgets)
        {
          o.c(paramAttributeSet.getBoolean(k, true));
        }
        else if (k == IpAddress.ConstraintLayout_Layout_barrierMargin)
        {
          k = paramAttributeSet.getDimensionPixelSize(k, 0);
          o.d(k);
        }
        i += 1;
      }
      paramAttributeSet.recycle();
    }
    g = o;
    a();
  }
  
  public final void a(f paramF, int paramInt, boolean paramBoolean)
  {
    a = paramInt;
    if (paramBoolean)
    {
      paramInt = type;
      if (paramInt == 5) {
        a = 1;
      } else if (paramInt == 6) {
        a = 0;
      }
    }
    else
    {
      paramInt = type;
      if (paramInt == 5) {
        a = 0;
      } else if (paramInt == 6) {
        a = 1;
      }
    }
    if ((paramF instanceof h)) {
      ((h)paramF).setTitle(a);
    }
  }
  
  public void a(f paramF, boolean paramBoolean)
  {
    a(paramF, type, paramBoolean);
  }
  
  public int getMargin()
  {
    return o.k();
  }
  
  public int getType()
  {
    return type;
  }
  
  public boolean j()
  {
    return o.isVisible();
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean)
  {
    o.c(paramBoolean);
  }
  
  public void setDpMargin(int paramInt)
  {
    float f = getResourcesgetDisplayMetricsdensity;
    paramInt = (int)(paramInt * f + 0.5F);
    o.d(paramInt);
  }
  
  public void setMargin(int paramInt)
  {
    o.d(paramInt);
  }
  
  public void setType(int paramInt)
  {
    type = paramInt;
  }
}
