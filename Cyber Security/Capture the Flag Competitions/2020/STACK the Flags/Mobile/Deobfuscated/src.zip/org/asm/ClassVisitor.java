package org.asm;

public abstract class ClassVisitor {}
