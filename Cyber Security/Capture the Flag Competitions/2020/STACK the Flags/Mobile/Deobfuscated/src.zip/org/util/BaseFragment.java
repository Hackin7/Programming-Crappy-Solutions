package org.util;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;

public class BaseFragment
  extends Fragment
{
  public Canvas mActivity;
  
  public BaseFragment() {}
  
  public static void showDialog(Activity paramActivity)
  {
    paramActivity = paramActivity.getFragmentManager();
    if (paramActivity.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null)
    {
      paramActivity.beginTransaction().add(new BaseFragment(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      paramActivity.executePendingTransactions();
    }
  }
  
  public final void b(Canvas paramCanvas)
  {
    if (paramCanvas != null) {
      paramCanvas.visitParameter();
    }
  }
  
  public final void c(Canvas paramCanvas)
  {
    if (paramCanvas != null) {
      paramCanvas.delete();
    }
  }
  
  public final void clear(Scope paramScope)
  {
    Object localObject = getActivity();
    if ((localObject instanceof LruCache))
    {
      ((LruCache)localObject).getLifecycle().append(paramScope);
      return;
    }
    if ((localObject instanceof d))
    {
      localObject = ((d)localObject).getLifecycle();
      if ((localObject instanceof f)) {
        ((f)localObject).append(paramScope);
      }
    }
  }
  
  public void onActivityCreated(Bundle paramBundle)
  {
    super.onActivityCreated(paramBundle);
    b(mActivity);
    clear(Scope.ON_CREATE);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    clear(Scope.ON_DESTROY);
    mActivity = null;
  }
  
  public void onPause()
  {
    super.onPause();
    clear(Scope.ON_PAUSE);
  }
  
  public void onResume()
  {
    super.onResume();
    c(mActivity);
    clear(Scope.ON_RESUME);
  }
  
  public void onStart()
  {
    super.onStart();
    reset(mActivity);
    clear(Scope.ON_START);
  }
  
  public void onStop()
  {
    super.onStop();
    clear(Scope.ON_STOP);
  }
  
  public final void reset(Canvas paramCanvas)
  {
    if (paramCanvas != null) {
      paramCanvas.destroy();
    }
  }
}
