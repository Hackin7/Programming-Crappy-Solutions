package org.codehaus.asm;

public abstract interface Pair<T> {}
