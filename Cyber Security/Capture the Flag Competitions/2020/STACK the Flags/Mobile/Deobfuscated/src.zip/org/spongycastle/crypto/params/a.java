package org.spongycastle.crypto.params;

import a.c.a.b.b;
import a.c.a.b.b.c;
import java.util.HashMap;
import java.util.Map.Entry;

public class a<K, V>
  extends b<K, V>
{
  public HashMap<K, b.c<K, V>> b = new HashMap();
  
  public a() {}
  
  public Object a(Object paramObject)
  {
    Object localObject = super.a(paramObject);
    b.remove(paramObject);
    return localObject;
  }
  
  public Object b(Object paramObject1, Object paramObject2)
  {
    Attribute localAttribute = b(paramObject1);
    if (localAttribute != null) {
      return d;
    }
    b.put(paramObject1, a(paramObject1, paramObject2));
    return null;
  }
  
  public Attribute b(Object paramObject)
  {
    return (Attribute)b.get(paramObject);
  }
  
  public boolean contains(Object paramObject)
  {
    return b.containsKey(paramObject);
  }
  
  public Map.Entry getValue(Object paramObject)
  {
    if (contains(paramObject)) {
      return b.get(paramObject)).b;
    }
    return null;
  }
}
