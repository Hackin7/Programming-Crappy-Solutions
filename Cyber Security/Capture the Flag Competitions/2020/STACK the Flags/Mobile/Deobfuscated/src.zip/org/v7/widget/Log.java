package org.v7.widget;

import android.content.res.Resources;

public class Log
  extends Resources
{
  public static boolean DEBUG = false;
  
  public static boolean checkSettings()
  {
    return false;
  }
  
  public static boolean i()
  {
    checkSettings();
    return false;
  }
}
