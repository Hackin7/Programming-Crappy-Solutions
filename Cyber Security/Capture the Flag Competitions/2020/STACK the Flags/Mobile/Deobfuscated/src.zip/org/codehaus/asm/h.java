package org.codehaus.asm;

import java.util.ArrayList;

public class h
  implements d
{
  public Label a = null;
  public float b = 0.0F;
  public ByteVector c;
  public boolean f = false;
  public boolean g;
  public ArrayList<a.f.b.h> n = new ArrayList();
  
  public h() {}
  
  public h(Item paramItem)
  {
    c = new f(this, paramItem);
  }
  
  public String a()
  {
    if (a == null)
    {
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append("");
      ((StringBuilder)localObject1).append("0");
      localObject1 = ((StringBuilder)localObject1).toString();
    }
    else
    {
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append("");
      ((StringBuilder)localObject1).append(a);
      localObject1 = ((StringBuilder)localObject1).toString();
    }
    Object localObject2 = new StringBuilder();
    ((StringBuilder)localObject2).append((String)localObject1);
    ((StringBuilder)localObject2).append(" = ");
    Object localObject1 = ((StringBuilder)localObject2).toString();
    localObject2 = localObject1;
    int i = 0;
    if (b != 0.0F)
    {
      localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append((String)localObject1);
      ((StringBuilder)localObject2).append(b);
      localObject2 = ((StringBuilder)localObject2).toString();
      i = 1;
    }
    int k = c.size();
    int j = 0;
    while (j < k)
    {
      localObject1 = c.a(j);
      if (localObject1 == null)
      {
        localObject1 = localObject2;
      }
      else
      {
        float f2 = c.b(j);
        float f1 = f2;
        if (f2 == 0.0F)
        {
          localObject1 = localObject2;
        }
        else
        {
          String str = ((Label)localObject1).toString();
          if (i == 0)
          {
            localObject1 = localObject2;
            if (f2 < 0.0F)
            {
              localObject1 = new StringBuilder();
              ((StringBuilder)localObject1).append((String)localObject2);
              ((StringBuilder)localObject1).append("- ");
              localObject1 = ((StringBuilder)localObject1).toString();
              f1 = f2 * -1.0F;
            }
          }
          else if (f2 > 0.0F)
          {
            localObject1 = new StringBuilder();
            ((StringBuilder)localObject1).append((String)localObject2);
            ((StringBuilder)localObject1).append(" + ");
            localObject1 = ((StringBuilder)localObject1).toString();
          }
          else
          {
            localObject1 = new StringBuilder();
            ((StringBuilder)localObject1).append((String)localObject2);
            ((StringBuilder)localObject1).append(" - ");
            localObject1 = ((StringBuilder)localObject1).toString();
            f1 = f2 * -1.0F;
          }
          if (f1 == 1.0F)
          {
            localObject2 = new StringBuilder();
            ((StringBuilder)localObject2).append((String)localObject1);
            ((StringBuilder)localObject2).append(str);
            localObject1 = ((StringBuilder)localObject2).toString();
          }
          else
          {
            localObject2 = new StringBuilder();
            ((StringBuilder)localObject2).append((String)localObject1);
            ((StringBuilder)localObject2).append(f1);
            ((StringBuilder)localObject2).append(" ");
            ((StringBuilder)localObject2).append(str);
            localObject1 = ((StringBuilder)localObject2).toString();
          }
          i = 1;
        }
      }
      j += 1;
      localObject2 = localObject1;
    }
    if (i == 0)
    {
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append((String)localObject2);
      ((StringBuilder)localObject1).append("0.0");
      return ((StringBuilder)localObject1).toString();
    }
    return localObject2;
  }
  
  public Label a(ClassWriter paramClassWriter)
  {
    Object localObject4 = null;
    Object localObject3 = null;
    float f5 = 0.0F;
    float f4 = 0.0F;
    boolean bool4 = false;
    boolean bool3 = false;
    int j = c.size();
    int i = 0;
    while (i < j)
    {
      float f1 = c.b(i);
      paramClassWriter = c.a(i);
      Object localObject2;
      boolean bool1;
      Object localObject1;
      float f2;
      float f3;
      boolean bool2;
      if (i == c.a)
      {
        if (localObject3 == null)
        {
          localObject2 = paramClassWriter;
          bool1 = write(paramClassWriter);
          localObject1 = localObject4;
          f2 = f1;
          f3 = f4;
          bool2 = bool3;
        }
        else if (f5 > f1)
        {
          localObject2 = paramClassWriter;
          bool1 = write(paramClassWriter);
          localObject1 = localObject4;
          f2 = f1;
          f3 = f4;
          bool2 = bool3;
        }
        else
        {
          localObject1 = localObject4;
          localObject2 = localObject3;
          f2 = f5;
          f3 = f4;
          bool1 = bool4;
          bool2 = bool3;
          if (!bool4)
          {
            localObject1 = localObject4;
            localObject2 = localObject3;
            f2 = f5;
            f3 = f4;
            bool1 = bool4;
            bool2 = bool3;
            if (write(paramClassWriter))
            {
              bool1 = true;
              localObject1 = localObject4;
              localObject2 = paramClassWriter;
              f2 = f1;
              f3 = f4;
              bool2 = bool3;
            }
          }
        }
      }
      else
      {
        localObject1 = localObject4;
        localObject2 = localObject3;
        f2 = f5;
        f3 = f4;
        bool1 = bool4;
        bool2 = bool3;
        if (localObject3 == null)
        {
          localObject1 = localObject4;
          localObject2 = localObject3;
          f2 = f5;
          f3 = f4;
          bool1 = bool4;
          bool2 = bool3;
          if (f1 < 0.0F) {
            if (localObject4 == null)
            {
              localObject1 = paramClassWriter;
              bool2 = write(paramClassWriter);
              localObject2 = localObject3;
              f2 = f5;
              f3 = f1;
              bool1 = bool4;
            }
            else if (f4 > f1)
            {
              localObject1 = paramClassWriter;
              bool2 = write(paramClassWriter);
              localObject2 = localObject3;
              f2 = f5;
              f3 = f1;
              bool1 = bool4;
            }
            else
            {
              localObject1 = localObject4;
              localObject2 = localObject3;
              f2 = f5;
              f3 = f4;
              bool1 = bool4;
              bool2 = bool3;
              if (!bool3)
              {
                localObject1 = localObject4;
                localObject2 = localObject3;
                f2 = f5;
                f3 = f4;
                bool1 = bool4;
                bool2 = bool3;
                if (write(paramClassWriter))
                {
                  bool2 = true;
                  bool1 = bool4;
                  f3 = f1;
                  f2 = f5;
                  localObject2 = localObject3;
                  localObject1 = paramClassWriter;
                }
              }
            }
          }
        }
      }
      i += 1;
      localObject4 = localObject1;
      localObject3 = localObject2;
      f5 = f2;
      f4 = f3;
      bool4 = bool1;
      bool3 = bool2;
    }
    if (localObject3 != null) {
      return localObject3;
    }
    return localObject4;
  }
  
  public Label a(ClassWriter paramClassWriter, boolean[] paramArrayOfBoolean)
  {
    return a(paramArrayOfBoolean, null);
  }
  
  public final Label a(boolean[] paramArrayOfBoolean, Label paramLabel)
  {
    float f1 = 0.0F;
    Object localObject1 = null;
    int j = c.size();
    int i = 0;
    while (i < j)
    {
      float f3 = c.b(i);
      float f2 = f1;
      Object localObject2 = localObject1;
      if (f3 < 0.0F)
      {
        Label localLabel = c.a(i);
        if (paramArrayOfBoolean != null)
        {
          f2 = f1;
          localObject2 = localObject1;
          if (paramArrayOfBoolean[n] != 0) {}
        }
        else
        {
          f2 = f1;
          localObject2 = localObject1;
          if (localLabel != paramLabel)
          {
            c localC = i;
            if (localC != c.c)
            {
              f2 = f1;
              localObject2 = localObject1;
              if (localC != c.d) {}
            }
            else
            {
              f2 = f1;
              localObject2 = localObject1;
              if (f3 < f1)
              {
                f2 = f3;
                localObject2 = localLabel;
              }
            }
          }
        }
      }
      i += 1;
      f1 = f2;
      localObject1 = localObject2;
    }
    return localObject1;
  }
  
  public h a(float paramFloat1, float paramFloat2, float paramFloat3, Label paramLabel1, Label paramLabel2, Label paramLabel3, Label paramLabel4)
  {
    b = 0.0F;
    if ((paramFloat2 != 0.0F) && (paramFloat1 != paramFloat3))
    {
      if (paramFloat1 == 0.0F)
      {
        c.a(paramLabel1, 1.0F);
        c.a(paramLabel2, -1.0F);
        return this;
      }
      if (paramFloat3 == 0.0F)
      {
        c.a(paramLabel3, 1.0F);
        c.a(paramLabel4, -1.0F);
        return this;
      }
      paramFloat1 = paramFloat1 / paramFloat2 / (paramFloat3 / paramFloat2);
      c.a(paramLabel1, 1.0F);
      c.a(paramLabel2, -1.0F);
      c.a(paramLabel4, paramFloat1);
      c.a(paramLabel3, -paramFloat1);
      return this;
    }
    c.a(paramLabel1, 1.0F);
    c.a(paramLabel2, -1.0F);
    c.a(paramLabel4, 1.0F);
    c.a(paramLabel3, -1.0F);
    return this;
  }
  
  public h a(ClassWriter paramClassWriter, int paramInt)
  {
    c.a(paramClassWriter.a(paramInt, "ep"), 1.0F);
    c.a(paramClassWriter.a(paramInt, "em"), -1.0F);
    return this;
  }
  
  public h a(Label paramLabel, int paramInt)
  {
    if (paramInt < 0)
    {
      b = (paramInt * -1);
      c.a(paramLabel, 1.0F);
      return this;
    }
    b = paramInt;
    c.a(paramLabel, -1.0F);
    return this;
  }
  
  public h a(Label paramLabel1, Label paramLabel2, float paramFloat)
  {
    c.a(paramLabel1, -1.0F);
    c.a(paramLabel2, paramFloat);
    return this;
  }
  
  public h a(Label paramLabel1, Label paramLabel2, int paramInt)
  {
    int i = 0;
    int k = 0;
    if (paramInt != 0)
    {
      int j = paramInt;
      i = k;
      if (paramInt < 0)
      {
        j = paramInt * -1;
        i = 1;
      }
      b = j;
    }
    if (i == 0)
    {
      c.a(paramLabel1, -1.0F);
      c.a(paramLabel2, 1.0F);
      return this;
    }
    c.a(paramLabel1, 1.0F);
    c.a(paramLabel2, -1.0F);
    return this;
  }
  
  public h a(Label paramLabel1, Label paramLabel2, int paramInt1, float paramFloat, Label paramLabel3, Label paramLabel4, int paramInt2)
  {
    if (paramLabel2 == paramLabel3)
    {
      c.a(paramLabel1, 1.0F);
      c.a(paramLabel4, 1.0F);
      c.a(paramLabel2, -2.0F);
      return this;
    }
    if (paramFloat == 0.5F)
    {
      c.a(paramLabel1, 1.0F);
      c.a(paramLabel2, -1.0F);
      c.a(paramLabel3, -1.0F);
      c.a(paramLabel4, 1.0F);
      if ((paramInt1 > 0) || (paramInt2 > 0))
      {
        b = (-paramInt1 + paramInt2);
        return this;
      }
    }
    else
    {
      if (paramFloat <= 0.0F)
      {
        c.a(paramLabel1, -1.0F);
        c.a(paramLabel2, 1.0F);
        b = paramInt1;
        return this;
      }
      if (paramFloat >= 1.0F)
      {
        c.a(paramLabel4, -1.0F);
        c.a(paramLabel3, 1.0F);
        b = (-paramInt2);
        return this;
      }
      c.a(paramLabel1, (1.0F - paramFloat) * 1.0F);
      c.a(paramLabel2, (1.0F - paramFloat) * -1.0F);
      c.a(paramLabel3, -1.0F * paramFloat);
      c.a(paramLabel4, paramFloat * 1.0F);
      if ((paramInt1 > 0) || (paramInt2 > 0)) {
        b = (-paramInt1 * (1.0F - paramFloat) + paramInt2 * paramFloat);
      }
    }
    return this;
  }
  
  public h a(Label paramLabel1, Label paramLabel2, Label paramLabel3, int paramInt)
  {
    int i = 0;
    int k = 0;
    if (paramInt != 0)
    {
      int j = paramInt;
      i = k;
      if (paramInt < 0)
      {
        j = paramInt * -1;
        i = 1;
      }
      b = j;
    }
    if (i == 0)
    {
      c.a(paramLabel1, -1.0F);
      c.a(paramLabel2, 1.0F);
      c.a(paramLabel3, 1.0F);
      return this;
    }
    c.a(paramLabel1, 1.0F);
    c.a(paramLabel2, -1.0F);
    c.a(paramLabel3, -1.0F);
    return this;
  }
  
  public h a(Label paramLabel1, Label paramLabel2, Label paramLabel3, Label paramLabel4, float paramFloat)
  {
    c.a(paramLabel3, 0.5F);
    c.a(paramLabel4, 0.5F);
    c.a(paramLabel1, -0.5F);
    c.a(paramLabel2, -0.5F);
    b = (-paramFloat);
    return this;
  }
  
  public void a(ClassWriter paramClassWriter, Label paramLabel, boolean paramBoolean)
  {
    if (!d) {
      return;
    }
    float f1 = c.b(paramLabel);
    b += g * f1;
    c.a(paramLabel, paramBoolean);
    if (paramBoolean) {
      paramLabel.a(this);
    }
    c.a(z.d[p], f1, paramBoolean);
    if (c.size() == 0)
    {
      f = true;
      k = true;
    }
  }
  
  public void a(ClassWriter paramClassWriter, h paramH, boolean paramBoolean)
  {
    float f1 = c.a(paramH, paramBoolean);
    b += b * f1;
    if (paramBoolean) {
      a.a(this);
    }
    if ((a != null) && (c.size() == 0))
    {
      f = true;
      k = true;
    }
  }
  
  public void a(d paramD)
  {
    if ((paramD instanceof h))
    {
      paramD = (h)paramD;
      a = null;
      c.clear();
      int i = 0;
      while (i < c.size())
      {
        Label localLabel = c.a(i);
        float f1 = c.b(i);
        c.a(localLabel, f1, true);
        i += 1;
      }
    }
  }
  
  public h add(Label paramLabel1, Label paramLabel2, Label paramLabel3, Label paramLabel4, float paramFloat)
  {
    c.a(paramLabel1, -1.0F);
    c.a(paramLabel2, 1.0F);
    c.a(paramLabel3, paramFloat);
    c.a(paramLabel4, -paramFloat);
    return this;
  }
  
  public boolean add(Label paramLabel)
  {
    return c.a(paramLabel);
  }
  
  public h b(Label paramLabel, int paramInt)
  {
    a = paramLabel;
    a = paramInt;
    b = paramInt;
    f = true;
    return this;
  }
  
  public h b(Label paramLabel1, Label paramLabel2, Label paramLabel3, int paramInt)
  {
    int i = 0;
    int k = 0;
    if (paramInt != 0)
    {
      int j = paramInt;
      i = k;
      if (paramInt < 0)
      {
        j = paramInt * -1;
        i = 1;
      }
      b = j;
    }
    if (i == 0)
    {
      c.a(paramLabel1, -1.0F);
      c.a(paramLabel2, 1.0F);
      c.a(paramLabel3, -1.0F);
      return this;
    }
    c.a(paramLabel1, 1.0F);
    c.a(paramLabel2, -1.0F);
    c.a(paramLabel3, 1.0F);
    return this;
  }
  
  public void b()
  {
    a = null;
    c.clear();
    b = 0.0F;
    f = false;
  }
  
  public void b(ClassWriter paramClassWriter, Label paramLabel, boolean paramBoolean)
  {
    if (!c) {
      return;
    }
    float f1 = c.b(paramLabel);
    b += a * f1;
    c.a(paramLabel, paramBoolean);
    if (paramBoolean) {
      paramLabel.a(this);
    }
    if (c.size() == 0)
    {
      f = true;
      k = true;
    }
  }
  
  public void b(Label paramLabel)
  {
    Label localLabel = a;
    if (localLabel != null)
    {
      c.a(localLabel, -1.0F);
      a.f = -1;
      a = null;
    }
    float f1 = c.a(paramLabel, true) * -1.0F;
    a = paramLabel;
    if (f1 == 1.0F) {
      return;
    }
    b /= f1;
    c.a(f1);
  }
  
  public boolean b(ClassWriter paramClassWriter)
  {
    boolean bool = false;
    paramClassWriter = a(paramClassWriter);
    if (paramClassWriter == null) {
      bool = true;
    } else {
      b(paramClassWriter);
    }
    if (c.size() == 0) {
      f = true;
    }
    return bool;
  }
  
  public Label c(Label paramLabel)
  {
    return a(null, paramLabel);
  }
  
  public h c(Label paramLabel, int paramInt)
  {
    c.a(paramLabel, paramInt);
    return this;
  }
  
  public void c(ClassWriter paramClassWriter)
  {
    if (a.length == 0) {
      return;
    }
    int i = 0;
    while (i == 0)
    {
      int k = c.size();
      int j = 0;
      Label localLabel;
      while (j < k)
      {
        localLabel = c.a(j);
        if ((f != -1) || (c) || (d)) {
          n.add(localLabel);
        }
        j += 1;
      }
      k = n.size();
      if (k > 0)
      {
        j = 0;
        while (j < k)
        {
          localLabel = (Label)n.get(j);
          if (c) {
            b(paramClassWriter, localLabel, true);
          } else if (d) {
            a(paramClassWriter, localLabel, true);
          } else {
            a(paramClassWriter, a[f], true);
          }
          j += 1;
        }
        n.clear();
      }
      else
      {
        i = 1;
      }
    }
    if ((a != null) && (c.size() == 0))
    {
      f = true;
      k = true;
    }
  }
  
  public boolean c()
  {
    Label localLabel = a;
    return (localLabel != null) && ((i == c.a) || (b >= 0.0F));
  }
  
  public void clear()
  {
    c.clear();
    a = null;
    b = 0.0F;
  }
  
  public void d()
  {
    float f1 = b;
    if (f1 < 0.0F)
    {
      b = (f1 * -1.0F);
      c.a();
    }
  }
  
  public void d(Label paramLabel)
  {
    float f1 = 1.0F;
    int i = k;
    if (i == 1) {
      f1 = 1.0F;
    } else if (i == 2) {
      f1 = 1000.0F;
    } else if (i == 3) {
      f1 = 1000000.0F;
    } else if (i == 4) {
      f1 = 1.0E9F;
    } else if (i == 5) {
      f1 = 1.0E12F;
    }
    c.a(paramLabel, f1);
  }
  
  public boolean isEmpty()
  {
    return (a == null) && (b == 0.0F) && (c.size() == 0);
  }
  
  public Label n()
  {
    return a;
  }
  
  public String toString()
  {
    return a();
  }
  
  public final boolean write(Label paramLabel)
  {
    return v <= 1;
  }
}
