package org.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.ActionMenuItemView.b;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.ActionMenuView.a;
import java.util.ArrayList;
import org.core.asm.signature.DrawableCompat;
import org.core.view.ActionProvider;
import org.core.view.ActionProvider.SubUiVisibilityListener;
import org.v7.R.attr;
import org.v7.R.layout;
import org.v7.view.ActionBarPolicy;
import org.v7.view.menu.ListPopupWindow;
import org.v7.view.menu.MenuBuilder;
import org.v7.view.menu.MenuView;
import org.v7.view.menu.MenuView.ItemView;
import org.v7.view.menu.SubMenuBuilder;
import org.v7.view.menu.b;
import org.v7.view.menu.i;
import org.v7.view.menu.l.a;

public class ActionMenuPresenter
  extends b
  implements ActionProvider.SubUiVisibilityListener
{
  public final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  public ActionButtonSubmenu mActionButtonPopup;
  public int mActionItemWidthLimit;
  public boolean mExpandedActionViewsExclusive;
  public int mMaxItems;
  public int mMinCellSize;
  public int mOpenSubMenuId;
  public OverflowMenuButton mOverflowButton;
  public OverflowPopup mOverflowPopup;
  public Drawable mPendingOverflowIcon;
  public boolean mPendingOverflowIconSet;
  public ActionMenuPopupCallback mPopupCallback;
  public final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  public OpenOverflowRunnable mPostedOpenRunnable;
  public boolean mReserveOverflow;
  public boolean mReserveOverflowSet;
  public int mWidthLimit;
  
  public ActionMenuPresenter(Context paramContext)
  {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  public void a(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    dismissPopupMenus();
    super.a(paramMenuBuilder, paramBoolean);
  }
  
  public void bindItemView(org.v7.view.menu.MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView)
  {
    paramItemView.initialize(paramMenuItemImpl, 0);
    paramMenuItemImpl = (ActionMenuView)mMenuView;
    paramItemView = (ActionMenuItemView)paramItemView;
    paramItemView.setItemInvoker(paramMenuItemImpl);
    if (mPopupCallback == null) {
      mPopupCallback = new ActionMenuPopupCallback();
    }
    paramItemView.setPopupCallback(mPopupCallback);
  }
  
  public boolean dismissPopupMenus()
  {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt)
  {
    if (paramViewGroup.getChildAt(paramInt) == mOverflowButton) {
      return false;
    }
    super.filterLeftoverView(paramViewGroup, paramInt);
    return true;
  }
  
  public final View findViewForItem(MenuItem paramMenuItem)
  {
    ViewGroup localViewGroup = (ViewGroup)mMenuView;
    if (localViewGroup == null) {
      return null;
    }
    int j = localViewGroup.getChildCount();
    int i = 0;
    while (i < j)
    {
      View localView = localViewGroup.getChildAt(i);
      if (((localView instanceof MenuView.ItemView)) && (((MenuView.ItemView)localView).getItemData() == paramMenuItem)) {
        return localView;
      }
      i += 1;
    }
    return null;
  }
  
  public boolean flagActionItems()
  {
    Object localObject1 = mMenu;
    Object localObject2;
    int i1;
    if (localObject1 != null)
    {
      localObject2 = ((MenuBuilder)localObject1).getVisibleItems();
      localObject1 = localObject2;
      i1 = ((ArrayList)localObject2).size();
    }
    else
    {
      localObject1 = null;
      i1 = 0;
    }
    int i = mMaxItems;
    int i3 = mActionItemWidthLimit;
    int i5 = View.MeasureSpec.makeMeasureSpec(0, 0);
    ViewGroup localViewGroup = (ViewGroup)mMenuView;
    int m = 0;
    int n = 0;
    int i4 = 0;
    int k = 0;
    int j = 0;
    while (j < i1)
    {
      localObject2 = (org.v7.view.menu.MenuItemImpl)((ArrayList)localObject1).get(j);
      if (((org.v7.view.menu.MenuItemImpl)localObject2).requiresActionButton()) {
        m += 1;
      } else if (((org.v7.view.menu.MenuItemImpl)localObject2).requestsActionButton()) {
        n += 1;
      } else {
        k = 1;
      }
      i2 = i;
      if (mExpandedActionViewsExclusive)
      {
        i2 = i;
        if (((org.v7.view.menu.MenuItemImpl)localObject2).isActionViewExpanded()) {
          i2 = 0;
        }
      }
      j += 1;
      i = i2;
    }
    j = i;
    if (mReserveOverflow) {
      if (k == 0)
      {
        j = i;
        if (m + n <= i) {}
      }
      else
      {
        j = i - 1;
      }
    }
    j -= m;
    SparseBooleanArray localSparseBooleanArray = mActionButtonGroups;
    localSparseBooleanArray.clear();
    int i2 = 0;
    i = i4;
    for (n = i3;; n = m)
    {
      localObject2 = this;
      if (i2 >= i1) {
        break;
      }
      org.v7.view.menu.MenuItemImpl localMenuItemImpl = (org.v7.view.menu.MenuItemImpl)((ArrayList)localObject1).get(i2);
      if (localMenuItemImpl.requiresActionButton())
      {
        localObject2 = ((ActionMenuPresenter)localObject2).getItemView(localMenuItemImpl, null, localViewGroup);
        ((View)localObject2).measure(i5, i5);
        i3 = ((View)localObject2).getMeasuredWidth();
        m = n - i3;
        k = i;
        if (i == 0) {
          k = i3;
        }
        i = localMenuItemImpl.getGroupId();
        if (i != 0) {
          localSparseBooleanArray.put(i, true);
        }
        localMenuItemImpl.setIsActionButton(true);
        i = k;
      }
      else if (localMenuItemImpl.requestsActionButton())
      {
        i4 = localMenuItemImpl.getGroupId();
        boolean bool = localSparseBooleanArray.get(i4);
        int i6;
        if (((j > 0) || (bool)) && (n > 0)) {
          i6 = 1;
        } else {
          i6 = 0;
        }
        m = n;
        k = i;
        int i7 = i6;
        if (i6 != 0)
        {
          localObject2 = ((ActionMenuPresenter)localObject2).getItemView(localMenuItemImpl, null, localViewGroup);
          ((View)localObject2).measure(i5, i5);
          i3 = ((View)localObject2).getMeasuredWidth();
          m = n - i3;
          k = i;
          if (i == 0) {
            k = i3;
          }
          if (m + k > 0) {
            i = 1;
          } else {
            i = 0;
          }
          i7 = i6 & i;
        }
        if ((i7 != 0) && (i4 != 0))
        {
          localSparseBooleanArray.put(i4, true);
        }
        else if (bool)
        {
          localSparseBooleanArray.put(i4, false);
          n = 0;
          while (n < i2)
          {
            localObject2 = (org.v7.view.menu.MenuItemImpl)((ArrayList)localObject1).get(n);
            i = j;
            if (((org.v7.view.menu.MenuItemImpl)localObject2).getGroupId() == i4)
            {
              i = j;
              if (((org.v7.view.menu.MenuItemImpl)localObject2).isActionButton()) {
                i = j + 1;
              }
              ((org.v7.view.menu.MenuItemImpl)localObject2).setIsActionButton(false);
            }
            n += 1;
            j = i;
          }
        }
        i = j;
        if (i7 != 0) {
          i = j - 1;
        }
        localMenuItemImpl.setIsActionButton(i7);
        j = i;
        i = k;
      }
      else
      {
        localMenuItemImpl.setIsActionButton(false);
        m = n;
      }
      i2 += 1;
    }
    return true;
  }
  
  public View getItemView(org.v7.view.menu.MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup)
  {
    View localView2 = paramMenuItemImpl.getActionView();
    View localView1 = localView2;
    if ((localView2 == null) || (paramMenuItemImpl.hasCollapsibleActionView())) {
      localView1 = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup);
    }
    int i;
    if (paramMenuItemImpl.isActionViewExpanded()) {
      i = 8;
    } else {
      i = 0;
    }
    localView1.setVisibility(i);
    paramMenuItemImpl = (ActionMenuView)paramViewGroup;
    paramView = localView1.getLayoutParams();
    if (!paramMenuItemImpl.checkLayoutParams(paramView)) {
      localView1.setLayoutParams(paramMenuItemImpl.a(paramView));
    }
    return localView1;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    MenuView localMenuView = mMenuView;
    paramViewGroup = super.getMenuView(paramViewGroup);
    if (localMenuView != paramViewGroup) {
      ((ActionMenuView)paramViewGroup).setPresenter(this);
    }
    return paramViewGroup;
  }
  
  public Drawable getOverflowIcon()
  {
    OverflowMenuButton localOverflowMenuButton = mOverflowButton;
    if (localOverflowMenuButton != null) {
      return localOverflowMenuButton.getDrawable();
    }
    if (mPendingOverflowIconSet) {
      return mPendingOverflowIcon;
    }
    return null;
  }
  
  public boolean hideOverflowMenu()
  {
    Object localObject = mPostedOpenRunnable;
    if (localObject != null)
    {
      MenuView localMenuView = mMenuView;
      if (localMenuView != null)
      {
        ((View)localMenuView).removeCallbacks((Runnable)localObject);
        mPostedOpenRunnable = null;
        return true;
      }
    }
    localObject = mOverflowPopup;
    if (localObject != null)
    {
      ((i)localObject).dismiss();
      return true;
    }
    return false;
  }
  
  public boolean hideSubMenus()
  {
    ActionButtonSubmenu localActionButtonSubmenu = mActionButtonPopup;
    if (localActionButtonSubmenu != null)
    {
      localActionButtonSubmenu.dismiss();
      return true;
    }
    return false;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
  {
    super.initForMenu(paramContext, paramMenuBuilder);
    paramMenuBuilder = paramContext.getResources();
    paramContext = ActionBarPolicy.get(paramContext);
    if (!mReserveOverflowSet)
    {
      paramContext.showsOverflowMenuButton();
      mReserveOverflow = true;
    }
    mWidthLimit = paramContext.getEmbeddedMenuWidthLimit();
    mMaxItems = paramContext.init();
    int i = mWidthLimit;
    if (mReserveOverflow)
    {
      if (mOverflowButton == null)
      {
        paramContext = new OverflowMenuButton(mSystemContext);
        mOverflowButton = paramContext;
        if (mPendingOverflowIconSet)
        {
          paramContext.setImageDrawable(mPendingOverflowIcon);
          mPendingOverflowIcon = null;
          mPendingOverflowIconSet = false;
        }
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        mOverflowButton.measure(j, j);
      }
      i -= mOverflowButton.getMeasuredWidth();
    }
    else
    {
      mOverflowButton = null;
    }
    mActionItemWidthLimit = i;
    mMinCellSize = ((int)(getDisplayMetricsdensity * 56.0F));
  }
  
  public boolean isOverflowMenuShowPending()
  {
    return (mPostedOpenRunnable != null) || (isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing()
  {
    OverflowPopup localOverflowPopup = mOverflowPopup;
    return (localOverflowPopup != null) && (localOverflowPopup.isShowing());
  }
  
  public void onConfigurationChanged()
  {
    mMaxItems = ActionBarPolicy.get(mContext).init();
    MenuBuilder localMenuBuilder = mMenu;
    if (localMenuBuilder != null) {
      localMenuBuilder.onItemsChanged(true);
    }
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    if (!paramSubMenuBuilder.hasVisibleItems()) {
      return false;
    }
    for (Object localObject = paramSubMenuBuilder; ((SubMenuBuilder)localObject).getParentMenu() != mMenu; localObject = (SubMenuBuilder)((SubMenuBuilder)localObject).getParentMenu()) {}
    localObject = findViewForItem(((SubMenuBuilder)localObject).getItem());
    if (localObject == null) {
      return false;
    }
    ((org.v7.view.menu.MenuItemImpl)paramSubMenuBuilder.getItem()).getItemId();
    boolean bool2 = false;
    int j = paramSubMenuBuilder.size();
    int i = 0;
    boolean bool1;
    for (;;)
    {
      bool1 = bool2;
      if (i >= j) {
        break;
      }
      MenuItem localMenuItem = paramSubMenuBuilder.getItem(i);
      if ((localMenuItem.isVisible()) && (localMenuItem.getIcon() != null))
      {
        bool1 = true;
        break;
      }
      i += 1;
    }
    localObject = new ActionButtonSubmenu(mContext, paramSubMenuBuilder, (View)localObject);
    mActionButtonPopup = ((ActionButtonSubmenu)localObject);
    ((i)localObject).a(bool1);
    mActionButtonPopup.show();
    super.onSubMenuSelected(paramSubMenuBuilder);
    return true;
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean)
  {
    mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView)
  {
    mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable)
  {
    OverflowMenuButton localOverflowMenuButton = mOverflowButton;
    if (localOverflowMenuButton != null)
    {
      localOverflowMenuButton.setImageDrawable(paramDrawable);
      return;
    }
    mPendingOverflowIconSet = true;
    mPendingOverflowIcon = paramDrawable;
  }
  
  public void setReserveOverflow(boolean paramBoolean)
  {
    mReserveOverflow = paramBoolean;
    mReserveOverflowSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, org.v7.view.menu.MenuItemImpl paramMenuItemImpl)
  {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu()
  {
    if ((mReserveOverflow) && (!isOverflowMenuShowing()))
    {
      Object localObject = mMenu;
      if ((localObject != null) && (mMenuView != null) && (mPostedOpenRunnable == null) && (!((MenuBuilder)localObject).getNonActionItems().isEmpty()))
      {
        localObject = new OpenOverflowRunnable(new OverflowPopup(mContext, mMenu, mOverflowButton, true));
        mPostedOpenRunnable = ((OpenOverflowRunnable)localObject);
        ((View)mMenuView).post((Runnable)localObject);
        return true;
      }
    }
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    super.updateMenuView(paramBoolean);
    ((View)mMenuView).requestLayout();
    Object localObject1 = mMenu;
    Object localObject2;
    if (localObject1 != null)
    {
      localObject1 = ((MenuBuilder)localObject1).getActionItems();
      j = ((ArrayList)localObject1).size();
      i = 0;
      while (i < j)
      {
        localObject2 = ((org.v7.view.menu.MenuItemImpl)((ArrayList)localObject1).get(i)).getSupportActionProvider();
        if (localObject2 != null) {
          ((ActionProvider)localObject2).setSubUiVisibilityListener(this);
        }
        i += 1;
      }
    }
    localObject1 = mMenu;
    if (localObject1 != null) {
      localObject1 = ((MenuBuilder)localObject1).getNonActionItems();
    } else {
      localObject1 = null;
    }
    int j = 0;
    int i = j;
    boolean bool;
    if (mReserveOverflow)
    {
      i = j;
      if (localObject1 != null)
      {
        j = ((ArrayList)localObject1).size();
        i = 0;
        if (j == 1) {
          bool = ((org.v7.view.menu.MenuItemImpl)((ArrayList)localObject1).get(0)).isActionViewExpanded() ^ true;
        } else if (j > 0) {
          bool = true;
        }
      }
    }
    if (bool)
    {
      if (mOverflowButton == null) {
        mOverflowButton = new OverflowMenuButton(mSystemContext);
      }
      localObject1 = (ViewGroup)mOverflowButton.getParent();
      if (localObject1 != mMenuView)
      {
        if (localObject1 != null) {
          ((ViewGroup)localObject1).removeView(mOverflowButton);
        }
        localObject1 = (ActionMenuView)mMenuView;
        ((ViewGroup)localObject1).addView(mOverflowButton, ((ActionMenuView)localObject1).generateOverflowButtonLayoutParams());
      }
    }
    else
    {
      localObject1 = mOverflowButton;
      if (localObject1 != null)
      {
        localObject1 = ((View)localObject1).getParent();
        localObject2 = mMenuView;
        if (localObject1 == localObject2) {
          ((ViewGroup)localObject2).removeView(mOverflowButton);
        }
      }
    }
    ((ActionMenuView)mMenuView).setOverflowReserved(mReserveOverflow);
  }
  
  public class ActionButtonSubmenu
    extends i
  {
    public ActionButtonSubmenu(Context paramContext, SubMenuBuilder paramSubMenuBuilder, View paramView)
    {
      super(paramSubMenuBuilder, paramView, false, R.attr.actionOverflowMenuStyle);
      if (!((org.v7.view.menu.MenuItemImpl)paramSubMenuBuilder.getItem()).isActionButton())
      {
        paramSubMenuBuilder = mOverflowButton;
        paramContext = paramSubMenuBuilder;
        if (paramSubMenuBuilder == null) {
          paramContext = (View)ActionMenuPresenter.getMenuView(ActionMenuPresenter.this);
        }
        a(paramContext);
      }
      a(mPopupPresenterCallback);
    }
    
    public void onDismiss()
    {
      ActionMenuPresenter localActionMenuPresenter = ActionMenuPresenter.this;
      mActionButtonPopup = null;
      mOpenSubMenuId = 0;
      super.onDismiss();
    }
  }
  
  public class ActionMenuPopupCallback
    extends ActionMenuItemView.b
  {
    public ActionMenuPopupCallback() {}
    
    public ListPopupWindow getPopup()
    {
      ActionMenuPresenter.ActionButtonSubmenu localActionButtonSubmenu = mActionButtonPopup;
      if (localActionButtonSubmenu != null) {
        return localActionButtonSubmenu.b();
      }
      return null;
    }
  }
  
  public class OpenOverflowRunnable
    implements Runnable
  {
    public ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup paramOverflowPopup)
    {
      mPopup = paramOverflowPopup;
    }
    
    public void run()
    {
      if (ActionMenuPresenter.access$setMOverflowPopup(ActionMenuPresenter.this) != null) {
        ActionMenuPresenter.access$getMMenu(ActionMenuPresenter.this).changeMenuMode();
      }
      View localView = (View)ActionMenuPresenter.access$getMMenuView(ActionMenuPresenter.this);
      if ((localView != null) && (localView.getWindowToken() != null) && (mPopup.add())) {
        mOverflowPopup = mPopup;
      }
      mPostedOpenRunnable = null;
    }
  }
  
  public class OverflowMenuButton
    extends AppCompatImageView
    implements ActionMenuView.a
  {
    public OverflowMenuButton(Context paramContext)
    {
      super(null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      MenuItemImpl.setText(this, getContentDescription());
      setOnTouchListener(new c.d.a(this, this, ActionMenuPresenter.this));
    }
    
    public boolean needsDividerAfter()
    {
      return false;
    }
    
    public boolean needsDividerBefore()
    {
      return false;
    }
    
    public boolean performClick()
    {
      if (super.performClick()) {
        return true;
      }
      playSoundEffect(0);
      showOverflowMenu();
      return true;
    }
    
    public boolean setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      boolean bool = super.setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
      Drawable localDrawable1 = getDrawable();
      Drawable localDrawable2 = getBackground();
      if ((localDrawable1 != null) && (localDrawable2 != null))
      {
        int i = getWidth();
        paramInt2 = getHeight();
        paramInt1 = Math.max(i, paramInt2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        paramInt3 = getPaddingTop();
        paramInt4 = getPaddingBottom();
        i = (i + (j - k)) / 2;
        paramInt2 = (paramInt2 + (paramInt3 - paramInt4)) / 2;
        DrawableCompat.setHotspotBounds(localDrawable2, i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1);
      }
      return bool;
    }
  }
  
  public class OverflowPopup
    extends i
  {
    public OverflowPopup(Context paramContext, MenuBuilder paramMenuBuilder, View paramView, boolean paramBoolean)
    {
      super(paramMenuBuilder, paramView, paramBoolean, R.attr.actionOverflowMenuStyle);
      b(8388613);
      a(mPopupPresenterCallback);
    }
    
    public void onDismiss()
    {
      if (ActionMenuPresenter.access$setMActionButtonPopup(ActionMenuPresenter.this) != null) {
        ActionMenuPresenter.access$setMDialog(ActionMenuPresenter.this).close();
      }
      mOverflowPopup = null;
      super.onDismiss();
    }
  }
  
  public class PopupPresenterCallback
    implements l.a
  {
    public PopupPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      if ((paramMenuBuilder instanceof SubMenuBuilder)) {
        paramMenuBuilder.getRootMenu().close(false);
      }
      l.a localA = getCallback();
      if (localA != null) {
        localA.onCloseMenu(paramMenuBuilder, paramBoolean);
      }
    }
    
    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      if (paramMenuBuilder == ActionMenuPresenter.access$getMOverflowPopup(ActionMenuPresenter.this)) {
        return false;
      }
      mOpenSubMenuId = ((org.v7.view.menu.MenuItemImpl)((SubMenuBuilder)paramMenuBuilder).getItem()).getItemId();
      l.a localA = getCallback();
      if (localA != null) {
        return localA.onOpenSubMenu(paramMenuBuilder);
      }
      return false;
    }
  }
}
