package org.v7.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ToggleButton;

public class DisplayDimensions
  extends ToggleButton
{
  public final TimePicker a;
  
  public DisplayDimensions(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16842827);
  }
  
  public DisplayDimensions(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    ThemeUtils.init(this, getContext());
    paramContext = new TimePicker(this);
    a = paramContext;
    paramContext.init(paramAttributeSet, paramInt);
  }
}
