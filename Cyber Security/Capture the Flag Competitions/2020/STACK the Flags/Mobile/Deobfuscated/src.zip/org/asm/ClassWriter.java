package org.asm;

import android.graphics.PointF;
import android.view.View;

public class ClassWriter
{
  public int b;
  public int c;
  public int h;
  public View i;
  public int j;
  public int w;
  public int x;
  
  public ClassWriter(View paramView)
  {
    i = paramView;
  }
  
  public final void a()
  {
    Log.set(i, h, j, w, x);
    c = 0;
    b = 0;
  }
  
  public void a(PointF paramPointF)
  {
    h = Math.round(x);
    j = Math.round(y);
    int k = c + 1;
    c = k;
    if (k == b) {
      a();
    }
  }
  
  public void b(PointF paramPointF)
  {
    w = Math.round(x);
    x = Math.round(y);
    int k = b + 1;
    b = k;
    if (c == k) {
      a();
    }
  }
}
