package org.asm;

import android.graphics.Rect;

public class Response
  extends Message
{
  public Response(a paramA, Rect paramRect) {}
}
