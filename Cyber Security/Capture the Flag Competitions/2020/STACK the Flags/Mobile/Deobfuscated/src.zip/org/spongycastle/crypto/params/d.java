package org.spongycastle.crypto.params;

import a.c.a.b.b.c;
import a.c.a.b.b.f;
import java.util.Iterator;
import java.util.Map.Entry;

public class d
  implements Iterator<Map.Entry<K, V>>, b.f<K, V>
{
  public b.c<K, V> a;
  public boolean e = true;
  
  public d(f paramF) {}
  
  public Map.Entry c()
  {
    if (e)
    {
      e = false;
      a = d.a;
    }
    else
    {
      Attribute localAttribute = a;
      if (localAttribute != null) {
        localAttribute = a;
      } else {
        localAttribute = null;
      }
      a = localAttribute;
    }
    return a;
  }
  
  public boolean hasNext()
  {
    if (e) {
      return d.a != null;
    }
    Attribute localAttribute = a;
    return (localAttribute != null) && (a != null);
  }
  
  public void init(Attribute paramAttribute)
  {
    Attribute localAttribute = a;
    if (paramAttribute == localAttribute)
    {
      paramAttribute = b;
      a = paramAttribute;
      boolean bool;
      if (paramAttribute == null) {
        bool = true;
      } else {
        bool = false;
      }
      e = bool;
    }
  }
}
