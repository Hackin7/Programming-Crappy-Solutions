package org.asm;

import android.animation.AnimatorListenerAdapter;

public class LayoutManager
  extends AnimatorListenerAdapter
{
  public ClassWriter mViewBounds = b;
  
  public LayoutManager(f paramF, ClassWriter paramClassWriter) {}
}
