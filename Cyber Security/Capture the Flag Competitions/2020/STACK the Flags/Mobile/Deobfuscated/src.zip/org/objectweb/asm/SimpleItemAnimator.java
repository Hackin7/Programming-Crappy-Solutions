package org.objectweb.asm;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView.b0;
import androidx.recyclerview.widget.RecyclerView.l;
import androidx.recyclerview.widget.RecyclerView.l.c;

public abstract class SimpleItemAnimator
  extends RecyclerView.l
{
  public boolean mSupportsChangeAnimations = true;
  
  public SimpleItemAnimator() {}
  
  public abstract boolean animateChange(RecyclerView.b0 paramB0);
  
  public abstract boolean animateChange(RecyclerView.b0 paramB01, RecyclerView.b0 paramB02, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public boolean animateChange(RecyclerView.b0 paramB01, RecyclerView.b0 paramB02, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
  {
    int k = left;
    int m = top;
    int i;
    int j;
    if (paramB02.shouldIgnore())
    {
      i = left;
      j = top;
    }
    else
    {
      i = left;
      j = top;
    }
    return animateChange(paramB01, paramB02, k, m, i, j);
  }
  
  public boolean animateChange(RecyclerView.b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
  {
    if ((paramC1 != null) && ((left != left) || (top != top))) {
      return animateMove(paramB0, left, top, left, top);
    }
    animateChange(paramB0);
    return true;
  }
  
  public boolean animateDisappearance(RecyclerView.b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
  {
    int k = left;
    int m = top;
    paramC1 = itemView;
    int i;
    if (paramC2 == null) {
      i = paramC1.getLeft();
    } else {
      i = left;
    }
    int j;
    if (paramC2 == null) {
      j = paramC1.getTop();
    } else {
      j = top;
    }
    if ((!paramB0.isRemoved()) && ((k != i) || (m != j)))
    {
      paramC1.layout(i, j, paramC1.getWidth() + i, paramC1.getHeight() + j);
      return animateMove(paramB0, k, m, i, j);
    }
    animateRemove(paramB0);
    return true;
  }
  
  public abstract boolean animateMove(RecyclerView.b0 paramB0, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public boolean animatePersistence(RecyclerView.b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
  {
    if ((left == left) && (top == top))
    {
      dispatchMoveFinished(paramB0);
      return false;
    }
    return animateMove(paramB0, left, top, left, top);
  }
  
  public abstract boolean animateRemove(RecyclerView.b0 paramB0);
  
  public boolean canReuseUpdatedViewHolder(RecyclerView.b0 paramB0)
  {
    return (!mSupportsChangeAnimations) || (paramB0.isInvalid());
  }
  
  public final void dispatchAddFinished(RecyclerView.b0 paramB0)
  {
    onAddFinished();
    dispatchAnimationFinished(paramB0);
  }
  
  public final void dispatchAddStarting(RecyclerView.b0 paramB0)
  {
    onAddStarting();
  }
  
  public final void dispatchChangeFinished(RecyclerView.b0 paramB0, boolean paramBoolean)
  {
    onChangeFinished();
    dispatchAnimationFinished(paramB0);
  }
  
  public final void dispatchChangeStarting(RecyclerView.b0 paramB0, boolean paramBoolean)
  {
    onChangeStarting();
  }
  
  public final void dispatchMoveFinished(RecyclerView.b0 paramB0)
  {
    onMoveFinished();
    dispatchAnimationFinished(paramB0);
  }
  
  public final void dispatchMoveStarting(RecyclerView.b0 paramB0)
  {
    onMoveStarting();
  }
  
  public final void dispatchRemoveFinished(RecyclerView.b0 paramB0)
  {
    onRemoveFinished();
    dispatchAnimationFinished(paramB0);
  }
  
  public final void dispatchRemoveStarting(RecyclerView.b0 paramB0)
  {
    onRemoveStarting();
  }
  
  public void onAddFinished() {}
  
  public void onAddStarting() {}
  
  public void onChangeFinished() {}
  
  public void onChangeStarting() {}
  
  public void onMoveFinished() {}
  
  public void onMoveStarting() {}
  
  public void onRemoveFinished() {}
  
  public void onRemoveStarting() {}
}
