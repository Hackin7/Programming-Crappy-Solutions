package org.v7.app;

@Deprecated
public abstract class FragmentTransaction
{
  public FragmentTransaction() {}
  
  public abstract void replace();
}
