package org.codehaus.asm.asm.asm;

import a.f.b.i.m.d;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Label
  implements l
{
  public List<a.f.b.i.m.f> a = new ArrayList();
  public h b;
  public boolean c = false;
  public int d;
  public boolean e = false;
  public List<d> f = new ArrayList();
  public MathArrays.OrderDirection g = MathArrays.OrderDirection.INCREASING;
  public int h = 1;
  public boolean i = false;
  public int j;
  public l k = null;
  public c x = null;
  
  public Label(h paramH)
  {
    b = paramH;
  }
  
  public void a()
  {
    a.clear();
    f.clear();
    c = false;
    d = 0;
    e = false;
    i = false;
  }
  
  public void a(int paramInt)
  {
    if (c) {
      return;
    }
    c = true;
    d = paramInt;
    Iterator localIterator = f.iterator();
    while (localIterator.hasNext())
    {
      l localL = (l)localIterator.next();
      localL.a(localL);
    }
  }
  
  public void a(l paramL)
  {
    paramL = a.iterator();
    while (paramL.hasNext()) {
      if (!nextc) {
        return;
      }
    }
    e = true;
    paramL = k;
    if (paramL != null) {
      paramL.a(this);
    }
    if (i)
    {
      b.a(this);
      return;
    }
    paramL = null;
    int m = 0;
    Iterator localIterator = a.iterator();
    Object localObject;
    while (localIterator.hasNext())
    {
      localObject = (Label)localIterator.next();
      if (!(localObject instanceof c))
      {
        paramL = (l)localObject;
        m += 1;
      }
    }
    if ((paramL != null) && (m == 1) && (c))
    {
      localObject = x;
      if (localObject != null) {
        if (c) {
          j = (h * d);
        } else {
          return;
        }
      }
      a(d + j);
    }
    paramL = k;
    if (paramL != null) {
      paramL.a(this);
    }
  }
  
  public void b(l paramL)
  {
    f.add(paramL);
    if (c) {
      paramL.a(paramL);
    }
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(b.b.getString());
    localStringBuilder.append(":");
    localStringBuilder.append(g);
    localStringBuilder.append("(");
    Object localObject;
    if (c) {
      localObject = Integer.valueOf(d);
    } else {
      localObject = "unresolved";
    }
    localStringBuilder.append(localObject);
    localStringBuilder.append(") <t=");
    localStringBuilder.append(a.size());
    localStringBuilder.append(":d=");
    localStringBuilder.append(f.size());
    localStringBuilder.append(">");
    return localStringBuilder.toString();
  }
}
