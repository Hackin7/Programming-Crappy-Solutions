package org.greendroid.graphics.drawable;

public abstract class Series
{
  public Series() {}
  
  public boolean draw()
  {
    return false;
  }
  
  public boolean draw(int[] paramArrayOfInt)
  {
    return false;
  }
}
