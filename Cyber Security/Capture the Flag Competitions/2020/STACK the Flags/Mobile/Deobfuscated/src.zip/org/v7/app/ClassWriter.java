package org.v7.app;

import android.content.res.Resources;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.LongSparseArray;
import java.lang.reflect.Field;
import java.util.Map;

public class ClassWriter
{
  public static boolean a;
  public static Field b;
  public static Class<?> c;
  public static boolean e;
  public static boolean f;
  public static Field h;
  public static boolean i;
  public static Field x;
  
  public static void a(Resources paramResources)
  {
    int j = Build.VERSION.SDK_INT;
    if (j >= 28) {
      return;
    }
    if (j >= 24)
    {
      b(paramResources);
      return;
    }
    if (j >= 23)
    {
      c(paramResources);
      return;
    }
    init(paramResources);
  }
  
  public static void a(Object paramObject)
  {
    if (!a)
    {
      try
      {
        Class localClass = Class.forName("android.content.res.ThemedResourceCache");
        c = localClass;
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", localClassNotFoundException);
      }
      a = true;
    }
    Object localObject1 = c;
    if (localObject1 == null) {
      return;
    }
    if (!f)
    {
      try
      {
        localObject1 = ((Class)localObject1).getDeclaredField("mUnthemedEntries");
        b = (Field)localObject1;
        ((Field)localObject1).setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", localNoSuchFieldException);
      }
      f = true;
    }
    Field localField = b;
    if (localField == null) {
      return;
    }
    Object localObject2 = null;
    try
    {
      paramObject = localField.get(paramObject);
      paramObject = (LongSparseArray)paramObject;
    }
    catch (IllegalAccessException paramObject)
    {
      Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", paramObject);
      paramObject = localObject2;
    }
    if (paramObject != null) {
      paramObject.clear();
    }
  }
  
  public static void b(Resources paramResources)
  {
    if (!i)
    {
      try
      {
        Field localField1 = Resources.class.getDeclaredField("mResourcesImpl");
        h = localField1;
        localField1.setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException1)
      {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", localNoSuchFieldException1);
      }
      i = true;
    }
    Field localField3 = h;
    if (localField3 == null) {
      return;
    }
    Field localField2 = null;
    try
    {
      paramResources = localField3.get(paramResources);
    }
    catch (IllegalAccessException paramResources)
    {
      Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", paramResources);
      paramResources = localField2;
    }
    if (paramResources == null) {
      return;
    }
    if (!e)
    {
      try
      {
        localField2 = paramResources.getClass().getDeclaredField("mDrawableCache");
        x = localField2;
        localField2.setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException2)
      {
        Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", localNoSuchFieldException2);
      }
      e = true;
    }
    localField3 = null;
    Field localField4 = x;
    Object localObject = localField3;
    if (localField4 != null) {
      try
      {
        localObject = localField4.get(paramResources);
      }
      catch (IllegalAccessException paramResources)
      {
        Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", paramResources);
        localObject = localField3;
      }
    }
    if (localObject != null) {
      a(localObject);
    }
  }
  
  public static void c(Resources paramResources)
  {
    if (!e)
    {
      try
      {
        Field localField1 = Resources.class.getDeclaredField("mDrawableCache");
        x = localField1;
        localField1.setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", localNoSuchFieldException);
      }
      e = true;
    }
    Object localObject2 = null;
    Field localField2 = x;
    Object localObject1 = localObject2;
    if (localField2 != null) {
      try
      {
        localObject1 = localField2.get(paramResources);
      }
      catch (IllegalAccessException paramResources)
      {
        Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", paramResources);
        localObject1 = localObject2;
      }
    }
    if (localObject1 == null) {
      return;
    }
    a(localObject1);
  }
  
  public static void init(Resources paramResources)
  {
    if (!e)
    {
      try
      {
        Field localField1 = Resources.class.getDeclaredField("mDrawableCache");
        x = localField1;
        localField1.setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", localNoSuchFieldException);
      }
      e = true;
    }
    Field localField2 = x;
    if (localField2 != null)
    {
      Object localObject = null;
      try
      {
        paramResources = localField2.get(paramResources);
        paramResources = (Map)paramResources;
      }
      catch (IllegalAccessException paramResources)
      {
        Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", paramResources);
        paramResources = localObject;
      }
      if (paramResources != null) {
        paramResources.clear();
      }
    }
  }
}
