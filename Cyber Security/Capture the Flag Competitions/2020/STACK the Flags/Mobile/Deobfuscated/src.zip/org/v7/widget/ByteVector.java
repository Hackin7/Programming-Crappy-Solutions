package org.v7.widget;

import android.view.MenuItem;
import org.v7.view.menu.MenuBuilder;

public abstract interface ByteVector
{
  public abstract void a(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem);
  
  public abstract void b(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem);
}
