package org.spongycastle.crypto.util;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class NamedThreadFactory
  implements ThreadFactory
{
  public final AtomicInteger threadNumber = new AtomicInteger(0);
  
  public NamedThreadFactory(DiskLruCache paramDiskLruCache) {}
  
  public Thread newThread(Runnable paramRunnable)
  {
    paramRunnable = new Thread(paramRunnable);
    paramRunnable.setName(String.format("arch_disk_io_%d", new Object[] { Integer.valueOf(threadNumber.getAndIncrement()) }));
    return paramRunnable;
  }
}
