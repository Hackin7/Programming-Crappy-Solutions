package org.util;

@Deprecated
public abstract interface LruCache
  extends d
{
  public abstract f getLifecycle();
}
