package org.util;

public abstract interface Canvas
{
  public abstract void delete();
  
  public abstract void destroy();
  
  public abstract void visitParameter();
}
