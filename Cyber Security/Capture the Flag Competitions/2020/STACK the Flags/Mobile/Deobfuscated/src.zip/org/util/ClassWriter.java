package org.util;

import a.m.a.a;
import a.m.d.a;
import a.m.g;
import a.m.n;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ClassWriter
{
  public static ClassWriter b = new ClassWriter();
  public final Map<Class, Boolean> a = new HashMap();
  public final Map<Class, a.a> c = new HashMap();
  
  public ClassWriter() {}
  
  public boolean a(Class paramClass)
  {
    Object localObject = (Boolean)a.get(paramClass);
    if (localObject != null) {
      return ((Boolean)localObject).booleanValue();
    }
    localObject = getMethod(paramClass);
    int j = localObject.length;
    int i = 0;
    while (i < j)
    {
      if ((Type)localObject[i].getAnnotation(n.class) != null)
      {
        get(paramClass, (Method[])localObject);
        return true;
      }
      i += 1;
    }
    a.put(paramClass, Boolean.valueOf(false));
    return false;
  }
  
  public Item get(Class paramClass)
  {
    Item localItem = (Item)c.get(paramClass);
    if (localItem != null) {
      return localItem;
    }
    return get(paramClass, null);
  }
  
  public final Item get(Class paramClass, Method[] paramArrayOfMethod)
  {
    Object localObject1 = paramClass.getSuperclass();
    HashMap localHashMap = new HashMap();
    if (localObject1 != null)
    {
      localObject1 = get((Class)localObject1);
      if (localObject1 != null) {
        localHashMap.putAll(properties);
      }
    }
    localObject1 = paramClass.getInterfaces();
    int j = localObject1.length;
    int i = 0;
    Object localObject2;
    Object localObject3;
    while (i < j)
    {
      localObject2 = getproperties.entrySet().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (Map.Entry)((Iterator)localObject2).next();
        get(localHashMap, (Matrix)((Map.Entry)localObject3).getKey(), (Scope)((Map.Entry)localObject3).getValue(), paramClass);
      }
      i += 1;
    }
    if (paramArrayOfMethod == null) {
      paramArrayOfMethod = getMethod(paramClass);
    }
    boolean bool = false;
    int k = paramArrayOfMethod.length;
    j = 0;
    while (j < k)
    {
      localObject1 = paramArrayOfMethod[j];
      localObject3 = (Type)((Method)localObject1).getAnnotation(n.class);
      if (localObject3 != null)
      {
        bool = true;
        localObject2 = ((Method)localObject1).getParameterTypes();
        i = 0;
        if (localObject2.length > 0)
        {
          i = 1;
          if (!localObject2[0].isAssignableFrom(g.class)) {
            throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
          }
        }
        localObject3 = ((Type)localObject3).value();
        if (localObject2.length > 1)
        {
          i = 2;
          if (localObject2[1].isAssignableFrom(d.a.class))
          {
            if (localObject3 != Scope.ON_ANY) {
              throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
            }
          }
          else {
            throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
          }
        }
        if (localObject2.length <= 2) {
          get(localHashMap, new Matrix(i, (Method)localObject1), (Scope)localObject3, paramClass);
        }
      }
      else
      {
        j += 1;
        continue;
      }
      throw new IllegalArgumentException("cannot have more than 2 params");
    }
    paramArrayOfMethod = new Item(localHashMap);
    c.put(paramClass, paramArrayOfMethod);
    a.put(paramClass, Boolean.valueOf(bool));
    return paramArrayOfMethod;
  }
  
  public final void get(Map paramMap, Matrix paramMatrix, Scope paramScope, Class paramClass)
  {
    Scope localScope = (Scope)paramMap.get(paramMatrix);
    if ((localScope != null) && (paramScope != localScope))
    {
      paramMap = c;
      paramMatrix = new StringBuilder();
      paramMatrix.append("Method ");
      paramMatrix.append(paramMap.getName());
      paramMatrix.append(" in ");
      paramMatrix.append(paramClass.getName());
      paramMatrix.append(" already declared with different @OnLifecycleEvent value: previous value ");
      paramMatrix.append(localScope);
      paramMatrix.append(", new value ");
      paramMatrix.append(paramScope);
      throw new IllegalArgumentException(paramMatrix.toString());
    }
    if (localScope == null) {
      paramMap.put(paramMatrix, paramScope);
    }
  }
  
  public final Method[] getMethod(Class paramClass)
  {
    try
    {
      paramClass = paramClass.getDeclaredMethods();
      return paramClass;
    }
    catch (NoClassDefFoundError paramClass)
    {
      throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", paramClass);
    }
  }
}
