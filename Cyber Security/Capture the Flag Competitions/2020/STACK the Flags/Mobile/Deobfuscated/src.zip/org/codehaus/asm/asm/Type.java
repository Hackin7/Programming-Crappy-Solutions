package org.codehaus.asm.asm;

import org.codehaus.asm.asm.asm.a;

public class Type
  extends m
{
  public boolean _isArray = false;
  
  public Type()
  {
    new a();
  }
  
  public void a()
  {
    int i = 0;
    while (i < c)
    {
      f localF = b[i];
      if (localF != null) {
        localF.e(true);
      }
      i += 1;
    }
  }
  
  public void a(MethodWriter paramMethodWriter)
  {
    a();
  }
  
  public boolean isArray()
  {
    return _isArray;
  }
}
