package org.codehaus.asm;

public abstract interface ByteVector
{
  public abstract float a(Label paramLabel, boolean paramBoolean);
  
  public abstract float a(h paramH, boolean paramBoolean);
  
  public abstract Label a(int paramInt);
  
  public abstract void a();
  
  public abstract void a(float paramFloat);
  
  public abstract void a(Label paramLabel, float paramFloat);
  
  public abstract void a(Label paramLabel, float paramFloat, boolean paramBoolean);
  
  public abstract boolean a(Label paramLabel);
  
  public abstract float b(int paramInt);
  
  public abstract float b(Label paramLabel);
  
  public abstract void clear();
  
  public abstract int size();
}
