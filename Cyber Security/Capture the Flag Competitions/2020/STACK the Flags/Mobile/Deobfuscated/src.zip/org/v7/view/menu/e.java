package org.v7.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.view.menu.ExpandedMenuView;
import java.util.ArrayList;
import org.v7.R.layout;

public class e
  implements l, AdapterView.OnItemClickListener
{
  public Context a;
  public LayoutInflater b;
  public MenuBuilder c;
  public ExpandedMenuView d;
  public int e;
  public int f;
  public a g;
  public l.a k;
  public int l;
  
  public e(int paramInt1, int paramInt2)
  {
    f = paramInt1;
    e = paramInt2;
  }
  
  public e(Context paramContext, int paramInt)
  {
    this(paramInt, 0);
    a = paramContext;
    b = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a()
  {
    if (g == null) {
      g = new a();
    }
    return g;
  }
  
  public void a(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    l.a localA = k;
    if (localA != null) {
      localA.onCloseMenu(paramMenuBuilder, paramBoolean);
    }
  }
  
  public boolean collapseItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public boolean expandItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
  {
    return false;
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    if (d == null)
    {
      d = ((ExpandedMenuView)b.inflate(R.layout.abc_expanded_menu_layout, paramViewGroup, false));
      if (g == null) {
        g = new a();
      }
      d.setAdapter(g);
      d.setOnItemClickListener(this);
    }
    return d;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
  {
    if (e != 0)
    {
      paramContext = new ContextThemeWrapper(paramContext, e);
      a = paramContext;
      b = LayoutInflater.from(paramContext);
    }
    else if (a != null)
    {
      a = paramContext;
      if (b == null) {
        b = LayoutInflater.from(paramContext);
      }
    }
    c = paramMenuBuilder;
    paramContext = g;
    if (paramContext != null) {
      paramContext.notifyDataSetChanged();
    }
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    c.performItemAction(g.a(paramInt), this, 0);
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    if (!paramSubMenuBuilder.hasVisibleItems()) {
      return false;
    }
    new MenuDialogHelper(paramSubMenuBuilder).show(null);
    l.a localA = k;
    if (localA != null) {
      localA.onOpenSubMenu(paramSubMenuBuilder);
    }
    return true;
  }
  
  public void setCallback(l.a paramA)
  {
    k = paramA;
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    a localA = g;
    if (localA != null) {
      localA.notifyDataSetChanged();
    }
  }
  
  public class a
    extends BaseAdapter
  {
    public int b = -1;
    
    public a()
    {
      a();
    }
    
    public MenuItemImpl a(int paramInt)
    {
      ArrayList localArrayList = c.getNonActionItems();
      int i = paramInt + l;
      int j = b;
      paramInt = i;
      if (j >= 0)
      {
        paramInt = i;
        if (i >= j) {
          paramInt = i + 1;
        }
      }
      return (MenuItemImpl)localArrayList.get(paramInt);
    }
    
    public void a()
    {
      MenuItemImpl localMenuItemImpl = c.getExpandedItem();
      if (localMenuItemImpl != null)
      {
        ArrayList localArrayList = c.getNonActionItems();
        int j = localArrayList.size();
        int i = 0;
        while (i < j)
        {
          if ((MenuItemImpl)localArrayList.get(i) == localMenuItemImpl)
          {
            b = i;
            return;
          }
          i += 1;
        }
      }
      b = -1;
    }
    
    public int getCount()
    {
      int i = c.getNonActionItems().size() - l;
      if (b < 0) {
        return i;
      }
      return i - 1;
    }
    
    public long getItemId(int paramInt)
    {
      return paramInt;
    }
    
    public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      View localView = paramView;
      if (paramView == null)
      {
        paramView = e.this;
        localView = b.inflate(f, paramViewGroup, false);
      }
      ((MenuView.ItemView)localView).initialize(a(paramInt), 0);
      return localView;
    }
    
    public void notifyDataSetChanged()
    {
      a();
      super.notifyDataSetChanged();
    }
  }
}
