package org.asm;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

public class q
  extends g
{
  public q(int paramInt)
  {
    b(paramInt);
  }
  
  public static float a(Label paramLabel, float paramFloat)
  {
    float f = paramFloat;
    if (paramLabel != null)
    {
      paramLabel = (Float)c.get("android:fade:transitionAlpha");
      f = paramFloat;
      if (paramLabel != null) {
        f = paramLabel.floatValue();
      }
    }
    return f;
  }
  
  public final Animator a(View paramView, float paramFloat1, float paramFloat2)
  {
    if (paramFloat1 == paramFloat2) {
      return null;
    }
    Log.put(paramView, paramFloat1);
    ObjectAnimator localObjectAnimator = ObjectAnimator.ofFloat(paramView, Log.v, new float[] { paramFloat2 });
    localObjectAnimator.addListener(new AbsActionBarView.VisibilityAnimListener(paramView));
    a(new t(this, paramView));
    return localObjectAnimator;
  }
  
  public Animator a(ViewGroup paramViewGroup, View paramView, Label paramLabel1, Label paramLabel2)
  {
    float f2 = a(paramLabel1, 0.0F);
    float f1 = f2;
    if (f2 == 1.0F) {
      f1 = 0.0F;
    }
    return a(paramView, f1, 1.0F);
  }
  
  public void a(Label paramLabel)
  {
    super.a(paramLabel);
    c.put("android:fade:transitionAlpha", Float.valueOf(Log.set(a)));
  }
  
  public Animator b(ViewGroup paramViewGroup, View paramView, Label paramLabel1, Label paramLabel2)
  {
    Log.e(paramView);
    return a(paramView, a(paramLabel1, 1.0F), 0.0F);
  }
}
