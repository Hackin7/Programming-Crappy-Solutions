package org.v7.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import org.v7.R.styleable;
import org.v7.view.ActionMode;
import org.v7.view.ActionMode.Callback;

public abstract class ActionBar
{
  public ActionBar() {}
  
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean collapseActionView();
  
  public abstract int getDisplayOptions();
  
  public abstract Context getThemedContext();
  
  public boolean invalidateOptionsMenu()
  {
    return false;
  }
  
  public boolean isShowing()
  {
    return false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {}
  
  public void onDestroy() {}
  
  public abstract boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent);
  
  public boolean onKeyShortcut(KeyEvent paramKeyEvent)
  {
    return false;
  }
  
  public boolean openOptionsMenu()
  {
    return false;
  }
  
  public abstract void setDefaultDisplayHomeAsUpEnabled(boolean paramBoolean);
  
  public abstract void setShowHideAnimationEnabled(boolean paramBoolean);
  
  public abstract void setWindowTitle(CharSequence paramCharSequence);
  
  public ActionMode startActionMode(ActionMode.Callback paramCallback)
  {
    return null;
  }
  
  public class LayoutParams
    extends ViewGroup.MarginLayoutParams
  {
    public int gravity = 0;
    
    public LayoutParams(int paramInt)
    {
      super(paramInt);
      gravity = 8388627;
    }
    
    public LayoutParams(AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      this$1 = this$1.obtainStyledAttributes(paramAttributeSet, R.styleable.ActionBarLayout);
      gravity = this$1.getInt(R.styleable.ActionBarLayout_android_layout_gravity, 0);
      this$1.recycle();
    }
    
    public LayoutParams()
    {
      super();
    }
    
    public LayoutParams()
    {
      super();
      gravity = gravity;
    }
  }
}
