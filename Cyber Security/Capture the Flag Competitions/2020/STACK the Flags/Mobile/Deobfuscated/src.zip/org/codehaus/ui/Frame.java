package org.codehaus.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

public class Frame
{
  public int a = 0;
  public boolean e = false;
  public float h = NaN.0F;
  public int i = 0;
  public float w = 1.0F;
  
  public Frame() {}
  
  public void a(Context paramContext, AttributeSet paramAttributeSet)
  {
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.PropertySet);
    e = true;
    int k = paramContext.getIndexCount();
    int j = 0;
    while (j < k)
    {
      int m = paramContext.getIndex(j);
      if (m == IpAddress.PropertySet_android_alpha)
      {
        w = paramContext.getFloat(m, w);
      }
      else if (m == IpAddress.PropertySet_android_visibility)
      {
        a = paramContext.getInt(m, a);
        a = Item.a()[a];
      }
      else if (m == IpAddress.PropertySet_visibilityMode)
      {
        i = paramContext.getInt(m, i);
      }
      else if (m == IpAddress.PropertySet_motionProgress)
      {
        h = paramContext.getFloat(m, h);
      }
      j += 1;
    }
    paramContext.recycle();
  }
  
  public void a(Frame paramFrame)
  {
    e = e;
    a = a;
    w = w;
    h = h;
    i = i;
  }
}
