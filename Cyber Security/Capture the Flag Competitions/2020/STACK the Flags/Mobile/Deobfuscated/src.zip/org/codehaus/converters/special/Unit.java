package org.codehaus.converters.special;

public class Unit
{
  public static String[] type = { "standard", "accelerate", "decelerate", "linear" };
  public String name = "identity";
  
  static
  {
    new Unit();
  }
  
  public Unit() {}
  
  public String toString()
  {
    return name;
  }
}
