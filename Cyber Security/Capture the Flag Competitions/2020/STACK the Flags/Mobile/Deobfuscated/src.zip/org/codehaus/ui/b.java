package org.codehaus.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.xmlpull.v1.XmlPullParser;

public class b
{
  public int a;
  public Element b;
  public int c;
  public String g;
  public boolean k;
  public String l;
  public float m;
  
  public b(String paramString, Element paramElement, Object paramObject)
  {
    g = paramString;
    b = paramElement;
    a(paramObject);
  }
  
  public b(b paramB, Object paramObject)
  {
    g = g;
    b = b;
    a(paramObject);
  }
  
  public static HashMap a(HashMap paramHashMap, View paramView)
  {
    HashMap localHashMap = new HashMap();
    Class localClass = paramView.getClass();
    Iterator localIterator = paramHashMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      b localB = (b)paramHashMap.get(str);
      try
      {
        boolean bool = str.equals("BackgroundColor");
        Object localObject;
        if (bool)
        {
          localObject = paramView.getBackground();
          localObject = (ColorDrawable)localObject;
          int i = ((ColorDrawable)localObject).getColor();
          localHashMap.put(str, new b(localB, Integer.valueOf(i)));
        }
        else
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("getMap");
          ((StringBuilder)localObject).append(str);
          localObject = ((StringBuilder)localObject).toString();
          localObject = localClass.getMethod((String)localObject, new Class[0]);
          localObject = ((Method)localObject).invoke(paramView, new Object[0]);
          localHashMap.put(str, new b(localB, localObject));
        }
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        localInvocationTargetException.printStackTrace();
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        localIllegalAccessException.printStackTrace();
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        localNoSuchMethodException.printStackTrace();
      }
    }
    return localHashMap;
  }
  
  public static void a(View paramView, HashMap paramHashMap)
  {
    Class localClass = paramView.getClass();
    Iterator localIterator = paramHashMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = (String)localIterator.next();
      Object localObject3 = (b)paramHashMap.get(localObject1);
      Object localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append("set");
      ((StringBuilder)localObject2).append((String)localObject1);
      localObject2 = ((StringBuilder)localObject2).toString();
      Object localObject4 = b;
      try
      {
        int i = ((Enum)localObject4).ordinal();
        float f;
        switch (i)
        {
        default: 
          break;
        case 6: 
          localObject4 = Float.TYPE;
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { localObject4 });
          f = m;
          ((Method)localObject4).invoke(paramView, new Object[] { Float.valueOf(f) });
          break;
        case 5: 
          localObject4 = Boolean.TYPE;
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { localObject4 });
          boolean bool = k;
          ((Method)localObject4).invoke(paramView, new Object[] { Boolean.valueOf(bool) });
          break;
        case 4: 
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { CharSequence.class });
          localObject3 = l;
          ((Method)localObject4).invoke(paramView, new Object[] { localObject3 });
          break;
        case 1: 
          localObject4 = Float.TYPE;
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { localObject4 });
          f = m;
          ((Method)localObject4).invoke(paramView, new Object[] { Float.valueOf(f) });
          break;
        case 0: 
          localObject4 = Integer.TYPE;
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { localObject4 });
          i = c;
          ((Method)localObject4).invoke(paramView, new Object[] { Integer.valueOf(i) });
          break;
        case 3: 
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { Drawable.class });
          ColorDrawable localColorDrawable = new ColorDrawable();
          i = a;
          localColorDrawable.setColor(i);
          ((Method)localObject4).invoke(paramView, new Object[] { localColorDrawable });
          break;
        case 2: 
          localObject4 = Integer.TYPE;
          localObject4 = localClass.getMethod((String)localObject2, new Class[] { localObject4 });
          i = a;
          ((Method)localObject4).invoke(paramView, new Object[] { Integer.valueOf(i) });
        }
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        localObject3 = new StringBuilder();
        ((StringBuilder)localObject3).append(" Custom Attribute \"");
        ((StringBuilder)localObject3).append((String)localObject1);
        ((StringBuilder)localObject3).append("\" not found on ");
        ((StringBuilder)localObject3).append(localClass.getName());
        Log.e("TransitionLayout", ((StringBuilder)localObject3).toString());
        localInvocationTargetException.printStackTrace();
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        localObject3 = new StringBuilder();
        ((StringBuilder)localObject3).append(" Custom Attribute \"");
        ((StringBuilder)localObject3).append((String)localObject1);
        ((StringBuilder)localObject3).append("\" not found on ");
        ((StringBuilder)localObject3).append(localClass.getName());
        Log.e("TransitionLayout", ((StringBuilder)localObject3).toString());
        localIllegalAccessException.printStackTrace();
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.e("TransitionLayout", localNoSuchMethodException.getMessage());
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append(" Custom Attribute \"");
        localStringBuilder.append((String)localObject1);
        localStringBuilder.append("\" not found on ");
        localStringBuilder.append(localClass.getName());
        Log.e("TransitionLayout", localStringBuilder.toString());
        localObject1 = new StringBuilder();
        ((StringBuilder)localObject1).append(localClass.getName());
        ((StringBuilder)localObject1).append(" must have a method ");
        ((StringBuilder)localObject1).append(localIllegalAccessException);
        Log.e("TransitionLayout", ((StringBuilder)localObject1).toString());
      }
    }
  }
  
  public static void parse(Context paramContext, XmlPullParser paramXmlPullParser, HashMap paramHashMap)
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), IpAddress.CustomAttribute);
    Object localObject3 = null;
    XmlPullParser localXmlPullParser = null;
    Object localObject4 = null;
    int j = localTypedArray.getIndexCount();
    int i = 0;
    while (i < j)
    {
      int n = localTypedArray.getIndex(i);
      Object localObject2;
      Object localObject1;
      if (n == IpAddress.CustomAttribute_attributeName)
      {
        String str = localTypedArray.getString(n);
        localObject3 = str;
        localObject2 = localObject3;
        paramXmlPullParser = localXmlPullParser;
        localObject1 = localObject4;
        if (str != null)
        {
          localObject2 = localObject3;
          paramXmlPullParser = localXmlPullParser;
          localObject1 = localObject4;
          if (str.length() > 0)
          {
            paramXmlPullParser = new StringBuilder();
            paramXmlPullParser.append(Character.toUpperCase(str.charAt(0)));
            paramXmlPullParser.append(str.substring(1));
            localObject2 = paramXmlPullParser.toString();
            paramXmlPullParser = localXmlPullParser;
            localObject1 = localObject4;
          }
        }
      }
      else if (n == IpAddress.CustomAttribute_customBoolean)
      {
        paramXmlPullParser = Boolean.valueOf(localTypedArray.getBoolean(n, false));
        localObject1 = Element.off;
        localObject2 = localObject3;
      }
      else if (n == IpAddress.CustomAttribute_customColorValue)
      {
        localObject1 = Element.depth;
        paramXmlPullParser = Integer.valueOf(localTypedArray.getColor(n, 0));
        localObject2 = localObject3;
      }
      else if (n == IpAddress.CustomAttribute_customColorDrawableValue)
      {
        localObject1 = Element.name;
        paramXmlPullParser = Integer.valueOf(localTypedArray.getColor(n, 0));
        localObject2 = localObject3;
      }
      else if (n == IpAddress.CustomAttribute_customPixelDimension)
      {
        localObject1 = Element.read;
        paramXmlPullParser = Float.valueOf(TypedValue.applyDimension(1, localTypedArray.getDimension(n, 0.0F), paramContext.getResources().getDisplayMetrics()));
        localObject2 = localObject3;
      }
      else if (n == IpAddress.CustomAttribute_customDimension)
      {
        localObject1 = Element.read;
        paramXmlPullParser = Float.valueOf(localTypedArray.getDimension(n, 0.0F));
        localObject2 = localObject3;
      }
      else if (n == IpAddress.CustomAttribute_customFloatValue)
      {
        localObject1 = Element.offset;
        paramXmlPullParser = Float.valueOf(localTypedArray.getFloat(n, NaN.0F));
        localObject2 = localObject3;
      }
      else if (n == IpAddress.CustomAttribute_customIntegerValue)
      {
        localObject1 = Element.root;
        paramXmlPullParser = Integer.valueOf(localTypedArray.getInteger(n, -1));
        localObject2 = localObject3;
      }
      else
      {
        localObject2 = localObject3;
        paramXmlPullParser = localXmlPullParser;
        localObject1 = localObject4;
        if (n == IpAddress.CustomAttribute_customStringValue)
        {
          localObject1 = Element.text;
          paramXmlPullParser = localTypedArray.getString(n);
          localObject2 = localObject3;
        }
      }
      i += 1;
      localObject3 = localObject2;
      localXmlPullParser = paramXmlPullParser;
      localObject4 = localObject1;
    }
    if ((localObject3 != null) && (localXmlPullParser != null)) {
      paramHashMap.put(localObject3, new b(localObject3, localObject4, localXmlPullParser));
    }
    localTypedArray.recycle();
  }
  
  public void a(Object paramObject)
  {
    switch (b.ordinal())
    {
    default: 
      return;
    case 6: 
      m = ((Float)paramObject).floatValue();
      return;
    case 5: 
      k = ((Boolean)paramObject).booleanValue();
      return;
    case 4: 
      l = ((String)paramObject);
      return;
    case 1: 
      m = ((Float)paramObject).floatValue();
      return;
    case 0: 
      c = ((Integer)paramObject).intValue();
      return;
    }
    a = ((Integer)paramObject).intValue();
  }
}
