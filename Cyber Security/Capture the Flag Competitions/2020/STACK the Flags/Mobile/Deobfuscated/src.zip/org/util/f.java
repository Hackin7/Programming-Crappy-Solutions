package org.util;

import a.m.d.b;
import a.m.g;
import a.m.h.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import org.spongycastle.crypto.params.Attribute;
import org.spongycastle.crypto.params.HttpHost;

public class f
  extends Log
{
  public ArrayList<d.b> a = new ArrayList();
  public a.c.a.b.a<a.m.f, h.a> b = new org.spongycastle.crypto.params.a();
  public boolean c = false;
  public c d;
  public boolean e = false;
  public int f = 0;
  public final WeakReference<g> v;
  
  public f(d paramD)
  {
    v = new WeakReference(paramD);
    d = c.b;
  }
  
  public static c a(Scope paramScope)
  {
    int i = paramScope.ordinal();
    if (i != 0)
    {
      if (i != 1) {
        if (i != 2)
        {
          if (i != 3)
          {
            if (i == 4) {
              break label79;
            }
            if (i == 5) {
              return c.c;
            }
            StringBuilder localStringBuilder = new StringBuilder();
            localStringBuilder.append("Unexpected event value ");
            localStringBuilder.append(paramScope);
            throw new IllegalArgumentException(localStringBuilder.toString());
          }
        }
        else {
          return c.a;
        }
      }
      return c.f;
    }
    label79:
    return c.d;
  }
  
  public static c a(c paramC1, c paramC2)
  {
    if ((paramC2 != null) && (paramC2.compareTo(paramC1) < 0)) {
      return paramC2;
    }
    return paramC1;
  }
  
  public static Scope b(c paramC)
  {
    int i = paramC.ordinal();
    if ((i != 0) && (i != 1))
    {
      if (i != 2)
      {
        if (i != 3)
        {
          if (i != 4)
          {
            StringBuilder localStringBuilder = new StringBuilder();
            localStringBuilder.append("Unexpected state value ");
            localStringBuilder.append(paramC);
            throw new IllegalArgumentException(localStringBuilder.toString());
          }
          throw new IllegalArgumentException();
        }
        return Scope.ON_RESUME;
      }
      return Scope.ON_START;
    }
    return Scope.ON_CREATE;
  }
  
  public static Scope valueOf(c paramC)
  {
    int i = paramC.ordinal();
    if (i != 0)
    {
      if (i != 1)
      {
        if (i != 2)
        {
          if (i != 3)
          {
            if (i == 4) {
              return Scope.ON_PAUSE;
            }
            StringBuilder localStringBuilder = new StringBuilder();
            localStringBuilder.append("Unexpected state value ");
            localStringBuilder.append(paramC);
            throw new IllegalArgumentException(localStringBuilder.toString());
          }
          return Scope.ON_STOP;
        }
        return Scope.ON_DESTROY;
      }
      throw new IllegalArgumentException();
    }
    throw new IllegalArgumentException();
  }
  
  public final void a()
  {
    d localD = (d)v.get();
    if (localD != null)
    {
      while (!b())
      {
        e = false;
        if (d.compareTo(b.m()).getValue()).a) < 0) {
          a(localD);
        }
        Map.Entry localEntry = b.p();
        if ((!e) && (localEntry != null) && (d.compareTo(getValuea) > 0)) {
          b(localD);
        }
      }
      e = false;
      return;
    }
    throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
  }
  
  public void a(MethodVisitor paramMethodVisitor)
  {
    Object localObject = d;
    c localC = c.c;
    if (localObject != localC) {
      localC = c.b;
    }
    localObject = new m(paramMethodVisitor, localC);
    if ((m)b.b(paramMethodVisitor, localObject) != null) {
      return;
    }
    d localD = (d)v.get();
    if (localD == null) {
      return;
    }
    int i;
    if ((f == 0) && (!c)) {
      i = 0;
    } else {
      i = 1;
    }
    localC = b(paramMethodVisitor);
    f += 1;
    while ((a.compareTo(localC) < 0) && (b.contains(paramMethodVisitor)))
    {
      a(a);
      ((m)localObject).a(localD, b(a));
      c();
      localC = b(paramMethodVisitor);
    }
    if (i == 0) {
      a();
    }
    f -= 1;
  }
  
  public final void a(c paramC)
  {
    a.add(paramC);
  }
  
  public final void a(d paramD)
  {
    Object localObject2 = b;
    Object localObject1 = this;
    Iterator localIterator = ((org.spongycastle.crypto.params.f)localObject2).f();
    if ((((HttpHost)localIterator).hasNext()) && (!e))
    {
      Map.Entry localEntry = (Map.Entry)((HttpHost)localIterator).next();
      m localM = (m)localEntry.getValue();
      localObject2 = localObject1;
      for (;;)
      {
        localObject1 = localObject2;
        if (a.compareTo(d) <= 0) {
          break;
        }
        localObject1 = localObject2;
        if (e) {
          break;
        }
        org.spongycastle.crypto.params.a localA = b;
        localObject1 = localObject2;
        if (!localA.contains(localEntry.getKey())) {
          break;
        }
        localObject1 = valueOf(a);
        ((f)localObject2).a(a((Scope)localObject1));
        localM.a(paramD, (Scope)localObject1);
        ((f)localObject2).c();
      }
    }
  }
  
  public void append(Scope paramScope)
  {
    d(a(paramScope));
  }
  
  public final c b(MethodVisitor paramMethodVisitor)
  {
    paramMethodVisitor = b.getValue(paramMethodVisitor);
    Object localObject = null;
    if (paramMethodVisitor != null) {
      paramMethodVisitor = getValuea;
    } else {
      paramMethodVisitor = null;
    }
    if (!a.isEmpty())
    {
      localObject = a;
      localObject = (c)((ArrayList)localObject).get(((ArrayList)localObject).size() - 1);
    }
    return a(a(d, paramMethodVisitor), (c)localObject);
  }
  
  public final void b(d paramD)
  {
    org.spongycastle.crypto.params.d localD = b.a();
    while ((localD.hasNext()) && (!e))
    {
      Map.Entry localEntry = (Map.Entry)localD.next();
      m localM = (m)localEntry.getValue();
      while ((a.compareTo(d) < 0) && (!e) && (b.contains(localEntry.getKey())))
      {
        a(a);
        localM.a(paramD, b(a));
        c();
      }
    }
  }
  
  public final boolean b()
  {
    if (b.size() == 0) {
      return true;
    }
    c localC1 = b.m()).getValue()).a;
    c localC2 = b.p()).getValue()).a;
    return (localC1 == localC2) && (d == localC2);
  }
  
  public final void c()
  {
    ArrayList localArrayList = a;
    localArrayList.remove(localArrayList.size() - 1);
  }
  
  public void c(c paramC)
  {
    d(paramC);
  }
  
  public final void d(c paramC)
  {
    if (d == paramC) {
      return;
    }
    d = paramC;
    if ((!c) && (f == 0))
    {
      c = true;
      a();
      c = false;
      return;
    }
    e = true;
  }
  
  public void e(MethodVisitor paramMethodVisitor)
  {
    b.a(paramMethodVisitor);
  }
  
  public void i(c paramC)
  {
    c(paramC);
  }
  
  public c p()
  {
    return d;
  }
}
