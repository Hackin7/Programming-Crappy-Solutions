package org.v7.view.menu;

import android.widget.ListView;
import org.v7.widget.ListPopupWindow;
import org.v7.widget.i;

public class h
{
  public final i a;
  public final MenuBuilder c;
  public final int z;
  
  public h(i paramI, MenuBuilder paramMenuBuilder, int paramInt)
  {
    a = paramI;
    c = paramMenuBuilder;
    z = paramInt;
  }
  
  public ListView a()
  {
    return a.c();
  }
}
