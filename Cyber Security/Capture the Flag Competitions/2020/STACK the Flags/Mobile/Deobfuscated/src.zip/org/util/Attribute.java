package org.util;

public abstract interface Attribute
{
  public abstract void a(d paramD, Scope paramScope, boolean paramBoolean, AnnotationVisitor paramAnnotationVisitor);
}
