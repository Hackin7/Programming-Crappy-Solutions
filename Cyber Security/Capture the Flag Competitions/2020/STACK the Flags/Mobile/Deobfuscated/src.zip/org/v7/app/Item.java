package org.v7.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;

public abstract class Item
{
  public BroadcastReceiver text;
  
  public Item(AppCompatDelegateImplV7 paramAppCompatDelegateImplV7) {}
  
  public abstract int a();
  
  public abstract void d();
  
  public abstract IntentFilter init();
  
  public void set()
  {
    BroadcastReceiver localBroadcastReceiver = text;
    if (localBroadcastReceiver != null)
    {
      Context localContext = this$0.mContext;
      try
      {
        localContext.unregisterReceiver(localBroadcastReceiver);
      }
      catch (IllegalArgumentException localIllegalArgumentException) {}
      text = null;
    }
  }
  
  public void show()
  {
    set();
    IntentFilter localIntentFilter = init();
    if (localIntentFilter != null)
    {
      if (localIntentFilter.countActions() == 0) {
        return;
      }
      if (text == null) {
        text = new g.m.a(this);
      }
      this$0.mContext.registerReceiver(text, localIntentFilter);
    }
  }
}
