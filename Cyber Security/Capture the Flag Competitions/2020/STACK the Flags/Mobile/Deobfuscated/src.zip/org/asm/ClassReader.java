package org.asm;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

public class ClassReader
{
  public static void b(Animator paramAnimator, AnimatorListenerAdapter paramAnimatorListenerAdapter)
  {
    paramAnimator.addPauseListener(paramAnimatorListenerAdapter);
  }
  
  public static void remove(Animator paramAnimator)
  {
    paramAnimator.resume();
  }
  
  public static void start(Animator paramAnimator)
  {
    paramAnimator.pause();
  }
}
