package org.codehaus.asm.asm;

import java.util.ArrayList;
import org.codehaus.asm.ClassWriter;
import org.codehaus.asm.h;

public class ClassReader
{
  public static void a(MethodWriter paramMethodWriter, ClassWriter paramClassWriter, int paramInt1, int paramInt2, d paramD)
  {
    f localF1 = b;
    f localF3 = j;
    Object localObject1 = c;
    f localF2 = o;
    Object localObject5 = k;
    float f1 = l;
    Object localObject2 = e;
    localObject2 = d;
    int i1;
    if (c[paramInt1] == XLayoutStyle.c) {
      i1 = 1;
    } else {
      i1 = 0;
    }
    int i;
    int j;
    int k;
    int i3;
    int m;
    int n;
    int i2;
    if (paramInt1 == 0)
    {
      if (index == 0) {
        i = 1;
      } else {
        i = 0;
      }
      if (index == 1) {
        j = 1;
      } else {
        j = 0;
      }
      if (index == 2) {
        k = 1;
      } else {
        k = 0;
      }
      i3 = 0;
      localObject3 = localF1;
      m = i;
      n = j;
      i2 = k;
      i = i3;
    }
    else
    {
      if (count == 0) {
        j = 1;
      } else {
        j = 0;
      }
      if (count == 1) {
        k = 1;
      } else {
        k = 0;
      }
      if (count == 2) {
        m = 1;
      } else {
        m = 0;
      }
      i = 0;
      localObject3 = localF1;
      i2 = m;
      n = k;
      m = j;
    }
    Object localObject4;
    while (i == 0)
    {
      localObject2 = r[paramInt2];
      j = 4;
      if (i2 != 0) {
        j = 1;
      }
      k = ((Label)localObject2).b();
      if ((c[paramInt1] == XLayoutStyle.a) && (P[paramInt1] == 0)) {
        i3 = 1;
      } else {
        i3 = 0;
      }
      localObject4 = a;
      int i4 = k;
      if (localObject4 != null)
      {
        i4 = k;
        if (localObject3 != localF1) {
          i4 = k + ((Label)localObject4).b();
        }
      }
      k = j;
      if (i2 != 0)
      {
        k = j;
        if (localObject3 != localF1)
        {
          k = j;
          if (localObject3 != localObject1) {
            k = 8;
          }
        }
      }
      localObject4 = a;
      if (localObject4 != null)
      {
        if (localObject3 == localObject1) {
          paramClassWriter.b(i, i, i4, 6);
        } else {
          paramClassWriter.b(i, i, i4, 8);
        }
        j = k;
        if (i3 != 0)
        {
          j = k;
          if (i2 == 0) {
            j = 5;
          }
        }
        paramClassWriter.a(i, a.i, i4, j);
      }
      if (i1 != 0)
      {
        if ((((f)localObject3).length() != 8) && (c[paramInt1] == XLayoutStyle.a))
        {
          localObject2 = r;
          paramClassWriter.b(1i, i, 0, 5);
        }
        paramClassWriter.b(r[paramInt2].i, r[paramInt2].i, 0, 8);
      }
      localObject2 = r[(paramInt2 + 1)].a;
      if (localObject2 != null)
      {
        localObject4 = b;
        localObject2 = localObject4;
        localObject4 = r;
        if ((a != null) && (a.b == localObject3)) {
          break label644;
        }
        localObject2 = null;
      }
      else
      {
        localObject2 = null;
      }
      label644:
      if (localObject2 == null)
      {
        i = 1;
        localObject2 = localObject3;
      }
      localObject3 = localObject2;
    }
    if ((localF2 != null) && (r[(paramInt2 + 1)].a != null))
    {
      localObject2 = r[(paramInt2 + 1)];
      if ((c[paramInt1] == XLayoutStyle.a) && (P[paramInt1] == 0)) {
        i = 1;
      } else {
        i = 0;
      }
      if ((i != 0) && (i2 == 0))
      {
        localObject3 = a;
        if (b == paramMethodWriter)
        {
          paramClassWriter.a(i, i, -((Label)localObject2).b(), 5);
          break label823;
        }
      }
      if (i2 != 0)
      {
        localObject3 = a;
        if (b == paramMethodWriter) {
          paramClassWriter.a(i, i, -((Label)localObject2).b(), 4);
        }
      }
      label823:
      paramClassWriter.c(i, r[(paramInt2 + 1)].a.i, -((Label)localObject2).b(), 6);
    }
    if (i1 != 0)
    {
      paramMethodWriter = r[(paramInt2 + 1)].i;
      localObject2 = r;
      paramClassWriter.b(paramMethodWriter, 1i, localObject2[(paramInt2 + 1)].b(), 8);
    }
    Object localObject3 = s;
    Object localObject6;
    org.codehaus.asm.Label localLabel;
    Object localObject7;
    if (localObject3 != null)
    {
      j = ((ArrayList)localObject3).size();
      if (j > 1)
      {
        paramMethodWriter = null;
        float f3 = 0.0F;
        float f2 = f1;
        if (q)
        {
          f2 = f1;
          if (!z) {
            f2 = n;
          }
        }
        i = 0;
        while (i < j)
        {
          localObject2 = (f)((ArrayList)localObject3).get(i);
          float f4 = A[paramInt1];
          f1 = f4;
          if (f4 < 0.0F)
          {
            if (z)
            {
              localObject2 = r;
              paramClassWriter.a(1i, i, 0, 4);
              f1 = f3;
              break label1197;
            }
            f1 = 1.0F;
          }
          if (f1 == 0.0F)
          {
            localObject2 = r;
            paramClassWriter.a(1i, i, 0, 8);
            f1 = f3;
          }
          else
          {
            if (paramMethodWriter != null)
            {
              localObject4 = r;
              paramMethodWriter = i;
              localObject4 = 1i;
              localObject6 = r;
              localLabel = i;
              localObject6 = 1i;
              localObject7 = paramClassWriter.c();
              ((h)localObject7).a(f3, f2, f1, paramMethodWriter, (org.codehaus.asm.Label)localObject4, localLabel, (org.codehaus.asm.Label)localObject6);
              paramClassWriter.a((h)localObject7);
            }
            paramMethodWriter = (MethodWriter)localObject2;
          }
          label1197:
          i += 1;
          f3 = f1;
        }
      }
      else {}
    }
    if (localObject1 != null)
    {
      if ((localObject1 != localF2) && (i2 == 0)) {
        break label1395;
      }
      paramMethodWriter = r[paramInt2];
      paramD = r[(paramInt2 + 1)];
      paramMethodWriter = a;
      if (paramMethodWriter != null) {
        paramMethodWriter = paramMethodWriter.i;
      } else {
        paramMethodWriter = null;
      }
      paramD = a;
      if (paramD != null) {
        paramD = i;
      } else {
        paramD = null;
      }
      localObject2 = r[paramInt2];
      localObject3 = r[(paramInt2 + 1)];
      if ((paramMethodWriter != null) && (paramD != null))
      {
        if (paramInt1 == 0) {
          f1 = size;
        } else {
          f1 = height;
        }
        paramInt1 = ((Label)localObject2).b();
        i = ((Label)localObject3).b();
        paramClassWriter.a(i, paramMethodWriter, paramInt1, f1, paramD, i, i, 7);
      }
      break label2461;
    }
    label1395:
    if ((m != 0) && (localObject1 != null))
    {
      i = n;
      if ((i > 0) && (i == i)) {
        k = 1;
      } else {
        k = 0;
      }
      paramMethodWriter = (MethodWriter)localObject1;
      localObject4 = localObject1;
      while (paramMethodWriter != null)
      {
        for (paramD = right[paramInt1]; (paramD != null) && (paramD.length() == 8); paramD = right[paramInt1]) {}
        if ((paramD == null) && (paramMethodWriter != localF2)) {
          break label1874;
        }
        localObject5 = r[paramInt2];
        localObject7 = i;
        localObject2 = a;
        if (localObject2 != null) {
          localObject3 = i;
        } else {
          localObject3 = null;
        }
        if (localObject4 != paramMethodWriter)
        {
          localObject2 = r[(paramInt2 + 1)].i;
        }
        else
        {
          localObject2 = localObject3;
          if (paramMethodWriter == localObject1)
          {
            localObject2 = localObject3;
            if (localObject4 == paramMethodWriter)
            {
              localObject2 = r;
              if (a != null) {
                localObject2 = a.i;
              } else {
                localObject2 = null;
              }
            }
          }
        }
        localObject3 = null;
        i1 = ((Label)localObject5).b();
        j = i1;
        i2 = r[(paramInt2 + 1)].b();
        i = i2;
        if (paramD != null)
        {
          localObject3 = r[paramInt2];
          localObject5 = i;
          localLabel = r[(paramInt2 + 1)].i;
        }
        else
        {
          localObject6 = r[(paramInt2 + 1)].a;
          if (localObject6 != null) {
            localObject3 = i;
          }
          localLabel = r[(paramInt2 + 1)].i;
          localObject5 = localObject3;
          localObject3 = localObject6;
        }
        if (localObject3 != null) {
          i = i2 + ((Label)localObject3).b();
        }
        if (localObject4 != null) {
          j = i1 + r[(paramInt2 + 1)].b();
        }
        if ((localObject7 != null) && (localObject2 != null) && (localObject5 != null) && (localLabel != null))
        {
          if (paramMethodWriter == localObject1) {
            j = r[paramInt2].b();
          }
          if (paramMethodWriter == localF2) {
            i = r[(paramInt2 + 1)].b();
          }
          if (k != 0) {
            i1 = 8;
          } else {
            i1 = 5;
          }
          paramClassWriter.a((org.codehaus.asm.Label)localObject7, (org.codehaus.asm.Label)localObject2, j, 0.5F, (org.codehaus.asm.Label)localObject5, localLabel, i, i1);
        }
        label1874:
        if (paramMethodWriter.length() != 8) {
          localObject4 = paramMethodWriter;
        }
        paramMethodWriter = paramD;
      }
    }
    else if ((n != 0) && (localObject1 != null))
    {
      i = n;
      if ((i > 0) && (i == i)) {
        i = 1;
      } else {
        i = 0;
      }
      paramD = (d)localObject1;
      localObject3 = localObject1;
      while (paramD != null)
      {
        for (paramMethodWriter = right[paramInt1]; (paramMethodWriter != null) && (paramMethodWriter.length() == 8); paramMethodWriter = right[paramInt1]) {}
        localObject2 = paramMethodWriter;
        if (paramD != localObject1)
        {
          localObject2 = paramMethodWriter;
          if (paramD != localF2)
          {
            localObject2 = paramMethodWriter;
            if (paramMethodWriter != null)
            {
              localObject2 = paramMethodWriter;
              if (paramMethodWriter == localF2) {
                localObject2 = null;
              }
              localObject4 = r[paramInt2];
              localObject6 = i;
              paramMethodWriter = a;
              if (paramMethodWriter != null) {
                paramMethodWriter = paramMethodWriter.i;
              }
              localObject7 = r[(paramInt2 + 1)].i;
              paramMethodWriter = null;
              i1 = ((Label)localObject4).b();
              k = r[(paramInt2 + 1)].b();
              j = k;
              if (localObject2 != null)
              {
                localObject4 = r[paramInt2];
                localObject5 = i;
                paramMethodWriter = a;
                if (paramMethodWriter != null) {
                  paramMethodWriter = paramMethodWriter.i;
                } else {
                  paramMethodWriter = null;
                }
              }
              else
              {
                localObject4 = r[paramInt2];
                if (localObject4 != null) {
                  paramMethodWriter = i;
                }
                localLabel = r[(paramInt2 + 1)].i;
                localObject5 = paramMethodWriter;
                paramMethodWriter = localLabel;
              }
              if (localObject4 != null) {
                j = k + ((Label)localObject4).b();
              }
              i2 = r[(paramInt2 + 1)].b();
              if (i != 0) {
                k = 8;
              } else {
                k = 4;
              }
              if ((localObject6 != null) && (localObject7 != null) && (localObject5 != null) && (paramMethodWriter != null)) {
                paramClassWriter.a((org.codehaus.asm.Label)localObject6, (org.codehaus.asm.Label)localObject7, i1 + i2, 0.5F, (org.codehaus.asm.Label)localObject5, paramMethodWriter, j, k);
              }
            }
          }
        }
        if (paramD.length() != 8) {
          localObject3 = paramD;
        }
        paramD = (d)localObject2;
      }
      paramD = r[paramInt2];
      localObject3 = r[paramInt2].a;
      localObject2 = r[(paramInt2 + 1)];
      paramMethodWriter = r[(paramInt2 + 1)].a;
      if (localObject3 != null) {
        if (localObject1 != localF2) {
          paramClassWriter.a(i, i, paramD.b(), 5);
        } else if (paramMethodWriter != null) {
          paramClassWriter.a(i, i, paramD.b(), 0.5F, i, paramMethodWriter.i, ((Label)localObject2).b(), 5);
        } else {}
      }
      if ((paramMethodWriter != null) && (localObject1 != localF2)) {
        paramClassWriter.a(i, paramMethodWriter.i, -((Label)localObject2).b(), 5);
      }
    }
    label2461:
    if (((m != 0) || (n != 0)) && (localObject1 != null) && (localObject1 != localF2))
    {
      localObject2 = r[paramInt2];
      localObject3 = r[(paramInt2 + 1)];
      paramMethodWriter = a;
      if (paramMethodWriter != null) {
        paramD = paramMethodWriter.i;
      } else {
        paramD = null;
      }
      paramMethodWriter = a;
      if (paramMethodWriter != null) {
        paramMethodWriter = paramMethodWriter.i;
      } else {
        paramMethodWriter = null;
      }
      if (localF3 != localF2)
      {
        paramMethodWriter = r[(paramInt2 + 1)].a;
        if (paramMethodWriter != null) {
          paramMethodWriter = paramMethodWriter.i;
        } else {
          paramMethodWriter = null;
        }
      }
      if (localObject1 == localF2)
      {
        localObject1 = r;
        localObject2 = localObject1[paramInt2];
        localObject3 = localObject1[(paramInt2 + 1)];
      }
      if ((paramD != null) && (paramMethodWriter != null))
      {
        paramInt1 = ((Label)localObject2).b();
        paramInt2 = r[(paramInt2 + 1)].b();
        paramClassWriter.a(i, paramD, paramInt1, 0.5F, paramMethodWriter, i, paramInt2, 5);
      }
    }
  }
  
  public static void a(MethodWriter paramMethodWriter, ClassWriter paramClassWriter, ArrayList paramArrayList, int paramInt)
  {
    int i;
    int j;
    d[] arrayOfD;
    if (paramInt == 0)
    {
      i = 0;
      j = r;
      arrayOfD = p;
    }
    else
    {
      i = 2;
      j = n;
      arrayOfD = d;
    }
    int k = 0;
    while (k < j)
    {
      d localD = arrayOfD[k];
      localD.c();
      if ((paramArrayList == null) || (paramArrayList.contains(b))) {
        a(paramMethodWriter, paramClassWriter, paramInt, i, localD);
      }
      k += 1;
    }
  }
}
