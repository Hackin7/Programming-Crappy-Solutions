package org.objectweb.asm;

import android.view.View;
import android.view.ViewGroup.LayoutParams;
import androidx.recyclerview.widget.RecyclerView.b0;
import androidx.recyclerview.widget.RecyclerView.e;
import java.util.ArrayList;
import java.util.List;

public class ChildHelper
{
  public final Bucket mBucket;
  public final AnnotationVisitor mCallback;
  public final List<View> mHiddenViews;
  
  public ChildHelper(AnnotationVisitor paramAnnotationVisitor)
  {
    mCallback = paramAnnotationVisitor;
    mBucket = new Bucket();
    mHiddenViews = new ArrayList();
  }
  
  public void addView(View paramView, int paramInt, boolean paramBoolean)
  {
    if (paramInt < 0) {
      paramInt = ((RecyclerView.e)mCallback).getChildCount();
    } else {
      paramInt = getOffset(paramInt);
    }
    mBucket.insert(paramInt, paramBoolean);
    if (paramBoolean) {
      hideViewInternal(paramView);
    }
    ((RecyclerView.e)mCallback).addView(paramView, paramInt);
  }
  
  public void addView(View paramView, boolean paramBoolean)
  {
    addView(paramView, -1, paramBoolean);
  }
  
  public void attachViewToParent(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean)
  {
    if (paramInt < 0) {
      paramInt = ((RecyclerView.e)mCallback).getChildCount();
    } else {
      paramInt = getOffset(paramInt);
    }
    mBucket.insert(paramInt, paramBoolean);
    if (paramBoolean) {
      hideViewInternal(paramView);
    }
    ((RecyclerView.e)mCallback).attachViewToParent(paramView, paramInt, paramLayoutParams);
  }
  
  public void detachViewFromParent(int paramInt)
  {
    paramInt = getOffset(paramInt);
    mBucket.remove(paramInt);
    ((RecyclerView.e)mCallback).detachViewFromParent(paramInt);
  }
  
  public View findHiddenNonRemovedView(int paramInt)
  {
    int j = mHiddenViews.size();
    int i = 0;
    while (i < j)
    {
      View localView = (View)mHiddenViews.get(i);
      RecyclerView.b0 localB0 = ((RecyclerView.e)mCallback).getChildViewHolder(localView);
      if ((localB0.getLayoutPosition() == paramInt) && (!localB0.isInvalid()) && (!localB0.isRemoved())) {
        return localView;
      }
      i += 1;
    }
    return null;
  }
  
  public View getChildAt(int paramInt)
  {
    paramInt = getOffset(paramInt);
    return ((RecyclerView.e)mCallback).getChildAt(paramInt);
  }
  
  public int getChildCount()
  {
    return ((RecyclerView.e)mCallback).getChildCount() - mHiddenViews.size();
  }
  
  public final int getOffset(int paramInt)
  {
    if (paramInt < 0) {
      return -1;
    }
    int j = ((RecyclerView.e)mCallback).getChildCount();
    int i = paramInt;
    while (i < j)
    {
      int k = paramInt - (i - mBucket.countOnesBefore(i));
      if (k == 0)
      {
        while (mBucket.get(i)) {
          i += 1;
        }
        return i;
      }
      i += k;
    }
    return -1;
  }
  
  public View getUnfilteredChildAt(int paramInt)
  {
    return ((RecyclerView.e)mCallback).getChildAt(paramInt);
  }
  
  public int getUnfilteredChildCount()
  {
    return ((RecyclerView.e)mCallback).getChildCount();
  }
  
  public void hide(View paramView)
  {
    int i = ((RecyclerView.e)mCallback).indexOfChild(paramView);
    if (i >= 0)
    {
      mBucket.set(i);
      hideViewInternal(paramView);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("view is not a child, cannot hide ");
    localStringBuilder.append(paramView);
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public final void hideViewInternal(View paramView)
  {
    mHiddenViews.add(paramView);
    ((RecyclerView.e)mCallback).onEnteredHiddenState(paramView);
  }
  
  public int indexOfChild(View paramView)
  {
    int i = ((RecyclerView.e)mCallback).indexOfChild(paramView);
    if (i == -1) {
      return -1;
    }
    if (mBucket.get(i)) {
      return -1;
    }
    return i - mBucket.countOnesBefore(i);
  }
  
  public boolean isHidden(View paramView)
  {
    return mHiddenViews.contains(paramView);
  }
  
  public void removeAllViewsUnfiltered()
  {
    mBucket.reset();
    int i = mHiddenViews.size() - 1;
    while (i >= 0)
    {
      AnnotationVisitor localAnnotationVisitor = mCallback;
      View localView = (View)mHiddenViews.get(i);
      ((RecyclerView.e)localAnnotationVisitor).onLeftHiddenState(localView);
      mHiddenViews.remove(i);
      i -= 1;
    }
    ((RecyclerView.e)mCallback).removeAllViews();
  }
  
  public void removeView(View paramView)
  {
    int i = ((RecyclerView.e)mCallback).indexOfChild(paramView);
    if (i < 0) {
      return;
    }
    if (mBucket.remove(i)) {
      unhideViewInternal(paramView);
    }
    ((RecyclerView.e)mCallback).removeViewAt(i);
  }
  
  public void removeViewAt(int paramInt)
  {
    paramInt = getOffset(paramInt);
    View localView = ((RecyclerView.e)mCallback).getChildAt(paramInt);
    if (localView == null) {
      return;
    }
    if (mBucket.remove(paramInt)) {
      unhideViewInternal(localView);
    }
    ((RecyclerView.e)mCallback).removeViewAt(paramInt);
  }
  
  public boolean removeViewIfHidden(View paramView)
  {
    int i = ((RecyclerView.e)mCallback).indexOfChild(paramView);
    if (i == -1)
    {
      unhideViewInternal(paramView);
      return true;
    }
    if (mBucket.get(i))
    {
      mBucket.remove(i);
      unhideViewInternal(paramView);
      ((RecyclerView.e)mCallback).removeViewAt(i);
      return true;
    }
    return false;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(mBucket.toString());
    localStringBuilder.append(", hidden list:");
    localStringBuilder.append(mHiddenViews.size());
    return localStringBuilder.toString();
  }
  
  public void unhide(View paramView)
  {
    int i = ((RecyclerView.e)mCallback).indexOfChild(paramView);
    if (i >= 0)
    {
      if (mBucket.get(i))
      {
        mBucket.clear(i);
        unhideViewInternal(paramView);
        return;
      }
      localStringBuilder = new StringBuilder();
      localStringBuilder.append("trying to unhide a view that was not hidden");
      localStringBuilder.append(paramView);
      throw new RuntimeException(localStringBuilder.toString());
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("view is not a child, cannot hide ");
    localStringBuilder.append(paramView);
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public final boolean unhideViewInternal(View paramView)
  {
    if (mHiddenViews.remove(paramView))
    {
      ((RecyclerView.e)mCallback).onLeftHiddenState(paramView);
      return true;
    }
    return false;
  }
  
  public class Bucket
  {
    public long mData = 0L;
    public Bucket next;
    
    public Bucket() {}
    
    public void clear(int paramInt)
    {
      if (paramInt >= 64)
      {
        Bucket localBucket = next;
        if (localBucket != null) {
          localBucket.clear(paramInt - 64);
        }
      }
      else
      {
        mData &= 1L << paramInt;
      }
    }
    
    public int countOnesBefore(int paramInt)
    {
      Bucket localBucket = next;
      if (localBucket == null)
      {
        if (paramInt >= 64) {
          return Long.bitCount(mData);
        }
        return Long.bitCount(mData & (1L << paramInt) - 1L);
      }
      if (paramInt < 64) {
        return Long.bitCount(mData & (1L << paramInt) - 1L);
      }
      return localBucket.countOnesBefore(paramInt - 64) + Long.bitCount(mData);
    }
    
    public final void ensureNext()
    {
      if (next == null) {
        next = new Bucket();
      }
    }
    
    public boolean get(int paramInt)
    {
      if (paramInt >= 64)
      {
        ensureNext();
        return next.get(paramInt - 64);
      }
      return (mData & 1L << paramInt) != 0L;
    }
    
    public void insert(int paramInt, boolean paramBoolean)
    {
      if (paramInt >= 64)
      {
        ensureNext();
        next.insert(paramInt - 64, paramBoolean);
        return;
      }
      boolean bool;
      if ((mData & 0x8000000000000000) != 0L) {
        bool = true;
      } else {
        bool = false;
      }
      long l1 = (1L << paramInt) - 1L;
      long l2 = mData;
      mData = (l2 & l1 | (l2 & l1) << 1);
      if (paramBoolean) {
        set(paramInt);
      } else {
        clear(paramInt);
      }
      if ((bool) || (next != null))
      {
        ensureNext();
        next.insert(0, bool);
      }
    }
    
    public boolean remove(int paramInt)
    {
      if (paramInt >= 64)
      {
        ensureNext();
        return next.remove(paramInt - 64);
      }
      long l2 = 1L << paramInt;
      boolean bool;
      if ((mData & l2) != 0L) {
        bool = true;
      } else {
        bool = false;
      }
      long l1 = mData & l2;
      mData = l1;
      l2 -= 1L;
      mData = (l1 & l2 | Long.rotateRight(l1 & l2, 1));
      Bucket localBucket = next;
      if (localBucket != null)
      {
        if (localBucket.get(0)) {
          set(63);
        }
        next.remove(0);
      }
      return bool;
    }
    
    public void reset()
    {
      mData = 0L;
      Bucket localBucket = next;
      if (localBucket != null) {
        localBucket.reset();
      }
    }
    
    public void set(int paramInt)
    {
      if (paramInt >= 64)
      {
        ensureNext();
        next.set(paramInt - 64);
        return;
      }
      mData |= 1L << paramInt;
    }
    
    public String toString()
    {
      if (next == null) {
        return Long.toBinaryString(mData);
      }
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(next.toString());
      localStringBuilder.append("xx");
      localStringBuilder.append(Long.toBinaryString(mData));
      return localStringBuilder.toString();
    }
  }
}
