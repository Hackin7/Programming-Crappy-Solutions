package org.asm;

import android.view.View;

public class Widget
{
  public Label a;
  public aa b;
  public String e;
  public l g;
  public View i;
  
  public Widget(View paramView, String paramString, l paramL, aa paramAa, Label paramLabel)
  {
    i = paramView;
    e = paramString;
    a = paramLabel;
    b = paramAa;
    g = paramL;
  }
}
