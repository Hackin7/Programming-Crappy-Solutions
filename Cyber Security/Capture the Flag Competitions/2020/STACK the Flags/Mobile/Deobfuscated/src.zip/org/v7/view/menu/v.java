package org.v7.view.menu;

import android.widget.PopupWindow.OnDismissListener;

public class v
  implements PopupWindow.OnDismissListener
{
  public v(i paramI) {}
  
  public void onDismiss()
  {
    a.onDismiss();
  }
}
