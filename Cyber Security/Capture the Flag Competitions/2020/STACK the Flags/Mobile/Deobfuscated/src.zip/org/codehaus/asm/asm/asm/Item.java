package org.codehaus.asm.asm.asm;

public abstract interface Item {}
