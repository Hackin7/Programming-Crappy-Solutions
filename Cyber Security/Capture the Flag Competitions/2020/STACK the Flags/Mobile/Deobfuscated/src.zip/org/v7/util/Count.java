package org.v7.util;

public final class Count
{
  public static final int abc_vector_test = 2131165276;
  public static final int notification_action_background = 2131165327;
  public static final int notification_bg = 2131165328;
  public static final int notification_bg_low = 2131165329;
  public static final int notification_bg_low_normal = 2131165330;
  public static final int notification_bg_low_pressed = 2131165331;
  public static final int notification_bg_normal = 2131165332;
  public static final int notification_bg_normal_pressed = 2131165333;
  public static final int notification_icon_background = 2131165334;
  public static final int notification_template_icon_bg = 2131165335;
  public static final int notification_template_icon_low_bg = 2131165336;
  public static final int notification_tile_bg = 2131165337;
  public static final int notify_panel_notification_icon_bg = 2131165338;
}
