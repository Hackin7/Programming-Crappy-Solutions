package org.util;

import a.m.p;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class Label
{
  public final HashMap<String, p> b = new HashMap();
  
  public Label() {}
  
  public final i a(String paramString)
  {
    return (i)b.get(paramString);
  }
  
  public final void a()
  {
    Iterator localIterator = b.values().iterator();
    while (localIterator.hasNext()) {
      ((i)localIterator.next()).clear();
    }
    b.clear();
  }
  
  public final void a(String paramString, i paramI)
  {
    paramString = (i)b.put(paramString, paramI);
    if (paramString != null) {
      paramString.a();
    }
  }
}
