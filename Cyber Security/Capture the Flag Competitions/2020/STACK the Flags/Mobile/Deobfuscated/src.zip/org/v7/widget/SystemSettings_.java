package org.v7.widget;

public class SystemSettings_
  extends SystemSettings
{}
