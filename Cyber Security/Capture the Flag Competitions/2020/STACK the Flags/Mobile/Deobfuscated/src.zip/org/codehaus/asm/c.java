package org.codehaus.asm;

import a.f.b.h.a;

public enum c
{
  static
  {
    c localC = new c("UNKNOWN", 4);
    e = localC;
    $VALUES = new c[] { a, b, c, d, localC };
  }
}
