package org.objectweb.asm;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.n;
import androidx.recyclerview.widget.RecyclerView.r;
import androidx.recyclerview.widget.RecyclerView.s;
import androidx.recyclerview.widget.RecyclerView.y;
import org.core.view.ViewCompat;

public class ClassWriter
  extends RecyclerView.n
  implements RecyclerView.r
{
  public static final int[] I = { 16842919 };
  public static final int[] K = new int[0];
  public final int H;
  public final Runnable a = new MonthByWeekFragment.2(this);
  public final StateListDrawable b;
  public boolean c = false;
  public int d = 0;
  public float e;
  public final int[] f = new int[2];
  public float g;
  public final StateListDrawable h;
  public final int i;
  public final RecyclerView.s index = new IssueActivity.1(this);
  public final Drawable j;
  public int k;
  public boolean l = false;
  public int m = 0;
  public final ValueAnimator mAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
  public int n;
  public final int[] o = new int[2];
  public final int q;
  public final int r;
  public int s;
  public final int size;
  public int t;
  public RecyclerView this$0;
  public final int u;
  public int v = 0;
  public int w = 0;
  public int x = 0;
  public final Drawable y;
  
  public ClassWriter(RecyclerView paramRecyclerView, StateListDrawable paramStateListDrawable1, Drawable paramDrawable1, StateListDrawable paramStateListDrawable2, Drawable paramDrawable2, int paramInt1, int paramInt2, int paramInt3)
  {
    b = paramStateListDrawable1;
    j = paramDrawable1;
    h = paramStateListDrawable2;
    y = paramDrawable2;
    i = Math.max(paramInt1, paramStateListDrawable1.getIntrinsicWidth());
    H = Math.max(paramInt1, paramDrawable1.getIntrinsicWidth());
    size = Math.max(paramInt1, paramStateListDrawable2.getIntrinsicWidth());
    r = Math.max(paramInt1, paramDrawable2.getIntrinsicWidth());
    q = paramInt2;
    u = paramInt3;
    b.setAlpha(255);
    j.setAlpha(255);
    mAnimator.addListener(new ScrollingTabContainerView.VisibilityAnimListener(this));
    mAnimator.addUpdateListener(new MainActivity.5(this));
    put(paramRecyclerView);
  }
  
  public final int a(float paramFloat1, float paramFloat2, int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3)
  {
    int i1 = paramArrayOfInt[1] - paramArrayOfInt[0];
    if (i1 == 0) {
      return 0;
    }
    paramFloat1 = (paramFloat2 - paramFloat1) / i1;
    paramInt1 -= paramInt3;
    paramInt3 = (int)(paramInt1 * paramFloat1);
    paramInt2 += paramInt3;
    if ((paramInt2 < paramInt1) && (paramInt2 >= 0)) {
      return paramInt3;
    }
    return 0;
  }
  
  public final void a(float paramFloat)
  {
    int[] arrayOfInt = c();
    paramFloat = Math.max(arrayOfInt[0], Math.min(arrayOfInt[1], paramFloat));
    if (Math.abs(n - paramFloat) < 2.0F) {
      return;
    }
    int i1 = a(e, paramFloat, arrayOfInt, this$0.computeVerticalScrollRange(), this$0.computeVerticalScrollOffset(), m);
    if (i1 != 0) {
      this$0.scrollBy(0, i1);
    }
    e = paramFloat;
  }
  
  public void a(int paramInt)
  {
    if ((paramInt == 2) && (v != 2))
    {
      b.setState(I);
      init();
    }
    if (paramInt == 0) {
      setProgress();
    } else {
      show();
    }
    if ((v == 2) && (paramInt != 2))
    {
      b.setState(K);
      init(1200);
    }
    else if (paramInt == 1)
    {
      init(1500);
    }
    v = paramInt;
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    int i1 = this$0.computeVerticalScrollRange();
    int i2 = m;
    boolean bool;
    if ((i1 - i2 > 0) && (m >= q)) {
      bool = true;
    } else {
      bool = false;
    }
    c = bool;
    int i3 = this$0.computeHorizontalScrollRange();
    int i4 = w;
    if ((i3 - i4 > 0) && (w >= q)) {
      bool = true;
    } else {
      bool = false;
    }
    l = bool;
    if ((!c) && (!bool))
    {
      if (v != 0) {
        a(0);
      }
    }
    else
    {
      float f1;
      float f2;
      if (c)
      {
        f1 = paramInt2;
        f2 = i2 / 2.0F;
        n = ((int)(i2 * (f1 + f2) / i1));
        s = Math.min(i2, i2 * i2 / i1);
      }
      if (l)
      {
        f1 = paramInt1;
        f2 = i4 / 2.0F;
        t = ((int)(i4 * (f1 + f2) / i3));
        k = Math.min(i4, i4 * i4 / i3);
      }
      paramInt1 = v;
      if ((paramInt1 == 0) || (paramInt1 == 1)) {
        a(1);
      }
    }
  }
  
  public final void a(Canvas paramCanvas)
  {
    int i2 = w;
    int i1 = i;
    i2 -= i1;
    int i4 = n;
    int i3 = s;
    i4 -= i3 / 2;
    b.setBounds(0, 0, i1, i3);
    j.setBounds(0, 0, H, m);
    if (get())
    {
      j.draw(paramCanvas);
      paramCanvas.translate(i, i4);
      paramCanvas.scale(-1.0F, 1.0F);
      b.draw(paramCanvas);
      paramCanvas.scale(1.0F, 1.0F);
      paramCanvas.translate(-i, -i4);
      return;
    }
    paramCanvas.translate(i2, 0.0F);
    j.draw(paramCanvas);
    paramCanvas.translate(0.0F, i4);
    b.draw(paramCanvas);
    paramCanvas.translate(-i2, -i4);
  }
  
  public void a(Canvas paramCanvas, RecyclerView paramRecyclerView, RecyclerView.y paramY)
  {
    if ((w == this$0.getWidth()) && (m == this$0.getHeight()))
    {
      if (x != 0)
      {
        if (c) {
          a(paramCanvas);
        }
        if (l) {
          onDraw(paramCanvas);
        }
      }
    }
    else
    {
      w = this$0.getWidth();
      m = this$0.getHeight();
      a(0);
    }
  }
  
  public void a(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent)
  {
    if (v == 0) {
      return;
    }
    if (paramMotionEvent.getAction() == 0)
    {
      boolean bool1 = a(paramMotionEvent.getX(), paramMotionEvent.getY());
      boolean bool2 = get(paramMotionEvent.getX(), paramMotionEvent.getY());
      if ((bool1) || (bool2))
      {
        if (bool2)
        {
          d = 1;
          g = ((int)paramMotionEvent.getX());
        }
        else if (bool1)
        {
          d = 2;
          e = ((int)paramMotionEvent.getY());
        }
        a(2);
      }
      return;
    }
    if ((paramMotionEvent.getAction() == 1) && (v == 2))
    {
      e = 0.0F;
      g = 0.0F;
      a(1);
      d = 0;
      return;
    }
    if ((paramMotionEvent.getAction() == 2) && (v == 2))
    {
      show();
      if (d == 1) {
        b(paramMotionEvent.getX());
      }
      if (d == 2) {
        a(paramMotionEvent.getY());
      }
    }
  }
  
  public boolean a(float paramFloat1, float paramFloat2)
  {
    if (get() ? paramFloat1 <= i / 2 : paramFloat1 >= w - i)
    {
      int i1 = n;
      int i2 = s;
      if ((paramFloat2 >= i1 - i2 / 2) && (paramFloat2 <= i1 + i2 / 2)) {
        return true;
      }
    }
    return false;
  }
  
  public final int[] a()
  {
    int[] arrayOfInt = o;
    int i1 = u;
    arrayOfInt[0] = i1;
    arrayOfInt[1] = (w - i1);
    return arrayOfInt;
  }
  
  public void animate(int paramInt)
  {
    int i1 = x;
    if (i1 != 1)
    {
      if (i1 == 2) {}
    }
    else {
      mAnimator.cancel();
    }
    x = 3;
    ValueAnimator localValueAnimator = mAnimator;
    localValueAnimator.setFloatValues(new float[] { ((Float)localValueAnimator.getAnimatedValue()).floatValue(), 0.0F });
    mAnimator.setDuration(paramInt);
    mAnimator.start();
  }
  
  public final void b(float paramFloat)
  {
    int[] arrayOfInt = a();
    paramFloat = Math.max(arrayOfInt[0], Math.min(arrayOfInt[1], paramFloat));
    if (Math.abs(t - paramFloat) < 2.0F) {
      return;
    }
    int i1 = a(g, paramFloat, arrayOfInt, this$0.computeHorizontalScrollRange(), this$0.computeHorizontalScrollOffset(), w);
    if (i1 != 0) {
      this$0.scrollBy(i1, 0);
    }
    g = paramFloat;
  }
  
  public final int[] c()
  {
    int[] arrayOfInt = f;
    int i1 = u;
    arrayOfInt[0] = i1;
    arrayOfInt[1] = (m - i1);
    return arrayOfInt;
  }
  
  public final boolean get()
  {
    return ViewCompat.getLayoutDirection(this$0) == 1;
  }
  
  public boolean get(float paramFloat1, float paramFloat2)
  {
    if (paramFloat2 >= m - size)
    {
      int i1 = t;
      int i2 = k;
      if ((paramFloat1 >= i1 - i2 / 2) && (paramFloat1 <= i1 + i2 / 2)) {
        return true;
      }
    }
    return false;
  }
  
  public final void init()
  {
    this$0.removeCallbacks(a);
  }
  
  public final void init(int paramInt)
  {
    init();
    this$0.postDelayed(a, paramInt);
  }
  
  public final void onCreate()
  {
    this$0.addItemDecoration(this);
    this$0.addItemDecoration(this);
    this$0.addOnScrollListener(index);
  }
  
  public final void onDraw(Canvas paramCanvas)
  {
    int i2 = m;
    int i1 = size;
    i2 -= i1;
    int i4 = t;
    int i3 = k;
    i4 -= i3 / 2;
    h.setBounds(0, 0, i3, i1);
    y.setBounds(0, 0, w, r);
    paramCanvas.translate(0.0F, i2);
    y.draw(paramCanvas);
    paramCanvas.translate(i4, 0.0F);
    h.draw(paramCanvas);
    paramCanvas.translate(-i4, -i2);
  }
  
  public boolean onInterceptTouchEvent(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent)
  {
    int i1 = v;
    if (i1 == 1)
    {
      boolean bool1 = a(paramMotionEvent.getX(), paramMotionEvent.getY());
      boolean bool2 = get(paramMotionEvent.getX(), paramMotionEvent.getY());
      if ((paramMotionEvent.getAction() == 0) && ((bool1) || (bool2)))
      {
        if (bool2)
        {
          d = 1;
          g = ((int)paramMotionEvent.getX());
        }
        else if (bool1)
        {
          d = 2;
          e = ((int)paramMotionEvent.getY());
        }
        a(2);
        return true;
      }
      return false;
    }
    return i1 == 2;
  }
  
  public void onRequestDisallowInterceptTouchEvent(boolean paramBoolean) {}
  
  public final void put()
  {
    this$0.removeItemDecoration(this);
    this$0.removeOnItemTouchListener(this);
    this$0.removeOnScrollListener(index);
    init();
  }
  
  public void put(RecyclerView paramRecyclerView)
  {
    RecyclerView localRecyclerView = this$0;
    if (localRecyclerView == paramRecyclerView) {
      return;
    }
    if (localRecyclerView != null) {
      put();
    }
    this$0 = paramRecyclerView;
    if (paramRecyclerView != null) {
      onCreate();
    }
  }
  
  public void setProgress()
  {
    this$0.invalidate();
  }
  
  public void show()
  {
    int i1 = x;
    if (i1 != 0)
    {
      if (i1 != 3) {
        return;
      }
      mAnimator.cancel();
    }
    x = 1;
    ValueAnimator localValueAnimator = mAnimator;
    localValueAnimator.setFloatValues(new float[] { ((Float)localValueAnimator.getAnimatedValue()).floatValue(), 1.0F });
    mAnimator.setDuration(500L);
    mAnimator.setStartDelay(0L);
    mAnimator.start();
  }
}
