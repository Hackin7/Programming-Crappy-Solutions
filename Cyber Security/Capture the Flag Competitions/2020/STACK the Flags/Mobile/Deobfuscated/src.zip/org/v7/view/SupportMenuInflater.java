package org.v7.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff.Mode;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.core.view.ActionProvider;
import org.core.view.Switch;
import org.v7.R.styleable;
import org.v7.view.menu.MenuItemImpl;
import org.v7.view.menu.MenuItemWrapper;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class SupportMenuInflater
  extends MenuInflater
{
  public static final Class<?>[] ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE;
  public static final Class<?>[] items;
  public final Object[] mActionProviderConstructorArguments;
  public final Object[] mActionViewConstructorArguments;
  public Context mContext;
  public Object mRealOwner;
  
  static
  {
    Class[] arrayOfClass = new Class[1];
    arrayOfClass[0] = Context.class;
    items = arrayOfClass;
    ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE = arrayOfClass;
  }
  
  public SupportMenuInflater(Context paramContext)
  {
    super(paramContext);
    mContext = paramContext;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramContext;
    mActionViewConstructorArguments = arrayOfObject;
    mActionProviderConstructorArguments = arrayOfObject;
  }
  
  public final Object findRealOwner(Object paramObject)
  {
    if ((paramObject instanceof Activity)) {
      return paramObject;
    }
    Object localObject = paramObject;
    if ((paramObject instanceof ContextWrapper)) {
      localObject = findRealOwner(((ContextWrapper)paramObject).getBaseContext());
    }
    return localObject;
  }
  
  public Object getRealOwner()
  {
    if (mRealOwner == null) {
      mRealOwner = findRealOwner(mContext);
    }
    return mRealOwner;
  }
  
  public void inflate(int paramInt, android.view.Menu paramMenu)
  {
    if (!(paramMenu instanceof org.core.base.utils.Menu))
    {
      super.inflate(paramInt, paramMenu);
      return;
    }
    Object localObject3 = null;
    Object localObject2 = null;
    Object localObject1 = null;
    Object localObject4 = mContext;
    try
    {
      localObject4 = ((Context)localObject4).getResources().getLayout(paramInt);
      localObject2 = localObject4;
      localObject1 = localObject2;
      localObject3 = localObject2;
      parseMenu((XmlPullParser)localObject4, Xml.asAttributeSet((XmlPullParser)localObject4), paramMenu);
      ((XmlResourceParser)localObject4).close();
      return;
    }
    catch (Throwable paramMenu) {}catch (IOException paramMenu)
    {
      localObject1 = localObject3;
      throw new InflateException("Error inflating menu XML", paramMenu);
    }
    catch (XmlPullParserException paramMenu)
    {
      localObject1 = localObject2;
      throw new InflateException("Error inflating menu XML", paramMenu);
    }
    if (localObject1 != null) {
      localObject1.close();
    }
    throw paramMenu;
  }
  
  public final void parseMenu(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, android.view.Menu paramMenu)
  {
    MenuState localMenuState = new MenuState(paramMenu);
    int j = paramXmlPullParser.getEventType();
    int k = 0;
    Object localObject = null;
    int i;
    int m;
    do
    {
      if (j == 2)
      {
        paramMenu = paramXmlPullParser.getName();
        if (paramMenu.equals("menu"))
        {
          i = paramXmlPullParser.next();
          break;
        }
        paramXmlPullParser = new StringBuilder();
        paramXmlPullParser.append("Expecting menu, got ");
        paramXmlPullParser.append(paramMenu);
        throw new RuntimeException(paramXmlPullParser.toString());
      }
      m = paramXmlPullParser.next();
      i = m;
      j = i;
    } while (m != 1);
    j = 0;
    int n = i;
    while (j == 0) {
      if (n != 1)
      {
        if (n != 2)
        {
          if (n != 3)
          {
            i = k;
            paramMenu = (android.view.Menu)localObject;
            m = j;
          }
          else
          {
            String str = paramXmlPullParser.getName();
            if ((k != 0) && (str.equals(localObject)))
            {
              i = 0;
              paramMenu = null;
              m = j;
            }
            else if (str.equals("group"))
            {
              localMenuState.resetGroup();
              i = k;
              paramMenu = (android.view.Menu)localObject;
              m = j;
            }
            else if (str.equals("item"))
            {
              i = k;
              paramMenu = (android.view.Menu)localObject;
              m = j;
              if (!localMenuState.hasAddedItem())
              {
                paramMenu = itemActionProvider;
                if ((paramMenu != null) && (paramMenu.hasSubMenu()))
                {
                  localMenuState.addSubMenuItem();
                  i = k;
                  paramMenu = (android.view.Menu)localObject;
                  m = j;
                }
                else
                {
                  localMenuState.addItem();
                  i = k;
                  paramMenu = (android.view.Menu)localObject;
                  m = j;
                }
              }
            }
            else
            {
              i = k;
              paramMenu = (android.view.Menu)localObject;
              m = j;
              if (str.equals("menu"))
              {
                m = 1;
                i = k;
                paramMenu = (android.view.Menu)localObject;
              }
            }
          }
        }
        else if (k != 0)
        {
          i = k;
          paramMenu = (android.view.Menu)localObject;
          m = j;
        }
        else
        {
          paramMenu = paramXmlPullParser.getName();
          if (paramMenu.equals("group"))
          {
            localMenuState.readGroup(paramAttributeSet);
            i = k;
            paramMenu = (android.view.Menu)localObject;
            m = j;
          }
          else if (paramMenu.equals("item"))
          {
            localMenuState.parseMenu(paramAttributeSet);
            i = k;
            paramMenu = (android.view.Menu)localObject;
            m = j;
          }
          else if (paramMenu.equals("menu"))
          {
            parseMenu(paramXmlPullParser, paramAttributeSet, localMenuState.addSubMenuItem());
            i = k;
            paramMenu = (android.view.Menu)localObject;
            m = j;
          }
          else
          {
            i = 1;
            m = j;
          }
        }
        n = paramXmlPullParser.next();
        k = i;
        localObject = paramMenu;
        j = m;
      }
      else
      {
        throw new RuntimeException("Unexpected end of document");
      }
    }
  }
  
  public class InflatedOnMenuItemClickListener
    implements MenuItem.OnMenuItemClickListener
  {
    public static final Class<?>[] PARAM_TYPES = { MenuItem.class };
    public Method mMethod;
    
    public InflatedOnMenuItemClickListener(String paramString)
    {
      this$1 = getClass();
      Object localObject = PARAM_TYPES;
      try
      {
        localObject = getMethod(paramString, (Class[])localObject);
        mMethod = ((Method)localObject);
        return;
      }
      catch (Exception localException)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("Couldn't resolve menu item onClick handler ");
        localStringBuilder.append(paramString);
        localStringBuilder.append(" in class ");
        localStringBuilder.append(getName());
        this$1 = new InflateException(localStringBuilder.toString());
        initCause(localException);
        throw SupportMenuInflater.this;
      }
    }
    
    public boolean onMenuItemClick(MenuItem paramMenuItem)
    {
      Object localObject1 = mMethod;
      try
      {
        localObject1 = ((Method)localObject1).getReturnType();
        if (localObject1 == Boolean.TYPE)
        {
          localObject1 = mMethod;
          localObject2 = SupportMenuInflater.this;
          paramMenuItem = ((Method)localObject1).invoke(localObject2, new Object[] { paramMenuItem });
          paramMenuItem = (Boolean)paramMenuItem;
          boolean bool = paramMenuItem.booleanValue();
          return bool;
        }
        localObject1 = mMethod;
        Object localObject2 = SupportMenuInflater.this;
        ((Method)localObject1).invoke(localObject2, new Object[] { paramMenuItem });
        return true;
      }
      catch (Exception paramMenuItem)
      {
        throw new RuntimeException(paramMenuItem);
      }
    }
  }
  
  public class MenuState
  {
    public CharSequence author;
    public ColorStateList c = null;
    public int groupCategory;
    public int groupCheckable;
    public boolean groupEnabled;
    public int groupId;
    public int groupOrder;
    public boolean groupVisible;
    public int id;
    public ActionProvider itemActionProvider;
    public String itemActionProviderClassName;
    public String itemActionViewClassName;
    public int itemActionViewLayout;
    public boolean itemAdded;
    public char itemAlphabeticShortcut;
    public int itemCategoryOrder;
    public int itemCheckable;
    public boolean itemChecked;
    public boolean itemEnabled;
    public int itemIconResId;
    public int itemId;
    public String itemListenerMethodName;
    public int itemNumericShortcut;
    public int itemShowAsAction;
    public CharSequence itemTitle;
    public CharSequence itemTitleCondensed;
    public boolean itemVisible;
    public PorterDuff.Mode j = null;
    public android.view.Menu menu;
    public CharSequence name;
    public char title;
    
    public MenuState(android.view.Menu paramMenu)
    {
      menu = paramMenu;
      resetGroup();
    }
    
    public void addItem()
    {
      itemAdded = true;
      setItem(menu.add(groupId, itemId, itemCategoryOrder, itemTitle));
    }
    
    public SubMenu addSubMenuItem()
    {
      itemAdded = true;
      SubMenu localSubMenu = menu.addSubMenu(groupId, itemId, itemCategoryOrder, itemTitle);
      setItem(localSubMenu.getItem());
      return localSubMenu;
    }
    
    public final char getShortcut(String paramString)
    {
      if (paramString == null) {
        return '\000';
      }
      return paramString.charAt(0);
    }
    
    public boolean hasAddedItem()
    {
      return itemAdded;
    }
    
    public final Object newInstance(String paramString, Class[] paramArrayOfClass, Object[] paramArrayOfObject)
    {
      Context localContext = mContext;
      try
      {
        paramArrayOfClass = Class.forName(paramString, false, localContext.getClassLoader()).getConstructor(paramArrayOfClass);
        paramArrayOfClass.setAccessible(true);
        paramArrayOfClass = paramArrayOfClass.newInstance(paramArrayOfObject);
        return paramArrayOfClass;
      }
      catch (Exception paramArrayOfClass)
      {
        paramArrayOfObject = new StringBuilder();
        paramArrayOfObject.append("Cannot instantiate class: ");
        paramArrayOfObject.append(paramString);
        Log.w("SupportMenuInflater", paramArrayOfObject.toString(), paramArrayOfClass);
      }
      return null;
    }
    
    public void parseMenu(AttributeSet paramAttributeSet)
    {
      throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
    }
    
    public void readGroup(AttributeSet paramAttributeSet)
    {
      paramAttributeSet = mContext.obtainStyledAttributes(paramAttributeSet, R.styleable.MenuGroup);
      groupId = paramAttributeSet.getResourceId(R.styleable.MenuGroup_android_id, 0);
      groupCategory = paramAttributeSet.getInt(R.styleable.MenuGroup_android_menuCategory, 0);
      groupOrder = paramAttributeSet.getInt(R.styleable.MenuGroup_android_orderInCategory, 0);
      groupCheckable = paramAttributeSet.getInt(R.styleable.MenuGroup_android_checkableBehavior, 0);
      groupVisible = paramAttributeSet.getBoolean(R.styleable.MenuGroup_android_visible, true);
      groupEnabled = paramAttributeSet.getBoolean(R.styleable.MenuGroup_android_enabled, true);
      paramAttributeSet.recycle();
    }
    
    public void resetGroup()
    {
      groupId = 0;
      groupCategory = 0;
      groupOrder = 0;
      groupCheckable = 0;
      groupVisible = true;
      groupEnabled = true;
    }
    
    public final void setItem(MenuItem paramMenuItem)
    {
      Object localObject = paramMenuItem.setChecked(itemChecked).setVisible(itemVisible).setEnabled(itemEnabled);
      boolean bool;
      if (itemCheckable >= 1) {
        bool = true;
      } else {
        bool = false;
      }
      ((MenuItem)localObject).setCheckable(bool).setTitleCondensed(itemTitleCondensed).setIcon(itemIconResId);
      int i = itemShowAsAction;
      if (i >= 0) {
        paramMenuItem.setShowAsAction(i);
      }
      if (itemListenerMethodName != null) {
        if (!mContext.isRestricted()) {
          paramMenuItem.setOnMenuItemClickListener(new SupportMenuInflater.InflatedOnMenuItemClickListener(getRealOwner(), itemListenerMethodName));
        } else {
          throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
        }
      }
      if (itemCheckable >= 2) {
        if ((paramMenuItem instanceof MenuItemImpl)) {
          ((MenuItemImpl)paramMenuItem).setExclusiveCheckable(true);
        } else if ((paramMenuItem instanceof MenuItemWrapper)) {
          ((MenuItemWrapper)paramMenuItem).setExclusiveCheckable(true);
        }
      }
      i = 0;
      localObject = itemActionViewClassName;
      if (localObject != null)
      {
        paramMenuItem.setActionView((View)newInstance((String)localObject, SupportMenuInflater.items, mActionViewConstructorArguments));
        i = 1;
      }
      int k = itemActionViewLayout;
      if (k > 0) {
        if (i == 0) {
          paramMenuItem.setActionView(k);
        } else {
          Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
        }
      }
      localObject = itemActionProvider;
      if (localObject != null) {
        Switch.setActionProvider(paramMenuItem, (ActionProvider)localObject);
      }
      Switch.update(paramMenuItem, name);
      Switch.a(paramMenuItem, author);
      Switch.update(paramMenuItem, title, id);
      Switch.a(paramMenuItem, itemAlphabeticShortcut, itemNumericShortcut);
      localObject = j;
      if (localObject != null) {
        Switch.a(paramMenuItem, (PorterDuff.Mode)localObject);
      }
      localObject = c;
      if (localObject != null) {
        Switch.a(paramMenuItem, (ColorStateList)localObject);
      }
    }
  }
}
