package org.util;

import a.m.d.b;

public enum c
{
  static
  {
    b = new c("INITIALIZED", 1);
    d = new c("CREATED", 2);
    f = new c("STARTED", 3);
    c localC = new c("RESUMED", 4);
    a = localC;
    e = new c[] { c, b, d, f, localC };
  }
  
  public boolean a(c paramC)
  {
    return compareTo(paramC) >= 0;
  }
}
