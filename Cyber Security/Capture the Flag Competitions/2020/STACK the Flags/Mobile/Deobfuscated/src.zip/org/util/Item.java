package org.util;

import a.m.a.b;
import a.m.d.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Item
{
  public final Map<d.a, List<a.b>> c;
  public final Map<a.b, d.a> properties;
  
  public Item(Map paramMap)
  {
    properties = paramMap;
    c = new HashMap();
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Scope localScope = (Scope)localEntry.getValue();
      Object localObject = (List)c.get(localScope);
      paramMap = (Map)localObject;
      if (localObject == null)
      {
        localObject = new ArrayList();
        paramMap = (Map)localObject;
        c.put(localScope, localObject);
      }
      localObject = localEntry.getKey();
      ((List)paramMap).add(localObject);
    }
  }
  
  public static void a(List paramList, d paramD, Scope paramScope, Object paramObject)
  {
    if (paramList != null)
    {
      int i = paramList.size() - 1;
      while (i >= 0)
      {
        ((Matrix)paramList.get(i)).toString(paramD, paramScope, paramObject);
        i -= 1;
      }
    }
  }
  
  public void a(d paramD, Scope paramScope, Object paramObject)
  {
    a((List)c.get(paramScope), paramD, paramScope, paramObject);
    a((List)c.get(Scope.ON_ANY), paramD, paramScope, paramObject);
  }
}
