package org.asm;

import android.graphics.PointF;
import android.util.Property;
import android.view.View;

public final class TShortLinkedList
  extends Property<View, PointF>
{
  public TShortLinkedList(Class paramClass, String paramString)
  {
    super(paramClass, paramString);
  }
  
  public PointF add()
  {
    return null;
  }
  
  public void draw(View paramView, PointF paramPointF)
  {
    Log.set(paramView, Math.round(x), Math.round(y), paramView.getRight(), paramView.getBottom());
  }
}
