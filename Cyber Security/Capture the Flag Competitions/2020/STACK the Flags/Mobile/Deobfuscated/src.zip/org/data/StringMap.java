package org.data;

import a.e.f;
import java.util.Map;

public class StringMap
  extends f<E, E>
{
  public StringMap(TLongArrayList paramTLongArrayList) {}
  
  public void clear()
  {
    this$0.clear();
  }
  
  public int get(Object paramObject)
  {
    return this$0.indexOf(paramObject);
  }
  
  public Object get(int paramInt1, int paramInt2)
  {
    return this$0.next[paramInt1];
  }
  
  public Map get()
  {
    throw new UnsupportedOperationException("not a map");
  }
  
  public int indexOf(Object paramObject)
  {
    return this$0.indexOf(paramObject);
  }
  
  public Object put(int paramInt, Object paramObject)
  {
    throw new UnsupportedOperationException("not a map");
  }
  
  public void put(Object paramObject1, Object paramObject2)
  {
    this$0.add(paramObject1);
  }
  
  public void remove(int paramInt)
  {
    this$0.remove(paramInt);
  }
  
  public int size()
  {
    return this$0.length;
  }
}
