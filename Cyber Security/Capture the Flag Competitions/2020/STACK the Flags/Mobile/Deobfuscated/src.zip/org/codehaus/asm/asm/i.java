package org.codehaus.asm.asm;

import java.util.ArrayList;
import org.codehaus.asm.ClassWriter;

public class i
  extends f
{
  public Label a = a;
  public int b = -1;
  public boolean l;
  public int m = -1;
  public int p = 0;
  public float x = -1.0F;
  
  public i()
  {
    this$0.clear();
    this$0.add(a);
    int j = r.length;
    int i = 0;
    while (i < j)
    {
      r[i] = a;
      i += 1;
    }
  }
  
  public Label a()
  {
    return a;
  }
  
  public Label a(c paramC)
  {
    switch (paramC.ordinal())
    {
    default: 
      break;
    case 0: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
      return null;
    case 2: 
    case 4: 
      if (p == 0) {
        return a;
      }
      break;
    case 1: 
    case 3: 
      if (p == 1) {
        return a;
      }
      break;
    }
    throw new AssertionError(paramC.name());
  }
  
  public void a(float paramFloat)
  {
    if (paramFloat > -1.0F)
    {
      x = paramFloat;
      m = -1;
      b = -1;
    }
  }
  
  public void a(int paramInt)
  {
    if (p == paramInt) {
      return;
    }
    p = paramInt;
    this$0.clear();
    if (p == 1) {
      a = b;
    } else {
      a = a;
    }
    this$0.add(a);
    int i = r.length;
    paramInt = 0;
    while (paramInt < i)
    {
      r[paramInt] = a;
      paramInt += 1;
    }
  }
  
  public void a(ClassWriter paramClassWriter, boolean paramBoolean)
  {
    Object localObject2 = (MethodWriter)l();
    if (localObject2 == null) {
      return;
    }
    Label localLabel = ((f)localObject2).a(c.d);
    Object localObject1 = ((f)localObject2).a(c.i);
    f localF = n;
    int j = 1;
    int i;
    if ((localF != null) && (c[0] == XLayoutStyle.c)) {
      i = 1;
    } else {
      i = 0;
    }
    if (p == 0)
    {
      localLabel = ((f)localObject2).a(c.a);
      localObject1 = ((f)localObject2).a(c.b);
      localObject2 = n;
      if ((localObject2 != null) && (c[1] == XLayoutStyle.c)) {
        i = j;
      } else {
        i = 0;
      }
    }
    if ((l) && (a.equals()))
    {
      localObject2 = paramClassWriter.a(a);
      paramClassWriter.a((org.codehaus.asm.Label)localObject2, a.d());
      if (m != -1)
      {
        if (i != 0) {
          paramClassWriter.b(paramClassWriter.a(localObject1), (org.codehaus.asm.Label)localObject2, 0, 5);
        }
      }
      else if ((b != -1) && (i != 0))
      {
        localObject1 = paramClassWriter.a(localObject1);
        paramClassWriter.b((org.codehaus.asm.Label)localObject2, paramClassWriter.a(localLabel), 0, 5);
        paramClassWriter.b((org.codehaus.asm.Label)localObject1, (org.codehaus.asm.Label)localObject2, 0, 5);
      }
      l = false;
      return;
    }
    if (m != -1)
    {
      localObject2 = paramClassWriter.a(a);
      paramClassWriter.a((org.codehaus.asm.Label)localObject2, paramClassWriter.a(localLabel), m, 8);
      if (i != 0) {
        paramClassWriter.b(paramClassWriter.a(localObject1), (org.codehaus.asm.Label)localObject2, 0, 5);
      }
      return;
    }
    if (b != -1)
    {
      localObject2 = paramClassWriter.a(a);
      localObject1 = paramClassWriter.a(localObject1);
      paramClassWriter.a((org.codehaus.asm.Label)localObject2, (org.codehaus.asm.Label)localObject1, -b, 8);
      if (i != 0)
      {
        paramClassWriter.b((org.codehaus.asm.Label)localObject2, paramClassWriter.a(localLabel), 0, 5);
        paramClassWriter.b((org.codehaus.asm.Label)localObject1, (org.codehaus.asm.Label)localObject2, 0, 5);
      }
    }
    else if (x != -1.0F)
    {
      paramClassWriter.a(ClassWriter.a(paramClassWriter, paramClassWriter.a(a), paramClassWriter.a(localObject1), x));
    }
  }
  
  public void b(ClassWriter paramClassWriter, boolean paramBoolean)
  {
    if (l() == null) {
      return;
    }
    int i = paramClassWriter.b(a);
    if (p == 1)
    {
      g(i);
      setText(0);
      add(l().size());
      append(0);
      return;
    }
    g(0);
    setText(i);
    append(l().getValue());
    add(0);
  }
  
  public boolean b()
  {
    return l;
  }
  
  public void d(int paramInt)
  {
    if (paramInt > -1)
    {
      x = -1.0F;
      m = paramInt;
      b = -1;
    }
  }
  
  public boolean d()
  {
    return l;
  }
  
  public boolean g()
  {
    return true;
  }
  
  public void init(int paramInt)
  {
    if (paramInt > -1)
    {
      x = -1.0F;
      m = -1;
      b = paramInt;
    }
  }
  
  public int k()
  {
    return p;
  }
  
  public void k(int paramInt)
  {
    a.a(paramInt);
    l = true;
  }
  
  public int m()
  {
    return m;
  }
  
  public int n()
  {
    return b;
  }
  
  public float t()
  {
    return x;
  }
}
