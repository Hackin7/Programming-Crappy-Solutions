package org.asm;

public abstract interface m
{
  public abstract void a(l paramL);
  
  public abstract void b(l paramL);
  
  public abstract void c(l paramL);
  
  public abstract void d(l paramL);
}
