package org.codehaus.asm.asm.asm;

import java.util.List;
import org.codehaus.asm.asm.AnnotationWriter;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.f;

public class d
  extends h
{
  public Label a;
  public c c;
  
  public d(f paramF)
  {
    super(paramF);
    paramF = new Label(this);
    a = paramF;
    c = null;
    a.g = MathArrays.OrderDirection.g;
    c.g = MathArrays.OrderDirection.l;
    g = MathArrays.OrderDirection.Q;
    e = 1;
  }
  
  public void a()
  {
    Object localObject1 = b;
    if (d) {
      d.a(((f)localObject1).size());
    }
    int i;
    if (!d.c)
    {
      p = b.get();
      if (b.j()) {
        c = new o(this);
      }
      localObject1 = p;
      if (localObject1 != XLayoutStyle.a)
      {
        if (localObject1 == XLayoutStyle.r)
        {
          localObject1 = b.l();
          if ((localObject1 != null) && (((f)localObject1).get() == XLayoutStyle.b))
          {
            i = ((f)localObject1).size();
            int j = b.a.b();
            int k = b.g.b();
            a(a, e.a, b.a.b());
            a(c, e.c, -b.g.b());
            d.a(i - j - k);
            return;
          }
        }
        if (p == XLayoutStyle.b) {
          d.a(b.size());
        }
      }
    }
    else if (p == XLayoutStyle.r)
    {
      localObject1 = b.l();
      if ((localObject1 != null) && (((f)localObject1).get() == XLayoutStyle.b))
      {
        a(a, e.a, b.a.b());
        a(c, e.c, -b.g.b());
        return;
      }
    }
    if (d.c)
    {
      localObject1 = b;
      if (d)
      {
        localObject2 = r;
        if ((2a != null) && (3a != null))
        {
          if (((f)localObject1).c())
          {
            a.j = b.r[2].b();
            c.j = (-b.r[3].b());
          }
          else
          {
            localObject1 = a(b.r[2]);
            if (localObject1 != null) {
              a(a, (Label)localObject1, b.r[2].b());
            }
            localObject1 = a(b.r[3]);
            if (localObject1 != null) {
              a(c, (Label)localObject1, -b.r[3].b());
            }
            a.i = true;
            c.i = true;
          }
          if (!b.j()) {
            return;
          }
          a(a, a, b.newClass());
          return;
        }
        localObject1 = b;
        localObject2 = r;
        if (2a != null)
        {
          localObject1 = a(localObject2[2]);
          if (localObject1 != null)
          {
            a(a, (Label)localObject1, b.r[2].b());
            a(c, a, d.d);
            if (b.j()) {
              a(a, a, b.newClass());
            }
          }
          return;
        }
        if (3a != null)
        {
          localObject1 = a(localObject2[3]);
          if (localObject1 != null)
          {
            a(c, (Label)localObject1, -b.r[3].b());
            a(a, c, -d.d);
          }
          if (b.j()) {
            a(a, a, b.newClass());
          }
          return;
        }
        if (4a != null)
        {
          localObject1 = a(localObject2[4]);
          if (localObject1 != null)
          {
            a(a, (Label)localObject1, 0);
            a(a, a, -b.newClass());
            a(c, a, d.d);
          }
          return;
        }
        if (((localObject1 instanceof AnnotationWriter)) || (((f)localObject1).l() == null) || (b.a(org.codehaus.asm.asm.c.l).a != null)) {
          return;
        }
        localObject1 = b.l().e.a;
        a(a, (Label)localObject1, b.getTitle());
        a(c, a, d.d);
        if (b.j()) {
          a(a, a, b.newClass());
        }
        return;
      }
    }
    if ((!d.c) && (p == XLayoutStyle.a))
    {
      localObject1 = b;
      i = h;
      if (i != 2)
      {
        if ((i == 3) && (!((f)localObject1).c()))
        {
          localObject1 = b;
          if (k != 3)
          {
            localObject1 = f.d;
            d.a.add(localObject1);
            f.add(d);
            localObject1 = d;
            i = true;
            f.add(a);
            d.f.add(c);
          }
        }
      }
      else
      {
        localObject1 = ((f)localObject1).l();
        if (localObject1 != null)
        {
          localObject1 = e.d;
          d.a.add(localObject1);
          f.add(d);
          localObject1 = d;
          i = true;
          f.add(a);
          d.f.add(c);
        }
      }
    }
    else
    {
      d.b(this);
    }
    localObject1 = b;
    Object localObject2 = r;
    if ((2a != null) && (3a != null))
    {
      if (((f)localObject1).c())
      {
        a.j = b.r[2].b();
        c.j = (-b.r[3].b());
      }
      else
      {
        localObject1 = a(b.r[2]);
        localObject2 = a(b.r[3]);
        ((Label)localObject1).b(this);
        ((Label)localObject2).b(this);
        this.i = AllowedSolution.H;
      }
      if (b.j()) {
        a(a, a, 1, c);
      }
    }
    else
    {
      localObject1 = b;
      localObject2 = r;
      if (2a != null)
      {
        localObject1 = a(localObject2[2]);
        if (localObject1 != null)
        {
          a(a, (Label)localObject1, b.r[2].b());
          a(c, a, 1, d);
          if (b.j()) {
            a(a, a, 1, c);
          }
          if ((p == XLayoutStyle.a) && (b.i() > 0.0F))
          {
            localObject1 = b.f;
            if (p == XLayoutStyle.a)
            {
              d.f.add(d);
              d.a.add(b.f.d);
              d.k = this;
            }
          }
        }
      }
      else if (3a != null)
      {
        localObject1 = a(localObject2[3]);
        if (localObject1 != null)
        {
          a(c, (Label)localObject1, -b.r[3].b());
          a(a, c, -1, d);
          if (b.j()) {
            a(a, a, 1, c);
          }
        }
      }
      else if (4a != null)
      {
        localObject1 = a(localObject2[4]);
        if (localObject1 != null)
        {
          a(a, (Label)localObject1, 0);
          a(a, a, -1, c);
          a(c, a, 1, d);
        }
      }
      else if ((!(localObject1 instanceof AnnotationWriter)) && (((f)localObject1).l() != null))
      {
        localObject1 = b.l().e.a;
        a(a, (Label)localObject1, b.getTitle());
        a(c, a, 1, d);
        if (b.j()) {
          a(a, a, 1, c);
        }
        if ((p == XLayoutStyle.a) && (b.i() > 0.0F))
        {
          localObject1 = b.f;
          if (p == XLayoutStyle.a)
          {
            d.f.add(d);
            d.a.add(b.f.d);
            d.k = this;
          }
        }
      }
    }
    if (d.a.size() == 0) {
      d.e = true;
    }
  }
  
  public void a(l paramL)
  {
    int i = this.i.ordinal();
    if (i != 1)
    {
      if (i != 2)
      {
        if (i == 3)
        {
          paramL = b;
          a(a, g, 1);
        }
      }
      else {
        notifyDataSetChanged();
      }
    }
    else {
      setTitle();
    }
    paramL = d;
    int j;
    float f;
    if ((e) && (!c) && (p == XLayoutStyle.a))
    {
      paramL = b;
      i = h;
      if (i != 2)
      {
        if ((i == 3) && (f.d.c))
        {
          i = 0;
          j = paramL.r();
          if (j != -1)
          {
            if (j != 0)
            {
              if (j == 1)
              {
                paramL = b;
                i = (int)(f.d.d / paramL.i() + 0.5F);
              }
            }
            else
            {
              paramL = b;
              i = (int)(f.d.d * paramL.i() + 0.5F);
            }
          }
          else
          {
            paramL = b;
            i = (int)(f.d.d / paramL.i() + 0.5F);
          }
          d.a(i);
        }
      }
      else
      {
        paramL = paramL.l();
        if (paramL != null)
        {
          paramL = e.d;
          if (c)
          {
            f = b.q;
            i = (int)(d * f + 0.5F);
            d.a(i);
          }
        }
      }
    }
    paramL = a;
    if (e)
    {
      Label localLabel = c;
      if (!e) {
        return;
      }
      if ((c) && (c) && (d.c)) {
        return;
      }
      if ((!d.c) && (p == XLayoutStyle.a))
      {
        paramL = b;
        if ((k == 0) && (!paramL.c()))
        {
          localLabel = (Label)a.a.get(0);
          paramL = (Label)c.a.get(0);
          i = d;
          localLabel = a;
          i += j;
          j = d + c.j;
          localLabel.a(i);
          c.a(j);
          d.a(j - i);
          return;
        }
      }
      if ((!d.c) && (p == XLayoutStyle.a) && (g == 1) && (a.a.size() > 0) && (c.a.size() > 0))
      {
        paramL = (Label)a.a.get(0);
        localLabel = (Label)c.a.get(0);
        i = d;
        j = a.j;
        i = d + c.j - (i + j);
        paramL = d;
        j = d;
        if (i < j) {
          paramL.a(i);
        } else {
          paramL.a(j);
        }
      }
      if (!d.c) {
        return;
      }
      if ((a.a.size() > 0) && (c.a.size() > 0))
      {
        paramL = (Label)a.a.get(0);
        localLabel = (Label)c.a.get(0);
        i = d + a.j;
        j = d + c.j;
        f = b.height();
        if (paramL == localLabel)
        {
          i = d;
          j = d;
          f = 0.5F;
        }
        int k = d.d;
        a.a((int)(i + 0.5F + (j - i - k) * f));
        c.a(a.d + d.d);
      }
    }
  }
  
  public void b()
  {
    f = false;
    a.a();
    a.c = false;
    c.a();
    c.c = false;
    a.a();
    a.c = false;
    d.c = false;
  }
  
  public void d()
  {
    Label localLabel = a;
    if (c) {
      b.setText(d);
    }
  }
  
  public void e()
  {
    q = null;
    a.a();
    c.a();
    a.a();
    d.a();
    f = false;
  }
  
  public boolean k()
  {
    if (p == XLayoutStyle.a) {
      return b.h == 0;
    }
    return true;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("VerticalRun ");
    localStringBuilder.append(b.getString());
    return localStringBuilder.toString();
  }
}
