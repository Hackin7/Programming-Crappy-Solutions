package org.codehaus.asm.asm.asm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.codehaus.asm.asm.Label;
import org.codehaus.asm.asm.MethodWriter;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.b;
import org.codehaus.asm.asm.c;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.h;
import org.codehaus.asm.asm.i;

public class g
{
  public static a c = new a();
  
  public static void a(MethodWriter paramMethodWriter, Item paramItem)
  {
    Object localObject2 = paramMethodWriter.doubleValue();
    Object localObject1 = paramMethodWriter.get();
    paramMethodWriter.read();
    ArrayList localArrayList = paramMethodWriter.m();
    int n = localArrayList.size();
    int i = 0;
    while (i < n)
    {
      ((f)localArrayList.get(i)).read();
      i += 1;
    }
    if (localObject2 == XLayoutStyle.b) {
      paramMethodWriter.a(0, paramMethodWriter.getValue());
    } else {
      paramMethodWriter.close(0);
    }
    i = 0;
    int k = 0;
    int m = 0;
    int j;
    while (m < n)
    {
      localObject2 = (f)localArrayList.get(m);
      if ((localObject2 instanceof i))
      {
        localObject2 = (i)localObject2;
        j = i;
        if (((i)localObject2).k() == 1)
        {
          if (((i)localObject2).m() != -1) {
            ((i)localObject2).k(((i)localObject2).m());
          } else if ((((i)localObject2).n() != -1) && (paramMethodWriter.d())) {
            ((i)localObject2).k(paramMethodWriter.getValue() - ((i)localObject2).n());
          } else if (paramMethodWriter.d()) {
            ((i)localObject2).k((int)(((i)localObject2).t() * paramMethodWriter.getValue() + 0.5F));
          }
          j = 1;
        }
      }
      for (;;)
      {
        break;
        j = i;
        if ((localObject2 instanceof h))
        {
          j = i;
          if (((h)localObject2).getItemId() == 0)
          {
            k = 1;
            j = i;
          }
        }
      }
      m += 1;
      i = j;
    }
    if (i != 0)
    {
      i = 0;
      while (i < n)
      {
        localObject2 = (f)localArrayList.get(i);
        if ((localObject2 instanceof i))
        {
          localObject2 = (i)localObject2;
          if (((i)localObject2).k() == 1) {
            b((f)localObject2, paramItem);
          }
        }
        i += 1;
      }
    }
    b(paramMethodWriter, paramItem);
    if (k != 0)
    {
      i = 0;
      while (i < n)
      {
        localObject2 = (f)localArrayList.get(i);
        if ((localObject2 instanceof h))
        {
          localObject2 = (h)localObject2;
          if (((h)localObject2).getItemId() == 0) {
            c((h)localObject2, paramItem, 0);
          }
        }
        i += 1;
      }
    }
    if (localObject1 == XLayoutStyle.b) {
      paramMethodWriter.b(0, paramMethodWriter.size());
    } else {
      paramMethodWriter.set(0);
    }
    i = 0;
    k = 0;
    m = 0;
    while (m < n)
    {
      localObject1 = (f)localArrayList.get(m);
      if ((localObject1 instanceof i))
      {
        localObject1 = (i)localObject1;
        j = i;
        if (((i)localObject1).k() == 0)
        {
          if (((i)localObject1).m() != -1) {
            ((i)localObject1).k(((i)localObject1).m());
          } else if ((((i)localObject1).n() != -1) && (paramMethodWriter.b())) {
            ((i)localObject1).k(paramMethodWriter.size() - ((i)localObject1).n());
          } else if (paramMethodWriter.b()) {
            ((i)localObject1).k((int)(((i)localObject1).t() * paramMethodWriter.size() + 0.5F));
          }
          j = 1;
        }
      }
      for (;;)
      {
        break;
        j = i;
        if ((localObject1 instanceof h))
        {
          j = i;
          if (((h)localObject1).getItemId() == 1)
          {
            k = 1;
            j = i;
          }
        }
      }
      m += 1;
      i = j;
    }
    if (i != 0)
    {
      i = 0;
      while (i < n)
      {
        localObject1 = (f)localArrayList.get(i);
        if ((localObject1 instanceof i))
        {
          localObject1 = (i)localObject1;
          if (((i)localObject1).k() == 0) {
            a((f)localObject1, paramItem);
          }
        }
        i += 1;
      }
    }
    a(paramMethodWriter, paramItem);
    if (k != 0)
    {
      i = 0;
      while (i < n)
      {
        paramMethodWriter = (f)localArrayList.get(i);
        if ((paramMethodWriter instanceof h))
        {
          paramMethodWriter = (h)paramMethodWriter;
          if (paramMethodWriter.getItemId() == 1) {
            c(paramMethodWriter, paramItem, 1);
          }
        }
        i += 1;
      }
    }
    i = 0;
    while (i < n)
    {
      paramMethodWriter = (f)localArrayList.get(i);
      if ((paramMethodWriter.next()) && (b(paramMethodWriter)))
      {
        MethodWriter.a(paramMethodWriter, paramItem, c, false);
        b(paramMethodWriter, paramItem);
        a(paramMethodWriter, paramItem);
      }
      i += 1;
    }
  }
  
  public static void a(Item paramItem, f paramF)
  {
    float f = paramF.height();
    int m = a.a.d();
    int k = g.a.d();
    int i = a.b() + m;
    int j = k - g.b();
    if (m == k)
    {
      f = 0.5F;
      i = m;
      j = k;
    }
    int n = paramF.size();
    k = j - i - n;
    if (i > j) {
      k = i - j - n;
    }
    int i1 = (int)(k * f + 0.5F);
    k = i + i1;
    m = k + n;
    if (i > j)
    {
      k = i - i1;
      m = k - n;
    }
    paramF.b(k, m);
    a(paramF, paramItem);
  }
  
  public static void a(f paramF, Item paramItem)
  {
    if ((!(paramF instanceof MethodWriter)) && (paramF.next()) && (b(paramF))) {
      MethodWriter.a(paramF, paramItem, new a(), false);
    }
    Object localObject2 = paramF.a(c.a);
    Object localObject1 = paramF.a(c.b);
    int k = ((Label)localObject2).d();
    int j = ((Label)localObject1).d();
    Label localLabel1;
    f localF;
    boolean bool;
    int i;
    if ((((Label)localObject2).get() != null) && (((Label)localObject2).equals()))
    {
      localObject2 = ((Label)localObject2).get().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localLabel1 = (Label)((Iterator)localObject2).next();
        localF = b;
        bool = b(localF);
        if ((localF.next()) && (bool)) {
          MethodWriter.a(localF, paramItem, new a(), false);
        }
        Label localLabel2;
        if ((localF.get() == XLayoutStyle.a) && (!bool))
        {
          if ((localF.get() == XLayoutStyle.a) && ((localF.length() == 8) || ((h == 0) && (localF.i() == 0.0F))) && (!localF.c()) && (!localF.q()))
          {
            if (localLabel1 == a)
            {
              localLabel2 = g.a;
              if ((localLabel2 != null) && (localLabel2.equals())) {}
            }
            else
            {
              if (localLabel1 != g) {
                break label301;
              }
              localLabel1 = a.a;
              if ((localLabel1 == null) || (!localLabel1.equals())) {
                break label301;
              }
            }
            i = 1;
            break label303;
            label301:
            i = 0;
            label303:
            if ((i != 0) && (!localF.c())) {
              a(paramF, paramItem, localF);
            }
          }
        }
        else if (!localF.next())
        {
          localLabel2 = a;
          if ((localLabel1 == localLabel2) && (g.a == null))
          {
            i = localLabel2.b() + k;
            localF.b(i, localF.size() + i);
            a(localF, paramItem);
          }
          else
          {
            localLabel2 = g;
            if ((localLabel1 == localLabel2) && (a == null))
            {
              i = k - localLabel2.b();
              localF.b(i - localF.size(), i);
              a(localF, paramItem);
            }
            else if (localLabel1 == a)
            {
              localLabel1 = g.a;
              if ((localLabel1 != null) && (localLabel1.equals())) {
                a(paramItem, localF);
              }
            }
          }
        }
      }
    }
    if ((paramF instanceof i)) {
      return;
    }
    if ((((Label)localObject1).get() != null) && (((Label)localObject1).equals()))
    {
      localObject1 = ((Label)localObject1).get().iterator();
      label656:
      label658:
      label902:
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Label)((Iterator)localObject1).next();
        localF = b;
        bool = b(localF);
        if ((localF.next()) && (bool)) {
          MethodWriter.a(localF, paramItem, new a(), false);
        }
        if (localObject2 == a)
        {
          localLabel1 = g.a;
          if ((localLabel1 != null) && (localLabel1.equals())) {}
        }
        else
        {
          if (localObject2 != g) {
            break label656;
          }
          localLabel1 = a.a;
          if ((localLabel1 == null) || (!localLabel1.equals())) {
            break label656;
          }
        }
        i = 1;
        break label658;
        i = 0;
        if ((localF.get() == XLayoutStyle.a) && (!bool))
        {
          if (localF.get() == XLayoutStyle.a)
          {
            if (localF.length() != 8) {
              if (h == 0) {
                if (localF.i() != 0.0F) {
                  break label902;
                }
              } else {
                break label902;
              }
            }
            if ((localF.c()) || (localF.q()) || (i == 0) || (localF.c())) {
              break label902;
            }
            a(paramF, paramItem, localF);
          }
        }
        else if (!localF.next())
        {
          localLabel1 = a;
          if ((localObject2 == localLabel1) && (g.a == null))
          {
            i = localLabel1.b() + j;
            localF.b(i, localF.size() + i);
            a(localF, paramItem);
          }
          else
          {
            localLabel1 = g;
            if ((localObject2 == localLabel1) && (a.a == null))
            {
              i = j - localLabel1.b();
              localF.b(i - localF.size(), i);
              a(localF, paramItem);
            }
            else if ((i != 0) && (!localF.c()))
            {
              a(paramItem, localF);
            }
          }
        }
      }
    }
    paramF = paramF.a(c.g);
    if (paramF.get() != null)
    {
      if (paramF.equals())
      {
        i = paramF.d();
        paramF = paramF.get().iterator();
      }
    }
    else
    {
      while (paramF.hasNext())
      {
        localObject1 = (Label)paramF.next();
        localObject2 = b;
        bool = b((f)localObject2);
        if ((((f)localObject2).next()) && (bool)) {
          MethodWriter.a((f)localObject2, paramItem, new a(), false);
        }
        if (((((f)localObject2).get() != XLayoutStyle.a) || (bool)) && (!((f)localObject2).next()) && (localObject1 == u)) {
          ((f)localObject2).b(i);
        }
        try
        {
          a((f)localObject2, paramItem);
        }
        catch (Throwable paramF)
        {
          throw paramF;
        }
      }
      return;
    }
  }
  
  public static void a(f paramF1, Item paramItem, f paramF2)
  {
    float f = paramF2.height();
    int k = a.a.d() + a.b();
    int m = g.a.d() - g.b();
    if (m >= k)
    {
      int j = paramF2.size();
      int i = j;
      if (paramF2.length() != 8)
      {
        int n = h;
        if (n == 2)
        {
          if ((paramF1 instanceof MethodWriter)) {
            i = paramF1.size();
          } else {
            i = paramF1.l().size();
          }
          i = (int)(f * 0.5F * i);
        }
        else
        {
          i = j;
          if (n == 0) {
            i = m - k;
          }
        }
        j = Math.max(m, i);
        i = j;
        n = p;
        if (n > 0) {
          i = Math.min(n, j);
        }
      }
      j = k + (int)((m - k - i) * f + 0.5F);
      paramF2.b(j, j + i);
      a(paramF2, paramItem);
    }
  }
  
  public static void b(Item paramItem, f paramF)
  {
    float f1 = paramF.width();
    int m = b.a.d();
    int k = i.a.d();
    int i = b.b() + m;
    int j = k - i.b();
    if (m == k)
    {
      f1 = 0.5F;
      i = m;
      j = k;
    }
    int n = paramF.getValue();
    k = j - i - n;
    if (i > j) {
      k = i - j - n;
    }
    float f2 = f1;
    if (((MethodWriter)paramF.l()).visitParameterAnnotation()) {
      f2 = 1.0F - f1;
    }
    int i1 = (int)(k * f2 + 0.5F);
    k = i + i1;
    m = k + n;
    if (i > j)
    {
      k = i + i1;
      m = k - n;
    }
    paramF.a(k, m);
    b(paramF, paramItem);
  }
  
  public static void b(f paramF, Item paramItem)
  {
    if ((!(paramF instanceof MethodWriter)) && (paramF.next()) && (b(paramF))) {
      MethodWriter.a(paramF, paramItem, new a(), false);
    }
    Object localObject2 = paramF.a(c.d);
    Object localObject1 = paramF.a(c.i);
    int k = ((Label)localObject2).d();
    int j = ((Label)localObject1).d();
    Label localLabel1;
    f localF;
    boolean bool;
    int i;
    if ((((Label)localObject2).get() != null) && (((Label)localObject2).equals()))
    {
      localObject2 = ((Label)localObject2).get().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localLabel1 = (Label)((Iterator)localObject2).next();
        localF = b;
        bool = b(localF);
        if ((localF.next()) && (bool)) {
          MethodWriter.a(localF, paramItem, new a(), false);
        }
        Label localLabel2;
        if ((localF.doubleValue() == XLayoutStyle.a) && (!bool))
        {
          if ((localF.doubleValue() == XLayoutStyle.a) && ((localF.length() == 8) || ((k == 0) && (localF.i() == 0.0F))) && (!localF.f()) && (!localF.q()))
          {
            if (localLabel1 == b)
            {
              localLabel2 = i.a;
              if ((localLabel2 != null) && (localLabel2.equals())) {}
            }
            else
            {
              if (localLabel1 != i) {
                break label301;
              }
              localLabel1 = b.a;
              if ((localLabel1 == null) || (!localLabel1.equals())) {
                break label301;
              }
            }
            i = 1;
            break label303;
            label301:
            i = 0;
            label303:
            if ((i != 0) && (!localF.f())) {
              b(paramF, paramItem, localF);
            }
          }
        }
        else if (!localF.next())
        {
          localLabel2 = b;
          if ((localLabel1 == localLabel2) && (i.a == null))
          {
            i = localLabel2.b() + k;
            localF.a(i, localF.getValue() + i);
            b(localF, paramItem);
          }
          else
          {
            localLabel2 = i;
            if ((localLabel1 == localLabel2) && (b.a == null))
            {
              i = k - localLabel2.b();
              localF.a(i - localF.getValue(), i);
              b(localF, paramItem);
            }
            else if (localLabel1 == b)
            {
              localLabel1 = i.a;
              if ((localLabel1 != null) && (localLabel1.equals()) && (!localF.f())) {
                b(paramItem, localF);
              }
            }
          }
        }
      }
    }
    if ((paramF instanceof i)) {
      return;
    }
    if ((((Label)localObject1).get() != null) && (((Label)localObject1).equals()))
    {
      localObject1 = ((Label)localObject1).get().iterator();
      label670:
      label672:
      label916:
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Label)((Iterator)localObject1).next();
        localF = b;
        bool = b(localF);
        if ((localF.next()) && (bool)) {
          MethodWriter.a(localF, paramItem, new a(), false);
        }
        if (localObject2 == b)
        {
          localLabel1 = i.a;
          if ((localLabel1 != null) && (localLabel1.equals())) {}
        }
        else
        {
          if (localObject2 != i) {
            break label670;
          }
          localLabel1 = b.a;
          if ((localLabel1 == null) || (!localLabel1.equals())) {
            break label670;
          }
        }
        i = 1;
        break label672;
        i = 0;
        if ((localF.doubleValue() == XLayoutStyle.a) && (!bool))
        {
          if (localF.doubleValue() == XLayoutStyle.a)
          {
            if (localF.length() != 8) {
              if (k == 0) {
                if (localF.i() != 0.0F) {
                  break label916;
                }
              } else {
                break label916;
              }
            }
            if ((localF.f()) || (localF.q()) || (i == 0) || (localF.f())) {
              break label916;
            }
            b(paramF, paramItem, localF);
          }
        }
        else if (!localF.next())
        {
          localLabel1 = b;
          if ((localObject2 == localLabel1) && (i.a == null))
          {
            i = localLabel1.b() + j;
            localF.a(i, localF.getValue() + i);
            b(localF, paramItem);
          }
          else
          {
            localLabel1 = i;
            if ((localObject2 == localLabel1) && (b.a == null))
            {
              i = j - localLabel1.b();
              localF.a(i - localF.getValue(), i);
              b(localF, paramItem);
            }
            else if ((i != 0) && (!localF.f()))
            {
              b(paramItem, localF);
            }
          }
        }
      }
    }
  }
  
  public static void b(f paramF1, Item paramItem, f paramF2)
  {
    float f = paramF2.width();
    int k = b.a.d() + b.b();
    int m = i.a.d() - i.b();
    if (m >= k)
    {
      int j = paramF2.getValue();
      int i = j;
      if (paramF2.length() != 8)
      {
        int n = k;
        if (n == 2)
        {
          if ((paramF1 instanceof MethodWriter)) {
            i = paramF1.getValue();
          } else {
            i = paramF1.l().getValue();
          }
          i = (int)(paramF2.width() * 0.5F * i);
        }
        else
        {
          i = j;
          if (n == 0) {
            i = m - k;
          }
        }
        j = Math.max(l, i);
        i = j;
        n = o;
        if (n > 0) {
          i = Math.min(n, j);
        }
      }
      j = k + (int)((m - k - i) * f + 0.5F);
      paramF2.a(j, j + i);
      b(paramF2, paramItem);
    }
  }
  
  public static boolean b(f paramF)
  {
    XLayoutStyle localXLayoutStyle1 = paramF.doubleValue();
    XLayoutStyle localXLayoutStyle2 = paramF.get();
    MethodWriter localMethodWriter;
    if (paramF.l() != null) {
      localMethodWriter = (MethodWriter)paramF.l();
    } else {
      localMethodWriter = null;
    }
    int i;
    if (((localMethodWriter == null) || (localMethodWriter.doubleValue() == XLayoutStyle.b)) || (((localMethodWriter == null) || (localMethodWriter.get() == XLayoutStyle.b)) || ((localXLayoutStyle1 != XLayoutStyle.b) && (localXLayoutStyle1 != XLayoutStyle.c) && ((localXLayoutStyle1 != XLayoutStyle.a) || (k != 0) || (E != 0.0F) || (!paramF.c(0))) && (!paramF.d())))) {
      i = 0;
    } else {
      i = 1;
    }
    int j;
    if ((localXLayoutStyle2 != XLayoutStyle.b) && (localXLayoutStyle2 != XLayoutStyle.c) && ((localXLayoutStyle2 != XLayoutStyle.a) || (h != 0) || (E != 0.0F) || (!paramF.c(1))) && (!paramF.b())) {
      j = 0;
    } else {
      j = 1;
    }
    if (E > 0.0F)
    {
      if (i != 0) {
        break label225;
      }
      if (j != 0) {
        return true;
      }
    }
    if ((i != 0) && (j != 0))
    {
      return true;
      label225:
      return true;
    }
    return false;
  }
  
  public static void c(h paramH, Item paramItem, int paramInt)
  {
    if (paramH.a())
    {
      if (paramInt == 0)
      {
        b(paramH, paramItem);
        return;
      }
      a(paramH, paramItem);
    }
  }
}
