package org.v7.app;

import a.e.g;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.ComponentName;
import android.content.ContextWrapper;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.BaseBundle;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewManager;
import android.view.ViewParent;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout.LayoutParams;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import java.lang.reflect.Constructor;
import org.core.data.RealVector;
import org.core.fonts.ContextCompat;
import org.core.fonts.data.Group;
import org.core.helpers.ActivityCompat;
import org.core.helpers.NavUtils;
import org.core.view.LayoutInflaterCompat;
import org.core.view.ViewCompat;
import org.core.view.ViewPropertyAnimatorCompat;
import org.core.view.i;
import org.core.view.k;
import org.util.c;
import org.util.d;
import org.v7.R.attr;
import org.v7.R.color;
import org.v7.R.layout;
import org.v7.R.style;
import org.v7.R.styleable;
import org.v7.view.ActionMode;
import org.v7.view.ActionMode.Callback;
import org.v7.view.SupportMenuInflater;
import org.v7.view.menu.MenuBuilder;
import org.v7.view.menu.MenuBuilder.Callback;
import org.v7.view.menu.MenuView;
import org.v7.view.menu.e;
import org.v7.view.menu.e.a;
import org.v7.view.menu.l;
import org.v7.view.menu.l.a;
import org.v7.widget.DecorContentParent;
import org.v7.widget.TintTypedArray;
import org.v7.widget.ViewUtils;
import org.xmlpull.v1.XmlPullParser;

public class AppCompatDelegateImplV7
  extends AppCompatDelegate
  implements MenuBuilder.Callback, LayoutInflater.Factory2
{
  public static final g<String, Integer> c = new org.data.Context();
  public static final boolean h;
  public static boolean l;
  public static final boolean p;
  public static final int[] s;
  public static final boolean y = false;
  public boolean b;
  public int i = -100;
  public Item k;
  public ActionBar mActionBar;
  public ActionMenuPresenterCallback mActionMenuPresenterCallback;
  public ActionMode mActionMode;
  public PopupWindow mActionModePopup;
  public ActionBarContextView mActionModeView;
  public final AppCompatCallback mAppCompatCallback;
  public AppCompatViewInflater mAppCompatViewInflater;
  public boolean mClosingActionMenu;
  public final android.content.Context mContext;
  public DecorContentParent mDecorContentParent;
  public boolean mEnableDefaultActionBarUp;
  public ViewPropertyAnimatorCompat mFadeAnim = null;
  public boolean mFeatureIndeterminateProgress;
  public boolean mFeatureProgress;
  public boolean mHandleNativeActionModes = true;
  public boolean mHasActionBar;
  public int mInvalidatePanelMenuFeatures;
  public boolean mInvalidatePanelMenuPosted;
  public final Runnable mInvalidatePanelMenuRunnable = new MonthByWeekFragment.2(this);
  public boolean mIsDestroyed;
  public boolean mIsFloating;
  public boolean mLongPressBackDown;
  public MenuInflater mMenuInflater;
  public WindowCallbackWrapper mOriginalWindowCallback;
  public boolean mOverlayActionBar;
  public boolean mOverlayActionMode;
  public PanelMenuPresenterCallback mPanelMenuPresenterCallback;
  public PanelFeatureState[] mPanels;
  public PanelFeatureState mPreparedPanel;
  public Runnable mShowActionModePopup;
  public View mStatusGuard;
  public ViewGroup mSubDecor;
  public boolean mSubDecorInstalled;
  public Rect mTempRect1;
  public Rect mTempRect2;
  public TextView mTitleView;
  public Window mWindow;
  public boolean mWindowNoTitle;
  public boolean r;
  public boolean result;
  public int settings;
  public final Object this$0;
  public CharSequence title;
  public boolean trust;
  public Item v;
  public boolean w;
  
  static
  {
    s = new int[] { 16842836 };
    h = "robolectric".equals(Build.FINGERPRINT) ^ true;
    p = true;
    if ((y) && (!l))
    {
      Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(Thread.getDefaultUncaughtExceptionHandler()));
      l = true;
    }
  }
  
  public AppCompatDelegateImplV7(Activity paramActivity, AppCompatCallback paramAppCompatCallback)
  {
    this(paramActivity, null, paramAppCompatCallback, paramActivity);
  }
  
  public AppCompatDelegateImplV7(Dialog paramDialog, AppCompatCallback paramAppCompatCallback)
  {
    this(paramDialog.getContext(), paramDialog.getWindow(), paramAppCompatCallback, paramDialog);
  }
  
  public AppCompatDelegateImplV7(android.content.Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback, Object paramObject)
  {
    mContext = paramContext;
    mAppCompatCallback = paramAppCompatCallback;
    this$0 = paramObject;
    if ((i == -100) && ((paramObject instanceof Dialog)))
    {
      paramContext = inflate();
      if (paramContext != null) {
        i = paramContext.getDelegate().i();
      }
    }
    if (i == -100)
    {
      paramContext = (Integer)c.get(this$0.getClass().getName());
      if (paramContext != null)
      {
        i = paramContext.intValue();
        c.remove(this$0.getClass().getName());
      }
    }
    if (paramWindow != null) {
      onCreate(paramWindow);
    }
    org.v7.widget.Context.a();
  }
  
  public static Configuration init(Configuration paramConfiguration1, Configuration paramConfiguration2)
  {
    Configuration localConfiguration = new Configuration();
    fontScale = 0.0F;
    if (paramConfiguration2 != null)
    {
      if (paramConfiguration1.diff(paramConfiguration2) == 0) {
        return localConfiguration;
      }
      float f1 = fontScale;
      float f2 = fontScale;
      if (f1 != f2) {
        fontScale = f2;
      }
      int j = mcc;
      int m = mcc;
      if (j != m) {
        mcc = m;
      }
      j = mnc;
      m = mnc;
      if (j != m) {
        mnc = m;
      }
      if (Build.VERSION.SDK_INT >= 24) {
        Event.setLocale(paramConfiguration1, paramConfiguration2, localConfiguration);
      } else if (!RealVector.equals(locale, locale)) {
        locale = locale;
      }
      j = touchscreen;
      m = touchscreen;
      if (j != m) {
        touchscreen = m;
      }
      j = keyboard;
      m = keyboard;
      if (j != m) {
        keyboard = m;
      }
      j = keyboardHidden;
      m = keyboardHidden;
      if (j != m) {
        keyboardHidden = m;
      }
      j = navigation;
      m = navigation;
      if (j != m) {
        navigation = m;
      }
      j = navigationHidden;
      m = navigationHidden;
      if (j != m) {
        navigationHidden = m;
      }
      j = orientation;
      m = orientation;
      if (j != m) {
        orientation = m;
      }
      j = screenLayout;
      m = screenLayout;
      if ((j & 0xF) != (m & 0xF)) {
        screenLayout |= m & 0xF;
      }
      j = screenLayout;
      m = screenLayout;
      if ((j & 0xC0) != (m & 0xC0)) {
        screenLayout |= m & 0xC0;
      }
      j = screenLayout;
      m = screenLayout;
      if ((j & 0x30) != (m & 0x30)) {
        screenLayout |= m & 0x30;
      }
      j = screenLayout;
      m = screenLayout;
      if ((j & 0x300) != (m & 0x300)) {
        screenLayout |= m & 0x300;
      }
      if (Build.VERSION.SDK_INT >= 26) {
        SupraCommand.register(paramConfiguration1, paramConfiguration2, localConfiguration);
      }
      j = uiMode;
      m = uiMode;
      if ((j & 0xF) != (m & 0xF)) {
        uiMode |= m & 0xF;
      }
      j = uiMode;
      m = uiMode;
      if ((j & 0x30) != (m & 0x30)) {
        uiMode |= m & 0x30;
      }
      j = screenWidthDp;
      m = screenWidthDp;
      if (j != m) {
        screenWidthDp = m;
      }
      j = screenHeightDp;
      m = screenHeightDp;
      if (j != m) {
        screenHeightDp = m;
      }
      j = smallestScreenWidthDp;
      m = smallestScreenWidthDp;
      if (j != m) {
        smallestScreenWidthDp = m;
      }
      FixedStepHandler.init(paramConfiguration1, paramConfiguration2, localConfiguration);
    }
    return localConfiguration;
  }
  
  public int a(android.content.Context paramContext, int paramInt)
  {
    if (paramInt != -100)
    {
      int j = paramInt;
      if (paramInt != -1)
      {
        if (paramInt != 0)
        {
          if ((paramInt != 1) && (paramInt != 2))
          {
            if (paramInt == 3) {
              return c(paramContext).a();
            }
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          }
        }
        else
        {
          if ((Build.VERSION.SDK_INT >= 23) && (((UiModeManager)paramContext.getApplicationContext().getSystemService(UiModeManager.class)).getNightMode() == 0)) {
            return -1;
          }
          j = a(paramContext).a();
        }
      }
      else {
        return j;
      }
    }
    else
    {
      return -1;
    }
    return paramInt;
  }
  
  public final Configuration a(android.content.Context paramContext, int paramInt, Configuration paramConfiguration)
  {
    if (paramInt != 1)
    {
      if (paramInt != 2) {
        paramInt = getApplicationContextgetResourcesgetConfigurationuiMode & 0x30;
      } else {
        paramInt = 32;
      }
    }
    else {
      paramInt = 16;
    }
    paramContext = new Configuration();
    fontScale = 0.0F;
    if (paramConfiguration != null) {
      paramContext.setTo(paramConfiguration);
    }
    uiMode = (uiMode & 0xFFFFFFCF | paramInt);
    return paramContext;
  }
  
  public final Item a(android.content.Context paramContext)
  {
    if (v == null) {
      v = new Frame(this, TwilightManager.getLastKnownLocation(paramContext));
    }
    return v;
  }
  
  public final void a(int paramInt, boolean paramBoolean, Configuration paramConfiguration)
  {
    Object localObject2 = mContext;
    Object localObject1 = this;
    android.content.res.Resources localResources = ((android.content.Context)localObject2).getResources();
    localObject2 = new Configuration(localResources.getConfiguration());
    if (paramConfiguration != null) {
      ((Configuration)localObject2).updateFrom(paramConfiguration);
    }
    uiMode = (getConfigurationuiMode & 0xFFFFFFCF | paramInt);
    localResources.updateConfiguration((Configuration)localObject2, null);
    if (Build.VERSION.SDK_INT < 26) {
      ClassWriter.a(localResources);
    }
    paramInt = settings;
    if (paramInt != 0)
    {
      paramConfiguration = mContext;
      paramConfiguration.setTheme(paramInt);
      if (Build.VERSION.SDK_INT >= 23) {
        mContext.getTheme().applyStyle(settings, true);
      }
    }
    paramConfiguration = this;
    if (paramBoolean)
    {
      localObject1 = this$0;
      if ((localObject1 instanceof Activity))
      {
        localObject1 = (Activity)localObject1;
        if ((localObject1 instanceof d))
        {
          if (((d)localObject1).getLifecycle().p().a(c.f)) {
            ((Activity)localObject1).onConfigurationChanged((Configuration)localObject2);
          }
          return;
        }
        if (r) {
          ((Activity)localObject1).onConfigurationChanged((Configuration)localObject2);
        }
      }
    }
  }
  
  public final boolean a()
  {
    if (mSubDecorInstalled)
    {
      ViewGroup localViewGroup = mSubDecor;
      if ((localViewGroup != null) && (ViewCompat.get(localViewGroup))) {
        return true;
      }
    }
    return false;
  }
  
  public final boolean a(int paramInt, boolean paramBoolean)
  {
    boolean bool2 = false;
    Object localObject = a(mContext, paramInt, null);
    boolean bool3 = onCreateView();
    int j = mContext.getResources().getConfiguration().uiMode & 0x30;
    int m = uiMode & 0x30;
    boolean bool1 = bool2;
    if (j != m)
    {
      bool1 = bool2;
      if (paramBoolean)
      {
        bool1 = bool2;
        if (!bool3)
        {
          bool1 = bool2;
          if (b) {
            if (!h)
            {
              bool1 = bool2;
              if (!w) {}
            }
            else
            {
              localObject = this$0;
              bool1 = bool2;
              if ((localObject instanceof Activity))
              {
                bool1 = bool2;
                if (!((Activity)localObject).isChild())
                {
                  ActivityCompat.onConfigurationChanged((Activity)this$0);
                  bool1 = true;
                }
              }
            }
          }
        }
      }
    }
    paramBoolean = bool1;
    if (!bool1)
    {
      paramBoolean = bool1;
      if (j != m)
      {
        a(m, bool3, null);
        paramBoolean = true;
      }
    }
    if (paramBoolean)
    {
      localObject = this$0;
      if ((localObject instanceof AppCompatActivity)) {
        ((AppCompatActivity)localObject).onNightModeChanged(paramInt);
      }
    }
    return paramBoolean;
  }
  
  public final boolean a(boolean paramBoolean)
  {
    if (mIsDestroyed) {
      return false;
    }
    int j = e();
    paramBoolean = a(a(mContext, j), paramBoolean);
    if (j == 0)
    {
      a(mContext).show();
    }
    else
    {
      localItem = v;
      if (localItem != null) {
        localItem.set();
      }
    }
    if (j == 3)
    {
      c(mContext).show();
      return paramBoolean;
    }
    Item localItem = k;
    if (localItem != null) {
      localItem.set();
    }
    return paramBoolean;
  }
  
  public final int access$300(org.core.view.Item paramItem, Rect paramRect)
  {
    int j = 0;
    if (paramItem != null) {
      j = paramItem.getSystemWindowInsetTop();
    } else if (paramRect != null) {
      j = top;
    }
    int m = 0;
    int i4 = 0;
    Object localObject = mActionModeView;
    int i2 = j;
    int i3 = m;
    if (localObject != null) {
      if ((((View)localObject).getLayoutParams() instanceof ViewGroup.MarginLayoutParams))
      {
        localObject = (ViewGroup.MarginLayoutParams)mActionModeView.getLayoutParams();
        i2 = 0;
        m = 0;
        int n;
        int i1;
        if (mActionModeView.isShown())
        {
          if (mTempRect1 == null)
          {
            mTempRect1 = new Rect();
            mTempRect2 = new Rect();
          }
          Rect localRect1 = mTempRect1;
          Rect localRect2 = mTempRect2;
          if (paramItem == null) {
            localRect1.set(paramRect);
          } else {
            localRect1.set(paramItem.getSystemWindowInsetLeft(), paramItem.getSystemWindowInsetTop(), paramItem.getSystemWindowInsetRight(), paramItem.getSystemWindowInsetBottom());
          }
          ViewUtils.computeFitSystemWindows(mSubDecor, localRect1, localRect2);
          i2 = top;
          i3 = left;
          i4 = right;
          paramItem = ViewCompat.b(mSubDecor);
          if (paramItem == null) {
            n = 0;
          } else {
            n = paramItem.getSystemWindowInsetLeft();
          }
          if (paramItem == null) {
            i1 = 0;
          } else {
            i1 = paramItem.getSystemWindowInsetRight();
          }
          if ((topMargin != i2) || (leftMargin != i3) || (rightMargin != i4))
          {
            topMargin = i2;
            leftMargin = i3;
            rightMargin = i4;
            m = 1;
          }
          if ((i2 > 0) && (mStatusGuard == null))
          {
            paramItem = new View(mContext);
            mStatusGuard = paramItem;
            paramItem.setVisibility(8);
            paramItem = new FrameLayout.LayoutParams(-1, topMargin, 51);
            leftMargin = n;
            rightMargin = i1;
            mSubDecor.addView(mStatusGuard, -1, paramItem);
          }
          else
          {
            paramItem = mStatusGuard;
            if (paramItem != null)
            {
              paramItem = (ViewGroup.MarginLayoutParams)paramItem.getLayoutParams();
              if ((height != topMargin) || (leftMargin != n) || (rightMargin != i1))
              {
                height = topMargin;
                leftMargin = n;
                rightMargin = i1;
                mStatusGuard.setLayoutParams(paramItem);
              }
            }
          }
          if (mStatusGuard != null) {
            i1 = 1;
          } else {
            i1 = 0;
          }
          if ((i1 != 0) && (mStatusGuard.getVisibility() != 0)) {
            onCreateView(mStatusGuard);
          }
          n = j;
          if (!mOverlayActionMode)
          {
            n = j;
            if (i1 != 0) {
              n = 0;
            }
          }
        }
        else
        {
          n = j;
          i1 = i4;
          m = i2;
          if (topMargin != 0)
          {
            m = 1;
            topMargin = 0;
            n = j;
            i1 = i4;
          }
        }
        i2 = n;
        i3 = i1;
        if (m != 0)
        {
          mActionModeView.setLayoutParams((ViewGroup.LayoutParams)localObject);
          i2 = n;
          i3 = i1;
        }
      }
      else
      {
        i2 = j;
        i3 = m;
      }
    }
    paramItem = mStatusGuard;
    if (paramItem != null)
    {
      if (i3 != 0) {
        j = 0;
      } else {
        j = 8;
      }
      paramItem.setVisibility(j);
    }
    return i2;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    ensureSubDecor();
    ((ViewGroup)mSubDecor.findViewById(16908290)).addView(paramView, paramLayoutParams);
    mOriginalWindowCallback.getDelegate().onContentChanged();
  }
  
  public final void applyFixedSizeWindow()
  {
    ContentFrameLayout localContentFrameLayout = (ContentFrameLayout)mSubDecor.findViewById(16908290);
    Object localObject = mWindow.getDecorView();
    localContentFrameLayout.setDecorPadding(((View)localObject).getPaddingLeft(), ((View)localObject).getPaddingTop(), ((View)localObject).getPaddingRight(), ((View)localObject).getPaddingBottom());
    localObject = mContext.obtainStyledAttributes(R.styleable.AppCompatTheme);
    ((TypedArray)localObject).getValue(R.styleable.AppCompatTheme_windowMinWidthMajor, localContentFrameLayout.getMinWidthMajor());
    ((TypedArray)localObject).getValue(R.styleable.AppCompatTheme_windowMinWidthMinor, localContentFrameLayout.getMinWidthMinor());
    if (((TypedArray)localObject).hasValue(R.styleable.AppCompatTheme_windowFixedWidthMajor)) {
      ((TypedArray)localObject).getValue(R.styleable.AppCompatTheme_windowFixedWidthMajor, localContentFrameLayout.getFixedWidthMajor());
    }
    if (((TypedArray)localObject).hasValue(R.styleable.AppCompatTheme_windowFixedWidthMinor)) {
      ((TypedArray)localObject).getValue(R.styleable.AppCompatTheme_windowFixedWidthMinor, localContentFrameLayout.getFixedWidthMinor());
    }
    if (((TypedArray)localObject).hasValue(R.styleable.AppCompatTheme_windowFixedHeightMajor)) {
      ((TypedArray)localObject).getValue(R.styleable.AppCompatTheme_windowFixedHeightMajor, localContentFrameLayout.getFixedHeightMajor());
    }
    if (((TypedArray)localObject).hasValue(R.styleable.AppCompatTheme_windowFixedHeightMinor)) {
      ((TypedArray)localObject).getValue(R.styleable.AppCompatTheme_windowFixedHeightMinor, localContentFrameLayout.getFixedHeightMinor());
    }
    ((TypedArray)localObject).recycle();
    localContentFrameLayout.requestLayout();
  }
  
  public void b()
  {
    r = true;
    d();
  }
  
  public final Item c(android.content.Context paramContext)
  {
    if (k == null) {
      k = new b(this, paramContext);
    }
    return k;
  }
  
  public void callOnPanelClosed(int paramInt, PanelFeatureState paramPanelFeatureState, Menu paramMenu)
  {
    Object localObject1 = paramPanelFeatureState;
    Object localObject2 = paramMenu;
    if (paramMenu == null)
    {
      PanelFeatureState localPanelFeatureState = paramPanelFeatureState;
      if (paramPanelFeatureState == null)
      {
        localPanelFeatureState = paramPanelFeatureState;
        if (paramInt >= 0)
        {
          localObject1 = mPanels;
          localPanelFeatureState = paramPanelFeatureState;
          if (paramInt < localObject1.length) {
            localPanelFeatureState = localObject1[paramInt];
          }
        }
      }
      localObject1 = localPanelFeatureState;
      localObject2 = paramMenu;
      if (localPanelFeatureState != null)
      {
        localObject2 = menu;
        localObject1 = localPanelFeatureState;
      }
    }
    if ((localObject1 != null) && (!isOpen)) {
      return;
    }
    if (!mIsDestroyed) {
      mOriginalWindowCallback.getDelegate().onPanelClosed(paramInt, (Menu)localObject2);
    }
  }
  
  public void checkCloseActionMenu(MenuBuilder paramMenuBuilder)
  {
    if (mClosingActionMenu) {
      return;
    }
    mClosingActionMenu = true;
    mDecorContentParent.dismissPopups();
    Window.Callback localCallback = getWindowCallback();
    if ((localCallback != null) && (!mIsDestroyed)) {
      localCallback.onPanelClosed(108, paramMenuBuilder);
    }
    mClosingActionMenu = false;
  }
  
  public void closePanel(int paramInt)
  {
    closePanel(getPanelState(paramInt), true);
  }
  
  public void closePanel(PanelFeatureState paramPanelFeatureState, boolean paramBoolean)
  {
    if ((paramBoolean) && (featureId == 0))
    {
      localObject = mDecorContentParent;
      if ((localObject != null) && (((DecorContentParent)localObject).isOverflowMenuShowing()))
      {
        checkCloseActionMenu(menu);
        return;
      }
    }
    Object localObject = (WindowManager)mContext.getSystemService("window");
    if ((localObject != null) && (isOpen))
    {
      ViewGroup localViewGroup = decorView;
      if (localViewGroup != null)
      {
        ((ViewManager)localObject).removeView(localViewGroup);
        if (paramBoolean) {
          callOnPanelClosed(featureId, paramPanelFeatureState, null);
        }
      }
    }
    isPrepared = false;
    isHandled = false;
    isOpen = false;
    shownPanelView = null;
    refreshDecorView = true;
    if (mPreparedPanel == paramPanelFeatureState) {
      mPreparedPanel = null;
    }
  }
  
  public final ViewGroup createSubDecor()
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a7 = a6\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer$LiveA.onUseLocal(UnSSATransformer.java:552)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer$LiveA.onUseLocal(UnSSATransformer.java:1)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.onUse(BaseAnalyze.java:166)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.onUse(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.travel(Cfg.java:331)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.travel(Cfg.java:387)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:90)\n\t... 17 more\n");
  }
  
  public View createView(View paramView, String paramString, android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    Object localObject = mAppCompatViewInflater;
    boolean bool2 = false;
    if (localObject == null)
    {
      localObject = mContext.obtainStyledAttributes(R.styleable.AppCompatTheme).getString(R.styleable.AppCompatTheme_viewInflaterClass);
      if (localObject == null) {
        mAppCompatViewInflater = new AppCompatViewInflater();
      } else {
        try
        {
          mAppCompatViewInflater = ((AppCompatViewInflater)Class.forName((String)localObject).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
        }
        catch (Throwable localThrowable)
        {
          StringBuilder localStringBuilder = new StringBuilder();
          localStringBuilder.append("Failed to instantiate custom view inflater ");
          localStringBuilder.append((String)localObject);
          localStringBuilder.append(". Falling back to default.");
          android.util.Log.i("AppCompatDelegate", localStringBuilder.toString(), localThrowable);
          mAppCompatViewInflater = new AppCompatViewInflater();
        }
      }
    }
    boolean bool1 = false;
    if (y) {
      if ((paramAttributeSet instanceof XmlPullParser))
      {
        bool1 = bool2;
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1) {
          bool1 = true;
        }
      }
      else
      {
        bool1 = shouldInheritContext((ViewParent)paramView);
      }
    }
    localObject = mAppCompatViewInflater;
    bool2 = y;
    org.v7.widget.Log.i();
    return ((AppCompatViewInflater)localObject).createView(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, false);
  }
  
  public boolean d()
  {
    return a(true);
  }
  
  public void dismissPopups()
  {
    Object localObject = mDecorContentParent;
    if (localObject != null) {
      ((DecorContentParent)localObject).dismissPopups();
    }
    if (mActionModePopup != null)
    {
      mWindow.getDecorView().removeCallbacks(mShowActionModePopup);
      if (mActionModePopup.isShowing())
      {
        localObject = mActionModePopup;
        try
        {
          ((PopupWindow)localObject).dismiss();
        }
        catch (IllegalArgumentException localIllegalArgumentException) {}
      }
      mActionModePopup = null;
    }
    endOnGoingFadeAnimation();
    MenuBuilder localMenuBuilder = getPanelState0menu;
    if (localMenuBuilder != null) {
      localMenuBuilder.close();
    }
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    Object localObject = this$0;
    boolean bool = localObject instanceof k;
    int j = 1;
    if ((bool) || ((localObject instanceof AppCompatDialog)))
    {
      localObject = mWindow.getDecorView();
      if ((localObject != null) && (i.a((View)localObject, paramKeyEvent))) {
        return true;
      }
    }
    if ((paramKeyEvent.getKeyCode() == 82) && (mOriginalWindowCallback.getDelegate().dispatchKeyEvent(paramKeyEvent))) {
      return true;
    }
    int m = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0) {
      j = 0;
    }
    if (j != 0) {
      return onKeyDown(m, paramKeyEvent);
    }
    return onKeyUp(m, paramKeyEvent);
  }
  
  public void doInvalidatePanelMenu(int paramInt)
  {
    PanelFeatureState localPanelFeatureState = getPanelState(paramInt);
    if (menu != null)
    {
      Bundle localBundle = new Bundle();
      menu.saveActionViewStates(localBundle);
      if (localBundle.size() > 0) {
        frozenActionViewState = localBundle;
      }
      menu.stopDispatchingItemsChanged();
      menu.clear();
    }
    refreshMenuContent = true;
    refreshDecorView = true;
    if (((paramInt == 108) || (paramInt == 0)) && (mDecorContentParent != null))
    {
      localPanelFeatureState = getPanelState(0);
      isPrepared = false;
      preparePanel(localPanelFeatureState, null);
    }
  }
  
  public final int e()
  {
    int j = i;
    if (j != -100) {
      return j;
    }
    AppCompatDelegate.compare();
    return -100;
  }
  
  public void endOnGoingFadeAnimation()
  {
    ViewPropertyAnimatorCompat localViewPropertyAnimatorCompat = mFadeAnim;
    if (localViewPropertyAnimatorCompat != null) {
      localViewPropertyAnimatorCompat.cancel();
    }
  }
  
  public final void ensureSubDecor()
  {
    if (!mSubDecorInstalled)
    {
      mSubDecor = createSubDecor();
      Object localObject1 = getTitle();
      if (!TextUtils.isEmpty((CharSequence)localObject1))
      {
        Object localObject2 = mDecorContentParent;
        if (localObject2 != null)
        {
          ((DecorContentParent)localObject2).setWindowTitle((CharSequence)localObject1);
        }
        else if (peekSupportActionBar() != null)
        {
          peekSupportActionBar().setWindowTitle((CharSequence)localObject1);
        }
        else
        {
          localObject2 = mTitleView;
          if (localObject2 != null) {
            ((TextView)localObject2).setText((CharSequence)localObject1);
          }
        }
      }
      applyFixedSizeWindow();
      onSubDecorInstalled();
      mSubDecorInstalled = true;
      localObject1 = getPanelState(0);
      if ((!mIsDestroyed) && (menu == null)) {
        invalidatePanelMenu(108);
      }
    }
  }
  
  public final void f()
  {
    Item localItem = v;
    if (localItem != null) {
      localItem.set();
    }
    localItem = k;
    if (localItem != null) {
      localItem.set();
    }
  }
  
  public PanelFeatureState findMenuPanel(Menu paramMenu)
  {
    PanelFeatureState[] arrayOfPanelFeatureState = mPanels;
    int j;
    if (arrayOfPanelFeatureState != null) {
      j = arrayOfPanelFeatureState.length;
    } else {
      j = 0;
    }
    int m = 0;
    while (m < j)
    {
      PanelFeatureState localPanelFeatureState = arrayOfPanelFeatureState[m];
      if ((localPanelFeatureState != null) && (menu == paramMenu)) {
        return localPanelFeatureState;
      }
      m += 1;
    }
    return null;
  }
  
  public View findViewById(int paramInt)
  {
    ensureSubDecor();
    return mWindow.findViewById(paramInt);
  }
  
  public final android.content.Context getActionBarThemedContext()
  {
    android.content.Context localContext = null;
    Object localObject = getSupportActionBar();
    if (localObject != null) {
      localContext = ((ActionBar)localObject).getThemedContext();
    }
    localObject = localContext;
    if (localContext == null) {
      localObject = mContext;
    }
    return localObject;
  }
  
  public final ActionBarDrawerToggle.Delegate getDrawerToggleDelegate()
  {
    return new AppCompatDelegateImplBase.ActionBarDrawableToggleImpl(this);
  }
  
  public MenuInflater getMenuInflater()
  {
    if (mMenuInflater == null)
    {
      initWindowDecorActionBar();
      Object localObject = mActionBar;
      if (localObject != null) {
        localObject = ((ActionBar)localObject).getThemedContext();
      } else {
        localObject = mContext;
      }
      mMenuInflater = new SupportMenuInflater((android.content.Context)localObject);
    }
    return mMenuInflater;
  }
  
  public PanelFeatureState getPanelState(int paramInt)
  {
    Object localObject2 = mPanels;
    Object localObject1 = localObject2;
    if ((localObject2 == null) || (localObject2.length <= paramInt))
    {
      arrayOfPanelFeatureState = new PanelFeatureState[paramInt + 1];
      if (localObject2 != null) {
        System.arraycopy(localObject2, 0, arrayOfPanelFeatureState, 0, localObject2.length);
      }
      localObject1 = arrayOfPanelFeatureState;
      mPanels = arrayOfPanelFeatureState;
    }
    PanelFeatureState[] arrayOfPanelFeatureState = localObject1[paramInt];
    localObject2 = arrayOfPanelFeatureState;
    if (arrayOfPanelFeatureState == null)
    {
      localObject2 = new PanelFeatureState(paramInt);
      localObject1[paramInt] = localObject2;
    }
    return localObject2;
  }
  
  public ActionBar getSupportActionBar()
  {
    initWindowDecorActionBar();
    return mActionBar;
  }
  
  public final CharSequence getTitle()
  {
    Object localObject = this$0;
    if ((localObject instanceof Activity)) {
      return ((Activity)localObject).getTitle();
    }
    return title;
  }
  
  public final Window.Callback getWindowCallback()
  {
    return mWindow.getCallback();
  }
  
  public int i()
  {
    return i;
  }
  
  public final AppCompatActivity inflate()
  {
    for (android.content.Context localContext = mContext; localContext != null; localContext = ((ContextWrapper)localContext).getBaseContext())
    {
      if ((localContext instanceof AppCompatActivity)) {
        return (AppCompatActivity)localContext;
      }
      if (!(localContext instanceof ContextWrapper)) {
        break;
      }
    }
    return null;
  }
  
  public final void initWindowDecorActionBar()
  {
    ensureSubDecor();
    if (mHasActionBar)
    {
      if (mActionBar != null) {
        return;
      }
      Object localObject = this$0;
      if ((localObject instanceof Activity)) {
        mActionBar = new WindowDecorActionBar((Activity)this$0, mOverlayActionBar);
      } else if ((localObject instanceof Dialog)) {
        mActionBar = new WindowDecorActionBar((Dialog)this$0);
      }
      localObject = mActionBar;
      if (localObject != null) {
        ((ActionBar)localObject).setDefaultDisplayHomeAsUpEnabled(mEnableDefaultActionBarUp);
      }
    }
  }
  
  public final boolean initializePanelContent(PanelFeatureState paramPanelFeatureState)
  {
    View localView = createdPanelView;
    if (localView != null)
    {
      shownPanelView = localView;
      return true;
    }
    if (menu == null) {
      return false;
    }
    if (mPanelMenuPresenterCallback == null) {
      mPanelMenuPresenterCallback = new PanelMenuPresenterCallback();
    }
    localView = (View)paramPanelFeatureState.getListMenuView(mPanelMenuPresenterCallback);
    shownPanelView = localView;
    return localView != null;
  }
  
  public final boolean initializePanelDecor(PanelFeatureState paramPanelFeatureState)
  {
    paramPanelFeatureState.setStyle(getActionBarThemedContext());
    decorView = new ListMenuDecorView(listPresenterContext);
    gravity = 81;
    return true;
  }
  
  public final boolean initializePanelMenu(PanelFeatureState paramPanelFeatureState)
  {
    Object localObject3 = mContext;
    int j = featureId;
    if (j != 0)
    {
      localObject1 = localObject3;
      if (j != 108) {}
    }
    else
    {
      localObject1 = localObject3;
      if (mDecorContentParent != null)
      {
        TypedValue localTypedValue = new TypedValue();
        Resources.Theme localTheme = ((android.content.Context)localObject3).getTheme();
        localTheme.resolveAttribute(R.attr.actionBarTheme, localTypedValue, true);
        localObject1 = null;
        if (resourceId != 0)
        {
          localObject2 = ((android.content.Context)localObject3).getResources().newTheme();
          localObject1 = localObject2;
          ((Resources.Theme)localObject2).setTo(localTheme);
          ((Resources.Theme)localObject2).applyStyle(resourceId, true);
          ((Resources.Theme)localObject2).resolveAttribute(R.attr.actionBarWidgetTheme, localTypedValue, true);
        }
        else
        {
          localTheme.resolveAttribute(R.attr.actionBarWidgetTheme, localTypedValue, true);
        }
        Object localObject2 = localObject1;
        if (resourceId != 0)
        {
          localObject2 = localObject1;
          if (localObject1 == null)
          {
            localObject1 = ((android.content.Context)localObject3).getResources().newTheme();
            localObject2 = localObject1;
            ((Resources.Theme)localObject1).setTo(localTheme);
          }
          ((Resources.Theme)localObject2).applyStyle(resourceId, true);
        }
        localObject1 = localObject3;
        if (localObject2 != null)
        {
          localObject3 = new org.v7.view.ContextThemeWrapper((android.content.Context)localObject3, 0);
          localObject1 = localObject3;
          ((org.v7.view.ContextThemeWrapper)localObject3).getTheme().setTo((Resources.Theme)localObject2);
        }
      }
    }
    Object localObject1 = new MenuBuilder((android.content.Context)localObject1);
    ((MenuBuilder)localObject1).setCallback(this);
    paramPanelFeatureState.setMenu((MenuBuilder)localObject1);
    return true;
  }
  
  public void installViewFactory()
  {
    LayoutInflater localLayoutInflater = LayoutInflater.from(mContext);
    if (localLayoutInflater.getFactory() == null)
    {
      LayoutInflaterCompat.setFactory(localLayoutInflater, this);
      return;
    }
    if (!(localLayoutInflater.getFactory2() instanceof AppCompatDelegateImplV7)) {
      android.util.Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
    }
  }
  
  public void invalidateOptionsMenu()
  {
    ActionBar localActionBar = getSupportActionBar();
    if ((localActionBar != null) && (localActionBar.invalidateOptionsMenu())) {
      return;
    }
    invalidatePanelMenu(0);
  }
  
  public final void invalidatePanelMenu(int paramInt)
  {
    mInvalidatePanelMenuFeatures |= 1 << paramInt;
    if (!mInvalidatePanelMenuPosted)
    {
      ViewCompat.postOnAnimation(mWindow.getDecorView(), mInvalidatePanelMenuRunnable);
      mInvalidatePanelMenuPosted = true;
    }
  }
  
  public boolean isHandleNativeActionModesEnabled()
  {
    return mHandleNativeActionModes;
  }
  
  public boolean onBackPressed()
  {
    Object localObject = mActionMode;
    if (localObject != null)
    {
      ((ActionMode)localObject).finish();
      return true;
    }
    localObject = getSupportActionBar();
    return (localObject != null) && (((ActionBar)localObject).collapseActionView());
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    if ((mHasActionBar) && (mSubDecorInstalled))
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null) {
        localActionBar.onConfigurationChanged(paramConfiguration);
      }
    }
    org.v7.widget.Context.get().get(mContext);
    a(false);
  }
  
  public android.content.Context onCreate(android.content.Context paramContext)
  {
    int j = 1;
    b = true;
    int m = a(paramContext, e());
    Object localObject2;
    if ((p) && ((paramContext instanceof android.view.ContextThemeWrapper)))
    {
      Configuration localConfiguration1 = a(paramContext, m, null);
      localObject2 = (android.view.ContextThemeWrapper)paramContext;
      try
      {
        ThemeManager.applyTheme((android.view.ContextThemeWrapper)localObject2, localConfiguration1);
        return paramContext;
      }
      catch (IllegalStateException localIllegalStateException1) {}
    }
    if ((paramContext instanceof org.v7.view.ContextThemeWrapper))
    {
      Configuration localConfiguration2 = a(paramContext, m, null);
      localObject2 = (org.v7.view.ContextThemeWrapper)paramContext;
      try
      {
        ((org.v7.view.ContextThemeWrapper)localObject2).getTheme(localConfiguration2);
        return paramContext;
      }
      catch (IllegalStateException localIllegalStateException2) {}
    }
    if (!h)
    {
      super.onCreate(paramContext);
      return paramContext;
    }
    try
    {
      Object localObject1 = paramContext.getPackageManager().getResourcesForApplication(paramContext.getApplicationInfo()).getConfiguration();
      localObject2 = paramContext.getResources().getConfiguration();
      if (!((Configuration)localObject1).equals((Configuration)localObject2)) {
        localObject1 = init((Configuration)localObject1, (Configuration)localObject2);
      } else {
        localObject1 = null;
      }
      localObject2 = a(paramContext, m, (Configuration)localObject1);
      localObject1 = new org.v7.view.ContextThemeWrapper(paramContext, R.style.Theme_AppCompat_Empty);
      ((org.v7.view.ContextThemeWrapper)localObject1).getTheme((Configuration)localObject2);
      try
      {
        paramContext = paramContext.getTheme();
        if (paramContext == null) {
          j = 0;
        }
      }
      catch (NullPointerException paramContext)
      {
        j = 0;
      }
      if (j != 0) {
        Group.getColor(((org.v7.view.ContextThemeWrapper)localObject1).getTheme());
      }
      super.onCreate((android.content.Context)localObject1);
      return localObject1;
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      throw new RuntimeException("Application failed to obtain resources from itself", paramContext);
    }
  }
  
  public void onCreate()
  {
    if ((this$0 instanceof Activity)) {
      AppCompatDelegate.setTitle(this);
    }
    if (mInvalidatePanelMenuPosted) {
      mWindow.getDecorView().removeCallbacks(mInvalidatePanelMenuRunnable);
    }
    r = false;
    mIsDestroyed = true;
    if (i != -100)
    {
      localObject = this$0;
      if (((localObject instanceof Activity)) && (((Activity)localObject).isChangingConfigurations()))
      {
        c.put(this$0.getClass().getName(), Integer.valueOf(i));
        break label121;
      }
    }
    c.remove(this$0.getClass().getName());
    label121:
    Object localObject = mActionBar;
    if (localObject != null) {
      ((ActionBar)localObject).onDestroy();
    }
    f();
  }
  
  public void onCreate(int paramInt)
  {
    settings = paramInt;
  }
  
  public void onCreate(Bundle paramBundle)
  {
    b = true;
    a(false);
    setContentView();
    Object localObject = this$0;
    if ((localObject instanceof Activity))
    {
      paramBundle = null;
      localObject = (Activity)localObject;
      try
      {
        localObject = NavUtils.getParentActivityName((Activity)localObject);
        paramBundle = (Bundle)localObject;
      }
      catch (IllegalArgumentException localIllegalArgumentException) {}
      if (paramBundle != null)
      {
        paramBundle = peekSupportActionBar();
        if (paramBundle == null) {
          mEnableDefaultActionBarUp = true;
        } else {
          paramBundle.setDefaultDisplayHomeAsUpEnabled(true);
        }
      }
      AppCompatDelegate.create(this);
    }
    w = true;
  }
  
  public final void onCreate(Window paramWindow)
  {
    if (mWindow == null)
    {
      Object localObject = paramWindow.getCallback();
      if (!(localObject instanceof WindowCallbackWrapper))
      {
        localObject = new WindowCallbackWrapper(this, (Window.Callback)localObject);
        mOriginalWindowCallback = ((WindowCallbackWrapper)localObject);
        paramWindow.setCallback((Window.Callback)localObject);
        localObject = TintTypedArray.obtainStyledAttributes(mContext, null, s);
        Drawable localDrawable = ((TintTypedArray)localObject).getDrawableIfKnown(0);
        if (localDrawable != null) {
          paramWindow.setBackgroundDrawable(localDrawable);
        }
        ((TintTypedArray)localObject).recycle();
        mWindow = paramWindow;
        return;
      }
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  public final View onCreateView(View paramView, String paramString, android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return createView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public final void onCreateView(View paramView)
  {
    int j;
    if ((ViewCompat.getWindowSystemUiVisibility(paramView) & 0x2000) != 0) {
      j = 1;
    } else {
      j = 0;
    }
    if (j != 0) {
      j = ContextCompat.getColor(mContext, R.color.abc_decor_view_status_guard_light);
    } else {
      j = ContextCompat.getColor(mContext, R.color.abc_decor_view_status_guard);
    }
    paramView.setBackgroundColor(j);
  }
  
  public final boolean onCreateView()
  {
    if ((!trust) && ((this$0 instanceof Activity)))
    {
      Object localObject1 = mContext.getPackageManager();
      if (localObject1 == null) {
        return false;
      }
      int j = 0;
      if (Build.VERSION.SDK_INT >= 29) {
        j = 269221888;
      } else if (Build.VERSION.SDK_INT >= 24) {
        j = 786432;
      }
      android.content.Context localContext = mContext;
      Object localObject2 = this$0;
      try
      {
        localObject1 = ((PackageManager)localObject1).getActivityInfo(new ComponentName(localContext, localObject2.getClass()), j);
        boolean bool;
        if ((localObject1 != null) && ((configChanges & 0x200) != 0)) {
          bool = true;
        } else {
          bool = false;
        }
        result = bool;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        android.util.Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", localNameNotFoundException);
        result = false;
      }
    }
    trust = true;
    return result;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    boolean bool = true;
    if (paramInt != 4)
    {
      if (paramInt != 82) {
        return false;
      }
      onKeyDownPanel(0, paramKeyEvent);
      return true;
    }
    if ((paramKeyEvent.getFlags() & 0x80) == 0) {
      bool = false;
    }
    mLongPressBackDown = bool;
    return false;
  }
  
  public final boolean onKeyDownPanel(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getRepeatCount() == 0)
    {
      PanelFeatureState localPanelFeatureState = getPanelState(paramInt);
      if (!isOpen) {
        return preparePanel(localPanelFeatureState, paramKeyEvent);
      }
    }
    return false;
  }
  
  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    Object localObject = getSupportActionBar();
    if ((localObject != null) && (((ActionBar)localObject).onKeyShortcut(paramInt, paramKeyEvent))) {
      return true;
    }
    localObject = mPreparedPanel;
    if ((localObject != null) && (performPanelShortcut((PanelFeatureState)localObject, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)))
    {
      paramKeyEvent = mPreparedPanel;
      if (paramKeyEvent != null)
      {
        isHandled = true;
        return true;
      }
    }
    else
    {
      if (mPreparedPanel == null)
      {
        localObject = getPanelState(0);
        preparePanel((PanelFeatureState)localObject, paramKeyEvent);
        boolean bool = performPanelShortcut((PanelFeatureState)localObject, paramKeyEvent.getKeyCode(), paramKeyEvent, 1);
        isPrepared = false;
        if (!bool) {
          break label116;
        }
        return true;
      }
      return false;
    }
    return true;
    label116:
    return false;
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt != 4)
    {
      if (paramInt != 82) {
        return false;
      }
      onKeyUpPanel(0, paramKeyEvent);
      return true;
    }
    boolean bool = mLongPressBackDown;
    mLongPressBackDown = false;
    paramKeyEvent = getPanelState(0);
    if (isOpen)
    {
      if (!bool)
      {
        closePanel(paramKeyEvent, true);
        return true;
      }
    }
    else {
      return onBackPressed();
    }
    return true;
  }
  
  public final boolean onKeyUpPanel(int paramInt, KeyEvent paramKeyEvent)
  {
    if (mActionMode != null) {
      return false;
    }
    boolean bool3 = false;
    PanelFeatureState localPanelFeatureState = getPanelState(paramInt);
    boolean bool1;
    if (paramInt == 0)
    {
      DecorContentParent localDecorContentParent = mDecorContentParent;
      if ((localDecorContentParent != null) && (localDecorContentParent.canShowOverflowMenu()) && (!ViewConfiguration.get(mContext).hasPermanentMenuKey()))
      {
        if (!mDecorContentParent.isOverflowMenuShowing())
        {
          bool1 = bool3;
          if (mIsDestroyed) {
            break label207;
          }
          bool1 = bool3;
          if (!preparePanel(localPanelFeatureState, paramKeyEvent)) {
            break label207;
          }
          bool1 = mDecorContentParent.showOverflowMenu();
          break label207;
        }
        bool1 = mDecorContentParent.hideOverflowMenu();
        break label207;
      }
    }
    if ((!isOpen) && (!isHandled))
    {
      bool1 = bool3;
      if (isPrepared)
      {
        boolean bool2 = true;
        if (refreshMenuContent)
        {
          isPrepared = false;
          bool2 = preparePanel(localPanelFeatureState, paramKeyEvent);
        }
        bool1 = bool3;
        if (bool2)
        {
          openPanel(localPanelFeatureState, paramKeyEvent);
          bool1 = true;
        }
      }
    }
    else
    {
      bool1 = isOpen;
      closePanel(localPanelFeatureState, true);
    }
    label207:
    if (bool1)
    {
      paramKeyEvent = (AudioManager)mContext.getApplicationContext().getSystemService("audio");
      if (paramKeyEvent != null)
      {
        paramKeyEvent.playSoundEffect(0);
        return bool1;
      }
      android.util.Log.w("AppCompatDelegate", "Couldn't get audio manager");
    }
    return bool1;
  }
  
  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    Window.Callback localCallback = getWindowCallback();
    if ((localCallback != null) && (!mIsDestroyed))
    {
      paramMenuBuilder = findMenuPanel(paramMenuBuilder.getRootMenu());
      if (paramMenuBuilder != null) {
        return localCallback.onMenuItemSelected(featureId, paramMenuItem);
      }
    }
    return false;
  }
  
  public void onMenuModeChange(MenuBuilder paramMenuBuilder)
  {
    reopenMenu(true);
  }
  
  public void onMenuOpened(int paramInt)
  {
    if (paramInt == 108)
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null) {
        localActionBar.a(true);
      }
    }
  }
  
  public void onPanelClosed(int paramInt)
  {
    Object localObject;
    if (paramInt == 108)
    {
      localObject = getSupportActionBar();
      if (localObject != null) {
        ((ActionBar)localObject).a(false);
      }
    }
    else if (paramInt == 0)
    {
      localObject = getPanelState(paramInt);
      if (isOpen) {
        closePanel((PanelFeatureState)localObject, false);
      }
    }
  }
  
  public void onPostCreate(Bundle paramBundle)
  {
    ensureSubDecor();
  }
  
  public void onPostResume()
  {
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null) {
      localActionBar.setShowHideAnimationEnabled(true);
    }
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {}
  
  public void onStop()
  {
    r = false;
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null) {
      localActionBar.setShowHideAnimationEnabled(false);
    }
  }
  
  public void onSubDecorInstalled() {}
  
  public final void onTitleChanged(CharSequence paramCharSequence)
  {
    title = paramCharSequence;
    Object localObject = mDecorContentParent;
    if (localObject != null)
    {
      ((DecorContentParent)localObject).setWindowTitle(paramCharSequence);
      return;
    }
    if (peekSupportActionBar() != null)
    {
      peekSupportActionBar().setWindowTitle(paramCharSequence);
      return;
    }
    localObject = mTitleView;
    if (localObject != null) {
      ((TextView)localObject).setText(paramCharSequence);
    }
  }
  
  public final void openPanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if (!isOpen)
    {
      if (mIsDestroyed) {
        return;
      }
      int j;
      if (featureId == 0)
      {
        if ((mContext.getResources().getConfiguration().screenLayout & 0xF) == 4) {
          j = 1;
        } else {
          j = 0;
        }
        if (j != 0) {
          return;
        }
      }
      Object localObject = getWindowCallback();
      if ((localObject != null) && (!((Window.Callback)localObject).onMenuOpened(featureId, menu)))
      {
        closePanel(paramPanelFeatureState, true);
        return;
      }
      WindowManager localWindowManager = (WindowManager)mContext.getSystemService("window");
      if (localWindowManager == null) {
        return;
      }
      if (!preparePanel(paramPanelFeatureState, paramKeyEvent)) {
        return;
      }
      int m = -2;
      if ((decorView != null) && (!refreshDecorView))
      {
        paramKeyEvent = createdPanelView;
        if (paramKeyEvent != null)
        {
          paramKeyEvent = paramKeyEvent.getLayoutParams();
          j = m;
          if (paramKeyEvent == null) {
            break label351;
          }
          j = m;
          if (width != -1) {
            break label351;
          }
          j = -1;
          break label351;
        }
      }
      for (;;)
      {
        j = m;
        break;
        paramKeyEvent = decorView;
        if (paramKeyEvent == null)
        {
          initializePanelDecor(paramPanelFeatureState);
          if (decorView != null) {}
        }
        else if ((refreshDecorView) && (paramKeyEvent.getChildCount() > 0))
        {
          decorView.removeAllViews();
        }
        if ((!initializePanelContent(paramPanelFeatureState)) || (!paramPanelFeatureState.hasPanelItems())) {
          break label417;
        }
        localObject = shownPanelView.getLayoutParams();
        paramKeyEvent = (KeyEvent)localObject;
        if (localObject == null) {
          paramKeyEvent = new ViewGroup.LayoutParams(-2, -2);
        }
        j = background;
        decorView.setBackgroundResource(j);
        localObject = shownPanelView.getParent();
        if ((localObject instanceof ViewGroup)) {
          ((ViewGroup)localObject).removeView(shownPanelView);
        }
        decorView.addView(shownPanelView, paramKeyEvent);
        if (!shownPanelView.hasFocus()) {
          shownPanelView.requestFocus();
        }
      }
      label351:
      isHandled = false;
      paramKeyEvent = new WindowManager.LayoutParams(j, -2, x, y, 1002, 8519680, -3);
      gravity = gravity;
      windowAnimations = windowAnimations;
      localWindowManager.addView(decorView, paramKeyEvent);
      isOpen = true;
      return;
      label417:
      refreshDecorView = true;
    }
  }
  
  public final ActionBar peekSupportActionBar()
  {
    return mActionBar;
  }
  
  public final boolean performPanelShortcut(PanelFeatureState paramPanelFeatureState, int paramInt1, KeyEvent paramKeyEvent, int paramInt2)
  {
    if (paramKeyEvent.isSystem()) {
      return false;
    }
    boolean bool2 = false;
    boolean bool1;
    if (!isPrepared)
    {
      bool1 = bool2;
      if (!preparePanel(paramPanelFeatureState, paramKeyEvent)) {}
    }
    else
    {
      MenuBuilder localMenuBuilder = menu;
      bool1 = bool2;
      if (localMenuBuilder != null) {
        bool1 = localMenuBuilder.performShortcut(paramInt1, paramKeyEvent, paramInt2);
      }
    }
    if ((bool1) && ((paramInt2 & 0x1) == 0) && (mDecorContentParent == null)) {
      closePanel(paramPanelFeatureState, true);
    }
    return bool1;
  }
  
  public final boolean preparePanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if (mIsDestroyed) {
      return false;
    }
    if (isPrepared) {
      return true;
    }
    Object localObject1 = mPreparedPanel;
    if ((localObject1 != null) && (localObject1 != paramPanelFeatureState)) {
      closePanel((PanelFeatureState)localObject1, false);
    }
    localObject1 = getWindowCallback();
    if (localObject1 != null) {
      createdPanelView = ((Window.Callback)localObject1).onCreatePanelView(featureId);
    }
    int j = featureId;
    if ((j != 0) && (j != 108)) {
      j = 0;
    } else {
      j = 1;
    }
    Object localObject2;
    if (j != 0)
    {
      localObject2 = mDecorContentParent;
      if (localObject2 != null) {
        ((DecorContentParent)localObject2).setMenuPrepared();
      }
    }
    if ((createdPanelView == null) && ((j == 0) || (!(peekSupportActionBar() instanceof ToolbarActionBar))))
    {
      if ((menu == null) || (refreshMenuContent))
      {
        if (menu == null)
        {
          initializePanelMenu(paramPanelFeatureState);
          if (menu == null) {
            return false;
          }
        }
        if ((j != 0) && (mDecorContentParent != null))
        {
          if (mActionMenuPresenterCallback == null) {
            mActionMenuPresenterCallback = new ActionMenuPresenterCallback();
          }
          mDecorContentParent.setMenu(menu, mActionMenuPresenterCallback);
        }
        menu.stopDispatchingItemsChanged();
        if (!((Window.Callback)localObject1).onCreatePanelMenu(featureId, menu))
        {
          paramPanelFeatureState.setMenu(null);
          if (j != 0)
          {
            paramPanelFeatureState = mDecorContentParent;
            if (paramPanelFeatureState != null)
            {
              paramPanelFeatureState.setMenu(null, mActionMenuPresenterCallback);
              return false;
            }
          }
        }
        else
        {
          refreshMenuContent = false;
        }
      }
      else
      {
        menu.stopDispatchingItemsChanged();
        localObject2 = frozenActionViewState;
        if (localObject2 != null)
        {
          menu.restoreActionViewStates((Bundle)localObject2);
          frozenActionViewState = null;
        }
        if (!((Window.Callback)localObject1).onPreparePanel(0, createdPanelView, menu))
        {
          if (j != 0)
          {
            paramKeyEvent = mDecorContentParent;
            if (paramKeyEvent != null) {
              paramKeyEvent.setMenu(null, mActionMenuPresenterCallback);
            }
          }
          menu.startDispatchingItemsChanged();
          return false;
        }
        if (paramKeyEvent != null) {
          j = paramKeyEvent.getDeviceId();
        } else {
          j = -1;
        }
        boolean bool;
        if (KeyCharacterMap.load(j).getKeyboardType() != 1) {
          bool = true;
        } else {
          bool = false;
        }
        qwertyMode = bool;
        menu.setQwertyMode(bool);
        menu.startDispatchingItemsChanged();
      }
    }
    else
    {
      isPrepared = true;
      isHandled = false;
      mPreparedPanel = paramPanelFeatureState;
      return true;
    }
    return false;
  }
  
  public final void reopenMenu(boolean paramBoolean)
  {
    Object localObject = mDecorContentParent;
    if ((localObject != null) && (((DecorContentParent)localObject).canShowOverflowMenu()) && ((!ViewConfiguration.get(mContext).hasPermanentMenuKey()) || (mDecorContentParent.isOverflowMenuShowPending())))
    {
      localObject = getWindowCallback();
      if ((mDecorContentParent.isOverflowMenuShowing()) && (paramBoolean))
      {
        mDecorContentParent.hideOverflowMenu();
        if (!mIsDestroyed) {
          ((Window.Callback)localObject).onPanelClosed(108, getPanelState0menu);
        }
      }
      else if ((localObject != null) && (!mIsDestroyed))
      {
        if ((mInvalidatePanelMenuPosted) && ((0x1 & mInvalidatePanelMenuFeatures) != 0))
        {
          mWindow.getDecorView().removeCallbacks(mInvalidatePanelMenuRunnable);
          mInvalidatePanelMenuRunnable.run();
        }
        PanelFeatureState localPanelFeatureState = getPanelState(0);
        MenuBuilder localMenuBuilder = menu;
        if ((localMenuBuilder != null) && (!refreshMenuContent) && (((Window.Callback)localObject).onPreparePanel(0, createdPanelView, localMenuBuilder)))
        {
          ((Window.Callback)localObject).onMenuOpened(108, menu);
          mDecorContentParent.showOverflowMenu();
        }
      }
    }
    else
    {
      localObject = getPanelState(0);
      refreshDecorView = true;
      closePanel((PanelFeatureState)localObject, false);
      openPanel((PanelFeatureState)localObject, null);
    }
  }
  
  public boolean requestWindowFeature(int paramInt)
  {
    paramInt = sanitizeWindowFeatureId(paramInt);
    if ((mWindowNoTitle) && (paramInt == 108)) {
      return false;
    }
    if ((mHasActionBar) && (paramInt == 1)) {
      mHasActionBar = false;
    }
    if (paramInt != 1)
    {
      if (paramInt != 2)
      {
        if (paramInt != 5)
        {
          if (paramInt != 10)
          {
            if (paramInt != 108)
            {
              if (paramInt != 109) {
                return mWindow.requestFeature(paramInt);
              }
              throwFeatureRequestIfSubDecorInstalled();
              mOverlayActionBar = true;
              return true;
            }
            throwFeatureRequestIfSubDecorInstalled();
            mHasActionBar = true;
            return true;
          }
          throwFeatureRequestIfSubDecorInstalled();
          mOverlayActionMode = true;
          return true;
        }
        throwFeatureRequestIfSubDecorInstalled();
        mFeatureProgress = true;
        return true;
      }
      throwFeatureRequestIfSubDecorInstalled();
      mFeatureIndeterminateProgress = true;
      return true;
    }
    throwFeatureRequestIfSubDecorInstalled();
    mWindowNoTitle = true;
    return true;
  }
  
  public final int sanitizeWindowFeatureId(int paramInt)
  {
    if (paramInt == 8)
    {
      android.util.Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    }
    if (paramInt == 9)
    {
      android.util.Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      return 109;
    }
    return paramInt;
  }
  
  public final void setContentView()
  {
    if (mWindow == null)
    {
      Object localObject = this$0;
      if ((localObject instanceof Activity)) {
        onCreate(((Activity)localObject).getWindow());
      }
    }
    if (mWindow != null) {
      return;
    }
    throw new IllegalStateException("We have not been given a Window");
  }
  
  public void setContentView(int paramInt)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)mSubDecor.findViewById(16908290);
    localViewGroup.removeAllViews();
    LayoutInflater.from(mContext).inflate(paramInt, localViewGroup);
    mOriginalWindowCallback.getDelegate().onContentChanged();
  }
  
  public void setContentView(View paramView)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)mSubDecor.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView);
    mOriginalWindowCallback.getDelegate().onContentChanged();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)mSubDecor.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView, paramLayoutParams);
    mOriginalWindowCallback.getDelegate().onContentChanged();
  }
  
  public void setSupportActionBar(Toolbar paramToolbar)
  {
    if (!(this$0 instanceof Activity)) {
      return;
    }
    ActionBar localActionBar = getSupportActionBar();
    if (!(localActionBar instanceof WindowDecorActionBar))
    {
      mMenuInflater = null;
      if (localActionBar != null) {
        localActionBar.onDestroy();
      }
      if (paramToolbar != null)
      {
        paramToolbar = new ToolbarActionBar(paramToolbar, getTitle(), mOriginalWindowCallback);
        mActionBar = paramToolbar;
        mWindow.setCallback(paramToolbar.getWrappedWindowCallback());
      }
      else
      {
        mActionBar = null;
        mWindow.setCallback(mOriginalWindowCallback);
      }
      invalidateOptionsMenu();
      return;
    }
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public final boolean shouldInheritContext(ViewParent paramViewParent)
  {
    if (paramViewParent == null) {
      return false;
    }
    View localView = mWindow.getDecorView();
    for (;;)
    {
      if (paramViewParent == null) {
        return true;
      }
      if ((paramViewParent == localView) || (!(paramViewParent instanceof View))) {
        break;
      }
      if (ViewCompat.isAttachedToWindow((View)paramViewParent)) {
        return false;
      }
      paramViewParent = paramViewParent.getParent();
    }
    return false;
  }
  
  public ActionMode startSupportActionMode(ActionMode.Callback paramCallback)
  {
    if (paramCallback != null)
    {
      Object localObject = mActionMode;
      if (localObject != null) {
        ((ActionMode)localObject).finish();
      }
      paramCallback = new ActionModeCallbackWrapperV7(paramCallback);
      localObject = getSupportActionBar();
      if (localObject != null)
      {
        localObject = ((ActionBar)localObject).startActionMode(paramCallback);
        mActionMode = ((ActionMode)localObject);
        if (localObject != null)
        {
          AppCompatCallback localAppCompatCallback = mAppCompatCallback;
          if (localAppCompatCallback != null) {
            localAppCompatCallback.onSupportActionModeStarted((ActionMode)localObject);
          }
        }
      }
      if (mActionMode == null) {
        mActionMode = startSupportActionModeFromWindow(paramCallback);
      }
      return mActionMode;
    }
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  public ActionMode startSupportActionModeFromWindow(ActionMode.Callback paramCallback)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a16 = a15\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public final void throwFeatureRequestIfSubDecorInstalled()
  {
    if (!mSubDecorInstalled) {
      return;
    }
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  public final class ActionMenuPresenterCallback
    implements l.a
  {
    public ActionMenuPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      checkCloseActionMenu(paramMenuBuilder);
    }
    
    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      Window.Callback localCallback = getWindowCallback();
      if (localCallback != null) {
        localCallback.onMenuOpened(108, paramMenuBuilder);
      }
      return true;
    }
  }
  
  public class ActionModeCallbackWrapperV7
    implements ActionMode.Callback
  {
    public ActionMode.Callback mWrapped;
    
    public ActionModeCallbackWrapperV7(ActionMode.Callback paramCallback)
    {
      mWrapped = paramCallback;
    }
    
    public boolean onActionItemClicked(ActionMode paramActionMode, MenuItem paramMenuItem)
    {
      return mWrapped.onActionItemClicked(paramActionMode, paramMenuItem);
    }
    
    public boolean onCreateActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      return mWrapped.onCreateActionMode(paramActionMode, paramMenu);
    }
    
    public void onDestroyActionMode(ActionMode paramActionMode)
    {
      mWrapped.onDestroyActionMode(paramActionMode);
      paramActionMode = AppCompatDelegateImplV7.this;
      if (mActionModePopup != null) {
        mWindow.getDecorView().removeCallbacks(mShowActionModePopup);
      }
      paramActionMode = AppCompatDelegateImplV7.this;
      if (mActionModeView != null)
      {
        paramActionMode.endOnGoingFadeAnimation();
        paramActionMode = AppCompatDelegateImplV7.this;
        localObject = ViewCompat.animate(mActionModeView);
        ((ViewPropertyAnimatorCompat)localObject).alpha(0.0F);
        mFadeAnim = ((ViewPropertyAnimatorCompat)localObject);
        mFadeAnim.setListener(new g.j.a(this));
      }
      paramActionMode = AppCompatDelegateImplV7.this;
      Object localObject = mAppCompatCallback;
      if (localObject != null) {
        ((AppCompatCallback)localObject).onSupportActionModeFinished(mActionMode);
      }
      paramActionMode = AppCompatDelegateImplV7.this;
      mActionMode = null;
      ViewCompat.requestApplyInsets(mSubDecor);
    }
    
    public boolean onPrepareActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      ViewCompat.requestApplyInsets(mSubDecor);
      return mWrapped.onPrepareActionMode(paramActionMode, paramMenu);
    }
  }
  
  public class ListMenuDecorView
    extends ContentFrameLayout
  {
    public ListMenuDecorView(android.content.Context paramContext)
    {
      super();
    }
    
    public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
    {
      return (AppCompatDelegateImplV7.this.dispatchKeyEvent(paramKeyEvent)) || (super.dispatchKeyEvent(paramKeyEvent));
    }
    
    public final boolean isOutOfBounds(int paramInt1, int paramInt2)
    {
      return (paramInt1 < -5) || (paramInt2 < -5) || (paramInt1 > getWidth() + 5) || (paramInt2 > getHeight() + 5);
    }
    
    public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
    {
      if ((paramMotionEvent.getAction() == 0) && (isOutOfBounds((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())))
      {
        closePanel(0);
        return true;
      }
      return super.onInterceptTouchEvent(paramMotionEvent);
    }
    
    public void setBackgroundResource(int paramInt)
    {
      setBackgroundDrawable(org.v7.internal.util.Resources.getDrawable(getContext(), paramInt));
    }
  }
  
  public final class PanelFeatureState
  {
    public int background;
    public View createdPanelView;
    public ViewGroup decorView;
    public int featureId;
    public Bundle frozenActionViewState;
    public int gravity;
    public boolean isHandled;
    public boolean isOpen;
    public boolean isPrepared;
    public e listMenuPresenter;
    public android.content.Context listPresenterContext;
    public MenuBuilder menu;
    public boolean qwertyMode;
    public boolean refreshDecorView;
    public boolean refreshMenuContent;
    public View shownPanelView;
    public int windowAnimations;
    public int x;
    public int y;
    
    public PanelFeatureState()
    {
      featureId = this$1;
      refreshDecorView = false;
    }
    
    public MenuView getListMenuView(l.a paramA)
    {
      if (menu == null) {
        return null;
      }
      if (listMenuPresenter == null)
      {
        e localE = new e(listPresenterContext, R.layout.abc_list_menu_item_layout);
        listMenuPresenter = localE;
        localE.setCallback(paramA);
        menu.addMenuPresenter(listMenuPresenter);
      }
      return listMenuPresenter.getMenuView(decorView);
    }
    
    public boolean hasPanelItems()
    {
      if (shownPanelView == null) {
        return false;
      }
      if (createdPanelView != null) {
        return true;
      }
      return ((e.a)listMenuPresenter.a()).getCount() > 0;
    }
    
    public void setMenu(MenuBuilder paramMenuBuilder)
    {
      Object localObject = menu;
      if (paramMenuBuilder == localObject) {
        return;
      }
      if (localObject != null) {
        ((MenuBuilder)localObject).removeMenuPresenter(listMenuPresenter);
      }
      menu = paramMenuBuilder;
      if (paramMenuBuilder != null)
      {
        localObject = listMenuPresenter;
        if (localObject != null) {
          paramMenuBuilder.addMenuPresenter((l)localObject);
        }
      }
    }
    
    public void setStyle(android.content.Context paramContext)
    {
      TypedValue localTypedValue = new TypedValue();
      Resources.Theme localTheme = paramContext.getResources().newTheme();
      localTheme.setTo(paramContext.getTheme());
      localTheme.resolveAttribute(R.attr.actionBarPopupTheme, localTypedValue, true);
      int i = resourceId;
      if (i != 0) {
        localTheme.applyStyle(i, true);
      }
      localTheme.resolveAttribute(R.attr.panelMenuListTheme, localTypedValue, true);
      i = resourceId;
      if (i != 0) {
        localTheme.applyStyle(i, true);
      } else {
        localTheme.applyStyle(R.style.Theme_AppCompat_CompactMenu, true);
      }
      paramContext = new org.v7.view.ContextThemeWrapper(paramContext, 0);
      paramContext.getTheme().setTo(localTheme);
      listPresenterContext = paramContext;
      paramContext = paramContext.obtainStyledAttributes(R.styleable.AppCompatTheme);
      background = paramContext.getResourceId(R.styleable.AppCompatTheme_panelBackground, 0);
      windowAnimations = paramContext.getResourceId(R.styleable.AppCompatTheme_android_windowAnimationStyle, 0);
      paramContext.recycle();
    }
  }
  
  public final class PanelMenuPresenterCallback
    implements l.a
  {
    public PanelMenuPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      MenuBuilder localMenuBuilder = paramMenuBuilder.getRootMenu();
      int i;
      if (localMenuBuilder != paramMenuBuilder) {
        i = 1;
      } else {
        i = 0;
      }
      AppCompatDelegateImplV7 localAppCompatDelegateImplV7 = AppCompatDelegateImplV7.this;
      if (i != 0) {
        paramMenuBuilder = localMenuBuilder;
      }
      paramMenuBuilder = localAppCompatDelegateImplV7.findMenuPanel(paramMenuBuilder);
      if (paramMenuBuilder != null)
      {
        if (i != 0)
        {
          callOnPanelClosed(featureId, paramMenuBuilder, localMenuBuilder);
          closePanel(paramMenuBuilder, true);
          return;
        }
        closePanel(paramMenuBuilder, paramBoolean);
      }
    }
    
    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      if (paramMenuBuilder == paramMenuBuilder.getRootMenu())
      {
        Object localObject = AppCompatDelegateImplV7.this;
        if (mHasActionBar)
        {
          localObject = ((AppCompatDelegateImplV7)localObject).getWindowCallback();
          if ((localObject != null) && (!mIsDestroyed)) {
            ((Window.Callback)localObject).onMenuOpened(108, paramMenuBuilder);
          }
        }
      }
      return true;
    }
  }
}
