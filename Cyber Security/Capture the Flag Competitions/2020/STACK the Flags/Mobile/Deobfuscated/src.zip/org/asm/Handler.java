package org.asm;

import a.e.a;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import org.core.view.ViewCompat;
import org.data.Context;
import org.data.Label;

public class Handler
{
  public static ArrayList<ViewGroup> a = new ArrayList();
  public static l b = new i();
  public static ThreadLocal<WeakReference<a<ViewGroup, ArrayList<a.r.l>>>> d = new ThreadLocal();
  
  public static Label a()
  {
    Object localObject = (WeakReference)d.get();
    if (localObject != null)
    {
      localObject = (Label)((WeakReference)localObject).get();
      if (localObject != null) {
        return localObject;
      }
    }
    localObject = new Label();
    WeakReference localWeakReference = new WeakReference(localObject);
    d.set(localWeakReference);
    return localObject;
  }
  
  public static void a(ViewGroup paramViewGroup, l paramL)
  {
    if ((!a.contains(paramViewGroup)) && (ViewCompat.get(paramViewGroup)))
    {
      a.add(paramViewGroup);
      l localL = paramL;
      if (paramL == null) {
        localL = b;
      }
      paramL = localL.b();
      b(paramViewGroup, paramL);
      MethodVisitor.a(paramViewGroup, null);
      show(paramViewGroup, paramL);
    }
  }
  
  public static void b(ViewGroup paramViewGroup, l paramL)
  {
    Object localObject = (ArrayList)a().get(paramViewGroup);
    if ((localObject != null) && (((ArrayList)localObject).size() > 0))
    {
      localObject = ((ArrayList)localObject).iterator();
      while (((Iterator)localObject).hasNext()) {
        ((l)((Iterator)localObject).next()).accept(paramViewGroup);
      }
    }
    if (paramL != null) {
      paramL.a(paramViewGroup, true);
    }
    paramViewGroup = MethodVisitor.getContentView(paramViewGroup);
    if (paramViewGroup == null) {
      return;
    }
    paramViewGroup.invoke();
    throw new NullPointerException("Null throw statement replaced by Soot");
  }
  
  public static void show(ViewGroup paramViewGroup, l paramL)
  {
    if ((paramL != null) && (paramViewGroup != null))
    {
      paramL = new OnSubscribeViewDetachedFromWindowFirst.SubscriptionAdapter(paramL, paramViewGroup);
      paramViewGroup.addOnAttachStateChangeListener(paramL);
      paramViewGroup.getViewTreeObserver().addOnPreDrawListener(paramL);
    }
  }
}
