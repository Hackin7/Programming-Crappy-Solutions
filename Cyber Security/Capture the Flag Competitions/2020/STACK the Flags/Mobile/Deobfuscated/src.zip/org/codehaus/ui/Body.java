package org.codehaus.ui;

public abstract class Body {}
