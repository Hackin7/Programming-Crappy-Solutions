package org.objectweb.asm;

import androidx.recyclerview.widget.RecyclerView;

public class e
{
  public RecyclerView a;
  public int b;
  public int c;
  public int k;
  public boolean l;
  
  public e() {}
  
  public void b()
  {
    l = false;
    c = 0;
    b = 0;
    a = null;
    k = 0;
  }
}
