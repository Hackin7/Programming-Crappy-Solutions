package org.asm;

import android.animation.Animator;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

public abstract class g
  extends l
{
  public static final String[] a = { "android:visibility:visibility", "android:visibility:parent" };
  public int c = 3;
  
  public g() {}
  
  public abstract Animator a(ViewGroup paramViewGroup, View paramView, Label paramLabel1, Label paramLabel2);
  
  public Animator a(ViewGroup paramViewGroup, Label paramLabel1, Label paramLabel2)
  {
    f0.b localB = b(paramLabel1, paramLabel2);
    if ((l) && ((g != null) || (a != null)))
    {
      if (c) {
        return b(paramViewGroup, paramLabel1, paramLabel2);
      }
      return a(paramViewGroup, paramLabel1, paramLabel2, b);
    }
    return null;
  }
  
  public Animator a(ViewGroup paramViewGroup, Label paramLabel1, Label paramLabel2, int paramInt)
  {
    if ((c & 0x2) != 2) {
      return null;
    }
    Object localObject2;
    if (paramLabel1 != null) {
      localObject2 = a;
    } else {
      localObject2 = null;
    }
    Object localObject1;
    if (paramLabel2 != null) {
      localObject1 = a;
    } else {
      localObject1 = null;
    }
    Object localObject5 = null;
    Object localObject4 = null;
    Object localObject3;
    int i;
    if ((localObject1 != null) && (((View)localObject1).getParent() != null))
    {
      if (paramInt == 4)
      {
        localObject3 = localObject1;
        localObject1 = localObject5;
      }
      else if (localObject2 == localObject1)
      {
        localObject3 = localObject1;
        localObject1 = localObject5;
      }
      else if (w)
      {
        localObject1 = localObject2;
        localObject3 = localObject4;
      }
      else
      {
        localObject1 = c.a(paramViewGroup, (View)localObject2, (View)((View)localObject2).getParent());
        localObject3 = localObject4;
      }
    }
    else if (localObject1 != null)
    {
      localObject3 = localObject4;
    }
    else
    {
      localObject1 = localObject5;
      localObject3 = localObject4;
      if (localObject2 != null) {
        if (((View)localObject2).getParent() == null)
        {
          localObject1 = localObject2;
          localObject3 = localObject4;
        }
        else
        {
          localObject1 = localObject5;
          localObject3 = localObject4;
          if ((((View)localObject2).getParent() instanceof View))
          {
            View localView = (View)((View)localObject2).getParent();
            if (!bdrawbl)
            {
              localObject1 = c.a(paramViewGroup, (View)localObject2, localView);
              localObject3 = localObject4;
            }
            else
            {
              localObject1 = localObject5;
              localObject3 = localObject4;
              if (localView.getParent() == null)
              {
                i = localView.getId();
                localObject1 = localObject5;
                localObject3 = localObject4;
                if (i != -1)
                {
                  localObject1 = localObject5;
                  localObject3 = localObject4;
                  if (paramViewGroup.findViewById(i) != null)
                  {
                    localObject1 = localObject5;
                    localObject3 = localObject4;
                    if (w)
                    {
                      localObject1 = localObject2;
                      localObject3 = localObject4;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if ((localObject1 != null) && (paramLabel1 != null))
    {
      localObject2 = (int[])c.get("android:visibility:screenLocation");
      paramInt = localObject2[0];
      i = localObject2[1];
      localObject2 = new int[2];
      paramViewGroup.getLocationOnScreen((int[])localObject2);
      ((View)localObject1).offsetLeftAndRight(paramInt - localObject2[0] - ((View)localObject1).getLeft());
      ((View)localObject1).offsetTopAndBottom(i - localObject2[1] - ((View)localObject1).getTop());
      localObject2 = Type.a(paramViewGroup);
      ((ByteVector)localObject2).b((View)localObject1);
      paramViewGroup = b(paramViewGroup, (View)localObject1, paramLabel1, paramLabel2);
      if (paramViewGroup == null)
      {
        ((ByteVector)localObject2).a((View)localObject1);
        return paramViewGroup;
      }
      paramViewGroup.addListener(new TwoCardOverlayAnimation.2(this, (Item)localObject2, (View)localObject1));
      return paramViewGroup;
    }
    if (localObject3 != null)
    {
      i = localObject3.getVisibility();
      Log.set(localObject3, 0);
      paramViewGroup = b(paramViewGroup, localObject3, paramLabel1, paramLabel2);
      if (paramViewGroup != null)
      {
        paramLabel1 = new f0.a(localObject3, paramInt, true);
        paramViewGroup.addListener(paramLabel1);
        ClassReader.b(paramViewGroup, paramLabel1);
        a(paramLabel1);
        return paramViewGroup;
      }
      Log.set(localObject3, i);
      return paramViewGroup;
    }
    return null;
  }
  
  public void a(Label paramLabel)
  {
    show(paramLabel);
  }
  
  public boolean a(Label paramLabel1, Label paramLabel2)
  {
    if ((paramLabel1 == null) && (paramLabel2 == null)) {
      return false;
    }
    if ((paramLabel1 != null) && (paramLabel2 != null) && (c.containsKey("android:visibility:visibility") != c.containsKey("android:visibility:visibility"))) {
      return false;
    }
    paramLabel1 = b(paramLabel1, paramLabel2);
    return (l) && ((i == 0) || (b == 0));
  }
  
  public abstract Animator b(ViewGroup paramViewGroup, View paramView, Label paramLabel1, Label paramLabel2);
  
  public Animator b(ViewGroup paramViewGroup, Label paramLabel1, Label paramLabel2)
  {
    if ((c & 0x1) == 1)
    {
      if (paramLabel2 == null) {
        return null;
      }
      if (paramLabel1 == null)
      {
        View localView = (View)a.getParent();
        if (bbdrawl) {
          return null;
        }
      }
      return a(paramViewGroup, a, paramLabel1, paramLabel2);
    }
    return null;
  }
  
  public final f0.b b(Label paramLabel1, Label paramLabel2)
  {
    f0.b localB = new f0.b();
    l = false;
    c = false;
    if ((paramLabel1 != null) && (c.containsKey("android:visibility:visibility")))
    {
      i = ((Integer)c.get("android:visibility:visibility")).intValue();
      g = ((ViewGroup)c.get("android:visibility:parent"));
    }
    else
    {
      i = -1;
      g = null;
    }
    if ((paramLabel2 != null) && (c.containsKey("android:visibility:visibility")))
    {
      b = ((Integer)c.get("android:visibility:visibility")).intValue();
      a = ((ViewGroup)c.get("android:visibility:parent"));
    }
    else
    {
      b = -1;
      a = null;
    }
    if ((paramLabel1 != null) && (paramLabel2 != null))
    {
      if ((i == b) && (g == a)) {
        return localB;
      }
      int i = i;
      int j = b;
      if (i != j)
      {
        if (i == 0)
        {
          c = false;
          l = true;
          return localB;
        }
        if (j == 0)
        {
          c = true;
          l = true;
          return localB;
        }
      }
      else
      {
        if (a == null)
        {
          c = false;
          l = true;
          return localB;
        }
        if (g == null)
        {
          c = true;
          l = true;
          return localB;
        }
      }
    }
    else
    {
      if ((paramLabel1 == null) && (b == 0))
      {
        c = true;
        l = true;
        return localB;
      }
      if ((paramLabel2 == null) && (i == 0))
      {
        c = false;
        l = true;
      }
    }
    return localB;
  }
  
  public void b(int paramInt)
  {
    if ((paramInt & 0xFFFFFFFC) == 0)
    {
      c = paramInt;
      return;
    }
    throw new IllegalArgumentException("Only MODE_IN and MODE_OUT flags are allowed");
  }
  
  public void b(Label paramLabel)
  {
    show(paramLabel);
  }
  
  public String[] c()
  {
    return a;
  }
  
  public final void show(Label paramLabel)
  {
    int i = a.getVisibility();
    c.put("android:visibility:visibility", Integer.valueOf(i));
    c.put("android:visibility:parent", a.getParent());
    int[] arrayOfInt = new int[2];
    a.getLocationOnScreen(arrayOfInt);
    c.put("android:visibility:screenLocation", arrayOfInt);
  }
}
