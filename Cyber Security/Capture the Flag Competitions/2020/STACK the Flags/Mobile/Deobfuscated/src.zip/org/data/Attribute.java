package org.data;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

public final class Attribute
  implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V>
{
  public int index;
  public int key;
  public boolean value = false;
  
  public Attribute(MapCollections paramMapCollections)
  {
    key = (paramMapCollections.size() - 1);
    index = -1;
  }
  
  public boolean equals(Object paramObject)
  {
    if (value)
    {
      if (!(paramObject instanceof Map.Entry)) {
        return false;
      }
      paramObject = (Map.Entry)paramObject;
      return (ContainerHelpers.equal(paramObject.getKey(), parent.get(index, 0))) && (ContainerHelpers.equal(paramObject.getValue(), parent.get(index, 1)));
    }
    throw new IllegalStateException("This container does not support retaining Map.Entry objects");
  }
  
  public Object getKey()
  {
    if (value) {
      return parent.get(index, 0);
    }
    throw new IllegalStateException("This container does not support retaining Map.Entry objects");
  }
  
  public Object getValue()
  {
    if (value) {
      return parent.get(index, 1);
    }
    throw new IllegalStateException("This container does not support retaining Map.Entry objects");
  }
  
  public boolean hasNext()
  {
    return index < key;
  }
  
  public int hashCode()
  {
    if (value)
    {
      Object localObject1 = parent;
      int i = index;
      int j = 0;
      localObject1 = ((MapCollections)localObject1).get(i, 0);
      Object localObject2 = parent.get(index, 1);
      if (localObject1 == null) {
        i = 0;
      } else {
        i = localObject1.hashCode();
      }
      if (localObject2 != null) {
        j = localObject2.hashCode();
      }
      return j ^ i;
    }
    throw new IllegalStateException("This container does not support retaining Map.Entry objects");
  }
  
  public void remove()
  {
    if (value)
    {
      parent.remove(index);
      index -= 1;
      key -= 1;
      value = false;
      return;
    }
    throw new IllegalStateException();
  }
  
  public Object setValue(Object paramObject)
  {
    if (value) {
      return parent.put(index, paramObject);
    }
    throw new IllegalStateException("This container does not support retaining Map.Entry objects");
  }
  
  public Map.Entry setValue()
  {
    if (hasNext())
    {
      index += 1;
      value = true;
      return this;
    }
    throw new NoSuchElementException();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(getKey());
    localStringBuilder.append("=");
    localStringBuilder.append(getValue());
    return localStringBuilder.toString();
  }
}
