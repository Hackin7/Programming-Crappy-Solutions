package org.codehaus.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import java.util.Arrays;

public class ClassWriter
{
  public static SparseIntArray mAlphaIndexer;
  public boolean A = true;
  public int K = -1;
  public int L = -1;
  public int M = -1;
  public boolean a = false;
  public int active = -1;
  public int b = -1;
  public int c = -1;
  public int cipher = 0;
  public int color = -1;
  public int count = 0;
  public int d = -1;
  public String data = null;
  public int digest = 0;
  public int dir = -1;
  public int e = -1;
  public int g = -1;
  public float h = 0.0F;
  public int i = 0;
  public int icon = -1;
  public int id = -1;
  public int image = -1;
  public int index = -1;
  public int j;
  public boolean k = false;
  public int key = -1;
  public int length = -1;
  public boolean m = false;
  public int m_count = -1;
  public int m_radius = -1;
  public float max = 1.0F;
  public float min = 1.0F;
  public int mode = -1;
  public int n = -1;
  public int name = -1;
  public int normal = -1;
  public float normalImpulse = 0.5F;
  public int normalMass = -1;
  public int[] o;
  public int out = -1;
  public int p = -1;
  public int pointCount = -1;
  public int points = -1;
  public int q;
  public int r = 0;
  public int radius = -1;
  public int s = -1;
  public int size = -1;
  public float start = -1.0F;
  public int state = -1;
  public String t;
  public float tangentImpulse = 0.5F;
  public int text = 0;
  public int type = -1;
  public String u;
  public int v = -1;
  public int value = -1;
  public int version = -1;
  public boolean w = false;
  public int wrap = -1;
  public float x = -1.0F;
  public float y = -1.0F;
  
  static
  {
    SparseIntArray localSparseIntArray = new SparseIntArray();
    mAlphaIndexer = localSparseIntArray;
    localSparseIntArray.append(IpAddress.Layout_layout_constraintLeft_toLeftOf, 24);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintLeft_toRightOf, 25);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintRight_toLeftOf, 28);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintRight_toRightOf, 29);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintTop_toTopOf, 35);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintTop_toBottomOf, 34);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintBottom_toTopOf, 4);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintBottom_toBottomOf, 3);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintBaseline_toBaselineOf, 1);
    mAlphaIndexer.append(IpAddress.Layout_layout_editor_absoluteX, 6);
    mAlphaIndexer.append(IpAddress.Layout_layout_editor_absoluteY, 7);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintGuide_begin, 17);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintGuide_end, 18);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintGuide_percent, 19);
    mAlphaIndexer.append(IpAddress.Layout_android_orientation, 26);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintStart_toEndOf, 31);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintStart_toStartOf, 32);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintEnd_toStartOf, 10);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintEnd_toEndOf, 9);
    mAlphaIndexer.append(IpAddress.Layout_layout_goneMarginLeft, 13);
    mAlphaIndexer.append(IpAddress.Layout_layout_goneMarginTop, 16);
    mAlphaIndexer.append(IpAddress.Layout_layout_goneMarginRight, 14);
    mAlphaIndexer.append(IpAddress.Layout_layout_goneMarginBottom, 11);
    mAlphaIndexer.append(IpAddress.Layout_layout_goneMarginStart, 15);
    mAlphaIndexer.append(IpAddress.Layout_layout_goneMarginEnd, 12);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintVertical_weight, 38);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintHorizontal_weight, 37);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintHorizontal_chainStyle, 39);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintVertical_chainStyle, 40);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintHorizontal_bias, 20);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintVertical_bias, 36);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintDimensionRatio, 5);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintLeft_creator, 76);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintTop_creator, 76);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintRight_creator, 76);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintBottom_creator, 76);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintBaseline_creator, 76);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_marginLeft, 23);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_marginRight, 27);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_marginStart, 30);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_marginEnd, 8);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_marginTop, 33);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_marginBottom, 2);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_width, 22);
    mAlphaIndexer.append(IpAddress.Layout_android_layout_height, 21);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintCircle, 61);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintCircleRadius, 62);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintCircleAngle, 63);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintWidth_percent, 69);
    mAlphaIndexer.append(IpAddress.Layout_layout_constraintHeight_percent, 70);
    mAlphaIndexer.append(IpAddress.Layout_chainUseRtl, 71);
    mAlphaIndexer.append(IpAddress.Layout_barrierDirection, 72);
    mAlphaIndexer.append(IpAddress.Layout_barrierMargin, 73);
    mAlphaIndexer.append(IpAddress.Layout_constraint_referenced_ids, 74);
    mAlphaIndexer.append(IpAddress.Layout_barrierAllowsGoneWidgets, 75);
  }
  
  public ClassWriter() {}
  
  public void init(Context paramContext, AttributeSet paramAttributeSet)
  {
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.Layout);
    k = true;
    int i2 = paramContext.getIndexCount();
    int i1 = 0;
    while (i1 < i2)
    {
      int i3 = paramContext.getIndex(i1);
      int i4 = mAlphaIndexer.get(i3);
      if (i4 != 80)
      {
        if (i4 != 81) {
          switch (i4)
          {
          default: 
            switch (i4)
            {
            default: 
              switch (i4)
              {
              default: 
                switch (i4)
                {
                default: 
                  paramAttributeSet = new StringBuilder();
                  paramAttributeSet.append("Unknown attribute 0x");
                  paramAttributeSet.append(Integer.toHexString(i3));
                  paramAttributeSet.append("   ");
                  paramAttributeSet.append(mAlphaIndexer.get(i3));
                  Log.w("ConstraintSet", paramAttributeSet.toString());
                  break;
                case 77: 
                  t = paramContext.getString(i3);
                  break;
                case 76: 
                  paramAttributeSet = new StringBuilder();
                  paramAttributeSet.append("unused attribute 0x");
                  paramAttributeSet.append(Integer.toHexString(i3));
                  paramAttributeSet.append("   ");
                  paramAttributeSet.append(mAlphaIndexer.get(i3));
                  Log.w("ConstraintSet", paramAttributeSet.toString());
                  break;
                case 75: 
                  A = paramContext.getBoolean(i3, A);
                  break;
                case 74: 
                  u = paramContext.getString(i3);
                  break;
                case 73: 
                  r = paramContext.getDimensionPixelSize(i3, r);
                  break;
                case 72: 
                  n = paramContext.getInt(i3, n);
                  break;
                case 71: 
                  Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                  break;
                case 70: 
                  min = paramContext.getFloat(i3, 1.0F);
                  break;
                case 69: 
                  max = paramContext.getFloat(i3, 1.0F);
                }
                break;
              case 63: 
                h = paramContext.getFloat(i3, h);
                break;
              case 62: 
                i = paramContext.getDimensionPixelSize(i3, i);
                break;
              case 61: 
                length = Item.getString(paramContext, i3, length);
              }
              break;
            case 59: 
              m_count = paramContext.getDimensionPixelSize(i3, m_count);
              break;
            case 58: 
              m_radius = paramContext.getDimensionPixelSize(i3, m_radius);
              break;
            case 57: 
              pointCount = paramContext.getDimensionPixelSize(i3, pointCount);
              break;
            case 56: 
              radius = paramContext.getDimensionPixelSize(i3, radius);
              break;
            case 55: 
              digest = paramContext.getInt(i3, digest);
              break;
            case 54: 
              cipher = paramContext.getInt(i3, cipher);
            }
            break;
          case 40: 
            count = paramContext.getInt(i3, count);
            break;
          case 39: 
            text = paramContext.getInt(i3, text);
            break;
          case 38: 
            start = paramContext.getFloat(i3, start);
            break;
          case 37: 
            y = paramContext.getFloat(i3, y);
            break;
          case 36: 
            tangentImpulse = paramContext.getFloat(i3, tangentImpulse);
            break;
          case 35: 
            active = Item.getString(paramContext, i3, active);
            break;
          case 34: 
            mode = Item.getString(paramContext, i3, mode);
            break;
          case 33: 
            wrap = paramContext.getDimensionPixelSize(i3, wrap);
            break;
          case 32: 
            color = Item.getString(paramContext, i3, color);
            break;
          case 31: 
            b = Item.getString(paramContext, i3, b);
            break;
          case 30: 
            image = paramContext.getDimensionPixelSize(i3, image);
            break;
          case 29: 
            value = Item.getString(paramContext, i3, value);
            break;
          case 28: 
            key = Item.getString(paramContext, i3, key);
            break;
          case 27: 
            index = paramContext.getDimensionPixelSize(i3, index);
            break;
          case 26: 
            id = paramContext.getInt(i3, id);
            break;
          case 25: 
            e = Item.getString(paramContext, i3, e);
            break;
          case 24: 
            d = Item.getString(paramContext, i3, d);
            break;
          case 23: 
            c = paramContext.getDimensionPixelSize(i3, c);
            break;
          case 22: 
            q = paramContext.getLayoutDimension(i3, q);
            break;
          case 21: 
            j = paramContext.getLayoutDimension(i3, j);
            break;
          case 20: 
            normalImpulse = paramContext.getFloat(i3, normalImpulse);
            break;
          case 19: 
            x = paramContext.getFloat(i3, x);
            break;
          case 18: 
            p = paramContext.getDimensionPixelOffset(i3, p);
            break;
          case 17: 
            s = paramContext.getDimensionPixelOffset(i3, s);
            break;
          case 16: 
            K = paramContext.getDimensionPixelSize(i3, K);
            break;
          case 15: 
            points = paramContext.getDimensionPixelSize(i3, points);
            break;
          case 14: 
            normal = paramContext.getDimensionPixelSize(i3, normal);
            break;
          case 13: 
            normalMass = paramContext.getDimensionPixelSize(i3, normalMass);
            break;
          case 12: 
            L = paramContext.getDimensionPixelSize(i3, L);
            break;
          case 11: 
            M = paramContext.getDimensionPixelSize(i3, M);
            break;
          case 10: 
            size = Item.getString(paramContext, i3, size);
            break;
          case 9: 
            version = Item.getString(paramContext, i3, version);
            break;
          case 8: 
            out = paramContext.getDimensionPixelSize(i3, out);
            break;
          case 7: 
            state = paramContext.getDimensionPixelOffset(i3, state);
            break;
          case 6: 
            type = paramContext.getDimensionPixelOffset(i3, type);
            break;
          case 5: 
            data = paramContext.getString(i3);
            break;
          case 4: 
            name = Item.getString(paramContext, i3, name);
            break;
          case 3: 
            icon = Item.getString(paramContext, i3, icon);
            break;
          case 2: 
            dir = paramContext.getDimensionPixelSize(i3, dir);
            break;
          case 1: 
            g = Item.getString(paramContext, i3, g);
            break;
          }
        } else {
          a = paramContext.getBoolean(i3, a);
        }
      }
      else {
        w = paramContext.getBoolean(i3, w);
      }
      i1 += 1;
    }
    paramContext.recycle();
  }
  
  public void init(ClassWriter paramClassWriter)
  {
    m = m;
    q = q;
    k = k;
    j = j;
    s = s;
    p = p;
    x = x;
    d = d;
    e = e;
    key = key;
    value = value;
    active = active;
    mode = mode;
    name = name;
    icon = icon;
    g = g;
    b = b;
    color = color;
    size = size;
    version = version;
    normalImpulse = normalImpulse;
    tangentImpulse = tangentImpulse;
    data = data;
    length = length;
    i = i;
    h = h;
    type = type;
    state = state;
    id = id;
    c = c;
    index = index;
    wrap = wrap;
    dir = dir;
    out = out;
    image = image;
    normalMass = normalMass;
    K = K;
    normal = normal;
    M = M;
    L = L;
    points = points;
    start = start;
    y = y;
    text = text;
    count = count;
    cipher = cipher;
    digest = digest;
    radius = radius;
    pointCount = pointCount;
    m_radius = m_radius;
    m_count = m_count;
    max = max;
    min = min;
    n = n;
    r = r;
    v = v;
    t = t;
    int[] arrayOfInt = o;
    if (arrayOfInt != null) {
      o = Arrays.copyOf(arrayOfInt, arrayOfInt.length);
    } else {
      o = null;
    }
    u = u;
    w = w;
    a = a;
    A = A;
  }
}
