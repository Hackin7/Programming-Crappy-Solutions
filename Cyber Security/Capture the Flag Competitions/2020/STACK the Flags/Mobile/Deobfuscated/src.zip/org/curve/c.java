package org.curve;

import androidx.activity.OnBackPressedDispatcher;
import org.util.d;

public abstract interface c
  extends d
{
  public abstract OnBackPressedDispatcher getOnBackPressedDispatcher();
}
