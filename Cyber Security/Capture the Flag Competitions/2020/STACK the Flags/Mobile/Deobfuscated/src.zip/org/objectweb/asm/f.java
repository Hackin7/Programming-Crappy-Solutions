package org.objectweb.asm;

import a.e.a;
import a.e.d;
import a.o.c.m.a;
import androidx.recyclerview.widget.RecyclerView.b0;
import androidx.recyclerview.widget.RecyclerView.d;
import androidx.recyclerview.widget.RecyclerView.l.c;
import org.data.Context;
import org.data.Item;
import org.data.Label;

public class f
{
  public final a<RecyclerView.b0, m.a> a = new Label();
  public final d<RecyclerView.b0> j = new Item();
  
  public f() {}
  
  public final RecyclerView.l.c a(RecyclerView.b0 paramB0, int paramInt)
  {
    int i = a.read(paramB0);
    if (i < 0) {
      return null;
    }
    h localH = (h)a.get(i);
    if (localH != null)
    {
      int k = c;
      if ((k & paramInt) != 0)
      {
        c = (paramInt & k);
        if (paramInt == 4)
        {
          paramB0 = j;
        }
        else
        {
          if (paramInt != 8) {
            break label109;
          }
          paramB0 = l;
        }
        if ((c & 0xC) != 0) {
          return paramB0;
        }
        a.write(i);
        h.b(localH);
        return paramB0;
        label109:
        throw new IllegalArgumentException("Must provide flag PRE or POST");
      }
    }
    return null;
    return paramB0;
  }
  
  public void a(RecyclerView.b0 paramB0)
  {
    paramB0 = (h)a.get(paramB0);
    if (paramB0 == null) {
      return;
    }
    c &= 0xFFFFFFFE;
  }
  
  public void a(RecyclerView.b0 paramB0, RecyclerView.l.c paramC)
  {
    h localH2 = (h)a.get(paramB0);
    h localH1 = localH2;
    if (localH2 == null)
    {
      localH2 = h.a();
      localH1 = localH2;
      a.put(paramB0, localH2);
    }
    l = paramC;
    c |= 0x8;
  }
  
  public void a(MethodVisitor paramMethodVisitor)
  {
    Object localObject1 = a;
    f localF = this;
    int i = ((Context)localObject1).size() - 1;
    while (i >= 0)
    {
      localObject1 = (RecyclerView.b0)a.getValue(i);
      Object localObject2 = a;
      localObject2 = (h)((Context)localObject2).write(i);
      int k = c;
      if ((k & 0x3) == 3)
      {
        ((RecyclerView.d)paramMethodVisitor).run((RecyclerView.b0)localObject1);
      }
      else
      {
        RecyclerView.l.c localC1;
        RecyclerView.l.c localC2;
        if ((k & 0x1) != 0)
        {
          localC1 = j;
          if (localC1 == null)
          {
            ((RecyclerView.d)paramMethodVisitor).run((RecyclerView.b0)localObject1);
          }
          else
          {
            localC2 = l;
            ((RecyclerView.d)paramMethodVisitor).visitFrame((RecyclerView.b0)localObject1, localC1, localC2);
          }
        }
        else if ((k & 0xE) == 14)
        {
          localC1 = j;
          localC2 = l;
          ((RecyclerView.d)paramMethodVisitor).a((RecyclerView.b0)localObject1, localC1, localC2);
        }
        else if ((k & 0xC) == 12)
        {
          localC1 = j;
          localC2 = l;
          ((RecyclerView.d)paramMethodVisitor).animateChange((RecyclerView.b0)localObject1, localC1, localC2);
        }
        else if ((k & 0x4) != 0)
        {
          localC1 = j;
          ((RecyclerView.d)paramMethodVisitor).visitFrame((RecyclerView.b0)localObject1, localC1, null);
        }
        else if ((k & 0x8) != 0)
        {
          localC1 = j;
          localC2 = l;
          ((RecyclerView.d)paramMethodVisitor).a((RecyclerView.b0)localObject1, localC1, localC2);
        }
      }
      h.b((h)localObject2);
      i -= 1;
    }
  }
  
  public void b(RecyclerView.b0 paramB0)
  {
    int i = j.b() - 1;
    while (i >= 0)
    {
      if (paramB0 == j.b(i))
      {
        j.a(i);
        break;
      }
      i -= 1;
    }
    paramB0 = (h)a.remove(paramB0);
    if (paramB0 != null) {
      h.b(paramB0);
    }
  }
  
  public void b(RecyclerView.b0 paramB0, RecyclerView.l.c paramC)
  {
    h localH2 = (h)a.get(paramB0);
    h localH1 = localH2;
    if (localH2 == null)
    {
      localH2 = h.a();
      localH1 = localH2;
      a.put(paramB0, localH2);
    }
    c |= 0x2;
    j = paramC;
  }
  
  public void c(RecyclerView.b0 paramB0)
  {
    h localH2 = (h)a.get(paramB0);
    h localH1 = localH2;
    if (localH2 == null)
    {
      localH2 = h.a();
      localH1 = localH2;
      a.put(paramB0, localH2);
    }
    c |= 0x1;
  }
  
  public void c(RecyclerView.b0 paramB0, RecyclerView.l.c paramC)
  {
    h localH2 = (h)a.get(paramB0);
    h localH1 = localH2;
    if (localH2 == null)
    {
      localH2 = h.a();
      localH1 = localH2;
      a.put(paramB0, localH2);
    }
    j = paramC;
    c |= 0x4;
  }
  
  public void clear()
  {
    a.clear();
    j.a();
  }
  
  public void clear(long paramLong, RecyclerView.b0 paramB0)
  {
    j.a(paramLong, paramB0);
  }
  
  public void clear(RecyclerView.b0 paramB0)
  {
    a(paramB0);
  }
  
  public void e() {}
  
  public boolean f(RecyclerView.b0 paramB0)
  {
    paramB0 = (h)a.get(paramB0);
    return (paramB0 != null) && ((c & 0x4) != 0);
  }
  
  public RecyclerView.b0 getFromOldChangeHolders(long paramLong)
  {
    return (RecyclerView.b0)j.get(paramLong);
  }
  
  public boolean isDisappearing(RecyclerView.b0 paramB0)
  {
    paramB0 = (h)a.get(paramB0);
    return (paramB0 != null) && ((c & 0x1) != 0);
  }
  
  public RecyclerView.l.c popFromPostLayout(RecyclerView.b0 paramB0)
  {
    return a(paramB0, 8);
  }
  
  public RecyclerView.l.c popFromPreLayout(RecyclerView.b0 paramB0)
  {
    return a(paramB0, 4);
  }
}
