package org.util;

public abstract interface a<T>
{
  public abstract void a(Object paramObject);
}
