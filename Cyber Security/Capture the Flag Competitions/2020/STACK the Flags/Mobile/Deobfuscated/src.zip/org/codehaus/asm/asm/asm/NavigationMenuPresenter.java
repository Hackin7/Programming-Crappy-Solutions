package org.codehaus.asm.asm.asm;

import java.util.List;
import org.codehaus.asm.asm.i;

public class NavigationMenuPresenter
  extends h
{
  public NavigationMenuPresenter(org.codehaus.asm.asm.f paramF)
  {
    super(paramF);
    f.e();
    e.e();
    e = ((i)paramF).k();
  }
  
  public void a()
  {
    Object localObject = (i)b;
    int i = ((i)localObject).m();
    int j = ((i)localObject).n();
    ((i)localObject).t();
    if (((i)localObject).k() == 1)
    {
      if (i != -1)
      {
        a.a.add(b.n.f.a);
        b.n.f.a.f.add(a);
        a.j = i;
      }
      else if (j != -1)
      {
        a.a.add(b.n.f.c);
        b.n.f.c.f.add(a);
        a.j = (-j);
      }
      else
      {
        localObject = a;
        i = true;
        a.add(b.n.f.c);
        b.n.f.c.f.add(a);
      }
      a(b.f.a);
      a(b.f.c);
      return;
    }
    if (i != -1)
    {
      a.a.add(b.n.e.a);
      b.n.e.a.f.add(a);
      a.j = i;
    }
    else if (j != -1)
    {
      a.a.add(b.n.e.c);
      b.n.e.c.f.add(a);
      a.j = (-j);
    }
    else
    {
      localObject = a;
      i = true;
      a.add(b.n.e.c);
      b.n.e.c.f.add(a);
    }
    a(b.e.a);
    a(b.e.c);
  }
  
  public final void a(Label paramLabel)
  {
    a.f.add(paramLabel);
    a.add(a);
  }
  
  public void a(l paramL)
  {
    paramL = a;
    if (!e) {
      return;
    }
    if (c) {
      return;
    }
    paramL = (Label)a.get(0);
    i localI = (i)b;
    int i = (int)(d * localI.t() + 0.5F);
    a.a(i);
  }
  
  public void d()
  {
    if (((i)b).k() == 1)
    {
      b.g(a.d);
      return;
    }
    b.setText(a.d);
  }
  
  public void e()
  {
    a.a();
  }
  
  public boolean k()
  {
    return false;
  }
}
