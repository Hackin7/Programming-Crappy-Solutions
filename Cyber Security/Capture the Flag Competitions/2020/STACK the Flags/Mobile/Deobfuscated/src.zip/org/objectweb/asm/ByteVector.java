package org.objectweb.asm;

import a.h.l.e;
import a.o.c.a.b;
import androidx.recyclerview.widget.RecyclerView.f;
import java.util.ArrayList;
import java.util.List;
import org.core.data.Context;
import org.core.data.LruCache;

public class ByteVector
  implements IntegerPolynomial
{
  public e<a.b> a = new LruCache(30);
  public final ArrayList<a.b> b = new ArrayList();
  public final ArrayList<a.b> c = new ArrayList();
  public final MethodWriter d;
  public final boolean data;
  public final Item i;
  public int n = 0;
  
  public ByteVector(Item paramItem)
  {
    this(paramItem, false);
  }
  
  public ByteVector(Item paramItem, boolean paramBoolean)
  {
    i = paramItem;
    data = paramBoolean;
    d = new MethodWriter(this);
  }
  
  public int a(int paramInt)
  {
    int i1 = b.size();
    int m = 0;
    for (int j = paramInt; m < i1; j = paramInt)
    {
      Label localLabel = (Label)b.get(m);
      paramInt = d;
      if (paramInt != 1)
      {
        int k;
        if (paramInt != 2)
        {
          if (paramInt != 8)
          {
            paramInt = j;
          }
          else
          {
            paramInt = a;
            if (paramInt == j)
            {
              paramInt = c;
            }
            else
            {
              k = j;
              if (paramInt < j) {
                k = j - 1;
              }
              paramInt = k;
              if (c <= k) {
                paramInt = k + 1;
              }
            }
          }
        }
        else
        {
          k = a;
          paramInt = j;
          if (k <= j)
          {
            paramInt = c;
            if (k + paramInt > j) {
              return -1;
            }
            paramInt = j - paramInt;
          }
        }
      }
      else
      {
        paramInt = j;
        if (a <= j) {
          paramInt = j + c;
        }
      }
      m += 1;
    }
    return j;
  }
  
  public int a(int paramInt1, int paramInt2)
  {
    int m = c.size();
    int k = paramInt2;
    for (paramInt2 = paramInt1; k < m; paramInt2 = paramInt1)
    {
      Label localLabel = (Label)c.get(k);
      int i1 = d;
      int j;
      if (i1 == 8)
      {
        paramInt1 = a;
        if (paramInt1 == paramInt2)
        {
          paramInt1 = c;
        }
        else
        {
          j = paramInt2;
          if (paramInt1 < paramInt2) {
            j = paramInt2 - 1;
          }
          paramInt1 = j;
          if (c <= j) {
            paramInt1 = j + 1;
          }
        }
      }
      else
      {
        j = a;
        paramInt1 = paramInt2;
        if (j <= paramInt2) {
          if (i1 == 2)
          {
            paramInt1 = c;
            if (paramInt2 < j + paramInt1) {
              return -1;
            }
            paramInt1 = paramInt2 - paramInt1;
          }
          else
          {
            paramInt1 = paramInt2;
            if (i1 == 1) {
              paramInt1 = paramInt2 + c;
            }
          }
        }
      }
      k += 1;
    }
    return paramInt2;
  }
  
  public Label a(int paramInt1, int paramInt2, int paramInt3, Object paramObject)
  {
    Label localLabel = (Label)a.get();
    if (localLabel == null) {
      return new Label(paramInt1, paramInt2, paramInt3, paramObject);
    }
    d = paramInt1;
    a = paramInt2;
    c = paramInt3;
    b = paramObject;
    return localLabel;
  }
  
  public void a()
  {
    d.b(b);
    int k = b.size();
    int j = 0;
    while (j < k)
    {
      Label localLabel = (Label)b.get(j);
      int m = d;
      if (m != 1)
      {
        if (m != 2)
        {
          if (m != 4)
          {
            if (m == 8) {
              visitTableSwitchInsn(localLabel);
            }
          }
          else {
            a(localLabel);
          }
        }
        else {
          d(localLabel);
        }
      }
      else {
        visitLookupSwitchInsn(localLabel);
      }
      j += 1;
    }
    b.clear();
  }
  
  public void a(List paramList)
  {
    int k = paramList.size();
    int j = 0;
    while (j < k)
    {
      write((Label)paramList.get(j));
      j += 1;
    }
    paramList.clear();
  }
  
  public final void a(Label paramLabel)
  {
    int k = a;
    int m = 0;
    int i5 = a;
    int i6 = c;
    int i4 = -1;
    int j = a;
    while (j < i5 + i6)
    {
      int i2;
      int i1;
      int i3;
      if ((((RecyclerView.f)i).a(j) == null) && (!b(j)))
      {
        i2 = k;
        i1 = m;
        if (i4 == 1)
        {
          add(a(4, k, m, b));
          i1 = 0;
          i2 = j;
        }
        m = 0;
        k = i2;
        i3 = i1;
        i1 = m;
      }
      else
      {
        i2 = k;
        i3 = m;
        if (i4 == 0)
        {
          b(a(4, k, m, b));
          i3 = 0;
          i2 = j;
        }
        i1 = 1;
        k = i2;
      }
      m = i3 + 1;
      j += 1;
      i4 = i1;
    }
    Object localObject = paramLabel;
    if (m != c)
    {
      localObject = b;
      write(paramLabel);
      localObject = a(4, k, m, localObject);
    }
    if (i4 == 0)
    {
      b((Label)localObject);
      return;
    }
    add((Label)localObject);
  }
  
  public void a(Label paramLabel, int paramInt)
  {
    ((RecyclerView.f)i).visitFrame(paramLabel);
    int j = d;
    if (j != 2)
    {
      if (j == 4)
      {
        localItem = i;
        j = c;
        paramLabel = b;
        ((RecyclerView.f)localItem).a(paramInt, j, paramLabel);
        return;
      }
      throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
    }
    Item localItem = i;
    j = c;
    ((RecyclerView.f)localItem).offsetPositionsForRemovingInvisible(paramInt, j);
  }
  
  public final void add(Label paramLabel)
  {
    c.add(paramLabel);
    int j = d;
    if (j != 1)
    {
      if (j != 2)
      {
        if (j != 4)
        {
          if (j == 8)
          {
            localObject = i;
            j = a;
            k = c;
            ((RecyclerView.f)localObject).a(j, k);
            return;
          }
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("Unknown update op type for ");
          ((StringBuilder)localObject).append(paramLabel);
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
        localObject = i;
        j = a;
        k = c;
        paramLabel = b;
        ((RecyclerView.f)localObject).a(j, k, paramLabel);
        return;
      }
      localObject = i;
      j = a;
      k = c;
      ((RecyclerView.f)localObject).offsetPositionsForRemovingLaidOutOrNewView(j, k);
      return;
    }
    Object localObject = i;
    j = a;
    int k = c;
    ((RecyclerView.f)localObject).append(j, k);
  }
  
  public boolean add()
  {
    return b.size() > 0;
  }
  
  public boolean add(int paramInt)
  {
    return (n & paramInt) != 0;
  }
  
  public final int b(int paramInt1, int paramInt2)
  {
    int k = c.size() - 1;
    Label localLabel;
    for (int j = paramInt1; k >= 0; j = paramInt1)
    {
      localLabel = (Label)c.get(k);
      int m = d;
      if (m == 8)
      {
        if (a < c)
        {
          paramInt1 = a;
          m = c;
        }
        else
        {
          paramInt1 = c;
          m = a;
        }
        if ((j >= paramInt1) && (j <= m))
        {
          m = a;
          if (paramInt1 == m)
          {
            if (paramInt2 == 1) {
              c += 1;
            } else if (paramInt2 == 2) {
              c -= 1;
            }
            paramInt1 = j + 1;
          }
          else
          {
            if (paramInt2 == 1) {
              a = (m + 1);
            } else if (paramInt2 == 2) {
              a = (m - 1);
            }
            paramInt1 = j - 1;
          }
        }
        else
        {
          m = a;
          paramInt1 = j;
          if (j < m) {
            if (paramInt2 == 1)
            {
              a = (m + 1);
              c += 1;
              paramInt1 = j;
            }
            else
            {
              paramInt1 = j;
              if (paramInt2 == 2)
              {
                a = (m - 1);
                c -= 1;
                paramInt1 = j;
              }
            }
          }
        }
      }
      else
      {
        int i1 = a;
        if (i1 <= j)
        {
          if (m == 1)
          {
            paramInt1 = j - c;
          }
          else
          {
            paramInt1 = j;
            if (m == 2) {
              paramInt1 = j + c;
            }
          }
        }
        else if (paramInt2 == 1)
        {
          a = (i1 + 1);
          paramInt1 = j;
        }
        else
        {
          paramInt1 = j;
          if (paramInt2 == 2)
          {
            a = (i1 - 1);
            paramInt1 = j;
          }
        }
      }
      k -= 1;
    }
    paramInt1 = c.size() - 1;
    while (paramInt1 >= 0)
    {
      localLabel = (Label)c.get(paramInt1);
      if (d == 8)
      {
        paramInt2 = c;
        if ((paramInt2 == a) || (paramInt2 < 0))
        {
          c.remove(paramInt1);
          write(localLabel);
        }
      }
      else if (c <= 0)
      {
        c.remove(paramInt1);
        write(localLabel);
      }
      paramInt1 -= 1;
    }
    return j;
  }
  
  public void b()
  {
    d();
    Object localObject = b;
    ByteVector localByteVector = this;
    int k = ((ArrayList)localObject).size();
    int j = 0;
    while (j < k)
    {
      localObject = b;
      localObject = (Label)((ArrayList)localObject).get(j);
      int m = d;
      Item localItem;
      int i1;
      if (m != 1)
      {
        if (m != 2)
        {
          if (m != 4)
          {
            if (m == 8)
            {
              ((RecyclerView.f)i).a((Label)localObject);
              localItem = i;
              m = a;
              i1 = c;
              ((RecyclerView.f)localItem).a(m, i1);
            }
          }
          else
          {
            ((RecyclerView.f)i).a((Label)localObject);
            localItem = i;
            m = a;
            i1 = c;
            localObject = b;
            ((RecyclerView.f)localItem).a(m, i1, localObject);
          }
        }
        else
        {
          ((RecyclerView.f)i).a((Label)localObject);
          localItem = i;
          m = a;
          i1 = c;
          ((RecyclerView.f)localItem).offsetPositionsForRemovingInvisible(m, i1);
        }
      }
      else
      {
        ((RecyclerView.f)i).a((Label)localObject);
        localItem = i;
        m = a;
        i1 = c;
        ((RecyclerView.f)localItem).append(m, i1);
      }
      j += 1;
    }
    localByteVector.a(b);
    n = 0;
  }
  
  public final void b(Label paramLabel)
  {
    int j = d;
    if ((j != 1) && (j != 8))
    {
      int i2 = b(a, j);
      int i3 = 1;
      j = a;
      int k = d;
      int m;
      if (k != 2)
      {
        if (k == 4)
        {
          m = 1;
        }
        else
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("op should be remove or update.");
          ((StringBuilder)localObject).append(paramLabel);
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
      }
      else {
        m = 0;
      }
      int i1 = 1;
      while (i1 < c)
      {
        int i4 = b(a + m * i1, d);
        k = 0;
        int i7 = d;
        int i6 = 0;
        int i5 = 0;
        if (i7 != 2)
        {
          if (i7 == 4)
          {
            k = i5;
            if (i4 == i2 + 1) {
              k = 1;
            }
          }
        }
        else
        {
          k = i6;
          if (i4 == i2) {
            k = 1;
          }
        }
        if (k != 0)
        {
          k = i3 + 1;
        }
        else
        {
          localObject = a(d, i2, i3, b);
          a((Label)localObject, j);
          write((Label)localObject);
          k = j;
          if (d == 4) {
            k = j + i3;
          }
          i2 = i4;
          i3 = 1;
          j = k;
          k = i3;
        }
        i1 += 1;
        i3 = k;
      }
      Object localObject = b;
      write(paramLabel);
      if (i3 > 0)
      {
        paramLabel = a(d, i2, i3, localObject);
        a(paramLabel, j);
        write(paramLabel);
      }
    }
    else
    {
      throw new IllegalArgumentException("should not dispatch add or move for pre layout");
    }
  }
  
  public final boolean b(int paramInt)
  {
    int m = c.size();
    int j = 0;
    while (j < m)
    {
      Label localLabel = (Label)c.get(j);
      int k = d;
      if (k == 8)
      {
        if (a(c, j + 1) == paramInt) {
          return true;
        }
      }
      else if (k == 1)
      {
        int i1 = a;
        int i2 = c;
        k = a;
        while (k < i1 + i2)
        {
          if (a(k, j + 1) == paramInt) {
            return true;
          }
          k += 1;
        }
      }
      j += 1;
    }
    return false;
  }
  
  public void d()
  {
    int k = c.size();
    int j = 0;
    while (j < k)
    {
      Item localItem = i;
      Label localLabel = (Label)c.get(j);
      ((RecyclerView.f)localItem).a(localLabel);
      j += 1;
    }
    a(c);
    n = 0;
  }
  
  public final void d(Label paramLabel)
  {
    int i4 = a;
    int i2 = 0;
    int i1 = a + c;
    int i3 = -1;
    int j = a;
    while (j < i1)
    {
      int k = 0;
      int m = 0;
      if ((((RecyclerView.f)i).a(j) == null) && (!b(j)))
      {
        if (i3 == 1)
        {
          add(a(2, i4, i2, null));
          m = 1;
        }
        k = 0;
      }
      else
      {
        if (i3 == 0)
        {
          b(a(2, i4, i2, null));
          k = 1;
        }
        i3 = 1;
        m = k;
        k = i3;
      }
      if (m != 0)
      {
        m = j - i2;
        i1 -= i2;
        j = 1;
      }
      else
      {
        i2 += 1;
        m = j;
        j = i2;
      }
      m += 1;
      i2 = j;
      j = m;
      i3 = k;
    }
    Label localLabel = paramLabel;
    if (i2 != c)
    {
      write(paramLabel);
      localLabel = a(2, i4, i2, null);
    }
    if (i3 == 0)
    {
      b(localLabel);
      return;
    }
    add(localLabel);
  }
  
  public int findPositionOffset(int paramInt)
  {
    return a(paramInt, 0);
  }
  
  public boolean get()
  {
    return (!c.isEmpty()) && (!b.isEmpty());
  }
  
  public final void visitLookupSwitchInsn(Label paramLabel)
  {
    add(paramLabel);
  }
  
  public final void visitTableSwitchInsn(Label paramLabel)
  {
    add(paramLabel);
  }
  
  public void write()
  {
    a(b);
    a(c);
    n = 0;
  }
  
  public void write(Label paramLabel)
  {
    if (!data)
    {
      b = null;
      a.get(paramLabel);
    }
  }
}
