package org.v7.view;

import a.b.o.f;
import a.e.g;
import android.view.MenuInflater;
import android.view.View;
import java.util.ArrayList;
import org.v7.view.menu.MenuItemWrapper;
import org.v7.view.menu.MenuWrapper;

public class SupportActionModeWrapper
  extends android.view.ActionMode
{
  public final android.content.Context mContext;
  public final ActionMode mWrappedObject;
  
  public SupportActionModeWrapper(android.content.Context paramContext, ActionMode paramActionMode)
  {
    mContext = paramContext;
    mWrappedObject = paramActionMode;
  }
  
  public void finish()
  {
    mWrappedObject.finish();
  }
  
  public View getCustomView()
  {
    return mWrappedObject.getCustomView();
  }
  
  public android.view.Menu getMenu()
  {
    return new MenuWrapper(mContext, (org.core.base.utils.Menu)mWrappedObject.getMenu());
  }
  
  public MenuInflater getMenuInflater()
  {
    return mWrappedObject.getMenuInflater();
  }
  
  public CharSequence getSubtitle()
  {
    return mWrappedObject.getSubtitle();
  }
  
  public Object getTag()
  {
    return mWrappedObject.getTag();
  }
  
  public CharSequence getTitle()
  {
    return mWrappedObject.getTitle();
  }
  
  public boolean getTitleOptionalHint()
  {
    return mWrappedObject.getTitleOptionalHint();
  }
  
  public void invalidate()
  {
    mWrappedObject.invalidate();
  }
  
  public boolean isTitleOptional()
  {
    return mWrappedObject.isTitleOptional();
  }
  
  public void setCustomView(View paramView)
  {
    mWrappedObject.setCustomView(paramView);
  }
  
  public void setSubtitle(int paramInt)
  {
    mWrappedObject.setSubtitle(paramInt);
  }
  
  public void setSubtitle(CharSequence paramCharSequence)
  {
    mWrappedObject.setSubtitle(paramCharSequence);
  }
  
  public void setTag(Object paramObject)
  {
    mWrappedObject.setTag(paramObject);
  }
  
  public void setTitle(int paramInt)
  {
    mWrappedObject.setTitle(paramInt);
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    mWrappedObject.setTitle(paramCharSequence);
  }
  
  public void setTitleOptionalHint(boolean paramBoolean)
  {
    mWrappedObject.setTitleOptionalHint(paramBoolean);
  }
  
  public class CallbackWrapper
    implements ActionMode.Callback
  {
    public final ArrayList<f> mActionModes;
    public final g<android.view.Menu, android.view.Menu> mMenus;
    public final android.view.ActionMode.Callback mWrappedCallback;
    
    public CallbackWrapper(android.view.ActionMode.Callback paramCallback)
    {
      mWrappedCallback = paramCallback;
      mActionModes = new ArrayList();
      mMenus = new org.data.Context();
    }
    
    public android.view.ActionMode getActionModeWrapper(ActionMode paramActionMode)
    {
      int i = 0;
      int j = mActionModes.size();
      while (i < j)
      {
        SupportActionModeWrapper localSupportActionModeWrapper = (SupportActionModeWrapper)mActionModes.get(i);
        if ((localSupportActionModeWrapper != null) && (mWrappedObject == paramActionMode)) {
          return localSupportActionModeWrapper;
        }
        i += 1;
      }
      paramActionMode = new SupportActionModeWrapper(SupportActionModeWrapper.this, paramActionMode);
      mActionModes.add(paramActionMode);
      return paramActionMode;
    }
    
    public final android.view.Menu getMenuWrapper(android.view.Menu paramMenu)
    {
      Object localObject = (android.view.Menu)mMenus.get(paramMenu);
      if (localObject == null)
      {
        localObject = new MenuWrapper(SupportActionModeWrapper.this, (org.core.base.utils.Menu)paramMenu);
        mMenus.put(paramMenu, localObject);
        return localObject;
      }
      return localObject;
    }
    
    public boolean onActionItemClicked(ActionMode paramActionMode, android.view.MenuItem paramMenuItem)
    {
      return mWrappedCallback.onActionItemClicked(getActionModeWrapper(paramActionMode), new MenuItemWrapper(SupportActionModeWrapper.this, (org.core.base.utils.MenuItem)paramMenuItem));
    }
    
    public boolean onCreateActionMode(ActionMode paramActionMode, android.view.Menu paramMenu)
    {
      return mWrappedCallback.onCreateActionMode(getActionModeWrapper(paramActionMode), getMenuWrapper(paramMenu));
    }
    
    public void onDestroyActionMode(ActionMode paramActionMode)
    {
      mWrappedCallback.onDestroyActionMode(getActionModeWrapper(paramActionMode));
    }
    
    public boolean onPrepareActionMode(ActionMode paramActionMode, android.view.Menu paramMenu)
    {
      return mWrappedCallback.onPrepareActionMode(getActionModeWrapper(paramActionMode), getMenuWrapper(paramMenu));
    }
  }
}
