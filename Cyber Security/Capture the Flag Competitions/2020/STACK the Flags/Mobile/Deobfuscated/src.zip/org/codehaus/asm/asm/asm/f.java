package org.codehaus.asm.asm.asm;

import java.util.List;
import org.codehaus.asm.asm.AnnotationWriter;
import org.codehaus.asm.asm.XLayoutStyle;

public class f
  extends h
{
  public static int[] d = new int[2];
  
  public f(org.codehaus.asm.asm.f paramF)
  {
    super(paramF);
    a.g = MathArrays.OrderDirection.p;
    c.g = MathArrays.OrderDirection.i;
    e = 0;
  }
  
  public void a()
  {
    Object localObject1 = b;
    if (d) {
      d.a(((org.codehaus.asm.asm.f)localObject1).getValue());
    }
    int i;
    if (!d.c)
    {
      localObject1 = b.doubleValue();
      p = ((XLayoutStyle)localObject1);
      if (localObject1 != XLayoutStyle.a)
      {
        if (localObject1 == XLayoutStyle.r)
        {
          localObject1 = b.l();
          if (((localObject1 != null) && (((org.codehaus.asm.asm.f)localObject1).doubleValue() == XLayoutStyle.b)) || (((org.codehaus.asm.asm.f)localObject1).doubleValue() == XLayoutStyle.r))
          {
            i = ((org.codehaus.asm.asm.f)localObject1).getValue();
            int j = b.b.b();
            int k = b.i.b();
            a(a, f.a, b.b.b());
            a(c, f.c, -b.i.b());
            d.a(i - j - k);
            return;
          }
        }
        if (p == XLayoutStyle.b) {
          d.a(b.getValue());
        }
      }
    }
    else if (p == XLayoutStyle.r)
    {
      localObject1 = b.l();
      if (((localObject1 != null) && (((org.codehaus.asm.asm.f)localObject1).doubleValue() == XLayoutStyle.b)) || (((org.codehaus.asm.asm.f)localObject1).doubleValue() == XLayoutStyle.r))
      {
        a(a, f.a, b.b.b());
        a(c, f.c, -b.i.b());
        return;
      }
    }
    if (d.c)
    {
      localObject1 = b;
      if (d)
      {
        localObject2 = r;
        if ((0a != null) && (1a != null))
        {
          if (((org.codehaus.asm.asm.f)localObject1).f())
          {
            a.j = b.r[0].b();
            c.j = (-b.r[1].b());
            return;
          }
          localObject1 = a(b.r[0]);
          if (localObject1 != null) {
            a(a, (Label)localObject1, b.r[0].b());
          }
          localObject1 = a(b.r[1]);
          if (localObject1 != null) {
            a(c, (Label)localObject1, -b.r[1].b());
          }
          a.i = true;
          c.i = true;
          return;
        }
        localObject1 = b;
        localObject2 = r;
        if (0a != null)
        {
          localObject1 = a(localObject2[0]);
          if (localObject1 != null)
          {
            a(a, (Label)localObject1, b.r[0].b());
            a(c, a, d.d);
          }
          return;
        }
        if (1a != null)
        {
          localObject1 = a(localObject2[1]);
          if (localObject1 != null)
          {
            a(c, (Label)localObject1, -b.r[1].b());
            a(a, c, -d.d);
          }
          return;
        }
        if (((localObject1 instanceof AnnotationWriter)) || (((org.codehaus.asm.asm.f)localObject1).l() == null) || (b.a(org.codehaus.asm.asm.c.l).a != null)) {
          return;
        }
        localObject1 = b.l().f.a;
        a(a, (Label)localObject1, b.e());
        a(c, a, d.d);
        return;
      }
    }
    if (p == XLayoutStyle.a)
    {
      localObject1 = b;
      i = k;
      if (i != 2)
      {
        if (i == 3) {
          if (h == 3)
          {
            a.k = this;
            c.k = this;
            localObject2 = e;
            a.k = this;
            c.k = this;
            d.k = this;
            if (((org.codehaus.asm.asm.f)localObject1).c())
            {
              d.a.add(b.e.d);
              b.e.d.f.add(d);
              localObject1 = b.e;
              d.k = this;
              d.a.add(a);
              d.a.add(b.e.c);
              b.e.a.f.add(d);
              b.e.c.f.add(d);
            }
            else if (b.f())
            {
              b.e.d.a.add(d);
              d.f.add(b.e.d);
            }
            else
            {
              b.e.d.a.add(d);
            }
          }
          else
          {
            localObject1 = e.d;
            d.a.add(localObject1);
            f.add(d);
            b.e.a.f.add(d);
            b.e.c.f.add(d);
            localObject1 = d;
            i = true;
            f.add(a);
            d.f.add(c);
            a.a.add(d);
            c.a.add(d);
          }
        }
      }
      else
      {
        localObject1 = ((org.codehaus.asm.asm.f)localObject1).l();
        if (localObject1 != null)
        {
          localObject1 = e.d;
          d.a.add(localObject1);
          f.add(d);
          localObject1 = d;
          i = true;
          f.add(a);
          d.f.add(c);
        }
      }
    }
    localObject1 = b;
    Object localObject2 = r;
    if ((0a != null) && (1a != null))
    {
      if (((org.codehaus.asm.asm.f)localObject1).f())
      {
        a.j = b.r[0].b();
        c.j = (-b.r[1].b());
        return;
      }
      localObject1 = a(b.r[0]);
      localObject2 = a(b.r[1]);
      ((Label)localObject1).b(this);
      ((Label)localObject2).b(this);
      this.i = AllowedSolution.H;
      return;
    }
    localObject1 = b;
    localObject2 = r;
    if (0a != null)
    {
      localObject1 = a(localObject2[0]);
      if (localObject1 != null)
      {
        a(a, (Label)localObject1, b.r[0].b());
        a(c, a, 1, d);
      }
      return;
    }
    if (1a != null)
    {
      localObject1 = a(localObject2[1]);
      if (localObject1 != null)
      {
        a(c, (Label)localObject1, -b.r[1].b());
        a(a, c, -1, d);
      }
      return;
    }
    if ((!(localObject1 instanceof AnnotationWriter)) && (((org.codehaus.asm.asm.f)localObject1).l() != null))
    {
      localObject1 = b.l().f.a;
      a(a, (Label)localObject1, b.e());
      a(c, a, 1, d);
    }
  }
  
  public void a(l paramL)
  {
    int i = this.i.ordinal();
    if (i != 1)
    {
      if (i != 2)
      {
        if (i == 3)
        {
          paramL = b;
          a(b, i, 0);
        }
      }
      else {
        notifyDataSetChanged();
      }
    }
    else {
      setTitle();
    }
    int j;
    Object localObject1;
    int k;
    float f;
    if ((!d.c) && (p == XLayoutStyle.a))
    {
      paramL = b;
      i = k;
      if (i != 2)
      {
        if (i == 3)
        {
          i = h;
          if ((i != 0) && (i != 3))
          {
            i = 0;
            j = paramL.r();
            if (j != -1)
            {
              if (j != 0)
              {
                if (j == 1)
                {
                  paramL = b;
                  i = (int)(e.d.d * paramL.i() + 0.5F);
                }
              }
              else
              {
                paramL = b;
                i = (int)(e.d.d / paramL.i() + 0.5F);
              }
            }
            else
            {
              paramL = b;
              i = (int)(e.d.d * paramL.i() + 0.5F);
            }
            d.a(i);
          }
          else
          {
            Object localObject2 = b;
            localObject1 = e;
            paramL = a;
            localObject1 = c;
            if (b.a != null) {
              i = 1;
            } else {
              i = 0;
            }
            if (b.a.a != null) {
              j = 1;
            } else {
              j = 0;
            }
            if (b.i.a != null) {
              k = 1;
            } else {
              k = 0;
            }
            int m;
            if (b.g.a != null) {
              m = 1;
            } else {
              m = 0;
            }
            int n = b.r();
            if ((i != 0) && (j != 0) && (k != 0) && (m != 0))
            {
              f = b.i();
              int i1;
              int i2;
              int i3;
              int i4;
              if ((c) && (c))
              {
                localObject2 = a;
                if (e)
                {
                  if (!c.e) {
                    return;
                  }
                  i = a.get(0)).d;
                  j = a.j;
                  k = c.a.get(0)).d;
                  m = c.j;
                  i1 = d;
                  i2 = j;
                  i3 = d;
                  i4 = j;
                  a(d, i + j, k - m, i1 + i2, i3 - i4, f, n);
                  d.a(d[0]);
                  b.e.d.a(d[1]);
                }
                return;
              }
              localObject2 = a;
              if (c)
              {
                Label localLabel = c;
                if (c) {
                  if (e)
                  {
                    if (!e) {
                      return;
                    }
                    i = d;
                    j = j;
                    k = d;
                    m = j;
                    i1 = a.get(0)).d;
                    i2 = j;
                    i3 = a.get(0)).d;
                    i4 = j;
                    a(d, i + j, k - m, i1 + i2, i3 - i4, f, n);
                    d.a(d[0]);
                    b.e.d.a(d[1]);
                  }
                  else
                  {
                    return;
                  }
                }
              }
              localObject2 = a;
              if (e)
              {
                if ((!c.e) || (!e)) {
                  return;
                }
                if (!e) {
                  return;
                }
                i = a.get(0)).d;
                j = a.j;
                k = c.a.get(0)).d;
                m = c.j;
                i1 = a.get(0)).d;
                i2 = j;
                i3 = a.get(0)).d;
                i4 = j;
                a(d, i + j, k - m, i1 + i2, i3 - i4, f, n);
                d.a(d[0]);
                b.e.d.a(d[1]);
              }
            }
            else if ((i != 0) && (k != 0))
            {
              if (a.e)
              {
                if (!c.e) {
                  return;
                }
                f = b.i();
                i = a.a.get(0)).d + a.j;
                j = c.a.get(0)).d - c.j;
                if ((n != -1) && (n != 0))
                {
                  if (n == 1)
                  {
                    j = b(j - i, 0);
                    i = j;
                    k = (int)(j / f + 0.5F);
                    j = b(k, 1);
                    if (k != j) {
                      i = (int)(j * f + 0.5F);
                    }
                    d.a(i);
                    b.e.d.a(j);
                  }
                }
                else
                {
                  j = b(j - i, 0);
                  i = j;
                  k = (int)(j * f + 0.5F);
                  j = b(k, 1);
                  if (k != j) {
                    i = (int)(j / f + 0.5F);
                  }
                  d.a(i);
                  b.e.d.a(j);
                }
              }
            }
            else if ((j != 0) && (m != 0))
            {
              if (e)
              {
                if (!e) {
                  return;
                }
                f = b.i();
                i = a.get(0)).d + j;
                j = a.get(0)).d - j;
                if (n != -1) {
                  if (n != 0)
                  {
                    if (n != 1) {
                      break label1488;
                    }
                  }
                  else
                  {
                    j = b(j - i, 1);
                    i = j;
                    k = (int)(j * f + 0.5F);
                    j = b(k, 0);
                    if (k != j) {
                      i = (int)(j / f + 0.5F);
                    }
                    d.a(j);
                    b.e.d.a(i);
                    break label1488;
                  }
                }
                j = b(j - i, 1);
                i = j;
                k = (int)(j / f + 0.5F);
                j = b(k, 0);
                if (k != j) {
                  i = (int)(j * f + 0.5F);
                }
                d.a(j);
                b.e.d.a(i);
              }
              else
              {
                return;
              }
            }
          }
        }
      }
      else
      {
        label1488:
        paramL = paramL.l();
        if (paramL != null)
        {
          paramL = f.d;
          if (c)
          {
            f = b.j;
            i = (int)(d * f + 0.5F);
            d.a(i);
          }
        }
      }
    }
    paramL = a;
    if (e)
    {
      localObject1 = c;
      if (!e) {
        return;
      }
      if ((c) && (c) && (d.c)) {
        return;
      }
      if ((!d.c) && (p == XLayoutStyle.a))
      {
        paramL = b;
        if ((k == 0) && (!paramL.f()))
        {
          localObject1 = (Label)a.a.get(0);
          paramL = (Label)c.a.get(0);
          i = d;
          localObject1 = a;
          i += j;
          j = d + c.j;
          ((Label)localObject1).a(i);
          c.a(j);
          d.a(j - i);
          return;
        }
      }
      if ((!d.c) && (p == XLayoutStyle.a) && (g == 1) && (a.a.size() > 0) && (c.a.size() > 0))
      {
        paramL = (Label)a.a.get(0);
        localObject1 = (Label)c.a.get(0);
        i = d;
        j = a.j;
        i = Math.min(d + c.j - (i + j), d.d);
        paramL = b;
        k = o;
        j = Math.max(l, i);
        i = j;
        if (k > 0) {
          i = Math.min(k, j);
        }
        d.a(i);
      }
      if (!d.c) {
        return;
      }
      paramL = (Label)a.a.get(0);
      localObject1 = (Label)c.a.get(0);
      i = d + a.j;
      j = d + c.j;
      f = b.width();
      if (paramL == localObject1)
      {
        i = d;
        j = d;
        f = 0.5F;
      }
      k = d.d;
      a.a((int)(i + 0.5F + (j - i - k) * f));
      c.a(a.d + d.d);
    }
  }
  
  public final void a(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5)
  {
    paramInt1 = paramInt2 - paramInt1;
    paramInt2 = paramInt4 - paramInt3;
    if (paramInt5 != -1)
    {
      if (paramInt5 != 0)
      {
        if (paramInt5 != 1) {
          return;
        }
        paramInt2 = (int)(paramInt1 * paramFloat + 0.5F);
        paramArrayOfInt[0] = paramInt1;
        paramArrayOfInt[1] = paramInt2;
        return;
      }
      paramArrayOfInt[0] = ((int)(paramInt2 * paramFloat + 0.5F));
      paramArrayOfInt[1] = paramInt2;
      return;
    }
    paramInt3 = (int)(paramInt2 * paramFloat + 0.5F);
    paramInt4 = (int)(paramInt1 / paramFloat + 0.5F);
    if (paramInt3 <= paramInt1)
    {
      paramArrayOfInt[0] = paramInt3;
      paramArrayOfInt[1] = paramInt2;
      return;
    }
    if (paramInt4 <= paramInt2)
    {
      paramArrayOfInt[0] = paramInt1;
      paramArrayOfInt[1] = paramInt4;
    }
  }
  
  public void b()
  {
    f = false;
    a.a();
    a.c = false;
    c.a();
    c.c = false;
    d.c = false;
  }
  
  public void d()
  {
    Label localLabel = a;
    if (c) {
      b.g(d);
    }
  }
  
  public void e()
  {
    q = null;
    a.a();
    c.a();
    d.a();
    f = false;
  }
  
  public boolean k()
  {
    if (p == XLayoutStyle.a) {
      return b.k == 0;
    }
    return true;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("HorizontalRun ");
    localStringBuilder.append(b.getString());
    return localStringBuilder.toString();
  }
}
