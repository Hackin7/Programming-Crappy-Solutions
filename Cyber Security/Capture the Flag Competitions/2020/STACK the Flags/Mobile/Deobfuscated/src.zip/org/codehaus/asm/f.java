package org.codehaus.asm;

import java.util.Arrays;

public class f
  implements ByteVector
{
  public static float c = 0.001F;
  public Label a = null;
  public int[] b = new int[8];
  public int[] e = new int[8];
  public int g = -1;
  public float[] j = new float[8];
  public int k = -1;
  public final Item n;
  public int q = 0;
  public int s = 8;
  public boolean t = false;
  public final h x;
  
  public f(h paramH, Item paramItem)
  {
    x = paramH;
    n = paramItem;
  }
  
  public final float a(Label paramLabel, boolean paramBoolean)
  {
    if (a == paramLabel) {
      a = null;
    }
    if (k == -1) {
      return 0.0F;
    }
    int i = k;
    int i1 = -1;
    int m = 0;
    while ((i != -1) && (m < q))
    {
      if (e[i] == n)
      {
        if (i == k)
        {
          k = b[i];
        }
        else
        {
          int[] arrayOfInt = b;
          arrayOfInt[i1] = arrayOfInt[i];
        }
        if (paramBoolean) {
          paramLabel.a(x);
        }
        v -= 1;
        q -= 1;
        e[i] = -1;
        if (t) {
          g = i;
        }
        return j[i];
      }
      i1 = i;
      i = b[i];
      m += 1;
    }
    return 0.0F;
  }
  
  public float a(h paramH, boolean paramBoolean)
  {
    float f = b(a);
    a(a, paramBoolean);
    paramH = c;
    int m = paramH.size();
    int i = 0;
    while (i < m)
    {
      Label localLabel = paramH.a(i);
      a(localLabel, paramH.b(localLabel) * f, paramBoolean);
      i += 1;
    }
    return f;
  }
  
  public Label a(int paramInt)
  {
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      if (i == paramInt) {
        return n.d[e[m]];
      }
      m = b[m];
      i += 1;
    }
    return null;
  }
  
  public void a()
  {
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      float[] arrayOfFloat = j;
      arrayOfFloat[m] *= -1.0F;
      m = b[m];
      i += 1;
    }
  }
  
  public void a(float paramFloat)
  {
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      float[] arrayOfFloat = j;
      arrayOfFloat[m] /= paramFloat;
      m = b[m];
      i += 1;
    }
  }
  
  public final void a(Label paramLabel, float paramFloat)
  {
    if (paramFloat == 0.0F)
    {
      a(paramLabel, true);
      return;
    }
    int i;
    if (k == -1)
    {
      k = 0;
      j[0] = paramFloat;
      e[0] = n;
      b[0] = -1;
      v += 1;
      paramLabel.b(x);
      q += 1;
      if (!t)
      {
        i = g + 1;
        g = i;
        paramLabel = e;
        if (i >= paramLabel.length)
        {
          t = true;
          g = (paramLabel.length - 1);
        }
      }
    }
    else
    {
      i = k;
      int i2 = -1;
      int m = 0;
      int i1;
      while ((i != -1) && (m < q))
      {
        arrayOfInt = e;
        int i3 = arrayOfInt[i];
        i1 = n;
        if (i3 == i1)
        {
          j[i] = paramFloat;
          return;
        }
        if (arrayOfInt[i] < i1) {
          i2 = i;
        }
        i = b[i];
        m += 1;
      }
      m = g;
      i = m + 1;
      if (t)
      {
        arrayOfInt = e;
        if (arrayOfInt[m] == -1) {
          i = g;
        } else {
          i = arrayOfInt.length;
        }
      }
      int[] arrayOfInt = e;
      m = i;
      if (i >= arrayOfInt.length)
      {
        m = i;
        if (q < arrayOfInt.length)
        {
          i1 = 0;
          for (;;)
          {
            arrayOfInt = e;
            m = i;
            if (i1 >= arrayOfInt.length) {
              break;
            }
            if (arrayOfInt[i1] == -1)
            {
              m = i1;
              break;
            }
            i1 += 1;
          }
        }
      }
      arrayOfInt = e;
      i = m;
      if (m >= arrayOfInt.length)
      {
        i = arrayOfInt.length;
        m = s * 2;
        s = m;
        t = false;
        g = (i - 1);
        j = Arrays.copyOf(j, m);
        e = Arrays.copyOf(e, s);
        b = Arrays.copyOf(b, s);
      }
      e[i] = n;
      j[i] = paramFloat;
      if (i2 != -1)
      {
        arrayOfInt = b;
        arrayOfInt[i] = arrayOfInt[i2];
        arrayOfInt[i2] = i;
      }
      else
      {
        b[i] = k;
        k = i;
      }
      v += 1;
      paramLabel.b(x);
      q += 1;
      if (!t) {
        g += 1;
      }
      if (q >= e.length) {
        t = true;
      }
      i = g;
      paramLabel = e;
      if (i >= paramLabel.length)
      {
        t = true;
        g = (paramLabel.length - 1);
      }
    }
  }
  
  public void a(Label paramLabel, float paramFloat, boolean paramBoolean)
  {
    if ((paramFloat > -0.001F) && (paramFloat < 0.001F)) {
      return;
    }
    int i;
    if (k == -1)
    {
      k = 0;
      j[0] = paramFloat;
      e[0] = n;
      b[0] = -1;
      v += 1;
      paramLabel.b(x);
      q += 1;
      if (!t)
      {
        i = g + 1;
        g = i;
        paramLabel = e;
        if (i >= paramLabel.length)
        {
          t = true;
          g = (paramLabel.length - 1);
        }
      }
    }
    else
    {
      i = k;
      int i2 = -1;
      int m = 0;
      int i1;
      while ((i != -1) && (m < q))
      {
        arrayOfInt = e;
        int i3 = arrayOfInt[i];
        i1 = n;
        if (i3 == i1)
        {
          float f = j[i] + paramFloat;
          paramFloat = f;
          if (f > -0.001F)
          {
            paramFloat = f;
            if (f < 0.001F) {
              paramFloat = 0.0F;
            }
          }
          j[i] = paramFloat;
          if (paramFloat != 0.0F) {
            return;
          }
          if (i == k)
          {
            k = b[i];
          }
          else
          {
            arrayOfInt = b;
            arrayOfInt[i2] = arrayOfInt[i];
          }
          if (paramBoolean) {
            paramLabel.a(x);
          }
          if (t) {
            g = i;
          }
          v -= 1;
          q -= 1;
          return;
        }
        if (arrayOfInt[i] < i1) {
          i2 = i;
        }
        i = b[i];
        m += 1;
      }
      m = g;
      i = m + 1;
      if (t)
      {
        arrayOfInt = e;
        if (arrayOfInt[m] == -1) {
          i = g;
        } else {
          i = arrayOfInt.length;
        }
      }
      int[] arrayOfInt = e;
      m = i;
      if (i >= arrayOfInt.length)
      {
        m = i;
        if (q < arrayOfInt.length)
        {
          i1 = 0;
          for (;;)
          {
            arrayOfInt = e;
            m = i;
            if (i1 >= arrayOfInt.length) {
              break;
            }
            if (arrayOfInt[i1] == -1)
            {
              m = i1;
              break;
            }
            i1 += 1;
          }
        }
      }
      arrayOfInt = e;
      i = m;
      if (m >= arrayOfInt.length)
      {
        i = arrayOfInt.length;
        m = s * 2;
        s = m;
        t = false;
        g = (i - 1);
        j = Arrays.copyOf(j, m);
        e = Arrays.copyOf(e, s);
        b = Arrays.copyOf(b, s);
      }
      e[i] = n;
      j[i] = paramFloat;
      if (i2 != -1)
      {
        arrayOfInt = b;
        arrayOfInt[i] = arrayOfInt[i2];
        arrayOfInt[i2] = i;
      }
      else
      {
        b[i] = k;
        k = i;
      }
      v += 1;
      paramLabel.b(x);
      q += 1;
      if (!t) {
        g += 1;
      }
      i = g;
      paramLabel = e;
      if (i >= paramLabel.length)
      {
        t = true;
        g = (paramLabel.length - 1);
      }
    }
  }
  
  public boolean a(Label paramLabel)
  {
    if (k == -1) {
      return false;
    }
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      if (e[m] == n) {
        return true;
      }
      m = b[m];
      i += 1;
    }
    return false;
  }
  
  public float b(int paramInt)
  {
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      if (i == paramInt) {
        return j[m];
      }
      m = b[m];
      i += 1;
    }
    return 0.0F;
  }
  
  public final float b(Label paramLabel)
  {
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      if (e[m] == n) {
        return j[m];
      }
      m = b[m];
      i += 1;
    }
    return 0.0F;
  }
  
  public final void clear()
  {
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      Label localLabel = n.d[e[m]];
      if (localLabel != null) {
        localLabel.a(x);
      }
      m = b[m];
      i += 1;
    }
    k = -1;
    g = -1;
    t = false;
    q = 0;
  }
  
  public int size()
  {
    return q;
  }
  
  public String toString()
  {
    String str = "";
    int m = k;
    int i = 0;
    while ((m != -1) && (i < q))
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(str);
      localStringBuilder.append(" -> ");
      str = localStringBuilder.toString();
      localStringBuilder = new StringBuilder();
      localStringBuilder.append(str);
      localStringBuilder.append(j[m]);
      localStringBuilder.append(" : ");
      str = localStringBuilder.toString();
      localStringBuilder = new StringBuilder();
      localStringBuilder.append(str);
      localStringBuilder.append(n.d[e[m]]);
      str = localStringBuilder.toString();
      m = b[m];
      i += 1;
    }
    return str;
  }
}
