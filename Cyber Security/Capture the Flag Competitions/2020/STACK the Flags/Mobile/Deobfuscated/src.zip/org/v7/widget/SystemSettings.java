package org.v7.widget;

import android.content.res.Resources;

public class SystemSettings
  extends Resources
{}
