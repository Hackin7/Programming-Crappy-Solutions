package org.data;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class Context<K, V>
{
  public static Object[] b;
  public static int i;
  public static Object[] q;
  public static int r;
  public Object[] a;
  public int[] n;
  public int size;
  
  public Context()
  {
    n = ContainerHelpers.n;
    a = ContainerHelpers.a;
    size = 0;
  }
  
  public Context(int paramInt)
  {
    if (paramInt == 0)
    {
      n = ContainerHelpers.n;
      a = ContainerHelpers.a;
    }
    else
    {
      a(paramInt);
    }
    size = 0;
  }
  
  public Context(Context paramContext)
  {
    this();
    if (paramContext != null) {
      a(paramContext);
    }
  }
  
  public static void a(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8) {
      try
      {
        if (i < 10)
        {
          paramArrayOfObject[0] = b;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt = (paramInt << 1) - 1;
          break label118;
          b = paramArrayOfObject;
          i += 1;
        }
        return;
      }
      catch (Throwable paramArrayOfInt)
      {
        throw paramArrayOfInt;
      }
    }
    if (paramArrayOfInt.length == 4) {}
    for (;;)
    {
      try
      {
        if (r < 10)
        {
          paramArrayOfObject[0] = q;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt = (paramInt << 1) - 1;
          break label134;
          q = paramArrayOfObject;
          r += 1;
        }
        return;
      }
      catch (Throwable paramArrayOfInt)
      {
        throw paramArrayOfInt;
      }
      return;
      label118:
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
      break;
      label134:
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
    }
  }
  
  public static int get(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    try
    {
      paramInt1 = ContainerHelpers.binarySearch(paramArrayOfInt, paramInt1, paramInt2);
      return paramInt1;
    }
    catch (ArrayIndexOutOfBoundsException paramArrayOfInt)
    {
      throw new ConcurrentModificationException();
    }
  }
  
  public final void a(int paramInt)
  {
    if (paramInt == 8) {
      try
      {
        if (b != null)
        {
          Object[] arrayOfObject1 = b;
          a = arrayOfObject1;
          b = (Object[])arrayOfObject1[0];
          n = ((int[])arrayOfObject1[1]);
          arrayOfObject1[1] = null;
          arrayOfObject1[0] = null;
          i -= 1;
          return;
        }
      }
      catch (Throwable localThrowable1)
      {
        throw localThrowable1;
      }
    }
    if (paramInt == 4) {
      try
      {
        if (q != null)
        {
          Object[] arrayOfObject2 = q;
          a = arrayOfObject2;
          q = (Object[])arrayOfObject2[0];
          n = ((int[])arrayOfObject2[1]);
          arrayOfObject2[1] = null;
          arrayOfObject2[0] = null;
          r -= 1;
          return;
        }
      }
      catch (Throwable localThrowable2)
      {
        throw localThrowable2;
      }
    }
    n = new int[paramInt];
    a = new Object[paramInt << 1];
  }
  
  public void a(Context paramContext)
  {
    int k = size;
    add(size + k);
    if (size == 0)
    {
      if (k > 0)
      {
        System.arraycopy(n, 0, n, 0, k);
        System.arraycopy(a, 0, a, 0, k << 1);
        size = k;
      }
    }
    else
    {
      int j = 0;
      while (j < k)
      {
        put(paramContext.getValue(j), paramContext.get(j));
        j += 1;
      }
    }
  }
  
  public int accept(Object paramObject)
  {
    int k = size * 2;
    Object[] arrayOfObject = a;
    int j;
    if (paramObject == null)
    {
      j = 1;
      while (j < k)
      {
        if (arrayOfObject[j] == null) {
          return j >> 1;
        }
        j += 2;
      }
    }
    else
    {
      j = 1;
      while (j < k)
      {
        if (paramObject.equals(arrayOfObject[j])) {
          return j >> 1;
        }
        j += 2;
      }
    }
    return -1;
  }
  
  public void add(int paramInt)
  {
    int j = size;
    if (n.length < paramInt)
    {
      int[] arrayOfInt = n;
      Object[] arrayOfObject = a;
      a(paramInt);
      if (size > 0)
      {
        System.arraycopy(arrayOfInt, 0, n, 0, j);
        System.arraycopy(arrayOfObject, 0, a, 0, j << 1);
      }
      a(arrayOfInt, arrayOfObject, j);
    }
    if (size == j) {
      return;
    }
    throw new ConcurrentModificationException();
  }
  
  public void clear()
  {
    if (size > 0)
    {
      int[] arrayOfInt = n;
      Object[] arrayOfObject = a;
      int j = size;
      n = ContainerHelpers.n;
      a = ContainerHelpers.a;
      size = 0;
      a(arrayOfInt, arrayOfObject, j);
    }
    if (size <= 0) {
      return;
    }
    throw new ConcurrentModificationException();
  }
  
  public boolean containsKey(Object paramObject)
  {
    return read(paramObject) >= 0;
  }
  
  public boolean containsValue(Object paramObject)
  {
    return accept(paramObject) >= 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    int j;
    int k;
    Object localObject1;
    Object localObject2;
    Object localObject3;
    boolean bool;
    if ((paramObject instanceof Context))
    {
      paramObject = (Context)paramObject;
      if (size() != paramObject.size()) {
        return false;
      }
      j = 0;
      try
      {
        for (;;)
        {
          k = size;
          if (j < k) {}
          try
          {
            localObject1 = getValue(j);
            localObject2 = get(j);
            localObject3 = paramObject.get(localObject1);
            if (localObject2 == null)
            {
              if (localObject3 != null) {
                break label241;
              }
              bool = paramObject.containsKey(localObject1);
              if (!bool) {
                return false;
              }
            }
            else
            {
              bool = localObject2.equals(localObject3);
              if (!bool) {
                return false;
              }
            }
            j += 1;
          }
          catch (ClassCastException paramObject)
          {
            return false;
          }
        }
        return true;
      }
      catch (NullPointerException paramObject)
      {
        return false;
      }
    }
    if ((paramObject instanceof Map))
    {
      paramObject = (Map)paramObject;
      if (size() != paramObject.size()) {
        return false;
      }
      j = 0;
      try
      {
        for (;;)
        {
          k = size;
          if (j < k) {}
          try
          {
            localObject1 = getValue(j);
            localObject2 = get(j);
            localObject3 = paramObject.get(localObject1);
            if (localObject2 == null)
            {
              if (localObject3 != null) {
                break label241;
              }
              bool = paramObject.containsKey(localObject1);
              if (!bool) {
                return false;
              }
            }
            else
            {
              bool = localObject2.equals(localObject3);
              if (!bool) {
                return false;
              }
            }
            j += 1;
          }
          catch (ClassCastException paramObject)
          {
            return false;
          }
        }
        return true;
      }
      catch (NullPointerException paramObject) {}
    }
    label241:
    return false;
  }
  
  public int get(Object paramObject, int paramInt)
  {
    int k = size;
    if (k == 0) {
      return -1;
    }
    int m = get(n, k, paramInt);
    if (m < 0) {
      return m;
    }
    if (paramObject.equals(a[(m << 1)])) {
      return m;
    }
    int j = m + 1;
    while ((j < k) && (n[j] == paramInt))
    {
      if (paramObject.equals(a[(j << 1)])) {
        return j;
      }
      j += 1;
    }
    k = m - 1;
    while ((k >= 0) && (n[k] == paramInt))
    {
      if (paramObject.equals(a[(k << 1)])) {
        return k;
      }
      k -= 1;
    }
    return j;
  }
  
  public Object get(int paramInt)
  {
    return a[((paramInt << 1) + 1)];
  }
  
  public Object get(int paramInt, Object paramObject)
  {
    paramInt = (paramInt << 1) + 1;
    Object[] arrayOfObject = a;
    Object localObject = arrayOfObject[paramInt];
    arrayOfObject[paramInt] = paramObject;
    return localObject;
  }
  
  public Object get(Object paramObject)
  {
    return getOrDefault(paramObject, null);
  }
  
  public Object getOrDefault(Object paramObject1, Object paramObject2)
  {
    int j = read(paramObject1);
    if (j >= 0) {
      return a[((j << 1) + 1)];
    }
    return paramObject2;
  }
  
  public Object getValue(int paramInt)
  {
    return a[(paramInt << 1)];
  }
  
  public int hashCode()
  {
    int[] arrayOfInt = n;
    Object[] arrayOfObject = a;
    int m = 0;
    int k = 0;
    int j = 1;
    int i2 = size;
    while (k < i2)
    {
      Object localObject = arrayOfObject[j];
      int i3 = arrayOfInt[k];
      int i1;
      if (localObject == null) {
        i1 = 0;
      } else {
        i1 = localObject.hashCode();
      }
      m += (i3 ^ i1);
      k += 1;
      j += 2;
    }
    return m;
  }
  
  public boolean isEmpty()
  {
    return size <= 0;
  }
  
  public Object put(Object paramObject1, Object paramObject2)
  {
    int m = size;
    int k;
    if (paramObject1 == null)
    {
      k = 0;
      j = read();
    }
    else
    {
      j = paramObject1.hashCode();
      k = j;
      j = get(paramObject1, j);
    }
    Object localObject;
    if (j >= 0)
    {
      j = (j << 1) + 1;
      paramObject1 = a;
      localObject = paramObject1[j];
      paramObject1[j] = paramObject2;
      return localObject;
    }
    int i1 = j;
    if (m >= n.length)
    {
      j = 4;
      if (m >= 8) {
        j = (m >> 1) + m;
      } else if (m >= 4) {
        j = 8;
      }
      localObject = n;
      Object[] arrayOfObject = a;
      a(j);
      if (m == size)
      {
        int[] arrayOfInt = n;
        if (arrayOfInt.length > 0)
        {
          System.arraycopy(localObject, 0, arrayOfInt, 0, localObject.length);
          System.arraycopy(arrayOfObject, 0, a, 0, arrayOfObject.length);
        }
        a((int[])localObject, arrayOfObject, m);
      }
      else
      {
        throw new ConcurrentModificationException();
      }
    }
    if (i1 < m)
    {
      localObject = n;
      System.arraycopy(localObject, i1, localObject, i1 + 1, m - i1);
      localObject = a;
      System.arraycopy(localObject, i1 << 1, localObject, i1 + 1 << 1, size - i1 << 1);
    }
    int j = size;
    if (m == j)
    {
      localObject = n;
      if (i1 < localObject.length)
      {
        localObject[i1] = k;
        localObject = a;
        localObject[(i1 << 1)] = paramObject1;
        localObject[((i1 << 1) + 1)] = paramObject2;
        size = (j + 1);
        return null;
      }
    }
    throw new ConcurrentModificationException();
  }
  
  public Object putIfAbsent(Object paramObject1, Object paramObject2)
  {
    Object localObject = get(paramObject1);
    if (localObject == null) {
      return put(paramObject1, paramObject2);
    }
    return localObject;
  }
  
  public int read()
  {
    int k = size;
    if (k == 0) {
      return -1;
    }
    int m = get(n, k, 0);
    if (m < 0) {
      return m;
    }
    if (a[(m << 1)] == null) {
      return m;
    }
    int j = m + 1;
    while ((j < k) && (n[j] == 0))
    {
      if (a[(j << 1)] == null) {
        return j;
      }
      j += 1;
    }
    k = m - 1;
    while ((k >= 0) && (n[k] == 0))
    {
      if (a[(k << 1)] == null) {
        return k;
      }
      k -= 1;
    }
    return j;
  }
  
  public int read(Object paramObject)
  {
    if (paramObject == null) {
      return read();
    }
    return get(paramObject, paramObject.hashCode());
  }
  
  public Object remove(Object paramObject)
  {
    int j = read(paramObject);
    if (j >= 0) {
      return write(j);
    }
    return null;
  }
  
  public boolean remove(Object paramObject1, Object paramObject2)
  {
    int j = read(paramObject1);
    if (j >= 0)
    {
      paramObject1 = get(j);
      if ((paramObject2 == paramObject1) || ((paramObject2 != null) && (paramObject2.equals(paramObject1))))
      {
        write(j);
        return true;
      }
    }
    return false;
  }
  
  public Object replace(Object paramObject1, Object paramObject2)
  {
    int j = read(paramObject1);
    if (j >= 0) {
      return get(j, paramObject2);
    }
    return null;
  }
  
  public boolean replace(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    int j = read(paramObject1);
    if (j >= 0)
    {
      paramObject1 = get(j);
      if ((paramObject1 == paramObject2) || ((paramObject2 != null) && (paramObject2.equals(paramObject1))))
      {
        get(j, paramObject3);
        return true;
      }
    }
    return false;
  }
  
  public int size()
  {
    return size;
  }
  
  public String toString()
  {
    if (isEmpty()) {
      return "{}";
    }
    StringBuilder localStringBuilder = new StringBuilder(size * 28);
    localStringBuilder.append('{');
    int j = 0;
    while (j < size)
    {
      if (j > 0) {
        localStringBuilder.append(", ");
      }
      Object localObject = getValue(j);
      if (localObject != this) {
        localStringBuilder.append(localObject);
      } else {
        localStringBuilder.append("(this Map)");
      }
      localStringBuilder.append('=');
      localObject = get(j);
      if (localObject != this) {
        localStringBuilder.append(localObject);
      } else {
        localStringBuilder.append("(this Map)");
      }
      j += 1;
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public Object write(int paramInt)
  {
    Object localObject2 = a;
    Object localObject1 = localObject2[((paramInt << 1) + 1)];
    int m = size;
    if (m <= 1)
    {
      a(n, (Object[])localObject2, m);
      n = ContainerHelpers.n;
      a = ContainerHelpers.a;
      paramInt = 0;
    }
    else
    {
      int k = m - 1;
      localObject2 = n;
      int i1 = localObject2.length;
      int j = 8;
      if ((i1 > 8) && (size < localObject2.length / 3))
      {
        if (m > 8) {
          j = m + (m >> 1);
        }
        localObject2 = n;
        Object[] arrayOfObject = a;
        a(j);
        if (m == size)
        {
          if (paramInt > 0)
          {
            System.arraycopy(localObject2, 0, n, 0, paramInt);
            System.arraycopy(arrayOfObject, 0, a, 0, paramInt << 1);
          }
          if (paramInt < k)
          {
            System.arraycopy(localObject2, paramInt + 1, n, paramInt, k - paramInt);
            System.arraycopy(arrayOfObject, paramInt + 1 << 1, a, paramInt << 1, k - paramInt << 1);
          }
          paramInt = k;
        }
        else
        {
          throw new ConcurrentModificationException();
        }
      }
      else
      {
        if (paramInt < k)
        {
          localObject2 = n;
          System.arraycopy(localObject2, paramInt + 1, localObject2, paramInt, k - paramInt);
          localObject2 = a;
          System.arraycopy(localObject2, paramInt + 1 << 1, localObject2, paramInt << 1, k - paramInt << 1);
        }
        localObject2 = a;
        localObject2[(k << 1)] = null;
        localObject2[((k << 1) + 1)] = null;
        paramInt = k;
      }
    }
    if (m == size)
    {
      size = paramInt;
      return localObject1;
    }
    throw new ConcurrentModificationException();
  }
}
