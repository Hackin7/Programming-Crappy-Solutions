package org.codehaus.asm.asm;

import a.f.b.i.e;
import java.util.ArrayList;

public class d
{
  public boolean E;
  public int a;
  public f b;
  public f c;
  public f d;
  public f e;
  public int f;
  public int g;
  public int i;
  public f j;
  public f k;
  public float l = 0.0F;
  public boolean m = false;
  public int n;
  public f o;
  public boolean q;
  public boolean r;
  public ArrayList<e> s;
  public int v;
  public boolean z;
  
  public d(f paramF, int paramInt, boolean paramBoolean)
  {
    b = paramF;
    a = paramInt;
    m = paramBoolean;
  }
  
  public static boolean a(f paramF, int paramInt)
  {
    if ((paramF.length() != 8) && (c[paramInt] == XLayoutStyle.a))
    {
      paramF = P;
      if ((paramF[paramInt] == 0) || (paramF[paramInt] == 3)) {
        return true;
      }
    }
    return false;
  }
  
  public final void a()
  {
    int i2 = a * 2;
    Object localObject3 = b;
    Object localObject2 = b;
    int i1 = 0;
    boolean bool;
    for (;;)
    {
      bool = true;
      if (i1 != 0) {
        break;
      }
      i += 1;
      localObject1 = right;
      int i3 = a;
      localObject1[i3] = null;
      H[i3] = null;
      if (((f)localObject2).length() != 8)
      {
        g += 1;
        if (((f)localObject2).getValue(a) != XLayoutStyle.a) {
          f += ((f)localObject2).remove(a);
        }
        i3 = f + r[i2].b();
        f = i3;
        f = (i3 + r[(i2 + 1)].b());
        i3 = v + r[i2].b();
        v = i3;
        v = (i3 + r[(i2 + 1)].b());
        if (c == null) {
          c = ((f)localObject2);
        }
        o = ((f)localObject2);
        localObject1 = c;
        i3 = a;
        if (localObject1[i3] == XLayoutStyle.a)
        {
          localObject1 = P;
          if ((localObject1[i3] == 0) || (localObject1[i3] == 3) || (localObject1[i3] == 2))
          {
            n += 1;
            localObject1 = A;
            i3 = a;
            float f1 = localObject1[i3];
            if (f1 > 0.0F) {
              l += localObject1[i3];
            }
            if (a((f)localObject2, a))
            {
              if (f1 < 0.0F) {
                q = true;
              } else {
                r = true;
              }
              if (s == null) {
                s = new ArrayList();
              }
              s.add(localObject2);
            }
            if (e == null) {
              e = ((f)localObject2);
            }
            localObject1 = d;
            if (localObject1 != null) {
              H[a] = localObject2;
            }
            d = ((f)localObject2);
          }
          if (a == 0 ? (k == 0) && ((l != 0) || (o != 0)) : (h == 0) && (m == 0) && (p != 0)) {}
          if (E == 0.0F) {}
        }
      }
      if (localObject3 != localObject2) {
        right[a] = localObject2;
      }
      localObject3 = localObject2;
      localObject1 = r[(i2 + 1)].a;
      if (localObject1 != null)
      {
        Object localObject4 = b;
        localObject1 = localObject4;
        localObject4 = r;
        if ((a == null) || (a.b != localObject2)) {
          localObject1 = null;
        }
      }
      else
      {
        localObject1 = null;
      }
      if (localObject1 != null) {
        localObject2 = localObject1;
      } else {
        i1 = 1;
      }
    }
    Object localObject1 = c;
    if (localObject1 != null) {
      f -= r[i2].b();
    }
    localObject1 = o;
    if (localObject1 != null) {
      f -= r[(i2 + 1)].b();
    }
    j = ((f)localObject2);
    if ((a == 0) && (m)) {
      k = ((f)localObject2);
    } else {
      k = b;
    }
    if ((!r) || (!q)) {
      bool = false;
    }
    z = bool;
  }
  
  public void c()
  {
    if (!E) {
      a();
    }
    E = true;
  }
}
