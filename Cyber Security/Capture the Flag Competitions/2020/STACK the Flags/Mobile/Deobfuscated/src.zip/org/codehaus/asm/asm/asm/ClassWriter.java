package org.codehaus.asm.asm.asm;

import a.f.b.i.m.p;
import androidx.constraintlayout.widget.ConstraintLayout.b;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.b;
import org.codehaus.asm.asm.i;

public class ClassWriter
{
  public org.codehaus.asm.asm.MethodWriter a;
  public a b;
  public boolean c = true;
  public boolean e = true;
  public org.codehaus.asm.asm.MethodWriter f;
  public Item h;
  public ArrayList<a.f.b.i.m.m> n;
  public ArrayList<p> p = new ArrayList();
  
  public ClassWriter(org.codehaus.asm.asm.MethodWriter paramMethodWriter)
  {
    new ArrayList();
    h = null;
    b = new a();
    n = new ArrayList();
    a = paramMethodWriter;
    f = paramMethodWriter;
  }
  
  public final int a(org.codehaus.asm.asm.MethodWriter paramMethodWriter, int paramInt)
  {
    int j = n.size();
    long l = 0L;
    int i = 0;
    while (i < j)
    {
      l = Math.max(l, ((e)n.get(i)).a(paramMethodWriter, paramInt));
      i += 1;
    }
    return (int)l;
  }
  
  public void a()
  {
    Iterator localIterator = a.a.iterator();
    while (localIterator.hasNext())
    {
      org.codehaus.asm.asm.f localF = (org.codehaus.asm.asm.f)localIterator.next();
      if (!d)
      {
        Object localObject2 = c;
        int k = 0;
        Object localObject1 = localObject2[0];
        Object localObject3 = localObject2[1];
        int i = k;
        int m = h;
        if ((localObject1 != XLayoutStyle.c) && ((localObject1 != XLayoutStyle.a) || (i != 1))) {
          i = 0;
        } else {
          i = 1;
        }
        int j;
        if (localObject3 != XLayoutStyle.c)
        {
          j = k;
          if (localObject3 == XLayoutStyle.a)
          {
            j = k;
            if (m != 1) {}
          }
        }
        else
        {
          j = 1;
        }
        localObject2 = f.d;
        boolean bool1 = c;
        c localC = e.d;
        boolean bool2 = c;
        if ((bool1) && (bool2))
        {
          localObject1 = XLayoutStyle.b;
          a(localF, (XLayoutStyle)localObject1, d, (XLayoutStyle)localObject1, d);
          d = true;
        }
        else if ((bool1) && (j != 0))
        {
          a(localF, XLayoutStyle.b, f.d.d, XLayoutStyle.c, e.d.d);
          if (localObject3 == XLayoutStyle.a)
          {
            e.d.d = localF.size();
          }
          else
          {
            e.d.a(localF.size());
            d = true;
          }
        }
        else if ((bool2) && (i != 0))
        {
          a(localF, XLayoutStyle.c, f.d.d, XLayoutStyle.b, e.d.d);
          if (localObject1 == XLayoutStyle.a)
          {
            f.d.d = localF.getValue();
          }
          else
          {
            f.d.a(localF.getValue());
            d = true;
          }
        }
        if (d)
        {
          localObject1 = e.c;
          if (localObject1 != null) {
            ((c)localObject1).a(localF.newClass());
          }
        }
      }
    }
  }
  
  public void a(ArrayList paramArrayList)
  {
    paramArrayList.clear();
    f.f.e();
    f.e.e();
    paramArrayList.add(f.f);
    paramArrayList.add(f.e);
    Object localObject1 = null;
    Object localObject2 = f;
    ClassWriter localClassWriter = this;
    Object localObject3 = a.iterator();
    while (((Iterator)localObject3).hasNext())
    {
      org.codehaus.asm.asm.f localF = (org.codehaus.asm.asm.f)((Iterator)localObject3).next();
      if ((localF instanceof i))
      {
        paramArrayList.add(new NavigationMenuPresenter(localF));
      }
      else
      {
        if (localF.f())
        {
          if (length == null) {
            length = new m(localF, 0);
          }
          localObject2 = localObject1;
          if (localObject1 == null) {
            localObject2 = new HashSet();
          }
          ((HashSet)localObject2).add(length);
          localObject1 = localObject2;
        }
        else
        {
          paramArrayList.add(f);
        }
        if (localF.c())
        {
          if (next == null) {
            next = new m(localF, 1);
          }
          localObject2 = localObject1;
          if (localObject1 == null) {
            localObject2 = new HashSet();
          }
          ((HashSet)localObject2).add(next);
        }
        else
        {
          paramArrayList.add(e);
          localObject2 = localObject1;
        }
        localObject1 = localObject2;
        if ((localF instanceof org.codehaus.asm.asm.m))
        {
          paramArrayList.add(new MethodWriter(localF));
          localObject1 = localObject2;
        }
      }
    }
    if (localObject1 != null) {
      paramArrayList.addAll((Collection)localObject1);
    }
    localObject1 = paramArrayList.iterator();
    while (((Iterator)localObject1).hasNext()) {
      ((h)((Iterator)localObject1).next()).e();
    }
    paramArrayList = paramArrayList.iterator();
    while (paramArrayList.hasNext())
    {
      localObject1 = (h)paramArrayList.next();
      localObject2 = b;
      localObject3 = f;
      if (localObject2 != localObject3) {
        ((h)localObject1).a();
      }
    }
  }
  
  public final void a(Label paramLabel1, int paramInt1, int paramInt2, Label paramLabel2, ArrayList paramArrayList, e paramE)
  {
    Object localObject1 = b;
    if (q == null)
    {
      paramLabel1 = a;
      if (localObject1 != f)
      {
        if (localObject1 == e) {
          return;
        }
        paramLabel1 = paramE;
        if (paramE == null)
        {
          paramLabel1 = new e((h)localObject1, paramInt2);
          paramArrayList.add(paramLabel1);
        }
        q = paramLabel1;
        paramLabel1.a((h)localObject1);
        paramE = a.f.iterator();
        Object localObject2;
        while (paramE.hasNext())
        {
          localObject2 = (l)paramE.next();
          if ((localObject2 instanceof Label)) {
            a((Label)localObject2, paramInt1, 0, paramLabel2, paramArrayList, paramLabel1);
          }
        }
        paramE = c.f.iterator();
        while (paramE.hasNext())
        {
          localObject2 = (l)paramE.next();
          if ((localObject2 instanceof Label)) {
            a((Label)localObject2, paramInt1, 1, paramLabel2, paramArrayList, paramLabel1);
          }
        }
        if ((paramInt1 == 1) && ((localObject1 instanceof d)))
        {
          paramE = a.f.iterator();
          while (paramE.hasNext())
          {
            localObject2 = (l)paramE.next();
            if ((localObject2 instanceof Label)) {
              a((Label)localObject2, paramInt1, 2, paramLabel2, paramArrayList, paramLabel1);
            }
          }
        }
        paramE = a.a.iterator();
        while (paramE.hasNext())
        {
          localObject2 = (Label)paramE.next();
          if (localObject2 == paramLabel2) {}
          a((Label)localObject2, paramInt1, 0, paramLabel2, paramArrayList, paramLabel1);
        }
        paramE = c.a.iterator();
        while (paramE.hasNext())
        {
          localObject2 = (Label)paramE.next();
          if (localObject2 == paramLabel2) {}
          a((Label)localObject2, paramInt1, 1, paramLabel2, paramArrayList, paramLabel1);
        }
        if (paramInt1 == 1)
        {
          if (!(localObject1 instanceof d)) {
            return;
          }
          paramE = a.a.iterator();
        }
      }
    }
    while (paramE.hasNext())
    {
      localObject1 = (Label)paramE.next();
      try
      {
        a((Label)localObject1, paramInt1, 2, paramLabel2, paramArrayList, paramLabel1);
      }
      catch (Throwable paramLabel1)
      {
        throw paramLabel1;
      }
    }
    return;
  }
  
  public final void a(h paramH, int paramInt, ArrayList paramArrayList)
  {
    Object localObject = a.f.iterator();
    l localL;
    while (((Iterator)localObject).hasNext())
    {
      localL = (l)((Iterator)localObject).next();
      if ((localL instanceof Label)) {
        a((Label)localL, paramInt, 0, c, paramArrayList, null);
      } else if ((localL instanceof h)) {
        a(a, paramInt, 0, c, paramArrayList, null);
      }
    }
    localObject = c.f.iterator();
    while (((Iterator)localObject).hasNext())
    {
      localL = (l)((Iterator)localObject).next();
      if ((localL instanceof Label)) {
        a((Label)localL, paramInt, 1, a, paramArrayList, null);
      } else if ((localL instanceof h)) {
        a(c, paramInt, 1, a, paramArrayList, null);
      }
    }
    if (paramInt == 1)
    {
      paramH = a.f.iterator();
      while (paramH.hasNext())
      {
        localObject = (l)paramH.next();
        if ((localObject instanceof Label)) {
          a((Label)localObject, paramInt, 2, null, paramArrayList, null);
        }
      }
    }
  }
  
  public final void a(org.codehaus.asm.asm.f paramF, XLayoutStyle paramXLayoutStyle1, int paramInt1, XLayoutStyle paramXLayoutStyle2, int paramInt2)
  {
    a localA = b;
    b = paramXLayoutStyle1;
    a = paramXLayoutStyle2;
    c = paramInt1;
    i = paramInt2;
    ((ConstraintLayout.b)h).a(paramF, localA);
    paramF.append(b.j);
    paramF.add(b.k);
    paramF.a(b.p);
    paramF.putShort(b.l);
  }
  
  public final boolean a(org.codehaus.asm.asm.MethodWriter paramMethodWriter)
  {
    Iterator localIterator = a.iterator();
    while (localIterator.hasNext())
    {
      org.codehaus.asm.asm.f localF = (org.codehaus.asm.asm.f)localIterator.next();
      Object localObject1 = c;
      Object localObject2 = localObject1[0];
      Object localObject3 = localObject1[1];
      if (localF.length() == 8)
      {
        d = true;
      }
      else
      {
        if ((j < 1.0F) && (localObject2 == XLayoutStyle.a)) {
          k = 2;
        }
        if ((q < 1.0F) && (localObject3 == XLayoutStyle.a)) {
          h = 2;
        }
        if (localF.i() > 0.0F) {
          if ((localObject2 == XLayoutStyle.a) && ((localObject3 == XLayoutStyle.c) || (localObject3 == XLayoutStyle.b)))
          {
            k = 3;
          }
          else if ((localObject3 == XLayoutStyle.a) && ((localObject2 == XLayoutStyle.c) || (localObject2 == XLayoutStyle.b)))
          {
            h = 3;
          }
          else
          {
            localObject1 = XLayoutStyle.a;
            if ((localObject2 == localObject1) && (localObject3 == localObject1))
            {
              if (k == 0) {
                k = 3;
              }
              if (h == 0) {
                h = 3;
              }
            }
          }
        }
        localObject1 = localObject2;
        if (localObject2 == XLayoutStyle.a)
        {
          localObject1 = localObject2;
          if (k == 1) {
            if (b.a != null)
            {
              localObject1 = localObject2;
              if (i.a != null) {}
            }
            else
            {
              localObject1 = XLayoutStyle.c;
            }
          }
        }
        localObject2 = localObject3;
        if (localObject3 == XLayoutStyle.a)
        {
          localObject2 = localObject3;
          if (h == 1) {
            if (a.a != null)
            {
              localObject2 = localObject3;
              if (g.a != null) {}
            }
            else
            {
              localObject2 = XLayoutStyle.c;
            }
          }
        }
        localObject3 = f;
        p = ((XLayoutStyle)localObject1);
        g = k;
        localObject3 = e;
        p = ((XLayoutStyle)localObject2);
        g = h;
        int i;
        int j;
        if (((localObject1 != XLayoutStyle.r) && (localObject1 != XLayoutStyle.b) && (localObject1 != XLayoutStyle.c)) || ((localObject2 != XLayoutStyle.r) && (localObject2 != XLayoutStyle.b) && (localObject2 != XLayoutStyle.c)))
        {
          float f1;
          if ((localObject1 == XLayoutStyle.a) && ((localObject2 == XLayoutStyle.c) || (localObject2 == XLayoutStyle.b)))
          {
            i = k;
            if (i == 3)
            {
              localObject1 = XLayoutStyle.c;
              if (localObject2 == localObject1) {
                a(localF, (XLayoutStyle)localObject1, 0, (XLayoutStyle)localObject1, 0);
              }
              i = localF.size();
              j = (int)(i * E + 0.5F);
              localObject1 = XLayoutStyle.b;
              a(localF, (XLayoutStyle)localObject1, j, (XLayoutStyle)localObject1, i);
              f.d.a(localF.getValue());
              e.d.a(localF.size());
              d = true;
              continue;
            }
            if (i == 1)
            {
              a(localF, XLayoutStyle.c, 0, (XLayoutStyle)localObject2, 0);
              f.d.d = localF.getValue();
              continue;
            }
            if (i == 2)
            {
              localObject3 = c;
              if ((localObject3[0] == XLayoutStyle.b) || (localObject3[0] == XLayoutStyle.r))
              {
                f1 = j;
                i = (int)(paramMethodWriter.getValue() * f1 + 0.5F);
                j = localF.size();
                a(localF, XLayoutStyle.b, i, (XLayoutStyle)localObject2, j);
                f.d.a(localF.getValue());
                e.d.a(localF.size());
                d = true;
              }
            }
            else
            {
              localObject3 = r;
              if ((0a == null) || (1a == null))
              {
                a(localF, XLayoutStyle.c, 0, (XLayoutStyle)localObject2, 0);
                f.d.a(localF.getValue());
                e.d.a(localF.size());
                d = true;
                continue;
              }
            }
          }
          float f2;
          if ((localObject2 == XLayoutStyle.a) && ((localObject1 == XLayoutStyle.c) || (localObject1 == XLayoutStyle.b)))
          {
            i = h;
            if (i == 3)
            {
              localObject2 = XLayoutStyle.c;
              if (localObject1 == localObject2) {
                a(localF, (XLayoutStyle)localObject2, 0, (XLayoutStyle)localObject2, 0);
              }
              i = localF.getValue();
              f2 = E;
              f1 = f2;
              if (localF.r() == -1) {
                f1 = 1.0F / f2;
              }
              j = (int)(i * f1 + 0.5F);
              localObject1 = XLayoutStyle.b;
              a(localF, (XLayoutStyle)localObject1, i, (XLayoutStyle)localObject1, j);
              f.d.a(localF.getValue());
              e.d.a(localF.size());
              d = true;
              continue;
            }
            if (i == 1)
            {
              a(localF, (XLayoutStyle)localObject1, 0, XLayoutStyle.c, 0);
              e.d.d = localF.size();
              continue;
            }
            if (i == 2)
            {
              localObject3 = c;
              if ((localObject3[1] == XLayoutStyle.b) || (localObject3[1] == XLayoutStyle.r))
              {
                f1 = q;
                i = localF.getValue();
                j = (int)(paramMethodWriter.size() * f1 + 0.5F);
                a(localF, (XLayoutStyle)localObject1, i, XLayoutStyle.b, j);
                f.d.a(localF.getValue());
                e.d.a(localF.size());
                d = true;
              }
            }
            else
            {
              localObject3 = r;
              if ((2a == null) || (3a == null))
              {
                a(localF, XLayoutStyle.c, 0, (XLayoutStyle)localObject2, 0);
                f.d.a(localF.getValue());
                e.d.a(localF.size());
                d = true;
                continue;
              }
            }
          }
          localObject3 = XLayoutStyle.a;
          if ((localObject1 == localObject3) && (localObject2 == localObject3))
          {
            i = k;
            if (i != 1)
            {
              j = h;
              if (j != 1)
              {
                if ((j != 2) || (i != 2)) {
                  continue;
                }
                localObject1 = c;
                localObject2 = localObject1[0];
                localObject3 = XLayoutStyle.b;
                if ((localObject2 != localObject3) && (localObject1[0] != localObject3)) {
                  continue;
                }
                localObject1 = c;
                localObject2 = localObject1[1];
                localObject3 = XLayoutStyle.b;
                if ((localObject2 != localObject3) && (localObject1[1] != localObject3)) {
                  continue;
                }
                f1 = j;
                f2 = q;
                i = (int)(paramMethodWriter.getValue() * f1 + 0.5F);
                j = (int)(paramMethodWriter.size() * f2 + 0.5F);
                localObject1 = XLayoutStyle.b;
                a(localF, (XLayoutStyle)localObject1, i, (XLayoutStyle)localObject1, j);
                f.d.a(localF.getValue());
                e.d.a(localF.size());
                d = true;
                continue;
              }
            }
            localObject1 = XLayoutStyle.c;
            a(localF, (XLayoutStyle)localObject1, 0, (XLayoutStyle)localObject1, 0);
            f.d.d = localF.getValue();
            e.d.d = localF.size();
          }
        }
        else
        {
          i = localF.getValue();
          localObject3 = localObject1;
          if (localObject1 == XLayoutStyle.r)
          {
            i = paramMethodWriter.getValue() - b.j - i.j;
            localObject3 = XLayoutStyle.b;
          }
          j = localF.size();
          localObject1 = localObject2;
          if (localObject2 == XLayoutStyle.r)
          {
            j = paramMethodWriter.size();
            int k = a.j;
            int m = g.j;
            localObject1 = XLayoutStyle.b;
            j = j - k - m;
          }
          a(localF, (XLayoutStyle)localObject3, i, (XLayoutStyle)localObject1, j);
          f.d.a(localF.getValue());
          e.d.a(localF.size());
          d = true;
        }
      }
    }
    return false;
  }
  
  public boolean a(boolean paramBoolean)
  {
    boolean bool2 = paramBoolean & true;
    if ((c) || (e))
    {
      localObject1 = a.a.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (org.codehaus.asm.asm.f)((Iterator)localObject1).next();
        ((org.codehaus.asm.asm.f)localObject2).setTitle();
        d = false;
        f.b();
        e.b();
      }
      a.setTitle();
      localObject1 = a;
      d = false;
      f.b();
      a.e.b();
      e = false;
    }
    a(f);
    a.g(0);
    a.setText(0);
    Object localObject1 = a.getValue(0);
    Object localObject2 = a.getValue(1);
    if (c) {
      c();
    }
    int k = a.e();
    int j = a.getTitle();
    a.f.a.a(k);
    a.e.a.a(j);
    a();
    Object localObject3 = XLayoutStyle.c;
    if ((localObject1 == localObject3) || (localObject2 == localObject3))
    {
      bool1 = bool2;
      if (bool2)
      {
        localObject3 = p.iterator();
        do
        {
          bool1 = bool2;
          if (!((Iterator)localObject3).hasNext()) {
            break;
          }
        } while (((h)((Iterator)localObject3).next()).k());
        bool1 = false;
      }
      if ((bool1) && (localObject1 == XLayoutStyle.c))
      {
        a.add(XLayoutStyle.b);
        localObject3 = a;
        ((org.codehaus.asm.asm.f)localObject3).append(a((org.codehaus.asm.asm.MethodWriter)localObject3, 0));
        localObject3 = a;
        f.d.a(((org.codehaus.asm.asm.f)localObject3).getValue());
      }
      if ((bool1) && (localObject2 == XLayoutStyle.c))
      {
        a.a(XLayoutStyle.b);
        localObject3 = a;
        ((org.codehaus.asm.asm.f)localObject3).add(a((org.codehaus.asm.asm.MethodWriter)localObject3, 1));
        localObject3 = a;
        e.d.a(((org.codehaus.asm.asm.f)localObject3).size());
      }
    }
    boolean bool1 = false;
    localObject3 = a.c;
    int i;
    if ((localObject3[0] == XLayoutStyle.b) || (localObject3[0] == XLayoutStyle.r))
    {
      i = a.getValue() + k;
      a.f.c.a(i);
      a.f.d.a(i - k);
      a();
      localObject3 = a.c;
      if ((localObject3[1] == XLayoutStyle.b) || (localObject3[1] == XLayoutStyle.r))
      {
        i = a.size() + j;
        a.e.c.a(i);
        a.e.d.a(i - j);
      }
      a();
      i = 1;
    }
    localObject3 = p.iterator();
    h localH;
    while (((Iterator)localObject3).hasNext())
    {
      localH = (h)((Iterator)localObject3).next();
      if ((b != a) || (f)) {
        localH.d();
      }
    }
    boolean bool3 = true;
    localObject3 = p.iterator();
    do
    {
      do
      {
        paramBoolean = bool3;
        if (!((Iterator)localObject3).hasNext()) {
          break;
        }
        localH = (h)((Iterator)localObject3).next();
      } while ((i == 0) && (b == a));
      if (!a.c)
      {
        paramBoolean = false;
        break;
      }
      if ((!c.c) && (!(localH instanceof NavigationMenuPresenter)))
      {
        paramBoolean = false;
        break;
      }
    } while ((d.c) || ((localH instanceof m)) || ((localH instanceof NavigationMenuPresenter)));
    paramBoolean = false;
    a.add((XLayoutStyle)localObject1);
    a.a((XLayoutStyle)localObject2);
    return paramBoolean;
  }
  
  public boolean a(boolean paramBoolean, int paramInt)
  {
    boolean bool2 = paramBoolean & true;
    XLayoutStyle localXLayoutStyle1 = a.getValue(0);
    XLayoutStyle localXLayoutStyle2 = a.getValue(1);
    int j = a.e();
    int k = a.getTitle();
    h localH;
    if (bool2)
    {
      localObject = XLayoutStyle.c;
      if ((localXLayoutStyle1 == localObject) || (localXLayoutStyle2 == localObject))
      {
        localObject = p.iterator();
        do
        {
          bool1 = bool2;
          if (!((Iterator)localObject).hasNext()) {
            break;
          }
          localH = (h)((Iterator)localObject).next();
        } while ((e != paramInt) || (localH.k()));
        bool1 = false;
        if (paramInt == 0)
        {
          if ((bool1) && (localXLayoutStyle1 == XLayoutStyle.c))
          {
            a.add(XLayoutStyle.b);
            localObject = a;
            ((org.codehaus.asm.asm.f)localObject).append(a((org.codehaus.asm.asm.MethodWriter)localObject, 0));
            localObject = a;
            f.d.a(((org.codehaus.asm.asm.f)localObject).getValue());
          }
        }
        else if ((bool1) && (localXLayoutStyle2 == XLayoutStyle.c))
        {
          a.a(XLayoutStyle.b);
          localObject = a;
          ((org.codehaus.asm.asm.f)localObject).add(a((org.codehaus.asm.asm.MethodWriter)localObject, 1));
          localObject = a;
          e.d.a(((org.codehaus.asm.asm.f)localObject).size());
        }
      }
    }
    boolean bool1 = false;
    int i;
    if (paramInt == 0)
    {
      localObject = a.c;
      if ((localObject[0] == XLayoutStyle.b) || (localObject[0] == XLayoutStyle.r))
      {
        i = a.getValue() + j;
        a.f.c.a(i);
        a.f.d.a(i - j);
        i = 1;
      }
    }
    else
    {
      localObject = a.c;
      if ((localObject[1] == XLayoutStyle.b) || (localObject[1] == XLayoutStyle.r))
      {
        i = a.size() + k;
        a.e.c.a(i);
        a.e.d.a(i - k);
        i = 1;
      }
    }
    a();
    Object localObject = p.iterator();
    while (((Iterator)localObject).hasNext())
    {
      localH = (h)((Iterator)localObject).next();
      if ((e == paramInt) && ((b != a) || (f))) {
        localH.d();
      }
    }
    boolean bool3 = true;
    localObject = p.iterator();
    do
    {
      do
      {
        paramBoolean = bool3;
        if (!((Iterator)localObject).hasNext()) {
          break;
        }
        localH = (h)((Iterator)localObject).next();
      } while ((e != paramInt) || ((i == 0) && (b == a)));
      if (!a.c)
      {
        paramBoolean = false;
        break;
      }
      if (!c.c)
      {
        paramBoolean = false;
        break;
      }
    } while (((localH instanceof m)) || (d.c));
    paramBoolean = false;
    a.add(localXLayoutStyle1);
    a.a(localXLayoutStyle2);
    return paramBoolean;
  }
  
  public void b(Item paramItem)
  {
    h = paramItem;
  }
  
  public boolean b()
  {
    if (c)
    {
      Object localObject1 = a.a.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        Object localObject2 = (org.codehaus.asm.asm.f)((Iterator)localObject1).next();
        ((org.codehaus.asm.asm.f)localObject2).setTitle();
        d = false;
        f localF = f;
        d.c = false;
        f = false;
        localF.b();
        localObject2 = e;
        d.c = false;
        f = false;
        ((d)localObject2).b();
      }
      a.setTitle();
      localObject1 = a;
      d = false;
      localObject1 = f;
      d.c = false;
      f = false;
      ((f)localObject1).b();
      localObject1 = a.e;
      d.c = false;
      f = false;
      ((d)localObject1).b();
      c();
    }
    a(f);
    a.g(0);
    a.setText(0);
    a.f.a.a(0);
    a.e.a.a(0);
    return true;
  }
  
  public void c()
  {
    a(p);
    n.clear();
    e.c = 0;
    a(a.f, 0, n);
    a(a.e, 1, n);
    c = false;
  }
  
  public void newUTF8()
  {
    e = true;
  }
  
  public void visitInnerClass()
  {
    c = true;
  }
}
