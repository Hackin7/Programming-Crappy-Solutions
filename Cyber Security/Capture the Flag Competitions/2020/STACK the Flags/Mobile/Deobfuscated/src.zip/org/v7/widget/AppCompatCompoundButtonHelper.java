package org.v7.widget;

import android.content.res.ColorStateList;
import android.content.res.Resources.NotFoundException;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import org.core.asm.signature.DrawableCompat;
import org.core.view.ViewCompat;
import org.core.widget.CompoundButtonCompatDonut;
import org.v7.R.styleable;
import org.v7.internal.util.Resources;

public class AppCompatCompoundButtonHelper
{
  public ColorStateList mButtonTintList = null;
  public PorterDuff.Mode mButtonTintMode = null;
  public boolean mHasButtonTint = false;
  public boolean mHasButtonTintMode = false;
  public boolean mSkipNextApply;
  public final CompoundButton mView;
  
  public AppCompatCompoundButtonHelper(CompoundButton paramCompoundButton)
  {
    mView = paramCompoundButton;
  }
  
  public void applyButtonTint()
  {
    Drawable localDrawable = CompoundButtonCompatDonut.getButtonDrawable(mView);
    if ((localDrawable != null) && ((mHasButtonTint) || (mHasButtonTintMode)))
    {
      localDrawable = DrawableCompat.wrap(localDrawable).mutate();
      if (mHasButtonTint) {
        DrawableCompat.setTintList(localDrawable, mButtonTintList);
      }
      if (mHasButtonTintMode) {
        DrawableCompat.setTintMode(localDrawable, mButtonTintMode);
      }
      if (localDrawable.isStateful()) {
        localDrawable.setState(mView.getDrawableState());
      }
      mView.setButtonDrawable(localDrawable);
    }
  }
  
  public int getCompoundPaddingLeft(int paramInt)
  {
    return paramInt;
  }
  
  public ColorStateList getSupportButtonTintList()
  {
    return mButtonTintList;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode()
  {
    return mButtonTintMode;
  }
  
  public void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt)
  {
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(mView.getContext(), paramAttributeSet, R.styleable.CompoundButton, paramInt, 0);
    CompoundButton localCompoundButton = mView;
    ViewCompat.obtainStyledAttributes(localCompoundButton, localCompoundButton.getContext(), R.styleable.CompoundButton, paramAttributeSet, localTintTypedArray.getResourceId(), paramInt, 0);
    int i = 0;
    try
    {
      boolean bool = localTintTypedArray.hasValue(R.styleable.CompoundButton_buttonCompat);
      paramInt = i;
      if (bool)
      {
        int j = localTintTypedArray.getResourceId(R.styleable.CompoundButton_buttonCompat, 0);
        paramInt = i;
        if (j != 0)
        {
          paramAttributeSet = mView;
          localCompoundButton = mView;
          try
          {
            paramAttributeSet.setButtonDrawable(Resources.getDrawable(localCompoundButton.getContext(), j));
            paramInt = 1;
          }
          catch (Resources.NotFoundException paramAttributeSet)
          {
            paramInt = i;
          }
        }
      }
      if (paramInt == 0)
      {
        bool = localTintTypedArray.hasValue(R.styleable.CompoundButton_android_button);
        if (bool)
        {
          paramInt = localTintTypedArray.getResourceId(R.styleable.CompoundButton_android_button, 0);
          if (paramInt != 0) {
            mView.setButtonDrawable(Resources.getDrawable(mView.getContext(), paramInt));
          }
        }
      }
      bool = localTintTypedArray.hasValue(R.styleable.CompoundButton_buttonTint);
      if (bool) {
        CompoundButtonCompatDonut.setButtonTintList(mView, localTintTypedArray.getColorStateList(R.styleable.CompoundButton_buttonTint));
      }
      bool = localTintTypedArray.hasValue(R.styleable.CompoundButton_buttonTintMode);
      if (bool) {
        CompoundButtonCompatDonut.setButtonTintMode(mView, DrawableUtils.parseTintMode(localTintTypedArray.getInt(R.styleable.CompoundButton_buttonTintMode, -1), null));
      }
      localTintTypedArray.recycle();
      return;
    }
    catch (Throwable paramAttributeSet)
    {
      localTintTypedArray.recycle();
      throw paramAttributeSet;
    }
  }
  
  public void onSetButtonDrawable()
  {
    if (mSkipNextApply)
    {
      mSkipNextApply = false;
      return;
    }
    mSkipNextApply = true;
    applyButtonTint();
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList)
  {
    mButtonTintList = paramColorStateList;
    mHasButtonTint = true;
    applyButtonTint();
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode)
  {
    mButtonTintMode = paramMode;
    mHasButtonTintMode = true;
    applyButtonTint();
  }
}
