package org.asm;

import a.e.a;
import a.r.l.d;
import a.r.l.f;
import a.r.r;
import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.core.view.ViewCompat;
import org.data.Context;
import org.data.Item;

public abstract class l
  implements Cloneable
{
  public static final AnnotationVisitor K = new AnnotationNode();
  public static final int[] V = { 2, 1, 3, 4 };
  public static ThreadLocal<a<Animator, l.d>> _threadEncoder = new ThreadLocal();
  public TimeInterpolator B = null;
  public ClassVisitor Q;
  public ArrayList<r> a;
  public ArrayList<Integer> b = null;
  public ArrayList<View> c = new ArrayList();
  public x d = new x();
  public long e = -1L;
  public ArrayList<String> f = null;
  public boolean found = false;
  public h g = null;
  public ArrayList<Class> h = null;
  public boolean i = false;
  public String id = getClass().getName();
  public ArrayList<l.f> j = null;
  public ArrayList<View> k = null;
  public ArrayList<Class> l = null;
  public AnnotationVisitor length = K;
  public int m = 0;
  public ArrayList<Animator> mListeners = new ArrayList();
  public ArrayList<Integer> n = new ArrayList();
  public ArrayList<String> o = null;
  public ArrayList<Integer> p = null;
  public ArrayList<View> q = null;
  public x r = new x();
  public ArrayList<Class> s = null;
  public int[] t = V;
  public ArrayList<r> u;
  public ArrayList<Animator> v = new ArrayList();
  public boolean w = false;
  public long x = -1L;
  public Message z;
  
  public l() {}
  
  public static void a(x paramX, View paramView, Label paramLabel)
  {
    d.put(paramView, paramLabel);
    int i1 = paramView.getId();
    if (i1 >= 0) {
      if (a.indexOfKey(i1) >= 0) {
        a.put(i1, null);
      } else {
        a.put(i1, paramView);
      }
    }
    paramLabel = ViewCompat.getValue(paramView);
    if (paramLabel != null) {
      if (c.containsKey(paramLabel)) {
        c.put(paramLabel, null);
      } else {
        c.put(paramLabel, paramView);
      }
    }
    if ((paramView.getParent() instanceof ListView))
    {
      paramLabel = (ListView)paramView.getParent();
      if (paramLabel.getAdapter().hasStableIds())
      {
        long l1 = paramLabel.getItemIdAtPosition(paramLabel.getPositionForView(paramView));
        if (b.remove(l1) >= 0)
        {
          paramView = (View)b.get(l1);
          if (paramView != null)
          {
            ViewCompat.setHasTransientState(paramView, false);
            b.a(l1, null);
          }
          return;
        }
        ViewCompat.setHasTransientState(paramView, true);
        b.a(l1, paramView);
      }
    }
  }
  
  public static boolean a(Label paramLabel1, Label paramLabel2, String paramString)
  {
    paramLabel1 = c.get(paramString);
    paramLabel2 = c.get(paramString);
    if ((paramLabel1 == null) && (paramLabel2 == null)) {
      return false;
    }
    if ((paramLabel1 != null) && (paramLabel2 != null)) {
      return paramLabel1.equals(paramLabel2) ^ true;
    }
    return true;
  }
  
  public static org.data.Label getInstance()
  {
    org.data.Label localLabel2 = (org.data.Label)_threadEncoder.get();
    org.data.Label localLabel1 = localLabel2;
    if (localLabel2 == null)
    {
      localLabel1 = new org.data.Label();
      _threadEncoder.set(localLabel1);
    }
    return localLabel1;
  }
  
  public Animator a(ViewGroup paramViewGroup, Label paramLabel1, Label paramLabel2)
  {
    return null;
  }
  
  public String a(String paramString)
  {
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append(paramString);
    ((StringBuilder)localObject).append(getClass().getSimpleName());
    ((StringBuilder)localObject).append("@");
    ((StringBuilder)localObject).append(Integer.toHexString(hashCode()));
    ((StringBuilder)localObject).append(": ");
    localObject = ((StringBuilder)localObject).toString();
    paramString = (String)localObject;
    if (e != -1L)
    {
      paramString = new StringBuilder();
      paramString.append((String)localObject);
      paramString.append("dur(");
      paramString.append(e);
      paramString.append(") ");
      paramString = paramString.toString();
    }
    localObject = paramString;
    if (x != -1L)
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append(paramString);
      ((StringBuilder)localObject).append("dly(");
      ((StringBuilder)localObject).append(x);
      ((StringBuilder)localObject).append(") ");
      localObject = ((StringBuilder)localObject).toString();
    }
    paramString = (String)localObject;
    if (B != null)
    {
      paramString = new StringBuilder();
      paramString.append((String)localObject);
      paramString.append("interp(");
      paramString.append(B);
      paramString.append(") ");
      paramString = paramString.toString();
    }
    if ((n.size() > 0) || (c.size() > 0))
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append(paramString);
      ((StringBuilder)localObject).append("tgts(");
      paramString = ((StringBuilder)localObject).toString();
      localObject = paramString;
      int i1;
      if (n.size() > 0)
      {
        i1 = 0;
        for (;;)
        {
          localObject = paramString;
          if (i1 >= n.size()) {
            break;
          }
          localObject = paramString;
          if (i1 > 0)
          {
            localObject = new StringBuilder();
            ((StringBuilder)localObject).append(paramString);
            ((StringBuilder)localObject).append(", ");
            localObject = ((StringBuilder)localObject).toString();
          }
          paramString = new StringBuilder();
          paramString.append((String)localObject);
          paramString.append(n.get(i1));
          paramString = paramString.toString();
          i1 += 1;
        }
      }
      paramString = (String)localObject;
      if (c.size() > 0)
      {
        i1 = 0;
        for (;;)
        {
          paramString = (String)localObject;
          if (i1 >= c.size()) {
            break;
          }
          paramString = (String)localObject;
          if (i1 > 0)
          {
            paramString = new StringBuilder();
            paramString.append((String)localObject);
            paramString.append(", ");
            paramString = paramString.toString();
          }
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append(paramString);
          ((StringBuilder)localObject).append(c.get(i1));
          localObject = ((StringBuilder)localObject).toString();
          i1 += 1;
        }
      }
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append(paramString);
      ((StringBuilder)localObject).append(")");
      return ((StringBuilder)localObject).toString();
    }
    return paramString;
  }
  
  public l a(m paramM)
  {
    if (j == null) {
      j = new ArrayList();
    }
    j.add(paramM);
    return this;
  }
  
  public void a()
  {
    int i1 = m - 1;
    m = i1;
    if (i1 == 0)
    {
      Object localObject = j;
      if ((localObject != null) && (((ArrayList)localObject).size() > 0))
      {
        localObject = (ArrayList)j.clone();
        int i2 = ((ArrayList)localObject).size();
        i1 = 0;
        while (i1 < i2)
        {
          ((m)((ArrayList)localObject).get(i1)).a(this);
          i1 += 1;
        }
      }
      i1 = 0;
      while (i1 < d.b.b())
      {
        localObject = (View)d.b.b(i1);
        if (localObject != null) {
          ViewCompat.setHasTransientState((View)localObject, false);
        }
        i1 += 1;
      }
      i1 = 0;
      while (i1 < r.b.b())
      {
        localObject = (View)r.b.b(i1);
        if (localObject != null) {
          ViewCompat.setHasTransientState((View)localObject, false);
        }
        i1 += 1;
      }
      i = true;
    }
  }
  
  public final void a(View paramView, boolean paramBoolean)
  {
    if (paramView == null) {
      return;
    }
    int i2 = paramView.getId();
    Object localObject = b;
    if ((localObject != null) && (((ArrayList)localObject).contains(Integer.valueOf(i2)))) {
      return;
    }
    localObject = k;
    if ((localObject != null) && (((ArrayList)localObject).contains(paramView))) {
      return;
    }
    localObject = l;
    int i1;
    if (localObject != null)
    {
      int i3 = ((ArrayList)localObject).size();
      i1 = 0;
      while (i1 < i3)
      {
        if (((Class)l.get(i1)).isInstance(paramView)) {
          return;
        }
        i1 += 1;
      }
    }
    if ((paramView.getParent() instanceof ViewGroup))
    {
      localObject = new Label();
      a = paramView;
      if (paramBoolean) {
        a((Label)localObject);
      } else {
        b((Label)localObject);
      }
      b.add(this);
      c((Label)localObject);
      if (paramBoolean) {
        a(d, paramView, (Label)localObject);
      } else {
        a(r, paramView, (Label)localObject);
      }
    }
    if ((paramView instanceof ViewGroup))
    {
      localObject = p;
      if ((localObject != null) && (((ArrayList)localObject).contains(Integer.valueOf(i2)))) {
        return;
      }
      localObject = q;
      if ((localObject != null) && (((ArrayList)localObject).contains(paramView))) {
        return;
      }
      localObject = s;
      if (localObject != null)
      {
        i2 = ((ArrayList)localObject).size();
        i1 = 0;
        while (i1 < i2)
        {
          if (((Class)s.get(i1)).isInstance(paramView)) {
            return;
          }
          i1 += 1;
        }
      }
      paramView = (ViewGroup)paramView;
      i1 = 0;
      while (i1 < paramView.getChildCount())
      {
        a(paramView.getChildAt(i1), paramBoolean);
        i1 += 1;
      }
    }
  }
  
  public void a(ViewGroup paramViewGroup, x paramX1, x paramX2, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    org.data.Label localLabel = getInstance();
    SparseIntArray localSparseIntArray = new SparseIntArray();
    int i3 = paramArrayList1.size();
    int i1 = 0;
    int i2;
    while (i1 < i3)
    {
      Object localObject2 = (Label)paramArrayList1.get(i1);
      paramX1 = (Label)paramArrayList2.get(i1);
      Object localObject1 = localObject2;
      if (localObject2 != null)
      {
        localObject1 = localObject2;
        if (!b.contains(this)) {
          localObject1 = null;
        }
      }
      Object localObject3 = paramX1;
      if (paramX1 != null)
      {
        localObject3 = paramX1;
        if (!b.contains(this)) {
          localObject3 = null;
        }
      }
      if ((localObject1 != null) || (localObject3 != null))
      {
        if ((localObject1 != null) && (localObject3 != null) && (!a((Label)localObject1, (Label)localObject3))) {
          i2 = 0;
        } else {
          i2 = 1;
        }
        if (i2 != 0)
        {
          localObject2 = a(paramViewGroup, (Label)localObject1, (Label)localObject3);
          paramX1 = (x)localObject2;
          if (paramX1 != null)
          {
            Object localObject4 = null;
            if (localObject3 != null)
            {
              localObject3 = a;
              String[] arrayOfString = c();
              if ((localObject3 != null) && (arrayOfString != null)) {
                if (arrayOfString.length > 0)
                {
                  localObject1 = new Label();
                  a = ((View)localObject3);
                  localObject2 = (Label)d.get(localObject3);
                  if (localObject2 != null)
                  {
                    i2 = 0;
                    while (i2 < arrayOfString.length)
                    {
                      c.put(arrayOfString[i2], c.get(arrayOfString[i2]));
                      i2 += 1;
                    }
                  }
                  int i4 = localLabel.size();
                  i2 = 0;
                  while (i2 < i4)
                  {
                    localObject2 = (Widget)localLabel.get((Animator)localLabel.getValue(i2));
                    if ((a != null) && (i == localObject3) && (e.equals(getId())) && (a.equals(localObject1)))
                    {
                      paramX1 = null;
                      break;
                    }
                    i2 += 1;
                  }
                  break label417;
                }
              }
              paramX1 = (x)localObject2;
              localObject1 = localObject4;
              label417:
              localObject2 = localObject3;
            }
            else
            {
              localObject2 = a;
              localObject1 = null;
            }
            if (paramX1 != null)
            {
              localLabel.put(paramX1, new Widget((View)localObject2, getId(), this, Log.a(paramViewGroup), (Label)localObject1));
              v.add(paramX1);
            }
          }
          else {}
        }
      }
      i1 += 1;
    }
    if (Long.MAX_VALUE != 0L)
    {
      i1 = 0;
      while (i1 < localSparseIntArray.size())
      {
        i2 = localSparseIntArray.keyAt(i1);
        paramViewGroup = (Animator)v.get(i2);
        paramViewGroup.setStartDelay(localSparseIntArray.valueAt(i1) - Long.MAX_VALUE + paramViewGroup.getStartDelay());
        i1 += 1;
      }
    }
  }
  
  public void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    a(paramBoolean);
    Object localObject;
    if ((n.size() > 0) || (c.size() > 0))
    {
      localObject = f;
      if ((localObject == null) || (((ArrayList)localObject).isEmpty()))
      {
        localObject = h;
        if ((localObject == null) || (((ArrayList)localObject).isEmpty())) {
          break label75;
        }
      }
    }
    a(paramViewGroup, paramBoolean);
    break label309;
    label75:
    int i1 = 0;
    while (i1 < n.size())
    {
      localObject = paramViewGroup.findViewById(((Integer)n.get(i1)).intValue());
      if (localObject != null)
      {
        Label localLabel = new Label();
        a = ((View)localObject);
        if (paramBoolean) {
          a(localLabel);
        } else {
          b(localLabel);
        }
        b.add(this);
        c(localLabel);
        if (paramBoolean) {
          a(d, (View)localObject, localLabel);
        } else {
          a(r, (View)localObject, localLabel);
        }
      }
      i1 += 1;
    }
    i1 = 0;
    while (i1 < c.size())
    {
      paramViewGroup = (View)c.get(i1);
      localObject = new Label();
      a = paramViewGroup;
      if (paramBoolean) {
        a((Label)localObject);
      } else {
        b((Label)localObject);
      }
      b.add(this);
      c((Label)localObject);
      if (paramBoolean) {
        a(d, paramViewGroup, (Label)localObject);
      } else {
        a(r, paramViewGroup, (Label)localObject);
      }
      i1 += 1;
    }
    label309:
    if (!paramBoolean) {}
  }
  
  public void a(AnnotationVisitor paramAnnotationVisitor)
  {
    if (paramAnnotationVisitor == null)
    {
      length = K;
      return;
    }
    length = paramAnnotationVisitor;
  }
  
  public void a(ClassVisitor paramClassVisitor)
  {
    Q = paramClassVisitor;
  }
  
  public abstract void a(Label paramLabel);
  
  public void a(Message paramMessage)
  {
    z = paramMessage;
  }
  
  public final void a(x paramX1, x paramX2)
  {
    org.data.Label localLabel1 = new org.data.Label(d);
    org.data.Label localLabel2 = new org.data.Label(d);
    int i1 = 0;
    for (;;)
    {
      int[] arrayOfInt = t;
      if (i1 >= arrayOfInt.length) {
        break;
      }
      int i2 = arrayOfInt[i1];
      if (i2 != 1)
      {
        if (i2 != 2)
        {
          if (i2 != 3)
          {
            if (i2 == 4) {
              a(localLabel1, localLabel2, b, b);
            }
          }
          else {
            a(localLabel1, localLabel2, a, a);
          }
        }
        else {
          a(localLabel1, localLabel2, c, c);
        }
      }
      else {
        a(localLabel1, localLabel2);
      }
      i1 += 1;
    }
    draw(localLabel1, localLabel2);
  }
  
  public final void a(org.data.Label paramLabel1, org.data.Label paramLabel2)
  {
    int i1 = paramLabel1.size() - 1;
    while (i1 >= 0)
    {
      Object localObject1 = (View)paramLabel1.getValue(i1);
      if ((localObject1 != null) && (a((View)localObject1)))
      {
        localObject1 = (Label)paramLabel2.remove(localObject1);
        if (localObject1 != null)
        {
          Object localObject2 = a;
          if ((localObject2 != null) && (a((View)localObject2)))
          {
            localObject2 = (Label)paramLabel1.write(i1);
            u.add(localObject2);
            a.add(localObject1);
          }
        }
      }
      i1 -= 1;
    }
  }
  
  public final void a(org.data.Label paramLabel1, org.data.Label paramLabel2, SparseArray paramSparseArray1, SparseArray paramSparseArray2)
  {
    int i2 = paramSparseArray1.size();
    int i1 = 0;
    while (i1 < i2)
    {
      View localView1 = (View)paramSparseArray1.valueAt(i1);
      if ((localView1 != null) && (a(localView1)))
      {
        View localView2 = (View)paramSparseArray2.get(paramSparseArray1.keyAt(i1));
        if ((localView2 != null) && (a(localView2)))
        {
          Label localLabel1 = (Label)paramLabel1.get(localView1);
          Label localLabel2 = (Label)paramLabel2.get(localView2);
          if ((localLabel1 != null) && (localLabel2 != null))
          {
            u.add(localLabel1);
            a.add(localLabel2);
            paramLabel1.remove(localView1);
            paramLabel2.remove(localView2);
          }
        }
      }
      i1 += 1;
    }
  }
  
  public final void a(org.data.Label paramLabel1, org.data.Label paramLabel2, Item paramItem1, Item paramItem2)
  {
    int i2 = paramItem1.b();
    int i1 = 0;
    while (i1 < i2)
    {
      View localView1 = (View)paramItem1.b(i1);
      if ((localView1 != null) && (a(localView1)))
      {
        View localView2 = (View)paramItem2.get(paramItem1.get(i1));
        if ((localView2 != null) && (a(localView2)))
        {
          Label localLabel1 = (Label)paramLabel1.get(localView1);
          Label localLabel2 = (Label)paramLabel2.get(localView2);
          if ((localLabel1 != null) && (localLabel2 != null))
          {
            u.add(localLabel1);
            a.add(localLabel2);
            paramLabel1.remove(localView1);
            paramLabel2.remove(localView2);
          }
        }
      }
      i1 += 1;
    }
  }
  
  public final void a(org.data.Label paramLabel1, org.data.Label paramLabel2, org.data.Label paramLabel3, org.data.Label paramLabel4)
  {
    int i2 = paramLabel3.size();
    int i1 = 0;
    while (i1 < i2)
    {
      View localView1 = (View)paramLabel3.get(i1);
      if ((localView1 != null) && (a(localView1)))
      {
        View localView2 = (View)paramLabel4.get(paramLabel3.getValue(i1));
        if ((localView2 != null) && (a(localView2)))
        {
          Label localLabel1 = (Label)paramLabel1.get(localView1);
          Label localLabel2 = (Label)paramLabel2.get(localView2);
          if ((localLabel1 != null) && (localLabel2 != null))
          {
            u.add(localLabel1);
            a.add(localLabel2);
            paramLabel1.remove(localView1);
            paramLabel2.remove(localView2);
          }
        }
      }
      i1 += 1;
    }
  }
  
  public void a(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      d.d.clear();
      d.a.clear();
      d.b.a();
      return;
    }
    r.d.clear();
    r.a.clear();
    r.b.a();
  }
  
  public boolean a(View paramView)
  {
    int i2 = paramView.getId();
    ArrayList localArrayList = b;
    if ((localArrayList != null) && (localArrayList.contains(Integer.valueOf(i2)))) {
      return false;
    }
    localArrayList = k;
    if ((localArrayList != null) && (localArrayList.contains(paramView))) {
      return false;
    }
    localArrayList = l;
    int i1;
    if (localArrayList != null)
    {
      int i3 = localArrayList.size();
      i1 = 0;
      while (i1 < i3)
      {
        if (((Class)l.get(i1)).isInstance(paramView)) {
          return false;
        }
        i1 += 1;
      }
    }
    if ((o != null) && (ViewCompat.getValue(paramView) != null) && (o.contains(ViewCompat.getValue(paramView)))) {
      return false;
    }
    if ((n.size() == 0) && (c.size() == 0))
    {
      localArrayList = h;
      if ((localArrayList == null) || (localArrayList.isEmpty()))
      {
        localArrayList = f;
        if (localArrayList == null) {
          break label296;
        }
        if (localArrayList.isEmpty()) {
          return true;
        }
      }
    }
    if (!n.contains(Integer.valueOf(i2)))
    {
      if (c.contains(paramView)) {
        return true;
      }
      localArrayList = f;
      if ((localArrayList != null) && (localArrayList.contains(ViewCompat.getValue(paramView)))) {
        return true;
      }
      if (h != null)
      {
        i1 = 0;
        while (i1 < h.size())
        {
          if (((Class)h.get(i1)).isInstance(paramView)) {
            return true;
          }
          i1 += 1;
        }
      }
      return false;
    }
    label296:
    return true;
    return false;
  }
  
  public boolean a(Label paramLabel1, Label paramLabel2)
  {
    if ((paramLabel1 != null) && (paramLabel2 != null))
    {
      Object localObject = c();
      if (localObject != null)
      {
        int i2 = localObject.length;
        int i1 = 0;
        while (i1 < i2)
        {
          if (a(paramLabel1, paramLabel2, localObject[i1])) {
            return true;
          }
          i1 += 1;
        }
        return false;
      }
      localObject = c.keySet().iterator();
      while (((Iterator)localObject).hasNext()) {
        if (a(paramLabel1, paramLabel2, (String)((Iterator)localObject).next())) {
          return true;
        }
      }
    }
    return false;
  }
  
  public void accept(View paramView)
  {
    if (!i)
    {
      org.data.Label localLabel = getInstance();
      int i1 = localLabel.size();
      paramView = Log.a(paramView);
      i1 -= 1;
      while (i1 >= 0)
      {
        Widget localWidget = (Widget)localLabel.get(i1);
        if ((i != null) && (paramView.equals(b))) {
          ClassReader.start((Animator)localLabel.getValue(i1));
        }
        i1 -= 1;
      }
      paramView = j;
      if ((paramView != null) && (paramView.size() > 0))
      {
        paramView = (ArrayList)j.clone();
        int i2 = paramView.size();
        i1 = 0;
        while (i1 < i2)
        {
          ((m)paramView.get(i1)).b(this);
          i1 += 1;
        }
      }
      found = true;
    }
  }
  
  public Label b(View paramView, boolean paramBoolean)
  {
    Object localObject = g;
    if (localObject != null) {
      return ((l)localObject).b(paramView, paramBoolean);
    }
    if (paramBoolean) {
      localObject = u;
    } else {
      localObject = a;
    }
    if (localObject == null) {
      return null;
    }
    int i4 = ((ArrayList)localObject).size();
    int i3 = -1;
    int i1 = 0;
    int i2;
    for (;;)
    {
      i2 = i3;
      if (i1 >= i4) {
        break;
      }
      Label localLabel = (Label)((ArrayList)localObject).get(i1);
      if (localLabel == null) {
        return null;
      }
      if (a == paramView)
      {
        i2 = i1;
        break;
      }
      i1 += 1;
    }
    if (i2 >= 0)
    {
      if (paramBoolean) {
        paramView = a;
      } else {
        paramView = u;
      }
      return (Label)paramView.get(i2);
    }
    return null;
  }
  
  public l b()
  {
    try
    {
      Object localObject1 = super.clone();
      localObject1 = (l)localObject1;
      Object localObject2 = new ArrayList();
      v = ((ArrayList)localObject2);
      localObject2 = new x();
      d = ((x)localObject2);
      localObject2 = new x();
      r = ((x)localObject2);
      u = null;
      a = null;
      return localObject1;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException) {}
    return null;
  }
  
  public l b(long paramLong)
  {
    e = paramLong;
    return this;
  }
  
  public l b(TimeInterpolator paramTimeInterpolator)
  {
    B = paramTimeInterpolator;
    return this;
  }
  
  public l b(View paramView)
  {
    c.remove(paramView);
    return this;
  }
  
  public l b(m paramM)
  {
    ArrayList localArrayList = j;
    if (localArrayList == null) {
      return this;
    }
    localArrayList.remove(paramM);
    if (j.size() == 0) {
      j = null;
    }
    return this;
  }
  
  public abstract void b(Label paramLabel);
  
  public void c(Label paramLabel) {}
  
  public String[] c()
  {
    return null;
  }
  
  public void close(Animator paramAnimator)
  {
    if (paramAnimator == null)
    {
      a();
      return;
    }
    if (getPaddingLeft() >= 0L) {
      paramAnimator.setDuration(getPaddingLeft());
    }
    if (next() >= 0L) {
      paramAnimator.setStartDelay(next());
    }
    if (onCloseMenu() != null) {
      paramAnimator.setInterpolator(onCloseMenu());
    }
    paramAnimator.addListener(new GlowPadView.4(this));
    paramAnimator.start();
  }
  
  public Label draw(View paramView, boolean paramBoolean)
  {
    Object localObject = g;
    if (localObject != null) {
      return ((l)localObject).draw(paramView, paramBoolean);
    }
    if (paramBoolean) {
      localObject = d;
    } else {
      localObject = r;
    }
    return (Label)d.get(paramView);
  }
  
  public void draw()
  {
    e();
    org.data.Label localLabel = getInstance();
    Iterator localIterator = v.iterator();
    while (localIterator.hasNext())
    {
      Animator localAnimator = (Animator)localIterator.next();
      if (localLabel.containsKey(localAnimator))
      {
        e();
        remove(localAnimator, localLabel);
      }
    }
    v.clear();
    a();
  }
  
  public void draw(View paramView)
  {
    if (found)
    {
      if (!i)
      {
        org.data.Label localLabel = getInstance();
        int i1 = localLabel.size();
        paramView = Log.a(paramView);
        i1 -= 1;
        while (i1 >= 0)
        {
          Widget localWidget = (Widget)localLabel.get(i1);
          if ((i != null) && (paramView.equals(b))) {
            ClassReader.remove((Animator)localLabel.getValue(i1));
          }
          i1 -= 1;
        }
        paramView = j;
        if ((paramView != null) && (paramView.size() > 0))
        {
          paramView = (ArrayList)j.clone();
          int i2 = paramView.size();
          i1 = 0;
          while (i1 < i2)
          {
            ((m)paramView.get(i1)).d(this);
            i1 += 1;
          }
        }
      }
      found = false;
    }
  }
  
  public void draw(ViewGroup paramViewGroup)
  {
    u = new ArrayList();
    a = new ArrayList();
    a(d, r);
    org.data.Label localLabel = getInstance();
    int i1 = localLabel.size();
    aa localAa = Log.a(paramViewGroup);
    i1 -= 1;
    while (i1 >= 0)
    {
      Animator localAnimator = (Animator)localLabel.getValue(i1);
      if (localAnimator != null)
      {
        Widget localWidget = (Widget)localLabel.get(localAnimator);
        if ((localWidget != null) && (i != null) && (localAa.equals(b)))
        {
          Label localLabel1 = a;
          Object localObject = i;
          int i2 = 1;
          Label localLabel2 = draw((View)localObject, true);
          localObject = b((View)localObject, true);
          if (((localLabel2 == null) && (localObject == null)) || (!g.a(localLabel1, (Label)localObject))) {
            i2 = 0;
          }
          if (i2 != 0) {
            if ((!localAnimator.isRunning()) && (!localAnimator.isStarted())) {
              localLabel.remove(localAnimator);
            } else {
              localAnimator.cancel();
            }
          }
        }
      }
      i1 -= 1;
    }
    a(paramViewGroup, d, r, u, a);
    draw();
  }
  
  public final void draw(org.data.Label paramLabel1, org.data.Label paramLabel2)
  {
    int i1 = 0;
    while (i1 < paramLabel1.size())
    {
      Label localLabel = (Label)paramLabel1.get(i1);
      if (a(a))
      {
        u.add(localLabel);
        a.add(null);
      }
      i1 += 1;
    }
    i1 = 0;
    while (i1 < paramLabel2.size())
    {
      paramLabel1 = (Label)paramLabel2.get(i1);
      if (a(a))
      {
        a.add(paramLabel1);
        u.add(null);
      }
      i1 += 1;
    }
  }
  
  public void e()
  {
    if (m == 0)
    {
      ArrayList localArrayList = j;
      if ((localArrayList != null) && (localArrayList.size() > 0))
      {
        localArrayList = (ArrayList)j.clone();
        int i2 = localArrayList.size();
        int i1 = 0;
        while (i1 < i2)
        {
          ((m)localArrayList.get(i1)).c(this);
          i1 += 1;
        }
      }
      i = false;
    }
    m += 1;
  }
  
  public Message f()
  {
    return z;
  }
  
  public l f(long paramLong)
  {
    x = paramLong;
    return this;
  }
  
  public List get()
  {
    return c;
  }
  
  public l get(View paramView)
  {
    c.add(paramView);
    return this;
  }
  
  public String getId()
  {
    return id;
  }
  
  public long getPaddingLeft()
  {
    return e;
  }
  
  public List getTitle()
  {
    return h;
  }
  
  public List getValue()
  {
    return f;
  }
  
  public List length()
  {
    return n;
  }
  
  public long next()
  {
    return x;
  }
  
  public TimeInterpolator onCloseMenu()
  {
    return B;
  }
  
  public final void remove(Animator paramAnimator, org.data.Label paramLabel)
  {
    if (paramAnimator != null)
    {
      paramAnimator.addListener(new MainActivity.29(this, paramLabel));
      close(paramAnimator);
    }
  }
  
  public void setCallback() {}
  
  public String toString()
  {
    return a("");
  }
  
  public AnnotationVisitor visitAnnotation()
  {
    return length;
  }
}
