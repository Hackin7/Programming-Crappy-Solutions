package org.v7.app;

import a.b.k.f;
import a.e.b;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import androidx.appcompat.widget.Toolbar;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import org.data.TLongArrayList;
import org.v7.view.ActionMode;
import org.v7.view.ActionMode.Callback;

public abstract class AppCompatDelegate
{
  public static int TAG = -100;
  public static final Object lock = new Object();
  public static final b<WeakReference<f>> queue = new TLongArrayList();
  
  public AppCompatDelegate() {}
  
  public static int compare()
  {
    return -100;
  }
  
  public static AppCompatDelegate create(Activity paramActivity, AppCompatCallback paramAppCompatCallback)
  {
    return new AppCompatDelegateImplV7(paramActivity, paramAppCompatCallback);
  }
  
  public static AppCompatDelegate create(Dialog paramDialog, AppCompatCallback paramAppCompatCallback)
  {
    return new AppCompatDelegateImplV7(paramDialog, paramAppCompatCallback);
  }
  
  public static void create(AppCompatDelegate paramAppCompatDelegate)
  {
    Object localObject = lock;
    try
    {
      remove(paramAppCompatDelegate);
      queue.add(new WeakReference(paramAppCompatDelegate));
      return;
    }
    catch (Throwable paramAppCompatDelegate)
    {
      throw paramAppCompatDelegate;
    }
  }
  
  public static void remove(AppCompatDelegate paramAppCompatDelegate)
  {
    Object localObject = lock;
    try
    {
      Iterator localIterator = queue.iterator();
      while (localIterator.hasNext())
      {
        AppCompatDelegate localAppCompatDelegate = (AppCompatDelegate)((WeakReference)localIterator.next()).get();
        if ((localAppCompatDelegate == paramAppCompatDelegate) || (localAppCompatDelegate == null)) {
          localIterator.remove();
        }
      }
      return;
    }
    catch (Throwable paramAppCompatDelegate)
    {
      throw paramAppCompatDelegate;
    }
  }
  
  public static void setTitle(AppCompatDelegate paramAppCompatDelegate)
  {
    Object localObject = lock;
    try
    {
      remove(paramAppCompatDelegate);
      return;
    }
    catch (Throwable paramAppCompatDelegate)
    {
      throw paramAppCompatDelegate;
    }
  }
  
  public abstract void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void b();
  
  public abstract View findViewById(int paramInt);
  
  public abstract ActionBarDrawerToggle.Delegate getDrawerToggleDelegate();
  
  public abstract MenuInflater getMenuInflater();
  
  public abstract ActionBar getSupportActionBar();
  
  public int i()
  {
    return -100;
  }
  
  public abstract void installViewFactory();
  
  public abstract void invalidateOptionsMenu();
  
  public abstract void onConfigurationChanged(Configuration paramConfiguration);
  
  public Context onCreate(Context paramContext)
  {
    setSupportActionBar();
    return paramContext;
  }
  
  public abstract void onCreate();
  
  public void onCreate(int paramInt) {}
  
  public abstract void onCreate(Bundle paramBundle);
  
  public abstract void onPostCreate(Bundle paramBundle);
  
  public abstract void onPostResume();
  
  public abstract void onSaveInstanceState(Bundle paramBundle);
  
  public abstract void onStop();
  
  public abstract void onTitleChanged(CharSequence paramCharSequence);
  
  public abstract boolean requestWindowFeature(int paramInt);
  
  public abstract void setContentView(int paramInt);
  
  public abstract void setContentView(View paramView);
  
  public abstract void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void setSupportActionBar() {}
  
  public abstract void setSupportActionBar(Toolbar paramToolbar);
  
  public abstract ActionMode startSupportActionMode(ActionMode.Callback paramCallback);
}
