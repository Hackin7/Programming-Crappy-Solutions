package org.codehaus.asm.asm.asm;

import java.util.Iterator;
import java.util.List;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.m;

public class MethodWriter
  extends h
{
  public MethodWriter(f paramF)
  {
    super(paramF);
  }
  
  public void a()
  {
    Object localObject1 = b;
    if ((localObject1 instanceof org.codehaus.asm.asm.h))
    {
      a.i = true;
      localObject1 = (org.codehaus.asm.asm.h)localObject1;
      int i = ((org.codehaus.asm.asm.h)localObject1).m();
      boolean bool = ((org.codehaus.asm.asm.h)localObject1).isVisible();
      Object localObject2;
      if (i != 0)
      {
        if (i != 1)
        {
          if (i != 2)
          {
            if (i != 3) {
              return;
            }
            a.g = MathArrays.OrderDirection.l;
            i = 0;
            while (i < c)
            {
              localObject2 = b[i];
              if ((bool) || (((f)localObject2).length() != 8))
              {
                localObject2 = e.c;
                f.add(a);
                a.a.add(localObject2);
              }
              i += 1;
            }
            a(b.e.a);
            a(b.e.c);
            return;
          }
          a.g = MathArrays.OrderDirection.g;
          i = 0;
          while (i < c)
          {
            localObject2 = b[i];
            if ((bool) || (((f)localObject2).length() != 8))
            {
              localObject2 = e.a;
              f.add(a);
              a.a.add(localObject2);
            }
            i += 1;
          }
          a(b.e.a);
          a(b.e.c);
          return;
        }
        a.g = MathArrays.OrderDirection.i;
        i = 0;
        while (i < c)
        {
          localObject2 = b[i];
          if ((bool) || (((f)localObject2).length() != 8))
          {
            localObject2 = f.c;
            f.add(a);
            a.a.add(localObject2);
          }
          i += 1;
        }
        a(b.f.a);
        a(b.f.c);
        return;
      }
      a.g = MathArrays.OrderDirection.p;
      i = 0;
      while (i < c)
      {
        localObject2 = b[i];
        if ((bool) || (((f)localObject2).length() != 8))
        {
          localObject2 = f.a;
          f.add(a);
          a.a.add(localObject2);
        }
        i += 1;
      }
      a(b.f.a);
      a(b.f.c);
    }
  }
  
  public final void a(Label paramLabel)
  {
    a.f.add(paramLabel);
    a.add(a);
  }
  
  public void a(l paramL)
  {
    paramL = (org.codehaus.asm.asm.h)b;
    int n = paramL.m();
    int j = -1;
    int i = 0;
    Iterator localIterator = a.a.iterator();
    while (localIterator.hasNext())
    {
      int k = nextd;
      int m;
      if (j != -1)
      {
        m = j;
        if (k >= j) {}
      }
      else
      {
        m = k;
      }
      j = m;
      if (i < k)
      {
        i = k;
        j = m;
      }
    }
    if ((n != 0) && (n != 2))
    {
      a.a(paramL.k() + i);
      return;
    }
    a.a(paramL.k() + j);
  }
  
  public void d()
  {
    f localF = b;
    if ((localF instanceof org.codehaus.asm.asm.h))
    {
      int i = ((org.codehaus.asm.asm.h)localF).m();
      if ((i != 0) && (i != 1))
      {
        b.setText(a.d);
        return;
      }
      b.g(a.d);
    }
  }
  
  public void e()
  {
    q = null;
    a.a();
  }
  
  public boolean k()
  {
    return false;
  }
}
