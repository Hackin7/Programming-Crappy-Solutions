package org.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.PopupWindow.OnDismissListener;
import org.core.view.GravityCompat;
import org.core.view.ViewCompat;

public class i
{
  public View a;
  public k b;
  public final Context c;
  public final MenuBuilder d;
  public final boolean f;
  public final int g;
  public boolean h;
  public int j = 8388611;
  public l.a k;
  public final PopupWindow.OnDismissListener l = new v(this);
  public PopupWindow.OnDismissListener mOnDismissListener;
  public final int v;
  
  public i(Context paramContext, MenuBuilder paramMenuBuilder, View paramView, boolean paramBoolean, int paramInt)
  {
    this(paramContext, paramMenuBuilder, paramView, paramBoolean, paramInt, 0);
  }
  
  public i(Context paramContext, MenuBuilder paramMenuBuilder, View paramView, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    c = paramContext;
    d = paramMenuBuilder;
    a = paramView;
    f = paramBoolean;
    g = paramInt1;
    v = paramInt2;
  }
  
  public final k a()
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a12 = a6\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
  
  public final void a(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    k localK = b();
    localK.c(paramBoolean2);
    if (paramBoolean1)
    {
      int i = paramInt1;
      if ((GravityCompat.getAbsoluteGravity(j, ViewCompat.getLayoutDirection(a)) & 0x7) == 5) {
        i = paramInt1 - a.getWidth();
      }
      localK.show(i);
      localK.c(paramInt2);
      paramInt1 = (int)(48.0F * c.getResources().getDisplayMetrics().density / 2.0F);
      localK.a(new Rect(i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1));
    }
    localK.show();
  }
  
  public void a(View paramView)
  {
    a = paramView;
  }
  
  public void a(l.a paramA)
  {
    k = paramA;
    k localK = b;
    if (localK != null) {
      localK.setCallback(paramA);
    }
  }
  
  public void a(boolean paramBoolean)
  {
    h = paramBoolean;
    k localK = b;
    if (localK != null) {
      localK.a(paramBoolean);
    }
  }
  
  public boolean a(int paramInt1, int paramInt2)
  {
    if (isShowing()) {
      return true;
    }
    if (a == null) {
      return false;
    }
    a(paramInt1, paramInt2, true, true);
    return true;
  }
  
  public boolean add()
  {
    if (isShowing()) {
      return true;
    }
    if (a == null) {
      return false;
    }
    a(0, 0, false, false);
    return true;
  }
  
  public k b()
  {
    if (b == null) {
      b = a();
    }
    return b;
  }
  
  public void b(int paramInt)
  {
    j = paramInt;
  }
  
  public void dismiss()
  {
    if (isShowing()) {
      b.dismiss();
    }
  }
  
  public boolean isShowing()
  {
    k localK = b;
    return (localK != null) && (localK.isShowing());
  }
  
  public void onDismiss()
  {
    b = null;
    PopupWindow.OnDismissListener localOnDismissListener = mOnDismissListener;
    if (localOnDismissListener != null) {
      localOnDismissListener.onDismiss();
    }
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    mOnDismissListener = paramOnDismissListener;
  }
  
  public void show()
  {
    if (add()) {
      return;
    }
    throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
  }
}
