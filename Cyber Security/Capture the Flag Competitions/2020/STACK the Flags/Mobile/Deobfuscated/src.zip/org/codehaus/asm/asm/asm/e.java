package org.codehaus.asm.asm.asm;

import a.f.b.i.m.p;
import java.util.ArrayList;
import java.util.List;

public class e
{
  public static int c;
  public h b = null;
  public ArrayList<p> l = new ArrayList();
  
  public e(h paramH, int paramInt)
  {
    c += 1;
    b = paramH;
  }
  
  public long a(org.codehaus.asm.asm.MethodWriter paramMethodWriter, int paramInt)
  {
    Object localObject = b;
    if ((localObject instanceof m))
    {
      if (e != paramInt) {
        return 0L;
      }
    }
    else if (paramInt == 0)
    {
      if (!(localObject instanceof f)) {
        return 0L;
      }
    }
    else if (!(localObject instanceof d)) {
      return 0L;
    }
    if (paramInt == 0) {
      localObject = f;
    } else {
      localObject = e;
    }
    localObject = a;
    if (paramInt == 0) {
      paramMethodWriter = f;
    } else {
      paramMethodWriter = e;
    }
    paramMethodWriter = c;
    boolean bool1 = b.a.a.contains(localObject);
    boolean bool2 = b.c.a.contains(paramMethodWriter);
    long l4 = b.c();
    long l1;
    long l2;
    if ((bool1) && (bool2))
    {
      l1 = a(b.a, 0L);
      long l3 = b(b.c, 0L);
      l2 = l1 - l4;
      int i = b.c.j;
      l1 = l2;
      if (l2 >= -i) {
        l1 = l2 + i;
      }
      l2 = -l3;
      i = b.a.j;
      l3 = l2 - l4 - i;
      l2 = l3;
      if (l3 >= i) {
        l2 = l3 - i;
      }
      float f = b.b.size(paramInt);
      l3 = 0L;
      if (f > 0.0F) {
        l3 = ((float)l2 / f + (float)l1 / (1.0F - f));
      }
      l1 = ((float)l3 * f + 0.5F);
      l2 = ((float)l3 * (1.0F - f) + 0.5F);
      paramMethodWriter = b;
      return a.j + (l1 + l4 + l2) - c.j;
    }
    if (bool1)
    {
      paramMethodWriter = b.a;
      return Math.max(a(paramMethodWriter, j), b.a.j + l4);
    }
    if (bool2)
    {
      paramMethodWriter = b.c;
      l1 = b(paramMethodWriter, j);
      l2 = -b.c.j;
      return Math.max(-l1, l2 + l4);
    }
    paramMethodWriter = b;
    return a.j + paramMethodWriter.c() - b.c.j;
  }
  
  public final long a(Label paramLabel, long paramLong)
  {
    h localH = b;
    if ((localH instanceof MethodWriter)) {
      return paramLong;
    }
    long l1 = paramLong;
    int j = f.size();
    int i = 0;
    long l2;
    while (i < j)
    {
      Object localObject = (l)f.get(i);
      l2 = l1;
      if ((localObject instanceof Label))
      {
        localObject = (Label)localObject;
        if (b == localH) {
          l2 = l1;
        } else {
          l2 = Math.max(l1, a((Label)localObject, j + paramLong));
        }
      }
      i += 1;
      l1 = l2;
    }
    if (paramLabel == a)
    {
      l2 = localH.c();
      return Math.max(Math.max(l1, a(c, paramLong + l2)), paramLong + l2 - c.j);
    }
    return l1;
  }
  
  public void a(h paramH)
  {
    l.add(paramH);
  }
  
  public final long b(Label paramLabel, long paramLong)
  {
    h localH = b;
    if ((localH instanceof MethodWriter)) {
      return paramLong;
    }
    long l1 = paramLong;
    int j = f.size();
    int i = 0;
    long l2;
    while (i < j)
    {
      Object localObject = (l)f.get(i);
      l2 = l1;
      if ((localObject instanceof Label))
      {
        localObject = (Label)localObject;
        if (b == localH) {
          l2 = l1;
        } else {
          l2 = Math.min(l1, b((Label)localObject, j + paramLong));
        }
      }
      i += 1;
      l1 = l2;
    }
    if (paramLabel == c)
    {
      l2 = localH.c();
      return Math.min(Math.min(l1, b(a, paramLong - l2)), paramLong - l2 - a.j);
    }
    return l1;
  }
}
