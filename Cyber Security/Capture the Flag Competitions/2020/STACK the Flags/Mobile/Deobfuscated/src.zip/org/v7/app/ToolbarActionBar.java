package org.v7.app;

import a.b.k.a.b;
import android.content.Context;
import android.content.res.Configuration;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.Window.Callback;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.Toolbar.f;
import java.util.ArrayList;
import org.core.view.ViewCompat;
import org.v7.view.WindowCallbackWrapper;
import org.v7.view.menu.MenuBuilder;
import org.v7.view.menu.l.a;
import org.v7.widget.DecorToolbar;
import org.v7.widget.ToolbarWidgetWrapper;

public class ToolbarActionBar
  extends ActionBar
{
  public ArrayList<a.b> a = new ArrayList();
  public boolean f;
  public DecorToolbar mDecorToolbar;
  public boolean mMenuCallbackSet;
  public final Toolbar.f mMenuClicker = new Preferences(this);
  public final Runnable mMenuInvalidator = new EventInfoFragment.1(this);
  public boolean mOptionsMenuInvalidated;
  public Window.Callback mWindowCallback;
  
  public ToolbarActionBar(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback)
  {
    mDecorToolbar = new ToolbarWidgetWrapper(paramToolbar, false);
    paramCallback = new ToolbarCallbackWrapper(paramCallback);
    mWindowCallback = paramCallback;
    mDecorToolbar.setWindowCallback(paramCallback);
    paramToolbar.setOnMenuItemClickListener(mMenuClicker);
    mDecorToolbar.setWindowTitle(paramCharSequence);
  }
  
  public void a(boolean paramBoolean)
  {
    if (paramBoolean == f) {
      return;
    }
    f = paramBoolean;
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((x)a.get(i)).onCloseMenu(paramBoolean);
      i += 1;
    }
  }
  
  public boolean collapseActionView()
  {
    if (mDecorToolbar.hasExpandedActionView())
    {
      mDecorToolbar.collapseActionView();
      return true;
    }
    return false;
  }
  
  public int getDisplayOptions()
  {
    return mDecorToolbar.getDisplayOptions();
  }
  
  public final Menu getMenu()
  {
    if (!mMenuCallbackSet)
    {
      mDecorToolbar.setMenuCallbacks(new ActionMenuPresenterCallback(), new ActionMenuView.MenuBuilderCallback(this));
      mMenuCallbackSet = true;
    }
    return mDecorToolbar.getMenu();
  }
  
  public Context getThemedContext()
  {
    return mDecorToolbar.getContext();
  }
  
  public Window.Callback getWrappedWindowCallback()
  {
    return mWindowCallback;
  }
  
  public boolean invalidateOptionsMenu()
  {
    mDecorToolbar.getViewGroup().removeCallbacks(mMenuInvalidator);
    ViewCompat.postOnAnimation(mDecorToolbar.getViewGroup(), mMenuInvalidator);
    return true;
  }
  
  public boolean isShowing()
  {
    return mDecorToolbar.hideOverflowMenu();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
  }
  
  public void onDestroy()
  {
    mDecorToolbar.getViewGroup().removeCallbacks(mMenuInvalidator);
  }
  
  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    Menu localMenu = getMenu();
    if (localMenu != null)
    {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      }
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1) {
        bool = false;
      }
      localMenu.setQwertyMode(bool);
      return localMenu.performShortcut(paramInt, paramKeyEvent, 0);
    }
    return false;
  }
  
  public boolean onKeyShortcut(KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getAction() == 1) {
      openOptionsMenu();
    }
    return true;
  }
  
  public boolean openOptionsMenu()
  {
    return mDecorToolbar.showOverflowMenu();
  }
  
  public void populateOptionsMenu()
  {
    Menu localMenu = getMenu();
    MenuBuilder localMenuBuilder;
    if ((localMenu instanceof MenuBuilder)) {
      localMenuBuilder = (MenuBuilder)localMenu;
    } else {
      localMenuBuilder = null;
    }
    if (localMenuBuilder != null) {
      localMenuBuilder.stopDispatchingItemsChanged();
    }
    try
    {
      localMenu.clear();
      boolean bool = mWindowCallback.onCreatePanelMenu(0, localMenu);
      if (bool)
      {
        bool = mWindowCallback.onPreparePanel(0, null, localMenu);
        if (bool) {}
      }
      else
      {
        localMenu.clear();
      }
      if (localMenuBuilder != null)
      {
        localMenuBuilder.startDispatchingItemsChanged();
        return;
      }
    }
    catch (Throwable localThrowable)
    {
      if (localMenuBuilder != null) {
        localMenuBuilder.startDispatchingItemsChanged();
      }
      throw localThrowable;
    }
  }
  
  public void setDefaultDisplayHomeAsUpEnabled(boolean paramBoolean) {}
  
  public void setShowHideAnimationEnabled(boolean paramBoolean) {}
  
  public void setWindowTitle(CharSequence paramCharSequence)
  {
    mDecorToolbar.setWindowTitle(paramCharSequence);
  }
  
  public final class ActionMenuPresenterCallback
    implements l.a
  {
    public boolean mClosingActionMenu;
    
    public ActionMenuPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      if (mClosingActionMenu) {
        return;
      }
      mClosingActionMenu = true;
      mDecorToolbar.dismissPopupMenus();
      Window.Callback localCallback = mWindowCallback;
      if (localCallback != null) {
        localCallback.onPanelClosed(108, paramMenuBuilder);
      }
      mClosingActionMenu = false;
    }
    
    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      Window.Callback localCallback = mWindowCallback;
      if (localCallback != null)
      {
        localCallback.onMenuOpened(108, paramMenuBuilder);
        return true;
      }
      return false;
    }
  }
  
  public class ToolbarCallbackWrapper
    extends WindowCallbackWrapper
  {
    public ToolbarCallbackWrapper(Window.Callback paramCallback)
    {
      super();
    }
    
    public View onCreatePanelView(int paramInt)
    {
      if (paramInt == 0) {
        return new View(mDecorToolbar.getContext());
      }
      return super.onCreatePanelView(paramInt);
    }
    
    public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
    {
      boolean bool = super.onPreparePanel(paramInt, paramView, paramMenu);
      if (bool)
      {
        paramView = ToolbarActionBar.this;
        if (!mOptionsMenuInvalidated)
        {
          mDecorToolbar.setMenuPrepared();
          mOptionsMenuInvalidated = true;
        }
      }
      return bool;
    }
  }
}
