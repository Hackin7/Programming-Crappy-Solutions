package org.asm;

import android.graphics.Rect;

public class FieldVisitor
  extends Message
{
  public FieldVisitor(a paramA, Rect paramRect) {}
}
