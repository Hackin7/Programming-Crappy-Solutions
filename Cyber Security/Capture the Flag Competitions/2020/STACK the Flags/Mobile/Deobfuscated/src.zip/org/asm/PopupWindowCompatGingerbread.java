package org.asm;

import android.graphics.Matrix;
import android.util.Log;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class PopupWindowCompatGingerbread
  extends NumberPicker
{
  public static Method sGetWindowLayoutTypeMethod;
  public static boolean sGetWindowLayoutTypeMethodAttempted;
  public static Method sSetWindowLayoutTypeMethod;
  public static boolean sSetWindowLayoutTypeMethodAttempted;
  
  public PopupWindowCompatGingerbread() {}
  
  public void get(View paramView, Matrix paramMatrix)
  {
    getWindowLayoutType();
    Method localMethod = sGetWindowLayoutTypeMethod;
    if (localMethod != null) {
      try
      {
        localMethod.invoke(paramView, new Object[] { paramMatrix });
        return;
      }
      catch (InvocationTargetException paramView)
      {
        throw new RuntimeException(paramView.getCause());
      }
      catch (IllegalAccessException paramView) {}
    }
  }
  
  public final void getWindowLayoutType()
  {
    if (!sGetWindowLayoutTypeMethodAttempted)
    {
      try
      {
        Method localMethod = View.class.getDeclaredMethod("transformMatrixToLocal", new Class[] { Matrix.class });
        sGetWindowLayoutTypeMethod = localMethod;
        localMethod.setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.i("ViewUtilsApi21", "Failed to retrieve transformMatrixToLocal method", localNoSuchMethodException);
      }
      sGetWindowLayoutTypeMethodAttempted = true;
    }
  }
  
  public void set(View paramView, Matrix paramMatrix)
  {
    setWindowLayoutType();
    Method localMethod = sSetWindowLayoutTypeMethod;
    if (localMethod != null) {
      try
      {
        localMethod.invoke(paramView, new Object[] { paramMatrix });
        return;
      }
      catch (InvocationTargetException paramView)
      {
        throw new RuntimeException(paramView.getCause());
      }
      catch (IllegalAccessException paramView) {}
    }
  }
  
  public final void setWindowLayoutType()
  {
    if (!sSetWindowLayoutTypeMethodAttempted)
    {
      try
      {
        Method localMethod = View.class.getDeclaredMethod("transformMatrixToGlobal", new Class[] { Matrix.class });
        sSetWindowLayoutTypeMethod = localMethod;
        localMethod.setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.i("ViewUtilsApi21", "Failed to retrieve transformMatrixToGlobal method", localNoSuchMethodException);
      }
      sSetWindowLayoutTypeMethodAttempted = true;
    }
  }
}
