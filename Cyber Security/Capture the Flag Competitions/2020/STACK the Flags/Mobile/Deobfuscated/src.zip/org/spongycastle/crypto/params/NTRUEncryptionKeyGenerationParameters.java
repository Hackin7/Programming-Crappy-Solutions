package org.spongycastle.crypto.params;

import a.c.a.b.b.e;

public class NTRUEncryptionKeyGenerationParameters<K, V>
  extends b.e<K, V>
{
  public NTRUEncryptionKeyGenerationParameters(Attribute paramAttribute1, Attribute paramAttribute2)
  {
    super(paramAttribute1, paramAttribute2);
  }
  
  public Attribute a(Attribute paramAttribute)
  {
    return a;
  }
  
  public Attribute equals(Attribute paramAttribute)
  {
    return b;
  }
}
