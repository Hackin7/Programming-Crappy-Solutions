package org.codehaus.asm;

import java.util.Arrays;

public class Attribute
  implements Comparable
{
  public Label s;
  
  public Attribute(i paramI1, i paramI2) {}
  
  public final boolean a()
  {
    int i = 8;
    while (i >= 0)
    {
      float f = s.m[i];
      if (f > 0.0F) {
        return false;
      }
      if (f < 0.0F) {
        return true;
      }
      i -= 1;
    }
    return false;
  }
  
  public final boolean a(Label paramLabel)
  {
    int i = 8;
    while (i >= 0)
    {
      float f1 = m[i];
      float f2 = s.m[i];
      if (f2 == f1) {
        i -= 1;
      } else if (f2 < f1) {
        return true;
      }
    }
    return false;
  }
  
  public boolean a(Label paramLabel, float paramFloat)
  {
    if (s.t)
    {
      int j = 1;
      i = 0;
      while (i < 9)
      {
        float[] arrayOfFloat = s.m;
        arrayOfFloat[i] += m[i] * paramFloat;
        if (Math.abs(arrayOfFloat[i]) < 1.0E-4F) {
          s.m[i] = 0.0F;
        } else {
          j = 0;
        }
        i += 1;
      }
      if (j != 0) {
        i.a(b, s);
      }
      return false;
    }
    int i = 0;
    while (i < 9)
    {
      float f1 = m[i];
      if (f1 != 0.0F)
      {
        float f2 = paramFloat * f1;
        f1 = f2;
        if (Math.abs(f2) < 1.0E-4F) {
          f1 = 0.0F;
        }
        s.m[i] = f1;
      }
      else
      {
        s.m[i] = 0.0F;
      }
      i += 1;
    }
    return true;
  }
  
  public void b()
  {
    Arrays.fill(s.m, 0.0F);
  }
  
  public int compareTo(Object paramObject)
  {
    paramObject = (Label)paramObject;
    return s.n - n;
  }
  
  public String toString()
  {
    Object localObject1 = "[ ";
    Object localObject2 = localObject1;
    if (s != null)
    {
      int i = 0;
      for (;;)
      {
        localObject2 = localObject1;
        if (i >= 9) {
          break;
        }
        localObject2 = new StringBuilder();
        ((StringBuilder)localObject2).append((String)localObject1);
        ((StringBuilder)localObject2).append(s.m[i]);
        ((StringBuilder)localObject2).append(" ");
        localObject1 = ((StringBuilder)localObject2).toString();
        i += 1;
      }
    }
    localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append((String)localObject2);
    ((StringBuilder)localObject1).append("] ");
    ((StringBuilder)localObject1).append(s);
    return ((StringBuilder)localObject1).toString();
  }
  
  public void write(Label paramLabel)
  {
    s = paramLabel;
  }
}
