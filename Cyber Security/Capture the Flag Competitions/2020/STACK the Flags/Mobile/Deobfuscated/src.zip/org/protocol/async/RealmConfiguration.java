package org.protocol.async;

import android.content.Context;

public class RealmConfiguration
{
  public final Context mApplicationContext;
}
