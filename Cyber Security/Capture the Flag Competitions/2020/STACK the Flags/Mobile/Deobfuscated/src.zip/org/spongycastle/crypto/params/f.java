package org.spongycastle.crypto.params;

import a.c.a.b.b.c;
import a.c.a.b.b.f;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;

public class f<K, V>
  implements Iterable<Map.Entry<K, V>>
{
  public b.c<K, V> a;
  public b.c<K, V> c;
  public WeakHashMap<b.f<K, V>, Boolean> m = new WeakHashMap();
  public int n = 0;
  
  public f() {}
  
  public Object a(Object paramObject)
  {
    paramObject = b(paramObject);
    if (paramObject == null) {
      return null;
    }
    n -= 1;
    if (!m.isEmpty())
    {
      localObject = m.keySet().iterator();
      while (((Iterator)localObject).hasNext()) {
        ((x)((Iterator)localObject).next()).init(paramObject);
      }
    }
    Object localObject = b;
    if (localObject != null) {
      a = a;
    } else {
      a = a;
    }
    localObject = a;
    if (localObject != null) {
      b = b;
    } else {
      c = b;
    }
    a = null;
    b = null;
    return d;
  }
  
  public Attribute a(Object paramObject1, Object paramObject2)
  {
    paramObject1 = new Attribute(paramObject1, paramObject2);
    n += 1;
    paramObject2 = c;
    if (paramObject2 == null)
    {
      a = paramObject1;
      c = paramObject1;
      return paramObject1;
    }
    a = paramObject1;
    b = paramObject2;
    c = paramObject1;
    return paramObject1;
  }
  
  public d a()
  {
    d localD = new d(this);
    m.put(localD, Boolean.valueOf(false));
    return localD;
  }
  
  public Attribute b(Object paramObject)
  {
    for (Attribute localAttribute = a; localAttribute != null; localAttribute = a) {
      if (x.equals(paramObject)) {
        return localAttribute;
      }
    }
    return localAttribute;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof f)) {
      return false;
    }
    Object localObject1 = (f)paramObject;
    if (size() != ((f)localObject1).size()) {
      return false;
    }
    paramObject = iterator();
    localObject1 = ((f)localObject1).iterator();
    while ((((HttpHost)paramObject).hasNext()) && (((HttpHost)localObject1).hasNext()))
    {
      Map.Entry localEntry = (Map.Entry)((HttpHost)paramObject).next();
      Object localObject2 = ((HttpHost)localObject1).next();
      if ((localEntry == null) && (localObject2 != null)) {
        break label134;
      }
      if ((localEntry != null) && (!localEntry.equals(localObject2))) {
        return false;
      }
    }
    return (!((HttpHost)paramObject).hasNext()) && (!((HttpHost)localObject1).hasNext());
    label134:
    return false;
  }
  
  public Iterator f()
  {
    l localL = new l(c, a);
    m.put(localL, Boolean.valueOf(false));
    return localL;
  }
  
  public int hashCode()
  {
    int i = 0;
    Iterator localIterator = iterator();
    while (((HttpHost)localIterator).hasNext()) {
      i += ((Map.Entry)((HttpHost)localIterator).next()).hashCode();
    }
    return i;
  }
  
  public Iterator iterator()
  {
    NTRUEncryptionKeyGenerationParameters localNTRUEncryptionKeyGenerationParameters = new NTRUEncryptionKeyGenerationParameters(a, c);
    m.put(localNTRUEncryptionKeyGenerationParameters, Boolean.valueOf(false));
    return localNTRUEncryptionKeyGenerationParameters;
  }
  
  public Map.Entry m()
  {
    return a;
  }
  
  public Map.Entry p()
  {
    return c;
  }
  
  public int size()
  {
    return n;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[");
    Iterator localIterator = iterator();
    while (((HttpHost)localIterator).hasNext())
    {
      localStringBuilder.append(((Map.Entry)((HttpHost)localIterator).next()).toString());
      if (((HttpHost)localIterator).hasNext()) {
        localStringBuilder.append(", ");
      }
    }
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }
}
