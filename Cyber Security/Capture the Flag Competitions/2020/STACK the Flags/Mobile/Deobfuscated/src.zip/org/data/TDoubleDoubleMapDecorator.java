package org.data;

import a.e.f;
import java.util.Map;

public class TDoubleDoubleMapDecorator
  extends f<K, V>
{
  public TDoubleDoubleMapDecorator(Label paramLabel) {}
  
  public void clear()
  {
    this$0.clear();
  }
  
  public int get(Object paramObject)
  {
    return this$0.accept(paramObject);
  }
  
  public Object get(int paramInt1, int paramInt2)
  {
    return this$0.a[((paramInt1 << 1) + paramInt2)];
  }
  
  public Map get()
  {
    return this$0;
  }
  
  public int indexOf(Object paramObject)
  {
    return this$0.read(paramObject);
  }
  
  public Object put(int paramInt, Object paramObject)
  {
    return this$0.get(paramInt, paramObject);
  }
  
  public void put(Object paramObject1, Object paramObject2)
  {
    this$0.put(paramObject1, paramObject2);
  }
  
  public void remove(int paramInt)
  {
    this$0.write(paramInt);
  }
  
  public int size()
  {
    return this$0.size;
  }
}
