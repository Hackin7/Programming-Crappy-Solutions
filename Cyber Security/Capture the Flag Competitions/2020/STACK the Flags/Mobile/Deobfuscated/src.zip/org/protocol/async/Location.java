package org.protocol.async;

public abstract interface Location
{
  public abstract String getQuery();
  
  public abstract void load(Connection paramConnection);
}
