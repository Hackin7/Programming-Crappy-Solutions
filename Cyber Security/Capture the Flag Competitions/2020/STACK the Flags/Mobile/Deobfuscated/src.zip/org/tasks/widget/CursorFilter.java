package org.tasks.widget;

import android.database.Cursor;
import android.widget.Filter;
import android.widget.Filter.FilterResults;
import org.v7.widget.SuggestionsAdapter;

public class CursorFilter
  extends Filter
{
  public CursorFilterClient mClient;
  
  public CursorFilter(CursorFilterClient paramCursorFilterClient)
  {
    mClient = paramCursorFilterClient;
  }
  
  public CharSequence convertResultToString(Object paramObject)
  {
    CursorFilterClient localCursorFilterClient = mClient;
    paramObject = (Cursor)paramObject;
    return ((SuggestionsAdapter)localCursorFilterClient).convertToString(paramObject);
  }
  
  public Filter.FilterResults performFiltering(CharSequence paramCharSequence)
  {
    paramCharSequence = ((SuggestionsAdapter)mClient).runQueryOnBackgroundThread(paramCharSequence);
    Filter.FilterResults localFilterResults = new Filter.FilterResults();
    if (paramCharSequence != null)
    {
      count = paramCharSequence.getCount();
      values = paramCharSequence;
      return localFilterResults;
    }
    count = 0;
    values = null;
    return localFilterResults;
  }
  
  public void publishResults(CharSequence paramCharSequence, Filter.FilterResults paramFilterResults)
  {
    paramCharSequence = ((CursorAdapter)mClient).getCursor();
    paramFilterResults = values;
    if ((paramFilterResults != null) && (paramFilterResults != paramCharSequence))
    {
      paramCharSequence = mClient;
      paramFilterResults = (Cursor)paramFilterResults;
      ((SuggestionsAdapter)paramCharSequence).changeCursor(paramFilterResults);
    }
  }
  
  public abstract interface CursorFilterClient {}
}
