package org.objectweb.asm;

import a.o.c.e.c;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView.b0;
import androidx.recyclerview.widget.RecyclerView.u;
import androidx.recyclerview.widget.RecyclerView.y;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

public final class b
  implements Runnable
{
  public static Comparator<e.c> b = new w();
  public static final ThreadLocal<a.o.c.e> random = new ThreadLocal();
  public ArrayList<e.c> a = new ArrayList();
  public long c;
  public long d;
  public ArrayList<androidx.recyclerview.widget.RecyclerView> l = new ArrayList();
  
  public b() {}
  
  public static boolean findViewHolderForPosition(androidx.recyclerview.widget.RecyclerView paramRecyclerView, int paramInt)
  {
    int j = mChildHelper.getUnfilteredChildCount();
    int i = 0;
    while (i < j)
    {
      RecyclerView.b0 localB0 = androidx.recyclerview.widget.RecyclerView.getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(i));
      if ((mPosition == paramInt) && (!localB0.isInvalid())) {
        return true;
      }
      i += 1;
    }
    return false;
  }
  
  public final RecyclerView.b0 a(androidx.recyclerview.widget.RecyclerView paramRecyclerView, int paramInt, long paramLong)
  {
    if (findViewHolderForPosition(paramRecyclerView, paramInt)) {
      return null;
    }
    RecyclerView.u localU = mRecycler;
    try
    {
      paramRecyclerView.onEnterLayoutOrScroll();
      RecyclerView.b0 localB0 = localU.getViewForPosition(paramInt, false, paramLong);
      if (localB0 != null) {
        try
        {
          boolean bool = localB0.isBound();
          if (bool)
          {
            bool = localB0.isInvalid();
            if (!bool)
            {
              localU.recycleView(itemView);
              break label88;
            }
          }
          localU.b(localB0, false);
        }
        catch (Throwable localThrowable1)
        {
          break label98;
        }
      }
      label88:
      paramRecyclerView.scrollByInternal(false);
      return localB0;
    }
    catch (Throwable localThrowable2)
    {
      label98:
      paramRecyclerView.scrollByInternal(false);
      throw localThrowable2;
    }
  }
  
  public final void a()
  {
    Object localObject2 = l;
    Object localObject1 = this;
    int n = ((ArrayList)localObject2).size();
    int j = 0;
    int i = 0;
    int k;
    while (i < n)
    {
      localObject2 = l;
      localObject2 = (androidx.recyclerview.widget.RecyclerView)((ArrayList)localObject2).get(i);
      k = j;
      if (((View)localObject2).getWindowVisibility() == 0)
      {
        d.a((androidx.recyclerview.widget.RecyclerView)localObject2, false);
        k = j + d.c;
      }
      i += 1;
      j = k;
    }
    localObject2 = a;
    ((ArrayList)localObject2).ensureCapacity(j);
    i = 0;
    j = 0;
    while (j < n)
    {
      localObject2 = l;
      androidx.recyclerview.widget.RecyclerView localRecyclerView = (androidx.recyclerview.widget.RecyclerView)((ArrayList)localObject2).get(j);
      int m;
      if (localRecyclerView.getWindowVisibility() != 0)
      {
        m = i;
        localObject2 = localObject1;
      }
      else
      {
        i localI = d;
        int i1 = Math.abs(e) + Math.abs(d);
        k = 0;
        for (;;)
        {
          m = i;
          localObject2 = localObject1;
          if (k >= c * 2) {
            break;
          }
          if (i >= a.size())
          {
            localObject2 = new e();
            a.add(localObject2);
          }
          else
          {
            localObject2 = (e)a.get(i);
          }
          m = b[(k + 1)];
          boolean bool;
          if (m <= i1) {
            bool = true;
          } else {
            bool = false;
          }
          l = bool;
          c = i1;
          b = m;
          a = localRecyclerView;
          k = b[k];
          i += 1;
          k += 2;
        }
      }
      j += 1;
      i = m;
      localObject1 = localObject2;
    }
    Collections.sort(a, b);
  }
  
  public final void a(long paramLong)
  {
    int i = 0;
    while (i < a.size())
    {
      e localE = (e)a.get(i);
      if (a == null) {
        return;
      }
      a(localE, paramLong);
      localE.b();
      i += 1;
    }
  }
  
  public void a(androidx.recyclerview.widget.RecyclerView paramRecyclerView)
  {
    l.remove(paramRecyclerView);
  }
  
  public void a(androidx.recyclerview.widget.RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    if ((paramRecyclerView.isAttachedToWindow()) && (c == 0L))
    {
      c = paramRecyclerView.getNanoTime();
      paramRecyclerView.post(this);
    }
    d.b(paramInt1, paramInt2);
  }
  
  public final void a(androidx.recyclerview.widget.RecyclerView paramRecyclerView, long paramLong)
  {
    if (paramRecyclerView == null) {
      return;
    }
    if ((mDataSetHasChangedAfterLayout) && (mChildHelper.getUnfilteredChildCount() != 0)) {
      paramRecyclerView.setAdapterInternal();
    }
    i localI = d;
    localI.a(paramRecyclerView, true);
    if (c != 0) {
      try
      {
        org.core.models.RecyclerView.beginSection("RV Nested Prefetch");
        mState.dispatchLayoutStep1(mAdapter);
        int i = 0;
        for (;;)
        {
          int j = c;
          if (i >= j * 2) {
            break;
          }
          a(paramRecyclerView, b[i], paramLong);
          i += 2;
        }
        org.core.models.RecyclerView.endSection();
        return;
      }
      catch (Throwable paramRecyclerView)
      {
        org.core.models.RecyclerView.endSection();
        throw paramRecyclerView;
      }
    }
  }
  
  public final void a(e paramE, long paramLong)
  {
    long l1;
    if (l) {
      l1 = Long.MAX_VALUE;
    } else {
      l1 = paramLong;
    }
    paramE = a(a, k, l1);
    if ((paramE != null) && (l != null) && (paramE.isBound()) && (!paramE.isInvalid())) {
      a((androidx.recyclerview.widget.RecyclerView)l.get(), paramLong);
    }
  }
  
  public void e(long paramLong)
  {
    a();
    a(paramLong);
  }
  
  public void run()
  {
    try
    {
      org.core.models.RecyclerView.beginSection("RV Prefetch");
      boolean bool = l.isEmpty();
      if (bool)
      {
        c = 0L;
        org.core.models.RecyclerView.endSection();
        return;
      }
      int j = l.size();
      long l1 = 0L;
      int i = 0;
      while (i < j)
      {
        androidx.recyclerview.widget.RecyclerView localRecyclerView = (androidx.recyclerview.widget.RecyclerView)l.get(i);
        int k = localRecyclerView.getWindowVisibility();
        l2 = l1;
        if (k == 0) {
          l2 = Math.max(localRecyclerView.getDrawingTime(), l1);
        }
        i += 1;
        l1 = l2;
      }
      if (l1 == 0L)
      {
        c = 0L;
        org.core.models.RecyclerView.endSection();
        return;
      }
      l1 = TimeUnit.MILLISECONDS.toNanos(l1);
      long l2 = d;
      e(l1 + l2);
      c = 0L;
      org.core.models.RecyclerView.endSection();
      return;
    }
    catch (Throwable localThrowable)
    {
      c = 0L;
      org.core.models.RecyclerView.endSection();
      throw localThrowable;
    }
  }
  
  public void start(androidx.recyclerview.widget.RecyclerView paramRecyclerView)
  {
    l.add(paramRecyclerView);
  }
}
