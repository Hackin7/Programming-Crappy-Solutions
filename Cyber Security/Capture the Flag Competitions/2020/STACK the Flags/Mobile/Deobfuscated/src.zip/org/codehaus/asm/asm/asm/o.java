package org.codehaus.asm.asm.asm;

public class o
  extends c
{
  public o(h paramH)
  {
    super(paramH);
  }
}
