package org.v7.graphics.drawable;

import android.animation.TimeInterpolator;
import android.graphics.drawable.AnimationDrawable;

public class ClassWriter
  implements TimeInterpolator
{
  public int[] k;
  public int v;
  public int w;
  
  public ClassWriter(AnimationDrawable paramAnimationDrawable, boolean paramBoolean)
  {
    b(paramAnimationDrawable, paramBoolean);
  }
  
  public int b(AnimationDrawable paramAnimationDrawable, boolean paramBoolean)
  {
    int n = paramAnimationDrawable.getNumberOfFrames();
    w = n;
    int[] arrayOfInt = k;
    if ((arrayOfInt == null) || (arrayOfInt.length < n)) {
      k = new int[n];
    }
    arrayOfInt = k;
    int j = 0;
    int i = 0;
    while (i < n)
    {
      if (paramBoolean) {
        m = n - i - 1;
      } else {
        m = i;
      }
      int m = paramAnimationDrawable.getDuration(m);
      arrayOfInt[i] = m;
      j += m;
      i += 1;
    }
    v = j;
    return j;
  }
  
  public int get()
  {
    return v;
  }
  
  public float getInterpolation(float paramFloat)
  {
    float f = v;
    int m = w;
    int[] arrayOfInt = k;
    int j = (int)(f * paramFloat + 0.5F);
    int i = 0;
    while ((i < m) && (j >= arrayOfInt[i]))
    {
      j -= arrayOfInt[i];
      i += 1;
    }
    if (i < m) {
      paramFloat = j / v;
    } else {
      paramFloat = 0.0F;
    }
    return i / m + paramFloat;
  }
}
