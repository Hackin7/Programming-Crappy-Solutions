package org.codehaus.asm.asm.asm;

import org.codehaus.asm.asm.XLayoutStyle;

public class a
{
  public XLayoutStyle a;
  public XLayoutStyle b;
  public int c;
  public boolean h;
  public int i;
  public int j;
  public int k;
  public int l;
  public boolean o;
  public boolean p;
  
  public a() {}
}
