package org.codehaus.ui;

import a.f.c.d.b;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.Xml;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;

public class c
{
  public ArrayList<d.b> a = new ArrayList();
  public int h = -1;
  public int i;
  public Item k;
  
  public c(Context paramContext, XmlPullParser paramXmlPullParser)
  {
    paramXmlPullParser = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), IpAddress.State);
    int m = paramXmlPullParser.getIndexCount();
    int j = 0;
    while (j < m)
    {
      int n = paramXmlPullParser.getIndex(j);
      if (n == IpAddress.State_android_id)
      {
        i = paramXmlPullParser.getResourceId(n, i);
      }
      else if (n == IpAddress.State_constraints)
      {
        h = paramXmlPullParser.getResourceId(n, h);
        Object localObject = paramContext.getResources().getResourceTypeName(h);
        paramContext.getResources().getResourceName(h);
        if ("layout".equals(localObject))
        {
          localObject = new Item();
          k = ((Item)localObject);
          ((Item)localObject).b(paramContext, h);
        }
      }
      j += 1;
    }
    paramXmlPullParser.recycle();
  }
  
  public void a(e paramE)
  {
    a.add(paramE);
  }
}
