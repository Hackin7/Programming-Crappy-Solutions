package org.codehaus.converters.lookup;

import android.content.Context;
import android.content.res.Resources;
import android.view.View;

public class SignatureReader
{
  public static String a(View paramView)
  {
    try
    {
      paramView = paramView.getContext().getResources().getResourceEntryName(paramView.getId());
      return paramView;
    }
    catch (Exception paramView) {}
    return "UNKNOWN";
  }
}
