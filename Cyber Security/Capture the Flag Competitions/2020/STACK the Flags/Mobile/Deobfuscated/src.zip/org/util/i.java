package org.util;

import java.io.Closeable;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class i
{
  public final Map<String, Object> m = new HashMap();
  
  public i() {}
  
  public static void close(Object paramObject)
  {
    if ((paramObject instanceof Closeable))
    {
      paramObject = (Closeable)paramObject;
      try
      {
        paramObject.close();
        return;
      }
      catch (IOException paramObject)
      {
        throw new RuntimeException(paramObject);
      }
    }
  }
  
  public void a() {}
  
  public final void clear()
  {
    Map localMap = m;
    if (localMap != null) {
      try
      {
        Iterator localIterator = m.values().iterator();
        while (localIterator.hasNext()) {
          close(localIterator.next());
        }
      }
      catch (Throwable localThrowable)
      {
        throw localThrowable;
      }
    }
    a();
  }
}
