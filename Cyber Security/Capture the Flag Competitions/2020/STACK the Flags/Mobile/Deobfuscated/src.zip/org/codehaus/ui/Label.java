package org.codehaus.ui;

import a.f.c.j;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintLayout.a;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import org.codehaus.asm.asm.AnnotationWriter;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.m;

public abstract class Label
  extends View
{
  public HashMap<Integer, String> a = new HashMap();
  public int[] b = new int[32];
  public Context c;
  public int d;
  public String e;
  public boolean f = false;
  public AnnotationWriter g;
  
  public Label(Context paramContext)
  {
    super(paramContext);
    c = paramContext;
    a(null);
  }
  
  public final int a(ConstraintLayout paramConstraintLayout, String paramString)
  {
    if (paramString != null)
    {
      if (paramConstraintLayout == null) {
        return 0;
      }
      Resources localResources = c.getResources();
      if (localResources == null) {
        return 0;
      }
      int j = paramConstraintLayout.getChildCount();
      int i = 0;
      while (i < j)
      {
        View localView = paramConstraintLayout.getChildAt(i);
        if (localView.getId() != -1)
        {
          Object localObject = null;
          try
          {
            String str = localResources.getResourceEntryName(localView.getId());
            localObject = str;
          }
          catch (Resources.NotFoundException localNotFoundException) {}
          if (paramString.equals(localObject)) {
            return localView.getId();
          }
        }
        i += 1;
      }
    }
    return 0;
  }
  
  public final int a(String paramString)
  {
    ConstraintLayout localConstraintLayout = null;
    if ((getParent() instanceof ConstraintLayout)) {
      localConstraintLayout = (ConstraintLayout)getParent();
    }
    int i = 0;
    int j = i;
    if (isInEditMode())
    {
      j = i;
      if (localConstraintLayout != null)
      {
        Object localObject = localConstraintLayout.a(0, paramString);
        j = i;
        if ((localObject instanceof Integer)) {
          j = ((Integer)localObject).intValue();
        }
      }
    }
    i = j;
    if (j == 0)
    {
      i = j;
      if (localConstraintLayout != null) {
        i = a(localConstraintLayout, paramString);
      }
    }
    j = i;
    if (i == 0) {
      try
      {
        j = j.class.getField(paramString).getInt(null);
      }
      catch (Exception localException)
      {
        j = i;
      }
    }
    i = j;
    if (j == 0) {
      i = c.getResources().getIdentifier(paramString, "id", c.getPackageName());
    }
    return i;
  }
  
  public void a()
  {
    if (g == null) {
      return;
    }
    ViewGroup.LayoutParams localLayoutParams = getLayoutParams();
    if ((localLayoutParams instanceof ConstraintLayout.a)) {
      a = ((f)g);
    }
  }
  
  public final void a(int paramInt)
  {
    if (paramInt == getId()) {
      return;
    }
    int i = d;
    int[] arrayOfInt = b;
    if (i + 1 > arrayOfInt.length) {
      b = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2);
    }
    arrayOfInt = b;
    i = d;
    arrayOfInt[i] = paramInt;
    d = (i + 1);
  }
  
  public void a(AttributeSet paramAttributeSet)
  {
    if (paramAttributeSet != null)
    {
      paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, IpAddress.ConstraintLayout_Layout);
      int j = paramAttributeSet.getIndexCount();
      int i = 0;
      while (i < j)
      {
        int k = paramAttributeSet.getIndex(i);
        if (k == IpAddress.ConstraintLayout_Layout_constraint_referenced_ids)
        {
          String str = paramAttributeSet.getString(k);
          e = str;
          setIds(str);
        }
        i += 1;
      }
      paramAttributeSet.recycle();
    }
  }
  
  public void a(ConstraintLayout paramConstraintLayout)
  {
    if (isInEditMode()) {
      setIds(e);
    }
    Object localObject1 = g;
    if (localObject1 == null) {
      return;
    }
    ((m)localObject1).setIcon();
    int i = 0;
    while (i < d)
    {
      int j = b[i];
      Object localObject3 = paramConstraintLayout.b(j);
      Object localObject2 = localObject3;
      localObject1 = localObject2;
      if (localObject3 == null)
      {
        localObject3 = (String)a.get(Integer.valueOf(j));
        j = a(paramConstraintLayout, (String)localObject3);
        localObject1 = localObject2;
        if (j != 0)
        {
          b[i] = j;
          a.put(Integer.valueOf(j), localObject3);
          localObject1 = paramConstraintLayout.b(j);
        }
      }
      if (localObject1 != null)
      {
        localObject2 = g;
        localObject1 = paramConstraintLayout.a((View)localObject1);
        ((m)localObject2).a((f)localObject1);
      }
      i += 1;
    }
    g.a(c);
  }
  
  public void a(f paramF, boolean paramBoolean) {}
  
  public final void add(String paramString)
  {
    if (paramString != null)
    {
      if (paramString.length() == 0) {
        return;
      }
      if (c == null) {
        return;
      }
      paramString = paramString.trim();
      if ((getParent() instanceof ConstraintLayout)) {
        localObject = (ConstraintLayout)getParent();
      }
      int i = a(paramString);
      if (i != 0)
      {
        a.put(Integer.valueOf(i), paramString);
        a(i);
        return;
      }
      Object localObject = new StringBuilder();
      ((StringBuilder)localObject).append("Could not find id of \"");
      ((StringBuilder)localObject).append(paramString);
      ((StringBuilder)localObject).append("\"");
      Log.w("ConstraintHelper", ((StringBuilder)localObject).toString());
    }
  }
  
  public void addTouchDelegate() {}
  
  public void b()
  {
    ViewParent localViewParent = getParent();
    if ((localViewParent != null) && ((localViewParent instanceof ConstraintLayout))) {
      b((ConstraintLayout)localViewParent);
    }
  }
  
  public void b(ConstraintLayout paramConstraintLayout)
  {
    int j = getVisibility();
    float f1 = getElevation();
    int i = 0;
    while (i < d)
    {
      View localView = paramConstraintLayout.b(b[i]);
      if (localView != null)
      {
        localView.setVisibility(j);
        if (f1 > 0.0F) {
          localView.setTranslationZ(localView.getTranslationZ() + f1);
        }
      }
      i += 1;
    }
  }
  
  public void draw() {}
  
  public int[] getReferencedIds()
  {
    return Arrays.copyOf(b, d);
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = e;
    if (str != null) {
      setIds(str);
    }
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    if (f)
    {
      super.onMeasure(paramInt1, paramInt2);
      return;
    }
    setMeasuredDimension(0, 0);
  }
  
  public void setAllCaps() {}
  
  public void setIds(String paramString)
  {
    e = paramString;
    if (paramString == null) {
      return;
    }
    int i = 0;
    d = 0;
    for (;;)
    {
      int j = paramString.indexOf(',', i);
      if (j == -1)
      {
        add(paramString.substring(i));
        return;
      }
      add(paramString.substring(i, j));
      i = j + 1;
    }
  }
  
  public void setReferencedIds(int[] paramArrayOfInt)
  {
    e = null;
    d = 0;
    int i = 0;
    while (i < paramArrayOfInt.length)
    {
      a(paramArrayOfInt[i]);
      i += 1;
    }
  }
}
