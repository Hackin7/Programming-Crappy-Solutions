package org.curve;

public abstract interface d
{
  public abstract void cancel();
}
