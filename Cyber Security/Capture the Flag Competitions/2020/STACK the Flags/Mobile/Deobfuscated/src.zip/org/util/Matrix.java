package org.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Matrix
{
  public final Method c;
  public final int d;
  
  public Matrix(int paramInt, Method paramMethod)
  {
    d = paramInt;
    c = paramMethod;
    paramMethod.setAccessible(true);
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass()) {
        return false;
      }
      paramObject = (Matrix)paramObject;
      return (d == d) && (c.getName().equals(c.getName()));
    }
    return false;
  }
  
  public int hashCode()
  {
    return d * 31 + c.getName().hashCode();
  }
  
  public void toString(d paramD, Scope paramScope, Object paramObject)
  {
    int i = d;
    Method localMethod;
    if (i != 0) {
      if (i != 1)
      {
        if (i != 2) {
          return;
        }
        localMethod = c;
      }
    }
    try
    {
      localMethod.invoke(paramObject, new Object[] { paramD, paramScope });
      return;
    }
    catch (IllegalAccessException paramD)
    {
      throw new RuntimeException(paramD);
    }
    catch (InvocationTargetException paramD)
    {
      throw new RuntimeException("Failed to call observer method", paramD.getCause());
    }
    paramScope = c;
    paramScope.invoke(paramObject, new Object[] { paramD });
    return;
    paramD = c;
    paramD.invoke(paramObject, new Object[0]);
  }
}
