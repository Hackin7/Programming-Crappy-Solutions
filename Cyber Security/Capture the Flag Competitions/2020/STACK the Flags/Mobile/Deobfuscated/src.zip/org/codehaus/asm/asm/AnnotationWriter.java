package org.codehaus.asm.asm;

public abstract interface AnnotationWriter
{
  public abstract void a(MethodWriter paramMethodWriter);
}
