package org.asm;

import android.animation.ObjectAnimator;
import android.graphics.Path;
import android.util.Property;

public class n
{
  public static ObjectAnimator a(Object paramObject, Property paramProperty, Path paramPath)
  {
    return ObjectAnimator.ofObject(paramObject, paramProperty, null, paramPath);
  }
}
