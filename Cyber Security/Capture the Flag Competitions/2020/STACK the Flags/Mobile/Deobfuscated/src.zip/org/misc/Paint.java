package org.misc;

import androidx.savedstate.SavedStateRegistry;
import org.util.d;

public abstract interface Paint
  extends d
{
  public abstract SavedStateRegistry getSavedStateRegistry();
}
