package org.v7.app;

import a.e.g;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.core.view.ViewCompat;
import org.v7.R.styleable;
import org.v7.view.ContextThemeWrapper;
import org.v7.widget.AppCompatAutoCompleteTextView;
import org.v7.widget.AppCompatButton;
import org.v7.widget.AppCompatCheckBox;
import org.v7.widget.AppCompatCheckedTextView;
import org.v7.widget.AppCompatEditText;
import org.v7.widget.AppCompatImageButton;
import org.v7.widget.AppCompatImageView;
import org.v7.widget.AppCompatMultiAutoCompleteTextView;
import org.v7.widget.AppCompatRadioButton;
import org.v7.widget.AppCompatRatingBar;
import org.v7.widget.AppCompatSpinner;
import org.v7.widget.DisplayDimensions;
import org.v7.widget.Switch;
import org.v7.widget.SwitchCompat;
import org.v7.widget.TintContextWrapper;

public class AppCompatViewInflater
{
  public static final String LOG_TAG = "AppCompatViewInflater";
  public static final String[] sClassPrefixList = { "android.widget.", "android.view.", "android.webkit." };
  public static final g<String, Constructor<? extends View>> sConstructorMap = new org.data.Context();
  public static final Class<?>[] sConstructorSignature = { android.content.Context.class, AttributeSet.class };
  public static final int[] sOnClickAttrs = { 16843375 };
  public final Object[] mConstructorArgs = new Object[2];
  
  public AppCompatViewInflater() {}
  
  private void checkOnClickListener(View paramView, AttributeSet paramAttributeSet)
  {
    Object localObject = paramView.getContext();
    if ((localObject instanceof ContextWrapper))
    {
      if (!ViewCompat.hasOnClickListeners(paramView)) {
        return;
      }
      paramAttributeSet = ((android.content.Context)localObject).obtainStyledAttributes(paramAttributeSet, sOnClickAttrs);
      localObject = paramAttributeSet.getString(0);
      if (localObject != null) {
        paramView.setOnClickListener(new DeclaredOnClickListener(paramView, (String)localObject));
      }
      paramAttributeSet.recycle();
    }
  }
  
  private View createViewByPrefix(android.content.Context paramContext, String paramString1, String paramString2)
  {
    Constructor localConstructor = (Constructor)sConstructorMap.get(paramString1);
    Object localObject = localConstructor;
    if ((localConstructor != null) || (paramString2 != null)) {}
    try
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append(paramString2);
      ((StringBuilder)localObject).append(paramString1);
      paramString2 = ((StringBuilder)localObject).toString();
      break label59;
      paramString2 = paramString1;
      label59:
      paramContext = Class.forName(paramString2, false, paramContext.getClassLoader()).asSubclass(View.class);
      paramString2 = sConstructorSignature;
      paramContext = paramContext.getConstructor(paramString2);
      localObject = paramContext;
      paramString2 = sConstructorMap;
      paramString2.put(paramString1, paramContext);
      ((Constructor)localObject).setAccessible(true);
      paramContext = mConstructorArgs;
      paramContext = ((Constructor)localObject).newInstance(paramContext);
      return (View)paramContext;
    }
    catch (Exception paramContext) {}
    return null;
  }
  
  private View createViewFromTag(android.content.Context paramContext, String paramString, AttributeSet paramAttributeSet)
  {
    String str = paramString;
    if (paramString.equals("view")) {
      str = paramAttributeSet.getAttributeValue(null, "class");
    }
    mConstructorArgs[0] = paramContext;
    mConstructorArgs[1] = paramAttributeSet;
    try
    {
      int i = str.indexOf('.');
      if (-1 == i)
      {
        i = 0;
        for (;;)
        {
          int j = sClassPrefixList.length;
          if (i >= j) {
            break;
          }
          paramString = sClassPrefixList[i];
          paramString = createViewByPrefix(paramContext, str, paramString);
          if (paramString != null)
          {
            paramContext = mConstructorArgs;
            paramContext[0] = null;
            paramContext[1] = null;
            return paramString;
          }
          i += 1;
        }
        paramContext = mConstructorArgs;
        paramContext[0] = null;
        paramContext[1] = null;
        return null;
      }
      paramContext = createViewByPrefix(paramContext, str, null);
      paramString = mConstructorArgs;
      paramString[0] = null;
      paramString[1] = null;
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      paramString = mConstructorArgs;
      paramString[0] = null;
      paramString[1] = null;
      throw paramContext;
    }
    catch (Exception paramContext)
    {
      paramContext = mConstructorArgs;
      paramContext[0] = null;
      paramContext[1] = null;
    }
    return null;
  }
  
  public static android.content.Context themifyContext(android.content.Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2)
  {
    paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.View, 0, 0);
    int i = 0;
    if (paramBoolean1) {
      i = paramAttributeSet.getResourceId(R.styleable.View_android_theme, 0);
    }
    int j = i;
    if (paramBoolean2)
    {
      j = i;
      if (i == 0)
      {
        int k = paramAttributeSet.getResourceId(R.styleable.View_theme, 0);
        i = k;
        j = i;
        if (k != 0)
        {
          Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
          j = i;
        }
      }
    }
    paramAttributeSet.recycle();
    if ((j != 0) && ((!(paramContext instanceof ContextThemeWrapper)) || (((ContextThemeWrapper)paramContext).getThemeResId() != j))) {
      return new ContextThemeWrapper(paramContext, j);
    }
    return paramContext;
  }
  
  private void verifyNotNull(View paramView, String paramString)
  {
    if (paramView != null) {
      return;
    }
    paramView = new StringBuilder();
    paramView.append(getClass().getName());
    paramView.append(" asked to inflate view for <");
    paramView.append(paramString);
    paramView.append(">, but returned null");
    throw new IllegalStateException(paramView.toString());
  }
  
  public AppCompatAutoCompleteTextView createAutoCompleteTextView(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatButton createButton(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatButton(paramContext, paramAttributeSet);
  }
  
  public AppCompatCheckBox createCheckBox(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatCheckBox(paramContext, paramAttributeSet);
  }
  
  public AppCompatCheckedTextView createCheckedTextView(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatCheckedTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatEditText createEditText(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatEditText(paramContext, paramAttributeSet);
  }
  
  public AppCompatImageButton createImageButton(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatImageButton(paramContext, paramAttributeSet);
  }
  
  public AppCompatImageView createImageView(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatImageView(paramContext, paramAttributeSet);
  }
  
  public AppCompatMultiAutoCompleteTextView createMultiAutoCompleteTextView(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatMultiAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatRadioButton createRadioButton(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatRadioButton(paramContext, paramAttributeSet);
  }
  
  public AppCompatRatingBar createRatingBar(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatRatingBar(paramContext, paramAttributeSet);
  }
  
  public SwitchCompat createSeekBar(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new SwitchCompat(paramContext, paramAttributeSet);
  }
  
  public AppCompatSpinner createSpinner(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new AppCompatSpinner(paramContext, paramAttributeSet);
  }
  
  public Switch createTextView(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new Switch(paramContext, paramAttributeSet);
  }
  
  public DisplayDimensions createToggleButton(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    return new DisplayDimensions(paramContext, paramAttributeSet);
  }
  
  public View createView(android.content.Context paramContext, String paramString, AttributeSet paramAttributeSet)
  {
    return null;
  }
  
  public final View createView(View paramView, String paramString, android.content.Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    Object localObject1 = paramContext;
    if (paramBoolean1)
    {
      localObject1 = paramContext;
      if (paramView != null) {
        localObject1 = paramView.getContext();
      }
    }
    if (!paramBoolean2)
    {
      paramView = (View)localObject1;
      if (!paramBoolean3) {}
    }
    else
    {
      paramView = themifyContext((android.content.Context)localObject1, paramAttributeSet, paramBoolean2, paramBoolean3);
    }
    localObject1 = paramView;
    if (paramBoolean4) {
      localObject1 = TintContextWrapper.wrap(paramView);
    }
    int i = -1;
    switch (paramString.hashCode())
    {
    default: 
      break;
    }
    for (;;)
    {
      break;
      if (paramString.equals("Button"))
      {
        i = 2;
        break;
        if (paramString.equals("EditText"))
        {
          i = 3;
          break;
          if (paramString.equals("CheckBox"))
          {
            i = 6;
            break;
            if (paramString.equals("AutoCompleteTextView"))
            {
              i = 9;
              break;
              if (paramString.equals("ImageView"))
              {
                i = 1;
                break;
                if (paramString.equals("ToggleButton"))
                {
                  i = 13;
                  break;
                  if (paramString.equals("RadioButton"))
                  {
                    i = 7;
                    break;
                    if (paramString.equals("Spinner"))
                    {
                      i = 4;
                      break;
                      if (paramString.equals("SeekBar"))
                      {
                        i = 12;
                        break;
                        if (paramString.equals("ImageButton"))
                        {
                          i = 5;
                          break;
                          if (paramString.equals("TextView"))
                          {
                            i = 0;
                            break;
                            if (paramString.equals("MultiAutoCompleteTextView"))
                            {
                              i = 10;
                              break;
                              if (paramString.equals("CheckedTextView"))
                              {
                                i = 8;
                                break;
                                if (paramString.equals("RatingBar")) {
                                  i = 11;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    switch (i)
    {
    default: 
      paramView = createView((android.content.Context)localObject1, paramString, paramAttributeSet);
      break;
    case 13: 
      localObject2 = createToggleButton((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 12: 
      localObject2 = createSeekBar((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 11: 
      localObject2 = createRatingBar((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 10: 
      localObject2 = createMultiAutoCompleteTextView((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 9: 
      localObject2 = createAutoCompleteTextView((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 8: 
      localObject2 = createCheckedTextView((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 7: 
      localObject2 = createRadioButton((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 6: 
      localObject2 = createCheckBox((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 5: 
      localObject2 = createImageButton((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 4: 
      localObject2 = createSpinner((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 3: 
      localObject2 = createEditText((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 2: 
      localObject2 = createButton((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 1: 
      localObject2 = createImageView((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
      break;
    case 0: 
      localObject2 = createTextView((android.content.Context)localObject1, paramAttributeSet);
      paramView = (View)localObject2;
      verifyNotNull((View)localObject2, paramString);
    }
    Object localObject2 = paramView;
    if (paramView == null)
    {
      localObject2 = paramView;
      if (paramContext != localObject1) {
        localObject2 = createViewFromTag((android.content.Context)localObject1, paramString, paramAttributeSet);
      }
    }
    if (localObject2 != null) {
      checkOnClickListener((View)localObject2, paramAttributeSet);
    }
    return localObject2;
  }
  
  public class DeclaredOnClickListener
    implements View.OnClickListener
  {
    public final String mMethodName;
    public android.content.Context mResolvedContext;
    public Method mResolvedMethod;
    
    public DeclaredOnClickListener(String paramString)
    {
      mMethodName = paramString;
    }
    
    public void onClick(View paramView)
    {
      if (mResolvedMethod == null) {
        resolveMethod(getContext());
      }
      Method localMethod = mResolvedMethod;
      android.content.Context localContext = mResolvedContext;
      try
      {
        localMethod.invoke(localContext, new Object[] { paramView });
        return;
      }
      catch (InvocationTargetException paramView)
      {
        throw new IllegalStateException("Could not execute method for android:onClick", paramView);
      }
      catch (IllegalAccessException paramView)
      {
        throw new IllegalStateException("Could not execute non-public method for android:onClick", paramView);
      }
    }
    
    public final void resolveMethod(android.content.Context paramContext)
    {
      while (paramContext != null)
      {
        try
        {
          boolean bool = paramContext.isRestricted();
          if (!bool)
          {
            Object localObject = paramContext.getClass();
            String str = mMethodName;
            localObject = ((Class)localObject).getMethod(str, new Class[] { View.class });
            if (localObject != null)
            {
              mResolvedMethod = ((Method)localObject);
              mResolvedContext = paramContext;
              return;
            }
          }
        }
        catch (NoSuchMethodException localNoSuchMethodException) {}
        if ((paramContext instanceof ContextWrapper)) {
          paramContext = ((ContextWrapper)paramContext).getBaseContext();
        } else {
          paramContext = null;
        }
      }
      int i = getId();
      if (i == -1)
      {
        paramContext = "";
      }
      else
      {
        paramContext = new StringBuilder();
        paramContext.append(" with id '");
        paramContext.append(getContext().getResources().getResourceEntryName(i));
        paramContext.append("'");
        paramContext = paramContext.toString();
      }
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("Could not find method ");
      localStringBuilder.append(mMethodName);
      localStringBuilder.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
      localStringBuilder.append(getClass());
      localStringBuilder.append(paramContext);
      throw new IllegalStateException(localStringBuilder.toString());
    }
  }
}
