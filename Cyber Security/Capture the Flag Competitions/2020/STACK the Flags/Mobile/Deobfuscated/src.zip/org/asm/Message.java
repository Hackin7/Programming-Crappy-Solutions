package org.asm;

public abstract class Message
{
  public Message() {}
}
