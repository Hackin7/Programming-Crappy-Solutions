package org.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;

public final class Context
{
  public static final PorterDuff.Mode DEFAULT_MODE = PorterDuff.Mode.SRC_IN;
  public static Context c;
  public AppCompatDrawableManager r;
  
  public Context() {}
  
  public static void a()
  {
    try
    {
      if (c == null)
      {
        Context localContext = new Context();
        c = localContext;
        r = AppCompatDrawableManager.get();
        cr.clear(new TintManager());
      }
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static PorterDuffColorFilter get(int paramInt, PorterDuff.Mode paramMode)
  {
    try
    {
      paramMode = AppCompatDrawableManager.getPorterDuffColorFilter(paramInt, paramMode);
      return paramMode;
    }
    catch (Throwable paramMode)
    {
      throw paramMode;
    }
  }
  
  public static Context get()
  {
    try
    {
      if (c == null) {
        a();
      }
      Context localContext = c;
      return localContext;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static void tintDrawable(Drawable paramDrawable, TintInfo paramTintInfo, int[] paramArrayOfInt)
  {
    AppCompatDrawableManager.tintDrawable(paramDrawable, paramTintInfo, paramArrayOfInt);
  }
  
  public void get(android.content.Context paramContext)
  {
    try
    {
      r.add(paramContext);
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public Drawable getDrawable(android.content.Context paramContext, int paramInt)
  {
    try
    {
      paramContext = r.getDrawable(paramContext, paramInt);
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public Drawable getDrawable(android.content.Context paramContext, int paramInt, boolean paramBoolean)
  {
    try
    {
      paramContext = r.getDrawable(paramContext, paramInt, paramBoolean);
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public ColorStateList getTintList(android.content.Context paramContext, int paramInt)
  {
    try
    {
      paramContext = r.get(paramContext, paramInt);
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
}
