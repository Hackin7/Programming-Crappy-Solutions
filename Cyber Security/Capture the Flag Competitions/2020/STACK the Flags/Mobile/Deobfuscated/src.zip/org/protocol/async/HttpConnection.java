package org.protocol.async;

public abstract interface HttpConnection
  extends Connection
{}
