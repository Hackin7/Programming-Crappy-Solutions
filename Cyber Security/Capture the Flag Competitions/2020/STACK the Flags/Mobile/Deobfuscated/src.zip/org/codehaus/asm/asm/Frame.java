package org.codehaus.asm.asm;

import org.codehaus.asm.ClassWriter;

public class Frame
{
  public static boolean[] d = new boolean[3];
  
  public static void a(MethodWriter paramMethodWriter, ClassWriter paramClassWriter, f paramF)
  {
    type = -1;
    flags = -1;
    int i;
    int j;
    if ((c[0] != XLayoutStyle.c) && (c[0] == XLayoutStyle.r))
    {
      i = b.j;
      j = paramMethodWriter.getValue() - i.j;
      Label localLabel = b;
      i = paramClassWriter.a(localLabel);
      localLabel = i;
      i = paramClassWriter.a(localLabel);
      paramClassWriter.a(b.i, i);
      paramClassWriter.a(i.i, j);
      type = 2;
      paramF.p(i, j);
    }
    if ((c[1] != XLayoutStyle.c) && (c[1] == XLayoutStyle.r))
    {
      i = a.j;
      j = paramMethodWriter.size() - g.j;
      paramMethodWriter = a;
      paramMethodWriter.i = paramClassWriter.a(paramMethodWriter);
      paramMethodWriter = g;
      paramMethodWriter.i = paramClassWriter.a(paramMethodWriter);
      paramClassWriter.a(a.i, i);
      paramClassWriter.a(g.i, j);
      if ((bottom > 0) || (paramF.length() == 8))
      {
        paramMethodWriter = u;
        paramMethodWriter.i = paramClassWriter.a(paramMethodWriter);
        paramClassWriter.a(u.i, bottom + i);
      }
      flags = 2;
      paramF.add(i, j);
    }
  }
  
  public static final boolean b(int paramInt1, int paramInt2)
  {
    return (paramInt1 & paramInt2) == paramInt2;
  }
}
