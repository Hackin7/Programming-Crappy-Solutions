package org.v7.app;

public class TwilightCalculator
{
  public static TwilightCalculator sInstance;
  public int state;
  public long sunrise;
  public long sunset;
  
  public TwilightCalculator() {}
  
  public static TwilightCalculator getInstance()
  {
    if (sInstance == null) {
      sInstance = new TwilightCalculator();
    }
    return sInstance;
  }
  
  public void calculateTwilight(long paramLong, double paramDouble1, double paramDouble2)
  {
    float f1 = (float)(paramLong - 946728000000L) / 8.64E7F;
    float f2 = 0.01720197F * f1 + 6.24006F;
    double d = 1.796593063D + (f2 + Math.sin(f2) * 0.03341960161924362D + Math.sin(2.0F * f2) * 3.4906598739326E-4D + Math.sin(3.0F * f2) * 5.236000106378924E-6D) + 3.141592653589793D;
    paramDouble2 = -paramDouble2 / 360.0D;
    paramDouble2 = 9.0E-4F + (float)Math.round(f1 - 9.0E-4F - paramDouble2) + paramDouble2 + Math.sin(f2) * 0.0053D + Math.sin(2.0D * d) * -0.0069D;
    d = Math.asin(Math.sin(d) * Math.sin(0.4092797040939331D));
    paramDouble1 = 0.01745329238474369D * paramDouble1;
    paramDouble1 = (Math.sin(-0.10471975803375244D) - Math.sin(paramDouble1) * Math.sin(d)) / (Math.cos(paramDouble1) * Math.cos(d));
    if (paramDouble1 >= 1.0D)
    {
      state = 1;
      sunset = -1L;
      sunrise = -1L;
      return;
    }
    if (paramDouble1 <= -1.0D)
    {
      state = 0;
      sunset = -1L;
      sunrise = -1L;
      return;
    }
    f1 = (float)(Math.acos(paramDouble1) / 6.283185307179586D);
    sunset = (Math.round((f1 + paramDouble2) * 8.64E7D) + 946728000000L);
    long l = Math.round((paramDouble2 - f1) * 8.64E7D) + 946728000000L;
    sunrise = l;
    if ((l < paramLong) && (sunset > paramLong))
    {
      state = 0;
      return;
    }
    state = 1;
  }
}
