package org.asm;

public class Frame
  extends p
{
  public h b;
  
  public Frame(h paramH)
  {
    b = paramH;
  }
  
  public void a(l paramL)
  {
    h localH = b;
    int i = n - 1;
    n = i;
    if (i == 0)
    {
      s = false;
      localH.a();
    }
    paramL.b(this);
  }
  
  public void c(l paramL)
  {
    paramL = b;
    if (!s)
    {
      paramL.e();
      b.s = true;
    }
  }
}
