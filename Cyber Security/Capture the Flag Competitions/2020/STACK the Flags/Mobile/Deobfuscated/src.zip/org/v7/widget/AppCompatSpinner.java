package org.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.AbsSavedState;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewTreeObserver;
import android.widget.AbsListView;
import android.widget.AbsSpinner;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import org.core.view.ViewCompat;
import org.v7.R.attr;
import org.v7.R.layout;
import org.v7.R.styleable;
import org.v7.view.ContextThemeWrapper;

public class AppCompatSpinner
  extends Spinner
{
  public static final int[] ATTRS_ANDROID_SPINNERMODE = { 16843505 };
  public final AppCompatBackgroundHelper mBackgroundTintHelper;
  public int mDropDownWidth;
  public ListPopupWindow.ForwardingListener mForwardingListener;
  public SpinnerCompat.SpinnerPopup mPopup;
  public final Context mPopupContext;
  public final boolean mPopupSet;
  public SpinnerAdapter mTempAdapter;
  public final Rect mTempRect = new Rect();
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.spinnerStyle);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme)
  {
    super(paramContext, paramAttributeSet, paramInt1);
    ThemeUtils.init(this, getContext());
    TintTypedArray localTintTypedArray2 = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
    mBackgroundTintHelper = new AppCompatBackgroundHelper(this);
    if (paramTheme != null)
    {
      mPopupContext = new ContextThemeWrapper(paramContext, paramTheme);
    }
    else
    {
      i = localTintTypedArray2.getResourceId(R.styleable.Spinner_popupTheme, 0);
      if (i != 0) {
        mPopupContext = new ContextThemeWrapper(paramContext, i);
      } else {
        mPopupContext = paramContext;
      }
    }
    int i = paramInt2;
    if (paramInt2 == -1)
    {
      paramTheme = null;
      Object localObject2 = null;
      Object localObject1 = ATTRS_ANDROID_SPINNERMODE;
      for (;;)
      {
        try
        {
          TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, (int[])localObject1, paramInt1, 0);
          localObject1 = localTypedArray;
          localObject2 = localObject1;
          paramTheme = (Resources.Theme)localObject1;
          boolean bool = localTypedArray.hasValue(0);
          paramTheme = (Resources.Theme)localObject1;
          i = paramInt2;
          if (bool)
          {
            localObject2 = localObject1;
            paramTheme = (Resources.Theme)localObject1;
            i = localTypedArray.getInt(0, 0);
            paramTheme = (Resources.Theme)localObject1;
          }
          paramTheme.recycle();
        }
        catch (Throwable paramContext)
        {
          break;
        }
        catch (Exception localException)
        {
          localObject2 = paramTheme;
          Log.i("AppCompatSpinner", "Could not read android:spinnerMode", localException);
          i = paramInt2;
          if (paramTheme == null) {
            break label252;
          }
        }
        i = paramInt2;
      }
      if (localObject2 != null) {
        ((TypedArray)localObject2).recycle();
      }
      throw paramContext;
    }
    label252:
    if (i != 0)
    {
      if (i == 1)
      {
        paramTheme = new DropdownPopup(mPopupContext, paramAttributeSet, paramInt1);
        TintTypedArray localTintTypedArray1 = TintTypedArray.obtainStyledAttributes(mPopupContext, paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
        mDropDownWidth = localTintTypedArray1.getLayoutDimension(R.styleable.Spinner_android_dropDownWidth, -2);
        paramTheme.setBackgroundDrawable(localTintTypedArray1.getDrawable(R.styleable.Spinner_android_popupBackground));
        paramTheme.setPromptText(localTintTypedArray2.getString(R.styleable.Spinner_android_prompt));
        localTintTypedArray1.recycle();
        mPopup = paramTheme;
        mForwardingListener = new ActivityChooserView.3(this, this, paramTheme);
      }
    }
    else
    {
      paramTheme = new SpinnerCompat.DialogPopup(this);
      mPopup = paramTheme;
      paramTheme.setPromptText(localTintTypedArray2.getString(R.styleable.Spinner_android_prompt));
    }
    paramTheme = localTintTypedArray2.getTextArray(R.styleable.Spinner_android_entries);
    if (paramTheme != null)
    {
      paramContext = new ArrayAdapter(paramContext, 17367048, paramTheme);
      paramContext.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
      setAdapter(paramContext);
    }
    localTintTypedArray2.recycle();
    mPopupSet = true;
    paramContext = mTempAdapter;
    if (paramContext != null)
    {
      setAdapter(paramContext);
      mTempAdapter = null;
    }
    mBackgroundTintHelper.loadFromAttributes(paramAttributeSet, paramInt1);
  }
  
  public int compatMeasureContentWidth(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable)
  {
    if (paramSpinnerAdapter == null) {
      return 0;
    }
    int i = 0;
    Object localObject = null;
    int k = 0;
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int i2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int j = Math.max(0, getSelectedItemPosition());
    int i3 = Math.min(paramSpinnerAdapter.getCount(), j + 15);
    j = Math.max(0, j - (15 - (i3 - j)));
    while (j < i3)
    {
      int n = paramSpinnerAdapter.getItemViewType(j);
      int m = k;
      if (n != k)
      {
        m = n;
        localObject = null;
      }
      View localView = paramSpinnerAdapter.getView(j, (View)localObject, this);
      localObject = localView;
      if (localView.getLayoutParams() == null) {
        localView.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
      }
      localView.measure(i1, i2);
      i = Math.max(i, localView.getMeasuredWidth());
      j += 1;
      k = m;
    }
    j = i;
    if (paramDrawable != null)
    {
      paramDrawable.getPadding(mTempRect);
      paramSpinnerAdapter = mTempRect;
      j = i + (left + right);
    }
    return j;
  }
  
  public void drawableStateChanged()
  {
    super.drawableStateChanged();
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.applySupportBackgroundTint();
    }
  }
  
  public int getDropDownHorizontalOffset()
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null) {
      return localSpinnerPopup.getHorizontalOffset();
    }
    return super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset()
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null) {
      return localSpinnerPopup.getVerticalOffset();
    }
    return super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth()
  {
    if (mPopup != null) {
      return mDropDownWidth;
    }
    return super.getDropDownWidth();
  }
  
  public final SpinnerCompat.SpinnerPopup getInternalPopup()
  {
    return mPopup;
  }
  
  public Drawable getPopupBackground()
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null) {
      return localSpinnerPopup.getBackground();
    }
    return super.getPopupBackground();
  }
  
  public Context getPopupContext()
  {
    return mPopupContext;
  }
  
  public CharSequence getPrompt()
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null) {
      return localSpinnerPopup.getHintText();
    }
    return super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList()
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      return localAppCompatBackgroundHelper.getSupportBackgroundTintList();
    }
    return null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      return localAppCompatBackgroundHelper.getSupportBackgroundTintMode();
    }
    return null;
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if ((localSpinnerPopup != null) && (localSpinnerPopup.isShowing())) {
      mPopup.dismiss();
    }
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    if ((mPopup != null) && (View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)) {
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), compatMeasureContentWidth(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight());
    }
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    paramParcelable = (AppCompatDelegateImplV7.PanelFeatureState.SavedState)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    if (isOpen)
    {
      paramParcelable = getViewTreeObserver();
      if (paramParcelable != null) {
        paramParcelable.addOnGlobalLayoutListener(new SpinnerCompat.2(this));
      }
    }
  }
  
  public Parcelable onSaveInstanceState()
  {
    AppCompatDelegateImplV7.PanelFeatureState.SavedState localSavedState = new AppCompatDelegateImplV7.PanelFeatureState.SavedState(super.onSaveInstanceState());
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    boolean bool;
    if ((localSpinnerPopup != null) && (localSpinnerPopup.isShowing())) {
      bool = true;
    } else {
      bool = false;
    }
    isOpen = bool;
    return localSavedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    ListPopupWindow.ForwardingListener localForwardingListener = mForwardingListener;
    if ((localForwardingListener != null) && (localForwardingListener.onTouch(this, paramMotionEvent))) {
      return true;
    }
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick()
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null)
    {
      if (!localSpinnerPopup.isShowing()) {
        show();
      }
      return true;
    }
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter)
  {
    if (!mPopupSet)
    {
      mTempAdapter = paramSpinnerAdapter;
      return;
    }
    super.setAdapter(paramSpinnerAdapter);
    if (mPopup != null)
    {
      Context localContext2 = mPopupContext;
      Context localContext1 = localContext2;
      if (localContext2 == null) {
        localContext1 = getContext();
      }
      mPopup.setAdapter(new SpinnerCompat.DropDownAdapter(paramSpinnerAdapter, localContext1.getTheme()));
    }
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    super.setBackgroundDrawable(paramDrawable);
    paramDrawable = mBackgroundTintHelper;
    if (paramDrawable != null) {
      paramDrawable.setSupportBackgroundTintList();
    }
  }
  
  public void setBackgroundResource(int paramInt)
  {
    super.setBackgroundResource(paramInt);
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.loadFromAttributes(paramInt);
    }
  }
  
  public void setDropDownHorizontalOffset(int paramInt)
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null)
    {
      localSpinnerPopup.setAdapter(paramInt);
      mPopup.setHorizontalOffset(paramInt);
      return;
    }
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt)
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null)
    {
      localSpinnerPopup.setVerticalOffset(paramInt);
      return;
    }
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt)
  {
    if (mPopup != null)
    {
      mDropDownWidth = paramInt;
      return;
    }
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable)
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null)
    {
      localSpinnerPopup.setBackgroundDrawable(paramDrawable);
      return;
    }
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt)
  {
    setPopupBackgroundDrawable(org.v7.internal.util.Resources.getDrawable(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence)
  {
    SpinnerCompat.SpinnerPopup localSpinnerPopup = mPopup;
    if (localSpinnerPopup != null)
    {
      localSpinnerPopup.setPromptText(paramCharSequence);
      return;
    }
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList)
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.setSupportBackgroundTintList(paramColorStateList);
    }
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.setSupportBackgroundTintMode(paramMode);
    }
  }
  
  public void show()
  {
    mPopup.show(getTextDirection(), getTextAlignment());
  }
  
  public class DropdownPopup
    extends ListPopupWindow
    implements SpinnerCompat.SpinnerPopup
  {
    public ListAdapter mAdapter;
    public CharSequence mHintText;
    public int mPadding;
    public final Rect mVisibleRect = new Rect();
    
    public DropdownPopup(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
    {
      super(paramAttributeSet, paramInt);
      setAdapter(AppCompatSpinner.this);
      setModal(true);
      setPromptPosition(0);
      setOnItemClickListener(new w.e.a(this, AppCompatSpinner.this));
    }
    
    public void computeContentWidth()
    {
      Object localObject = getBackground();
      int i = 0;
      if (localObject != null)
      {
        ((Drawable)localObject).getPadding(mTempRect);
        if (ViewUtils.isLayoutRtl(AppCompatSpinner.this)) {
          i = mTempRect.right;
        } else {
          i = -mTempRect.left;
        }
      }
      else
      {
        localObject = mTempRect;
        right = 0;
        left = 0;
      }
      int n = getPaddingLeft();
      int i1 = getPaddingRight();
      int i2 = getWidth();
      localObject = AppCompatSpinner.this;
      int j = mDropDownWidth;
      if (j == -2)
      {
        int k = ((AppCompatSpinner)localObject).compatMeasureContentWidth((SpinnerAdapter)mAdapter, getBackground());
        j = k;
        int m = getContext().getResources().getDisplayMetrics().widthPixels;
        localObject = mTempRect;
        m = m - left - right;
        if (k > m) {
          j = m;
        }
        setContentWidth(Math.max(j, i2 - n - i1));
      }
      else if (j == -1)
      {
        setContentWidth(i2 - n - i1);
      }
      else
      {
        setContentWidth(j);
      }
      if (ViewUtils.isLayoutRtl(AppCompatSpinner.this)) {
        i += i2 - i1 - getWidth() - getPadding();
      } else {
        i += getPadding() + n;
      }
      setHorizontalOffset(i);
    }
    
    public CharSequence getHintText()
    {
      return mHintText;
    }
    
    public int getPadding()
    {
      return mPadding;
    }
    
    public boolean isVisibleToUser(View paramView)
    {
      return (ViewCompat.isAttachedToWindow(paramView)) && (paramView.getGlobalVisibleRect(mVisibleRect));
    }
    
    public void setAdapter(int paramInt)
    {
      mPadding = paramInt;
    }
    
    public void setAdapter(ListAdapter paramListAdapter)
    {
      super.setAdapter(paramListAdapter);
      mAdapter = paramListAdapter;
    }
    
    public void setPromptText(CharSequence paramCharSequence)
    {
      mHintText = paramCharSequence;
    }
    
    public void show(int paramInt1, int paramInt2)
    {
      boolean bool = isShowing();
      computeContentWidth();
      show(2);
      super.show();
      Object localObject = c();
      ((AbsListView)localObject).setChoiceMode(1);
      ((View)localObject).setTextDirection(paramInt1);
      ((View)localObject).setTextAlignment(paramInt2);
      setSelection(getSelectedItemPosition());
      if (bool) {
        return;
      }
      localObject = getViewTreeObserver();
      if (localObject != null)
      {
        w.e.b localB = new w.e.b(this);
        ((ViewTreeObserver)localObject).addOnGlobalLayoutListener(localB);
        setOnDismissListener(new w.e.c(this, localB));
      }
    }
  }
}
