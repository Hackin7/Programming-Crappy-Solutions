package org.codehaus.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;

public abstract class ActionMenuItemView
  extends Label
{
  public boolean b;
  public boolean c;
  
  public void a(AttributeSet paramAttributeSet)
  {
    super.a(paramAttributeSet);
    if (paramAttributeSet != null)
    {
      paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, IpAddress.ConstraintLayout_Layout);
      int j = paramAttributeSet.getIndexCount();
      int i = 0;
      while (i < j)
      {
        int k = paramAttributeSet.getIndex(i);
        if (k == IpAddress.ConstraintLayout_Layout_android_visibility) {
          c = true;
        } else if (k == IpAddress.ConstraintLayout_Layout_android_elevation) {
          b = true;
        }
        i += 1;
      }
      paramAttributeSet.recycle();
    }
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    if ((c) || (b))
    {
      Object localObject = getParent();
      if ((localObject != null) && ((localObject instanceof ConstraintLayout)))
      {
        localObject = (ConstraintLayout)localObject;
        int j = getVisibility();
        float f = getElevation();
        int i = 0;
        while (i < d)
        {
          View localView = ((ConstraintLayout)localObject).b(b[i]);
          if (localView != null)
          {
            if (c) {
              localView.setVisibility(j);
            }
            if ((b) && (f > 0.0F)) {
              localView.setTranslationZ(localView.getTranslationZ() + f);
            }
          }
          i += 1;
        }
      }
    }
  }
  
  public void setElevation(float paramFloat)
  {
    super.setElevation(paramFloat);
    b();
  }
  
  public void setTitle() {}
  
  public void setVisibility(int paramInt)
  {
    super.setVisibility(paramInt);
    b();
  }
}
