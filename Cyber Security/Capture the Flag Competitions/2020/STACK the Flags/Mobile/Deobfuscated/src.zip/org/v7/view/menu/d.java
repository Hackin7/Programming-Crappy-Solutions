package org.v7.view.menu;

import a.b.o.j.d.d;
import a.b.o.j.g;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.core.view.GravityCompat;
import org.core.view.ViewCompat;
import org.v7.R.dimen;
import org.v7.R.layout;
import org.v7.widget.ByteVector;
import org.v7.widget.ListPopupWindow;
import org.v7.widget.i;

public final class d
  extends k
  implements l, View.OnKeyListener, PopupWindow.OnDismissListener
{
  public static final int p = R.layout.abc_cascading_menu_item_layout;
  public final Handler B;
  public boolean E;
  public final List<d.d> a = new ArrayList();
  public final int b;
  public final List<g> c = new ArrayList();
  public l.a d;
  public int e = 0;
  public int f;
  public final int g;
  public View h;
  public int i = 0;
  public PopupWindow.OnDismissListener j;
  public final boolean k;
  public final View.OnAttachStateChangeListener l = new MenuPopupHelper(this);
  public final Context m;
  public final int n;
  public boolean q;
  public boolean r;
  public boolean s;
  public int t;
  public final ViewTreeObserver.OnGlobalLayoutListener this$0 = new a(this);
  public final ByteVector v = new Label(this);
  public View view;
  public boolean w;
  public int x;
  public ViewTreeObserver y;
  
  public d(Context paramContext, View paramView, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    m = paramContext;
    h = paramView;
    g = paramInt1;
    n = paramInt2;
    k = paramBoolean;
    s = false;
    x = b();
    paramContext = paramContext.getResources();
    b = Math.max(getDisplayMetricswidthPixels / 2, paramContext.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    B = new Handler();
  }
  
  public final MenuItem a(MenuBuilder paramMenuBuilder1, MenuBuilder paramMenuBuilder2)
  {
    int i1 = 0;
    int i2 = paramMenuBuilder1.size();
    while (i1 < i2)
    {
      MenuItem localMenuItem = paramMenuBuilder1.getItem(i1);
      if ((localMenuItem.hasSubMenu()) && (paramMenuBuilder2 == localMenuItem.getSubMenu())) {
        return localMenuItem;
      }
      i1 += 1;
    }
    return null;
  }
  
  public final View a(h paramH, MenuBuilder paramMenuBuilder)
  {
    paramMenuBuilder = a(c, paramMenuBuilder);
    if (paramMenuBuilder == null) {
      return null;
    }
    ListView localListView = paramH.a();
    paramH = localListView.getAdapter();
    int i2;
    if ((paramH instanceof HeaderViewListAdapter))
    {
      paramH = (HeaderViewListAdapter)paramH;
      i2 = paramH.getHeadersCount();
      paramH = (x)paramH.getWrappedAdapter();
    }
    else
    {
      i2 = 0;
      paramH = (x)paramH;
    }
    int i4 = -1;
    int i1 = 0;
    int i5 = paramH.getCount();
    int i3;
    for (;;)
    {
      i3 = i4;
      if (i1 >= i5) {
        break;
      }
      if (paramMenuBuilder == paramH.a(i1))
      {
        i3 = i1;
        break;
      }
      i1 += 1;
    }
    if (i3 == -1) {
      return null;
    }
    i1 = i3 + i2 - localListView.getFirstVisiblePosition();
    if (i1 >= 0)
    {
      if (i1 >= localListView.getChildCount()) {
        return null;
      }
      return localListView.getChildAt(i1);
    }
    return null;
  }
  
  public final i a()
  {
    i localI = new i(m, null, g, n);
    localI.a(v);
    localI.setOnItemClickListener(this);
    localI.setOnDismissListener(this);
    localI.setAdapter(h);
    localI.dismiss(i);
    localI.setModal(true);
    localI.show(2);
    return localI;
  }
  
  public void a(int paramInt)
  {
    if (e != paramInt)
    {
      e = paramInt;
      i = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection(h));
    }
  }
  
  public void a(View paramView)
  {
    if (h != paramView)
    {
      h = paramView;
      i = GravityCompat.getAbsoluteGravity(e, ViewCompat.getLayoutDirection(paramView));
    }
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    j = paramOnDismissListener;
  }
  
  public final void a(MenuBuilder paramMenuBuilder)
  {
    Object localObject3 = LayoutInflater.from(m);
    Object localObject1 = new x(paramMenuBuilder, (LayoutInflater)localObject3, k, p);
    if ((!isShowing()) && (s)) {
      ((x)localObject1).a(true);
    } else if (isShowing()) {
      ((x)localObject1).a(k.onSubMenuSelected(paramMenuBuilder));
    }
    int i4 = k.measureContentWidth((ListAdapter)localObject1, null, m, b);
    i localI = a();
    localI.setAdapter((ListAdapter)localObject1);
    localI.setContentWidth(i4);
    localI.dismiss(i);
    if (a.size() > 0)
    {
      localObject1 = a;
      localObject1 = (h)((List)localObject1).get(((List)localObject1).size() - 1);
      localObject2 = a((h)localObject1, paramMenuBuilder);
    }
    else
    {
      localObject1 = null;
      localObject2 = null;
    }
    if (localObject2 != null)
    {
      localI.a(false);
      localI.show(null);
      int i2 = b(i4);
      int i1;
      if (i2 == 1) {
        i1 = 1;
      } else {
        i1 = 0;
      }
      x = i2;
      int i3;
      if (Build.VERSION.SDK_INT >= 26)
      {
        localI.setAdapter((View)localObject2);
        i3 = 0;
        i2 = 0;
      }
      else
      {
        int[] arrayOfInt1 = new int[2];
        h.getLocationOnScreen(arrayOfInt1);
        int[] arrayOfInt2 = new int[2];
        ((View)localObject2).getLocationOnScreen(arrayOfInt2);
        if ((i & 0x7) == 5)
        {
          arrayOfInt1[0] += h.getWidth();
          arrayOfInt2[0] += ((View)localObject2).getWidth();
        }
        i3 = arrayOfInt2[0] - arrayOfInt1[0];
        i2 = arrayOfInt2[1] - arrayOfInt1[1];
      }
      if ((i & 0x5) == 5)
      {
        if (i1 != 0) {
          i1 = i3 + i4;
        } else {
          i1 = i3 - ((View)localObject2).getWidth();
        }
      }
      else if (i1 != 0) {
        i1 = ((View)localObject2).getWidth() + i3;
      } else {
        i1 = i3 - i4;
      }
      localI.setHorizontalOffset(i1);
      localI.b(true);
      localI.setVerticalOffset(i2);
    }
    else
    {
      if (r) {
        localI.setHorizontalOffset(t);
      }
      if (q) {
        localI.setVerticalOffset(f);
      }
      localI.show(get());
    }
    Object localObject2 = new h(localI, paramMenuBuilder, x);
    a.add(localObject2);
    localI.show();
    localObject2 = localI.c();
    ((View)localObject2).setOnKeyListener(this);
    if ((localObject1 == null) && (E) && (paramMenuBuilder.getHeaderTitle() != null))
    {
      localObject1 = (FrameLayout)((LayoutInflater)localObject3).inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup)localObject2, false);
      localObject3 = (TextView)((View)localObject1).findViewById(16908310);
      ((View)localObject1).setEnabled(false);
      ((TextView)localObject3).setText(paramMenuBuilder.getHeaderTitle());
      ((ListView)localObject2).addHeaderView((View)localObject1, null, false);
      localI.show();
    }
  }
  
  public void a(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    int i1 = c(paramMenuBuilder);
    if (i1 < 0) {
      return;
    }
    int i2 = i1 + 1;
    if (i2 < a.size()) {
      a.get(i2)).c.close(false);
    }
    Object localObject = (h)a.remove(i1);
    c.removeMenuPresenter(this);
    if (w)
    {
      a.init(null);
      a.setAnimationStyle(0);
    }
    a.dismiss();
    i1 = a.size();
    if (i1 > 0) {
      x = a.get(i1 - 1)).z;
    } else {
      x = b();
    }
    if (i1 == 0)
    {
      dismiss();
      localObject = d;
      if (localObject != null) {
        ((l.a)localObject).onCloseMenu(paramMenuBuilder, true);
      }
      paramMenuBuilder = y;
      if (paramMenuBuilder != null)
      {
        if (paramMenuBuilder.isAlive()) {
          y.removeGlobalOnLayoutListener(this$0);
        }
        y = null;
      }
      view.removeOnAttachStateChangeListener(l);
      j.onDismiss();
      return;
    }
    if (paramBoolean) {
      a.get(0)).c.close(false);
    }
  }
  
  public void a(boolean paramBoolean)
  {
    s = paramBoolean;
  }
  
  public final int b()
  {
    if (ViewCompat.getLayoutDirection(h) == 1) {
      return 0;
    }
    return 1;
  }
  
  public final int b(int paramInt)
  {
    Object localObject = a;
    localObject = ((h)((List)localObject).get(((List)localObject).size() - 1)).a();
    int[] arrayOfInt = new int[2];
    ((View)localObject).getLocationOnScreen(arrayOfInt);
    Rect localRect = new Rect();
    view.getWindowVisibleDisplayFrame(localRect);
    if (x == 1)
    {
      if (arrayOfInt[0] + ((View)localObject).getWidth() + paramInt > right) {
        return 0;
      }
      return 1;
    }
    if (arrayOfInt[0] - paramInt < 0) {
      return 1;
    }
    return 0;
  }
  
  public final int c(MenuBuilder paramMenuBuilder)
  {
    int i1 = 0;
    int i2 = a.size();
    while (i1 < i2)
    {
      if (paramMenuBuilder == a.get(i1)).c) {
        return i1;
      }
      i1 += 1;
    }
    return -1;
  }
  
  public ListView c()
  {
    if (a.isEmpty()) {
      return null;
    }
    List localList = a;
    return ((h)localList.get(localList.size() - 1)).a();
  }
  
  public void c(int paramInt)
  {
    q = true;
    f = paramInt;
  }
  
  public void c(boolean paramBoolean)
  {
    E = paramBoolean;
  }
  
  public void dismiss()
  {
    int i1 = a.size();
    if (i1 > 0)
    {
      h[] arrayOfH = (h[])a.toArray(new h[i1]);
      i1 -= 1;
      while (i1 >= 0)
      {
        h localH = arrayOfH[i1];
        if (a.isShowing()) {
          a.dismiss();
        }
        i1 -= 1;
      }
    }
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  public boolean g()
  {
    return false;
  }
  
  public boolean isShowing()
  {
    return (a.size() > 0) && (a.get(0)).a.isShowing());
  }
  
  public void onDismiss()
  {
    Object localObject2 = null;
    int i1 = 0;
    int i2 = a.size();
    Object localObject1;
    for (;;)
    {
      localObject1 = localObject2;
      if (i1 >= i2) {
        break;
      }
      localObject1 = (h)a.get(i1);
      if (!a.isShowing()) {
        break;
      }
      i1 += 1;
    }
    if (localObject1 != null) {
      c.close(false);
    }
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramKeyEvent.getAction() == 1) && (paramInt == 82))
    {
      dismiss();
      return true;
    }
    return false;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    Object localObject = a.iterator();
    while (((Iterator)localObject).hasNext())
    {
      h localH = (h)((Iterator)localObject).next();
      if (paramSubMenuBuilder == c)
      {
        localH.a().requestFocus();
        return true;
      }
    }
    if (paramSubMenuBuilder.hasVisibleItems())
    {
      setTitle(paramSubMenuBuilder);
      localObject = d;
      if (localObject != null)
      {
        ((l.a)localObject).onOpenSubMenu(paramSubMenuBuilder);
        return true;
      }
    }
    else
    {
      return false;
    }
    return true;
  }
  
  public void setCallback(l.a paramA)
  {
    d = paramA;
  }
  
  public void setTitle(MenuBuilder paramMenuBuilder)
  {
    paramMenuBuilder.addMenuPresenter(this, m);
    if (isShowing())
    {
      a(paramMenuBuilder);
      return;
    }
    c.add(paramMenuBuilder);
  }
  
  public void show()
  {
    if (isShowing()) {
      return;
    }
    Object localObject = c.iterator();
    while (((Iterator)localObject).hasNext()) {
      a((MenuBuilder)((Iterator)localObject).next());
    }
    c.clear();
    localObject = h;
    view = ((View)localObject);
    if (localObject != null)
    {
      int i1;
      if (y == null) {
        i1 = 1;
      } else {
        i1 = 0;
      }
      localObject = view.getViewTreeObserver();
      y = ((ViewTreeObserver)localObject);
      if (i1 != 0) {
        ((ViewTreeObserver)localObject).addOnGlobalLayoutListener(this$0);
      }
      view.addOnAttachStateChangeListener(l);
    }
  }
  
  public void show(int paramInt)
  {
    r = true;
    t = paramInt;
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    Iterator localIterator = a.iterator();
    while (localIterator.hasNext()) {
      k.a(((h)localIterator.next()).a().getAdapter()).notifyDataSetChanged();
    }
  }
}
