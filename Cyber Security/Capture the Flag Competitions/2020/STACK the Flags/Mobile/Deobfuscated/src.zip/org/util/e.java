package org.util;

public class e
{
  public final Label c;
  public final k d;
  
  public e(Label paramLabel, k paramK)
  {
    d = paramK;
    c = paramLabel;
  }
  
  public i a(String paramString, Class paramClass)
  {
    Object localObject = c.a(paramString);
    if (paramClass.isInstance(localObject)) {
      return localObject;
    }
    localObject = d;
    if ((localObject instanceof x)) {
      paramClass = ((x)localObject).a(paramString, paramClass);
    } else {
      paramClass = ((k)localObject).a(paramClass);
    }
    c.a(paramString, paramClass);
    return paramClass;
  }
  
  public i add(Class paramClass)
  {
    String str = paramClass.getCanonicalName();
    if (str != null)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      localStringBuilder.append(str);
      return a(localStringBuilder.toString(), paramClass);
    }
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
}
