package org.codehaus.asm;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.HashMap;
import org.codehaus.asm.asm.f;

public class ClassWriter
{
  public static boolean M;
  public static boolean N;
  public static long e = 0L;
  public static boolean p;
  public static int q;
  public static boolean r = false;
  public static boolean s = true;
  public static long x;
  public d B;
  public h[] a = null;
  public int b = 0;
  public int c = 0;
  public d d;
  public boolean f = false;
  public boolean[] g = new boolean[32];
  public Label[] h = new Label[q];
  public boolean i = false;
  public int j = 32;
  public boolean k = false;
  public int l = 1;
  public int n = 32;
  public HashMap<String, a.f.b.h> o = null;
  public int w = 0;
  public int y = 32;
  public final Item z;
  
  static
  {
    p = true;
    M = true;
    N = false;
    q = 1000;
    x = 0L;
  }
  
  public ClassWriter()
  {
    toByteArray();
    Item localItem = new Item();
    z = localItem;
    d = new i(localItem);
    B = new h(z);
  }
  
  public static h a(ClassWriter paramClassWriter, Label paramLabel1, Label paramLabel2, float paramFloat)
  {
    paramClassWriter = paramClassWriter.c();
    paramClassWriter.a(paramLabel1, paramLabel2, paramFloat);
    return paramClassWriter;
  }
  
  public static void visitField() {}
  
  public final int a()
  {
    int i2 = 0;
    int m = 0;
    int i1;
    Object localObject;
    for (;;)
    {
      i1 = i2;
      if (m >= b) {
        break;
      }
      localObject = a;
      if ((a.i != c.a) && (b < 0.0F))
      {
        i1 = 1;
        break;
      }
      m += 1;
    }
    if (i1 != 0)
    {
      int i3 = 0;
      int i10;
      for (m = 0; i3 == 0; m = i10)
      {
        i10 = m + 1;
        float f1 = Float.MAX_VALUE;
        i2 = 0;
        i1 = -1;
        m = -1;
        int i4 = 0;
        Label localLabel;
        while (i4 < b)
        {
          localObject = a[i4];
          int i5;
          float f2;
          int i6;
          int i7;
          if (a.i == c.a)
          {
            i5 = i2;
            f2 = f1;
            i6 = i1;
            i7 = m;
          }
          else if (f)
          {
            i5 = i2;
            f2 = f1;
            i6 = i1;
            i7 = m;
          }
          else
          {
            i5 = i2;
            f2 = f1;
            i6 = i1;
            i7 = m;
            if (b < 0.0F)
            {
              int i11 = c.size();
              i6 = 0;
              while (i6 < i11)
              {
                localLabel = c.a(i6);
                float f3 = c.b(localLabel);
                int i8;
                int i9;
                if (f3 <= 0.0F)
                {
                  i7 = i2;
                  f2 = f1;
                  i8 = i1;
                  i9 = m;
                }
                else
                {
                  i5 = 0;
                  for (;;)
                  {
                    i7 = i2;
                    f2 = f1;
                    i8 = i1;
                    i9 = m;
                    if (i5 >= 9) {
                      break;
                    }
                    f2 = j[i5] / f3;
                    if ((f2 >= f1) || (i5 != i2))
                    {
                      i7 = i2;
                      if (i5 <= i2) {}
                    }
                    else
                    {
                      f1 = f2;
                      i1 = i4;
                      m = n;
                      i7 = i5;
                    }
                    i5 += 1;
                    i2 = i7;
                  }
                }
                i6 += 1;
                i2 = i7;
                f1 = f2;
                i1 = i8;
                m = i9;
              }
              i5 = i2;
              f2 = f1;
              i6 = i1;
              i7 = m;
            }
          }
          i4 += 1;
          i2 = i5;
          f1 = f2;
          i1 = i6;
          m = i7;
        }
        if (i1 != -1)
        {
          localObject = a[i1];
          a.f = -1;
          ((h)localObject).b(z.d[m]);
          localLabel = a;
          f = i1;
          localLabel.a(this, (h)localObject);
        }
        else
        {
          i3 = 1;
        }
        if (i10 > l / 2) {
          i3 = 1;
        }
      }
      return m;
    }
    return 0;
  }
  
  public final int a(d paramD)
  {
    int i3 = 0;
    int i4 = 0;
    int m = 0;
    int i1;
    int i2;
    for (;;)
    {
      i1 = i3;
      i2 = i4;
      if (m >= l) {
        break;
      }
      g[m] = false;
      m += 1;
    }
    while (i1 == 0)
    {
      i4 = i2 + 1;
      if (i4 >= l * 2) {
        return i4;
      }
      if (((h)paramD).n() != null) {
        g[nn] = true;
      }
      Label localLabel = paramD.a(this, g);
      Object localObject;
      if (localLabel != null)
      {
        localObject = g;
        m = n;
        if (localObject[m] != 0) {
          return i4;
        }
        localObject[m] = 1;
      }
      if (localLabel != null)
      {
        float f1 = Float.MAX_VALUE;
        i2 = -1;
        m = 0;
        while (m < b)
        {
          localObject = a[m];
          float f2;
          if (a.i == c.a)
          {
            i3 = i2;
            f2 = f1;
          }
          else if (f)
          {
            i3 = i2;
            f2 = f1;
          }
          else
          {
            i3 = i2;
            f2 = f1;
            if (((h)localObject).add(localLabel))
            {
              float f3 = c.b(localLabel);
              i3 = i2;
              f2 = f1;
              if (f3 < 0.0F)
              {
                f3 = -b / f3;
                i3 = i2;
                f2 = f1;
                if (f3 < f1)
                {
                  f2 = f3;
                  i3 = m;
                }
              }
            }
          }
          m += 1;
          i2 = i3;
          f1 = f2;
        }
        if (i2 > -1)
        {
          localObject = a[i2];
          a.f = -1;
          ((h)localObject).b(localLabel);
          localLabel = a;
          f = i2;
          localLabel.a(this, (h)localObject);
        }
        i2 = i4;
      }
      else
      {
        i1 = 1;
        i2 = i4;
      }
    }
    return i2;
  }
  
  public Label a(int paramInt, String paramString)
  {
    if (l + 1 >= n) {
      set();
    }
    paramString = a(c.d, paramString);
    int m = c + 1;
    c = m;
    l += 1;
    n = m;
    k = paramInt;
    z.d[m] = paramString;
    d.d(paramString);
    return paramString;
  }
  
  public Label a(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if (l + 1 >= n) {
      set();
    }
    Label localLabel1;
    if ((paramObject instanceof org.codehaus.asm.asm.Label))
    {
      Label localLabel2 = ((org.codehaus.asm.asm.Label)paramObject).c();
      localLabel1 = localLabel2;
      if (localLabel2 == null)
      {
        ((org.codehaus.asm.asm.Label)paramObject).setText();
        localLabel1 = ((org.codehaus.asm.asm.Label)paramObject).c();
      }
      int m = n;
      if ((m == -1) || (m > c) || (z.d[m] == null))
      {
        if (n != -1) {
          localLabel1.a();
        }
        m = c + 1;
        c = m;
        l += 1;
        n = m;
        i = c.a;
        z.d[m] = localLabel1;
        return localLabel1;
      }
    }
    else
    {
      return null;
    }
    return localLabel1;
  }
  
  public final Label a(c paramC, String paramString)
  {
    paramString = (Label)((MethodWriter)z.b).b();
    if (paramString == null)
    {
      Label localLabel = new Label(paramC);
      paramString = localLabel;
      localLabel.a(paramC);
    }
    else
    {
      paramString.a();
      paramString.a(paramC);
    }
    int m = w;
    int i1 = q;
    if (m >= i1)
    {
      m = i1 * 2;
      q = m;
      h = ((Label[])Arrays.copyOf(h, m));
    }
    paramC = h;
    m = w;
    w = (m + 1);
    paramC[m] = paramString;
    return paramString;
  }
  
  public h a(Label paramLabel1, Label paramLabel2, int paramInt1, int paramInt2)
  {
    if ((paramInt2 == 8) && (c) && (f == -1))
    {
      paramLabel1.a(this, a + paramInt1);
      return null;
    }
    h localH = c();
    localH.a(paramLabel1, paramLabel2, paramInt1);
    if (paramInt2 != 8) {
      localH.a(this, paramInt2);
    }
    a(localH);
    return localH;
  }
  
  public void a(Label paramLabel, int paramInt)
  {
    int m = f;
    if (m == -1)
    {
      paramLabel.a(this, paramInt);
      m = 0;
      while (m < c + 1)
      {
        localObject = z.d[m];
        if ((localObject != null) && (d) && (p == n)) {
          ((Label)localObject).a(this, paramInt + g);
        }
        m += 1;
      }
      return;
    }
    int i1 = f;
    if (m != -1)
    {
      localObject = a[i1];
      if (f)
      {
        b = paramInt;
        return;
      }
      if (c.size() == 0)
      {
        f = true;
        b = paramInt;
        return;
      }
      localObject = c();
      ((h)localObject).a(paramLabel, paramInt);
      a((h)localObject);
      return;
    }
    Object localObject = c();
    ((h)localObject).b(paramLabel, paramInt);
    a((h)localObject);
  }
  
  public void a(Label paramLabel1, Label paramLabel2, int paramInt)
  {
    h localH = c();
    Label localLabel = newUTF8();
    k = 0;
    localH.b(paramLabel1, paramLabel2, localLabel, paramInt);
    a(localH);
  }
  
  public void a(Label paramLabel1, Label paramLabel2, int paramInt1, float paramFloat, Label paramLabel3, Label paramLabel4, int paramInt2, int paramInt3)
  {
    h localH = c();
    localH.a(paramLabel1, paramLabel2, paramInt1, paramFloat, paramLabel3, paramLabel4, paramInt2);
    if (paramInt3 != 8) {
      localH.a(this, paramInt3);
    }
    a(localH);
  }
  
  public void a(Label paramLabel1, Label paramLabel2, Label paramLabel3, Label paramLabel4, float paramFloat, int paramInt)
  {
    h localH = c();
    localH.add(paramLabel1, paramLabel2, paramLabel3, paramLabel4, paramFloat);
    if (paramInt != 8) {
      localH.a(this, paramInt);
    }
    a(localH);
  }
  
  public void a(f paramF1, f paramF2, float paramFloat, int paramInt)
  {
    Label localLabel1 = a(paramF1.a(org.codehaus.asm.asm.c.d));
    Label localLabel3 = a(paramF1.a(org.codehaus.asm.asm.c.a));
    Label localLabel2 = a(paramF1.a(org.codehaus.asm.asm.c.i));
    Label localLabel5 = a(paramF1.a(org.codehaus.asm.asm.c.b));
    paramF1 = a(paramF2.a(org.codehaus.asm.asm.c.d));
    Label localLabel6 = a(paramF2.a(org.codehaus.asm.asm.c.a));
    Label localLabel4 = a(paramF2.a(org.codehaus.asm.asm.c.i));
    paramF2 = a(paramF2.a(org.codehaus.asm.asm.c.b));
    h localH = c();
    localH.a(localLabel3, localLabel5, localLabel6, paramF2, (float)(Math.sin(paramFloat) * paramInt));
    a(localH);
    paramF2 = c();
    paramF2.a(localLabel1, localLabel2, paramF1, localLabel4, (float)(Math.cos(paramFloat) * paramInt));
    a(paramF2);
  }
  
  public void a(h paramH)
  {
    if (paramH == null) {
      return;
    }
    if ((b + 1 >= j) || (l + 1 >= n)) {
      set();
    }
    int m = 0;
    int i1 = 0;
    if (!f)
    {
      paramH.c(this);
      if (paramH.isEmpty()) {
        return;
      }
      paramH.d();
      m = i1;
      if (paramH.b(this))
      {
        Label localLabel = visit();
        a = localLabel;
        int i2 = b;
        b(paramH);
        m = i1;
        if (b == i2 + 1)
        {
          i1 = 1;
          ((h)B).a(paramH);
          a(B);
          m = i1;
          if (f == -1)
          {
            if (a == localLabel)
            {
              localLabel = paramH.c(localLabel);
              if (localLabel != null) {
                paramH.b(localLabel);
              }
            }
            if (!f) {
              a.a(this, paramH);
            }
            ((MethodWriter)z.a).a(paramH);
            b -= 1;
            m = i1;
          }
        }
      }
      if (!paramH.c()) {
        return;
      }
    }
    if (m == 0) {
      b(paramH);
    }
  }
  
  public void a(h paramH, int paramInt1, int paramInt2)
  {
    paramH.c(a(paramInt2, null), paramInt1);
  }
  
  public final void accept()
  {
    int m = 0;
    while (m < b)
    {
      h localH = a[m];
      a.a = b;
      m += 1;
    }
  }
  
  public int b(Object paramObject)
  {
    paramObject = ((org.codehaus.asm.asm.Label)paramObject).c();
    if (paramObject != null) {
      return (int)(a + 0.5F);
    }
    return 0;
  }
  
  public void b()
  {
    int m = 0;
    for (;;)
    {
      localObject = z;
      arrayOfLabel = d;
      if (m >= arrayOfLabel.length) {
        break;
      }
      localObject = arrayOfLabel[m];
      if (localObject != null) {
        ((Label)localObject).a();
      }
      m += 1;
    }
    Object localObject = b;
    Label[] arrayOfLabel = h;
    m = w;
    ((MethodWriter)localObject).a(arrayOfLabel, m);
    w = 0;
    Arrays.fill(z.d, null);
    localObject = o;
    if (localObject != null) {
      ((HashMap)localObject).clear();
    }
    c = 0;
    d.clear();
    l = 1;
    m = 0;
    while (m < b)
    {
      localObject = a;
      if (localObject[m] != null) {
        g = false;
      }
      m += 1;
    }
    toByteArray();
    b = 0;
    B = new h(z);
  }
  
  public void b(Label paramLabel1, Label paramLabel2, int paramInt)
  {
    h localH = c();
    Label localLabel = newUTF8();
    k = 0;
    localH.a(paramLabel1, paramLabel2, localLabel, paramInt);
    a(localH);
  }
  
  public void b(Label paramLabel1, Label paramLabel2, int paramInt1, int paramInt2)
  {
    h localH = c();
    Label localLabel = newUTF8();
    k = 0;
    localH.a(paramLabel1, paramLabel2, localLabel, paramInt1);
    if (paramInt2 != 8) {
      a(localH, (int)(-1.0F * c.b(localLabel)), paramInt2);
    }
    a(localH);
  }
  
  public final void b(h paramH)
  {
    int m;
    if (f)
    {
      a.a(this, b);
    }
    else
    {
      Object localObject = a;
      m = b;
      localObject[m] = paramH;
      localObject = a;
      f = m;
      b = (m + 1);
      ((Label)localObject).a(this, paramH);
    }
    if (k)
    {
      int i1;
      for (m = 0; m < b; m = i1 + 1)
      {
        if (a[m] == null) {
          System.out.println("WTF");
        }
        paramH = a;
        i1 = m;
        if (paramH[m] != null)
        {
          i1 = m;
          if (f)
          {
            paramH = paramH[m];
            a.a(this, b);
            ((MethodWriter)z.a).a(paramH);
            a[m] = null;
            int i2 = m + 1;
            i1 = m + 1;
            int i3;
            for (;;)
            {
              i3 = b;
              if (i1 >= i3) {
                break;
              }
              paramH = a;
              paramH[(i1 - 1)] = paramH[i1];
              if (1a.f == i1) {
                1a.f = (i1 - 1);
              }
              i2 = i1;
              i1 += 1;
            }
            if (i2 < i3) {
              a[i2] = null;
            }
            b -= 1;
            i1 = m - 1;
          }
        }
      }
      k = false;
    }
  }
  
  public h c()
  {
    h localH = (h)((MethodWriter)z.a).b();
    if (localH == null)
    {
      localH = new h(z);
      x += 1L;
    }
    else
    {
      localH.b();
    }
    Label.accept();
    return localH;
  }
  
  public void c(Label paramLabel1, Label paramLabel2, int paramInt1, int paramInt2)
  {
    h localH = c();
    Label localLabel = newUTF8();
    k = 0;
    localH.b(paramLabel1, paramLabel2, localLabel, paramInt1);
    if (paramInt2 != 8) {
      a(localH, (int)(-1.0F * c.b(localLabel)), paramInt2);
    }
    a(localH);
  }
  
  public void c(d paramD)
  {
    a();
    a(paramD);
    accept();
  }
  
  public void d()
  {
    if (d.isEmpty())
    {
      accept();
      return;
    }
    if ((!i) && (!f))
    {
      c(d);
      return;
    }
    int i2 = 1;
    int m = 0;
    int i1;
    for (;;)
    {
      i1 = i2;
      if (m >= b) {
        break;
      }
      if (!a[m].f)
      {
        i1 = 0;
        break;
      }
      m += 1;
    }
    if (i1 == 0)
    {
      c(d);
      return;
    }
    accept();
  }
  
  public Item get()
  {
    return z;
  }
  
  public Label newUTF8()
  {
    if (l + 1 >= n) {
      set();
    }
    Label localLabel = a(c.c, null);
    int m = c + 1;
    c = m;
    l += 1;
    n = m;
    z.d[m] = localLabel;
    return localLabel;
  }
  
  public final void set()
  {
    int m = y * 2;
    y = m;
    a = ((h[])Arrays.copyOf(a, m));
    Item localItem = z;
    d = ((Label[])Arrays.copyOf(d, y));
    m = y;
    g = new boolean[m];
    n = m;
    j = m;
  }
  
  public final void toByteArray()
  {
    int m = 0;
    while (m < b)
    {
      h localH = a[m];
      if (localH != null) {
        ((MethodWriter)z.a).a(localH);
      }
      a[m] = null;
      m += 1;
    }
  }
  
  public Label visit()
  {
    if (l + 1 >= n) {
      set();
    }
    Label localLabel = a(c.c, null);
    int m = c + 1;
    c = m;
    l += 1;
    n = m;
    z.d[m] = localLabel;
    return localLabel;
  }
}
