package org.codehaus.asm;

import java.util.Arrays;

public class i
  extends h
{
  public int e = 128;
  public Label[] h = new Label['?'];
  public Attribute j = new Attribute(this, this);
  public int m = 0;
  public Label[] n = new Label['?'];
  
  public i(Item paramItem)
  {
    super(paramItem);
  }
  
  public Label a(ClassWriter paramClassWriter, boolean[] paramArrayOfBoolean)
  {
    int i1 = -1;
    int i = 0;
    while (i < m)
    {
      paramClassWriter = n[i];
      int k;
      if (paramArrayOfBoolean[n] != 0)
      {
        k = i1;
      }
      else
      {
        j.write(paramClassWriter);
        if (i1 == -1)
        {
          k = i1;
          if (j.a()) {
            k = i;
          }
        }
        else
        {
          k = i1;
          if (j.a(n[i1])) {
            k = i;
          }
        }
      }
      i += 1;
      i1 = k;
    }
    if (i1 == -1) {
      return null;
    }
    return n[i1];
  }
  
  public void a(ClassWriter paramClassWriter, h paramH, boolean paramBoolean)
  {
    paramClassWriter = a;
    if (paramClassWriter == null) {
      return;
    }
    ByteVector localByteVector = c;
    int k = localByteVector.size();
    int i = 0;
    while (i < k)
    {
      Label localLabel = localByteVector.a(i);
      float f = localByteVector.b(i);
      j.write(localLabel);
      if (j.a(paramClassWriter, f)) {
        a(localLabel);
      }
      b += b * f;
      i += 1;
    }
    clear(paramClassWriter);
  }
  
  public final void a(Label paramLabel)
  {
    int i = m;
    Label[] arrayOfLabel = n;
    if (i + 1 > arrayOfLabel.length)
    {
      arrayOfLabel = (Label[])Arrays.copyOf(arrayOfLabel, arrayOfLabel.length * 2);
      n = arrayOfLabel;
      h = ((Label[])Arrays.copyOf(arrayOfLabel, arrayOfLabel.length * 2));
    }
    arrayOfLabel = n;
    i = m;
    arrayOfLabel[i] = paramLabel;
    i += 1;
    m = i;
    if ((i > 1) && (1n > n))
    {
      i = 0;
      int k;
      for (;;)
      {
        k = m;
        if (i >= k) {
          break;
        }
        h[i] = n[i];
        i += 1;
      }
      Arrays.sort(h, 0, k, new DetailArret.1(this));
      i = 0;
      while (i < m)
      {
        n[i] = h[i];
        i += 1;
      }
    }
    t = true;
    paramLabel.b(this);
  }
  
  public void clear()
  {
    m = 0;
    b = 0.0F;
  }
  
  public final void clear(Label paramLabel)
  {
    int i = 0;
    while (i < m)
    {
      if (n[i] == paramLabel)
      {
        int k;
        for (;;)
        {
          k = m;
          if (i >= k - 1) {
            break;
          }
          Label[] arrayOfLabel = n;
          arrayOfLabel[i] = arrayOfLabel[(i + 1)];
          i += 1;
        }
        m = (k - 1);
        t = false;
        return;
      }
      i += 1;
    }
  }
  
  public void d(Label paramLabel)
  {
    j.write(paramLabel);
    j.b();
    m[k] = 1.0F;
    a(paramLabel);
  }
  
  public boolean isEmpty()
  {
    return m == 0;
  }
  
  public String toString()
  {
    Object localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append("");
    ((StringBuilder)localObject1).append(" goal -> (");
    ((StringBuilder)localObject1).append(b);
    ((StringBuilder)localObject1).append(") : ");
    localObject1 = ((StringBuilder)localObject1).toString();
    int i = 0;
    while (i < m)
    {
      Object localObject2 = n[i];
      j.write((Label)localObject2);
      localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append((String)localObject1);
      ((StringBuilder)localObject2).append(j);
      ((StringBuilder)localObject2).append(" ");
      localObject1 = ((StringBuilder)localObject2).toString();
      i += 1;
    }
    return localObject1;
  }
}
