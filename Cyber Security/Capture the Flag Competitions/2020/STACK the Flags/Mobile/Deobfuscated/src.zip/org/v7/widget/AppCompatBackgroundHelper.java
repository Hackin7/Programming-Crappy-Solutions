package org.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.View;
import org.core.view.ViewCompat;
import org.v7.R.styleable;

public class AppCompatBackgroundHelper
{
  public TintInfo mBackgroundTint;
  public TintInfo mInternalBackgroundTint;
  public int mOldLayerType = -1;
  public final Context mTintManager;
  public TintInfo mTmpInfo;
  public final View mView;
  
  public AppCompatBackgroundHelper(View paramView)
  {
    mView = paramView;
    mTintManager = Context.get();
  }
  
  public void applySupportBackgroundTint()
  {
    Drawable localDrawable = mView.getBackground();
    if (localDrawable != null)
    {
      if ((shouldCompatTintUsingFrameworkTint()) && (compatTintDrawableUsingFrameworkTint(localDrawable))) {
        return;
      }
      TintInfo localTintInfo = mBackgroundTint;
      if (localTintInfo != null)
      {
        Context.tintDrawable(localDrawable, localTintInfo, mView.getDrawableState());
        return;
      }
      localTintInfo = mInternalBackgroundTint;
      if (localTintInfo != null) {
        Context.tintDrawable(localDrawable, localTintInfo, mView.getDrawableState());
      }
    }
  }
  
  public final boolean compatTintDrawableUsingFrameworkTint(Drawable paramDrawable)
  {
    if (mTmpInfo == null) {
      mTmpInfo = new TintInfo();
    }
    TintInfo localTintInfo = mTmpInfo;
    localTintInfo.clear();
    Object localObject = ViewCompat.getBackgroundTintList(mView);
    if (localObject != null)
    {
      mHasTintList = true;
      mTintList = ((ColorStateList)localObject);
    }
    localObject = ViewCompat.getBackgroundTintMode(mView);
    if (localObject != null)
    {
      mHasTintMode = true;
      mTintMode = ((PorterDuff.Mode)localObject);
    }
    if ((!mHasTintList) && (!mHasTintMode)) {
      return false;
    }
    Context.tintDrawable(paramDrawable, localTintInfo, mView.getDrawableState());
    return true;
  }
  
  public ColorStateList getSupportBackgroundTintList()
  {
    TintInfo localTintInfo = mBackgroundTint;
    if (localTintInfo != null) {
      return mTintList;
    }
    return null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    TintInfo localTintInfo = mBackgroundTint;
    if (localTintInfo != null) {
      return mTintMode;
    }
    return null;
  }
  
  public void loadFromAttributes(int paramInt)
  {
    mOldLayerType = paramInt;
    Object localObject = mTintManager;
    if (localObject != null) {
      localObject = ((Context)localObject).getTintList(mView.getContext(), paramInt);
    } else {
      localObject = null;
    }
    setInternalBackgroundTint((ColorStateList)localObject);
    applySupportBackgroundTint();
  }
  
  public void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt)
  {
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(mView.getContext(), paramAttributeSet, R.styleable.ViewBackgroundHelper, paramInt, 0);
    View localView = mView;
    ViewCompat.obtainStyledAttributes(localView, localView.getContext(), R.styleable.ViewBackgroundHelper, paramAttributeSet, localTintTypedArray.getResourceId(), paramInt, 0);
    try
    {
      boolean bool = localTintTypedArray.hasValue(R.styleable.ViewBackgroundHelper_android_background);
      if (bool)
      {
        mOldLayerType = localTintTypedArray.getResourceId(R.styleable.ViewBackgroundHelper_android_background, -1);
        paramAttributeSet = mTintManager.getTintList(mView.getContext(), mOldLayerType);
        if (paramAttributeSet != null) {
          setInternalBackgroundTint(paramAttributeSet);
        }
      }
      bool = localTintTypedArray.hasValue(R.styleable.ViewBackgroundHelper_backgroundTint);
      if (bool) {
        ViewCompat.setBackgroundTintList(mView, localTintTypedArray.getColorStateList(R.styleable.ViewBackgroundHelper_backgroundTint));
      }
      bool = localTintTypedArray.hasValue(R.styleable.ViewBackgroundHelper_backgroundTintMode);
      if (bool) {
        ViewCompat.setBackgroundTintMode(mView, DrawableUtils.parseTintMode(localTintTypedArray.getInt(R.styleable.ViewBackgroundHelper_backgroundTintMode, -1), null));
      }
      localTintTypedArray.recycle();
      return;
    }
    catch (Throwable paramAttributeSet)
    {
      localTintTypedArray.recycle();
      throw paramAttributeSet;
    }
  }
  
  public void setInternalBackgroundTint(ColorStateList paramColorStateList)
  {
    if (paramColorStateList != null)
    {
      if (mInternalBackgroundTint == null) {
        mInternalBackgroundTint = new TintInfo();
      }
      TintInfo localTintInfo = mInternalBackgroundTint;
      mTintList = paramColorStateList;
      mHasTintList = true;
    }
    else
    {
      mInternalBackgroundTint = null;
    }
    applySupportBackgroundTint();
  }
  
  public void setSupportBackgroundTintList()
  {
    mOldLayerType = -1;
    setInternalBackgroundTint(null);
    applySupportBackgroundTint();
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList)
  {
    if (mBackgroundTint == null) {
      mBackgroundTint = new TintInfo();
    }
    TintInfo localTintInfo = mBackgroundTint;
    mTintList = paramColorStateList;
    mHasTintList = true;
    applySupportBackgroundTint();
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    if (mBackgroundTint == null) {
      mBackgroundTint = new TintInfo();
    }
    TintInfo localTintInfo = mBackgroundTint;
    mTintMode = paramMode;
    mHasTintMode = true;
    applySupportBackgroundTint();
  }
  
  public final boolean shouldCompatTintUsingFrameworkTint()
  {
    int i = Build.VERSION.SDK_INT;
    if (i > 21) {
      return mInternalBackgroundTint != null;
    }
    return i == 21;
  }
}
