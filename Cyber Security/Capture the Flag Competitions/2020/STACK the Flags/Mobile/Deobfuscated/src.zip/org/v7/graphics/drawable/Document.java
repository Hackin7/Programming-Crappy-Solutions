package org.v7.graphics.drawable;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.StateSet;

public class Document
  extends DrawableContainer.DrawableContainerState
{
  public int[][] q;
  
  public Document(Document paramDocument, VectorDrawableCompat paramVectorDrawableCompat, Resources paramResources)
  {
    super(paramDocument, paramVectorDrawableCompat, paramResources);
    if (paramDocument != null)
    {
      q = q;
      return;
    }
    q = new int[getChildren()][];
  }
  
  public int a(int[] paramArrayOfInt)
  {
    int[][] arrayOfInt = q;
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      if (StateSet.stateSetMatches(arrayOfInt[i], paramArrayOfInt)) {
        return i;
      }
      i += 1;
    }
    return -1;
  }
  
  public int add(int[] paramArrayOfInt, Drawable paramDrawable)
  {
    int i = add(paramDrawable);
    q[i] = paramArrayOfInt;
    return i;
  }
  
  public void addChild(int paramInt1, int paramInt2)
  {
    super.addChild(paramInt1, paramInt2);
    int[][] arrayOfInt = new int[paramInt2][];
    System.arraycopy(q, 0, arrayOfInt, 0, paramInt1);
    q = arrayOfInt;
  }
  
  public void init()
  {
    Object localObject = q;
    int[][] arrayOfInt = new int[localObject.length][];
    int i = localObject.length - 1;
    while (i >= 0)
    {
      localObject = q;
      if (localObject[i] != null) {
        localObject = (int[])localObject[i].clone();
      } else {
        localObject = null;
      }
      arrayOfInt[i] = localObject;
      i -= 1;
    }
    q = arrayOfInt;
  }
  
  public Drawable newDrawable()
  {
    return new VectorDrawableCompat(this, null);
  }
  
  public Drawable newDrawable(Resources paramResources)
  {
    return new VectorDrawableCompat(this, paramResources);
  }
}
