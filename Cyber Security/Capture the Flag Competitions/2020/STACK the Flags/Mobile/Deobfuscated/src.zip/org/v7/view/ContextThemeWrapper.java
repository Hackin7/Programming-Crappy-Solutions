package org.v7.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.view.LayoutInflater;
import org.v7.R.style;

public class ContextThemeWrapper
  extends ContextWrapper
{
  public LayoutInflater mInflater;
  public Resources.Theme mTheme;
  public int mThemeResource;
  public Resources resources;
  public Configuration theme;
  
  public ContextThemeWrapper()
  {
    super(null);
  }
  
  public ContextThemeWrapper(Context paramContext, int paramInt)
  {
    super(paramContext);
    mThemeResource = paramInt;
  }
  
  public ContextThemeWrapper(Context paramContext, Resources.Theme paramTheme)
  {
    super(paramContext);
    mTheme = paramTheme;
  }
  
  public void attachBaseContext(Context paramContext)
  {
    super.attachBaseContext(paramContext);
  }
  
  public AssetManager getAssets()
  {
    return getResources().getAssets();
  }
  
  public Resources getResources()
  {
    return getView();
  }
  
  public Object getSystemService(String paramString)
  {
    if ("layout_inflater".equals(paramString))
    {
      if (mInflater == null) {
        mInflater = LayoutInflater.from(getBaseContext()).cloneInContext(this);
      }
      return mInflater;
    }
    return getBaseContext().getSystemService(paramString);
  }
  
  public Resources.Theme getTheme()
  {
    Resources.Theme localTheme = mTheme;
    if (localTheme != null) {
      return localTheme;
    }
    if (mThemeResource == 0) {
      mThemeResource = R.style.Theme_AppCompat_Light;
    }
    initializeTheme();
    return mTheme;
  }
  
  public void getTheme(Configuration paramConfiguration)
  {
    if (resources == null)
    {
      if (theme == null)
      {
        theme = new Configuration(paramConfiguration);
        return;
      }
      throw new IllegalStateException("Override configuration has already been set");
    }
    throw new IllegalStateException("getResources() or getAssets() has already been called");
  }
  
  public int getThemeResId()
  {
    return mThemeResource;
  }
  
  public final Resources getView()
  {
    if (resources == null)
    {
      Configuration localConfiguration = theme;
      if (localConfiguration == null) {
        resources = super.getResources();
      } else {
        resources = createConfigurationContext(localConfiguration).getResources();
      }
    }
    return resources;
  }
  
  public final void initializeTheme()
  {
    int i;
    if (mTheme == null) {
      i = 1;
    } else {
      i = 0;
    }
    if (i != 0)
    {
      mTheme = getResources().newTheme();
      Resources.Theme localTheme = getBaseContext().getTheme();
      if (localTheme != null) {
        mTheme.setTo(localTheme);
      }
    }
    onApplyThemeResource(mTheme, mThemeResource);
  }
  
  public void onApplyThemeResource(Resources.Theme paramTheme, int paramInt)
  {
    paramTheme.applyStyle(paramInt, true);
  }
  
  public void setTheme(int paramInt)
  {
    if (mThemeResource != paramInt)
    {
      mThemeResource = paramInt;
      initializeTheme();
    }
  }
}
