package org.asm;

import a.e.a;
import a.e.d;
import a.r.r;
import android.util.SparseArray;
import android.view.View;
import org.data.Item;
import org.data.Label;

public class x
{
  public final SparseArray<View> a = new SparseArray();
  public final d<View> b = new Item();
  public final a<String, View> c = new Label();
  public final a<View, r> d = new Label();
  
  public x() {}
}
