package org.asm;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;

public class ByteVector
  implements Item
{
  public final ViewGroupOverlay n;
  
  public ByteVector(ViewGroup paramViewGroup)
  {
    n = paramViewGroup.getOverlay();
  }
  
  public void a(View paramView)
  {
    n.remove(paramView);
  }
  
  public void b(View paramView)
  {
    n.add(paramView);
  }
}
