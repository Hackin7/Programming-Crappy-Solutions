package org.asm;

import android.view.View;
import java.util.ArrayList;

public class MethodWriter
  implements m
{
  public MethodWriter(a paramA, View paramView, ArrayList paramArrayList) {}
  
  public void a(l paramL)
  {
    paramL.b(this);
    u.setVisibility(8);
    int j = v.size();
    int i = 0;
    while (i < j)
    {
      ((View)v.get(i)).setVisibility(0);
      i += 1;
    }
  }
  
  public void b(l paramL) {}
  
  public void c(l paramL) {}
  
  public void d(l paramL) {}
}
