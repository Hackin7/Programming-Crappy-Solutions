package org.v7.app;

import android.content.res.Configuration;

public class FixedStepHandler
{
  public static void init(Configuration paramConfiguration1, Configuration paramConfiguration2, Configuration paramConfiguration3)
  {
    int i = densityDpi;
    int j = densityDpi;
    if (i != j) {
      densityDpi = j;
    }
  }
}
