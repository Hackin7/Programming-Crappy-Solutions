package org.util;

public abstract interface h
  extends MethodVisitor
{
  public abstract void a(d paramD);
  
  public abstract void b(d paramD);
  
  public abstract void c(d paramD);
  
  public abstract void e(d paramD);
  
  public abstract void f(d paramD);
  
  public abstract void g(d paramD);
}
