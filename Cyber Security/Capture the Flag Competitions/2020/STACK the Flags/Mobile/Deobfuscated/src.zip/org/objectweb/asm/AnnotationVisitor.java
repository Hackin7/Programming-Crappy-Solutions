package org.objectweb.asm;

public abstract interface AnnotationVisitor {}
