package org.util;

public abstract interface MethodVisitor {}
