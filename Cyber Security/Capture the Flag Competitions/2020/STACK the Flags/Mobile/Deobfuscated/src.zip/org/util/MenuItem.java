package org.util;

public abstract interface MenuItem
  extends MethodVisitor
{
  public abstract void b(d paramD, Scope paramScope);
}
