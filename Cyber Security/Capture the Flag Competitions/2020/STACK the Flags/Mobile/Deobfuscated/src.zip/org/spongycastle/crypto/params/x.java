package org.spongycastle.crypto.params;

public abstract interface x<K, V>
{
  public abstract void init(Attribute paramAttribute);
}
