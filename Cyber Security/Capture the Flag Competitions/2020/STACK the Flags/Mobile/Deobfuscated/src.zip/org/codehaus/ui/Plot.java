package org.codehaus.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseIntArray;

public class Plot
{
  public static SparseIntArray o;
  public float a = 0.0F;
  public float c = NaN.0F;
  public boolean d = false;
  public float e = 1.0F;
  public float h = 0.0F;
  public float i = 0.0F;
  public float j = 0.0F;
  public float k = 0.0F;
  public float n = 0.0F;
  public boolean p = false;
  public float r = NaN.0F;
  public float s = 0.0F;
  public float w = 1.0F;
  
  static
  {
    SparseIntArray localSparseIntArray = new SparseIntArray();
    o = localSparseIntArray;
    localSparseIntArray.append(IpAddress.Transform_android_rotation, 1);
    o.append(IpAddress.Transform_android_rotationX, 2);
    o.append(IpAddress.Transform_android_rotationY, 3);
    o.append(IpAddress.Transform_android_scaleX, 4);
    o.append(IpAddress.Transform_android_scaleY, 5);
    o.append(IpAddress.Transform_android_transformPivotX, 6);
    o.append(IpAddress.Transform_android_transformPivotY, 7);
    o.append(IpAddress.Transform_android_translationX, 8);
    o.append(IpAddress.Transform_android_translationY, 9);
    o.append(IpAddress.Transform_android_translationZ, 10);
    o.append(IpAddress.Transform_android_elevation, 11);
  }
  
  public Plot() {}
  
  public void a(Context paramContext, AttributeSet paramAttributeSet)
  {
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.Transform);
    d = true;
    int i1 = paramContext.getIndexCount();
    int m = 0;
    while (m < i1)
    {
      int i2 = paramContext.getIndex(m);
      switch (o.get(i2))
      {
      default: 
        break;
      case 11: 
        p = true;
        h = paramContext.getDimension(i2, h);
        break;
      case 10: 
        k = paramContext.getDimension(i2, k);
        break;
      case 9: 
        j = paramContext.getDimension(i2, j);
        break;
      case 8: 
        n = paramContext.getDimension(i2, n);
        break;
      case 7: 
        c = paramContext.getDimension(i2, c);
        break;
      case 6: 
        r = paramContext.getDimension(i2, r);
        break;
      case 5: 
        w = paramContext.getFloat(i2, w);
        break;
      case 4: 
        e = paramContext.getFloat(i2, e);
        break;
      case 3: 
        s = paramContext.getFloat(i2, s);
        break;
      case 2: 
        i = paramContext.getFloat(i2, i);
        break;
      case 1: 
        a = paramContext.getFloat(i2, a);
      }
      m += 1;
    }
    paramContext.recycle();
  }
  
  public void a(Plot paramPlot)
  {
    d = d;
    a = a;
    i = i;
    s = s;
    e = e;
    w = w;
    r = r;
    c = c;
    n = n;
    j = j;
    k = k;
    p = p;
    h = h;
  }
}
