package org.spongycastle.crypto.util;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DiskLruCache
  extends f
{
  public final ExecutorService executorService = Executors.newFixedThreadPool(2, new NamedThreadFactory(this));
  public volatile Handler openCount;
  public final Object openFiles = new Object();
  
  public DiskLruCache() {}
  
  public void close(Runnable paramRunnable)
  {
    if (openCount == null)
    {
      Object localObject = openFiles;
      try
      {
        if (openCount == null) {
          openCount = new Handler(Looper.getMainLooper());
        }
      }
      catch (Throwable paramRunnable)
      {
        throw paramRunnable;
      }
    }
    openCount.post(paramRunnable);
  }
  
  public boolean close()
  {
    return Looper.getMainLooper().getThread() == Thread.currentThread();
  }
  
  public void remove(Runnable paramRunnable)
  {
    executorService.execute(paramRunnable);
  }
}
