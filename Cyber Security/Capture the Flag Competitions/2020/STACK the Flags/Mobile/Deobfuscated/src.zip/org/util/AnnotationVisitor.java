package org.util;

import java.util.HashMap;

public class AnnotationVisitor
{
  public AnnotationVisitor()
  {
    new HashMap();
  }
}
