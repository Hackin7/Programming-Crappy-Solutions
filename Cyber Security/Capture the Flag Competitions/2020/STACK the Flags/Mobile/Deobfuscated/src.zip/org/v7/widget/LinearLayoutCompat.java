package org.v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityRecord;
import org.core.view.GravityCompat;
import org.core.view.ViewCompat;
import org.v7.R.styleable;

public class LinearLayoutCompat
  extends ViewGroup
{
  public boolean mBaselineAligned = true;
  public int mBaselineAlignedChildIndex = -1;
  public int mBaselineChildTop = 0;
  public Drawable mDivider;
  public int mDividerHeight;
  public int mDividerPadding;
  public int mDividerWidth;
  public int mGravity = 8388659;
  public int[] mMaxAscent;
  public int[] mMaxDescent;
  public int mOrientation;
  public int mShowDividers;
  public int mTotalLength;
  public boolean mUseLargestChild;
  public float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.LinearLayoutCompat, paramInt, 0);
    ViewCompat.obtainStyledAttributes(this, paramContext, R.styleable.LinearLayoutCompat, paramAttributeSet, localTintTypedArray.getResourceId(), paramInt, 0);
    paramInt = localTintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0) {
      setOrientation(paramInt);
    }
    paramInt = localTintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0) {
      setGravity(paramInt);
    }
    boolean bool = localTintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool) {
      setBaselineAligned(bool);
    }
    mWeightSum = localTintTypedArray.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
    mBaselineAlignedChildIndex = localTintTypedArray.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    mUseLargestChild = localTintTypedArray.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(localTintTypedArray.getDrawable(R.styleable.LinearLayoutCompat_divider));
    mShowDividers = localTintTypedArray.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
    mDividerPadding = localTintTypedArray.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
    localTintTypedArray.recycle();
  }
  
  public i0.a a()
  {
    int i = mOrientation;
    if (i == 0) {
      return new i0.a(-2, -2);
    }
    if (i == 1) {
      return new i0.a(-1, -2);
    }
    return null;
  }
  
  public i0.a b(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new i0.a(paramLayoutParams);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof i0.a;
  }
  
  public void drawDividersHorizontal(Canvas paramCanvas)
  {
    int k = getVirtualChildCount();
    boolean bool = ViewUtils.isLayoutRtl(this);
    int i = 0;
    View localView;
    i0.a localA;
    while (i < k)
    {
      localView = getVirtualChildAt(i);
      if ((localView != null) && (localView.getVisibility() != 8) && (hasDividerBeforeChildAt(i)))
      {
        localA = (i0.a)localView.getLayoutParams();
        int j;
        if (bool) {
          j = localView.getRight() + rightMargin;
        } else {
          j = localView.getLeft() - leftMargin - mDividerWidth;
        }
        drawVerticalDivider(paramCanvas, j);
      }
      i += 1;
    }
    if (hasDividerBeforeChildAt(k))
    {
      localView = getVirtualChildAt(k - 1);
      if (localView == null)
      {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight() - mDividerWidth;
        }
      }
      else
      {
        localA = (i0.a)localView.getLayoutParams();
        if (bool) {
          i = localView.getLeft() - leftMargin - mDividerWidth;
        } else {
          i = localView.getRight() + rightMargin;
        }
      }
      drawVerticalDivider(paramCanvas, i);
    }
  }
  
  public void drawDividersVertical(Canvas paramCanvas)
  {
    int j = getVirtualChildCount();
    int i = 0;
    View localView;
    i0.a localA;
    while (i < j)
    {
      localView = getVirtualChildAt(i);
      if ((localView != null) && (localView.getVisibility() != 8) && (hasDividerBeforeChildAt(i)))
      {
        localA = (i0.a)localView.getLayoutParams();
        drawHorizontalDivider(paramCanvas, localView.getTop() - topMargin - mDividerHeight);
      }
      i += 1;
    }
    if (hasDividerBeforeChildAt(j))
    {
      localView = getVirtualChildAt(j - 1);
      if (localView == null)
      {
        i = getHeight() - getPaddingBottom() - mDividerHeight;
      }
      else
      {
        localA = (i0.a)localView.getLayoutParams();
        i = localView.getBottom() + bottomMargin;
      }
      drawHorizontalDivider(paramCanvas, i);
    }
  }
  
  public void drawHorizontalDivider(Canvas paramCanvas, int paramInt)
  {
    mDivider.setBounds(getPaddingLeft() + mDividerPadding, paramInt, getWidth() - getPaddingRight() - mDividerPadding, mDividerHeight + paramInt);
    mDivider.draw(paramCanvas);
  }
  
  public void drawVerticalDivider(Canvas paramCanvas, int paramInt)
  {
    mDivider.setBounds(paramInt, getPaddingTop() + mDividerPadding, mDividerWidth + paramInt, getHeight() - getPaddingBottom() - mDividerPadding);
    mDivider.draw(paramCanvas);
  }
  
  public final void forceUniformHeight(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    int i = 0;
    while (i < paramInt1)
    {
      View localView = getVirtualChildAt(i);
      if (localView.getVisibility() != 8)
      {
        i0.a localA = (i0.a)localView.getLayoutParams();
        if (height == -1)
        {
          int k = width;
          width = localView.getMeasuredWidth();
          measureChildWithMargins(localView, paramInt2, 0, j, 0);
          width = k;
        }
      }
      i += 1;
    }
  }
  
  public final void forceUniformWidth(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    int i = 0;
    while (i < paramInt1)
    {
      View localView = getVirtualChildAt(i);
      if (localView.getVisibility() != 8)
      {
        i0.a localA = (i0.a)localView.getLayoutParams();
        if (width == -1)
        {
          int k = height;
          height = localView.getMeasuredHeight();
          measureChildWithMargins(localView, j, 0, paramInt2, 0);
          height = k;
        }
      }
      i += 1;
    }
  }
  
  public int getBaseline()
  {
    if (mBaselineAlignedChildIndex < 0) {
      return super.getBaseline();
    }
    int i = getChildCount();
    int j = mBaselineAlignedChildIndex;
    if (i > j)
    {
      View localView = getChildAt(j);
      int k = localView.getBaseline();
      if (k == -1)
      {
        if (mBaselineAlignedChildIndex == 0) {
          return -1;
        }
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      }
      j = mBaselineChildTop;
      i = j;
      if (mOrientation == 1)
      {
        int m = mGravity & 0x70;
        i = j;
        if (m != 48) {
          if (m != 16)
          {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - mTotalLength;
            }
          }
          else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - mTotalLength) / 2;
          }
        }
      }
      return getLayoutParamstopMargin + i + k;
    }
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex()
  {
    return mBaselineAlignedChildIndex;
  }
  
  public int getChildrenSkipCount()
  {
    return 0;
  }
  
  public Drawable getDividerDrawable()
  {
    return mDivider;
  }
  
  public int getDividerPadding()
  {
    return mDividerPadding;
  }
  
  public int getDividerWidth()
  {
    return mDividerWidth;
  }
  
  public int getGravity()
  {
    return mGravity;
  }
  
  public int getNextLocationOffset()
  {
    return 0;
  }
  
  public int getOrientation()
  {
    return mOrientation;
  }
  
  public int getShowDividers()
  {
    return mShowDividers;
  }
  
  public View getVirtualChildAt(int paramInt)
  {
    return getChildAt(paramInt);
  }
  
  public int getVirtualChildCount()
  {
    return getChildCount();
  }
  
  public float getWeightSum()
  {
    return mWeightSum;
  }
  
  public int hasDividerBeforeChildAt()
  {
    return 0;
  }
  
  public boolean hasDividerBeforeChildAt(int paramInt)
  {
    if (paramInt == 0)
    {
      if ((mShowDividers & 0x1) != 0) {
        return true;
      }
    }
    else if (paramInt == getChildCount())
    {
      if ((mShowDividers & 0x4) != 0) {
        return true;
      }
    }
    else if ((mShowDividers & 0x2) != 0)
    {
      paramInt -= 1;
      while (paramInt >= 0)
      {
        if (getChildAt(paramInt).getVisibility() != 8) {
          return true;
        }
        paramInt -= 1;
      }
      return false;
    }
    return false;
  }
  
  public void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    boolean bool1 = ViewUtils.isLayoutRtl(this);
    int k = getPaddingTop();
    int n = paramInt4 - paramInt2;
    int i1 = getPaddingBottom();
    int i2 = getPaddingBottom();
    int i3 = getVirtualChildCount();
    int i4 = mGravity;
    boolean bool2 = mBaselineAligned;
    int[] arrayOfInt1 = mMaxAscent;
    int[] arrayOfInt2 = mMaxDescent;
    paramInt2 = GravityCompat.getAbsoluteGravity(i4 & 0x800007, ViewCompat.getLayoutDirection(this));
    if (paramInt2 != 1)
    {
      if (paramInt2 != 5) {
        paramInt1 = getPaddingLeft();
      } else {
        paramInt1 = getPaddingLeft() + paramInt3 - paramInt1 - mTotalLength;
      }
    }
    else {
      paramInt1 = getPaddingLeft() + (paramInt3 - paramInt1 - mTotalLength) / 2;
    }
    int i;
    if (bool1)
    {
      i = i3 - 1;
      paramInt4 = -1;
    }
    else
    {
      i = 0;
      paramInt4 = 1;
    }
    paramInt2 = 0;
    for (paramInt3 = paramInt1;; paramInt3 = paramInt1)
    {
      LinearLayoutCompat localLinearLayoutCompat = this;
      if (paramInt2 >= i3) {
        break;
      }
      int i5 = i + paramInt4 * paramInt2;
      View localView = localLinearLayoutCompat.getVirtualChildAt(i5);
      int j;
      if (localView == null)
      {
        paramInt1 = paramInt3 + hasDividerBeforeChildAt();
        j = paramInt2;
      }
      else
      {
        paramInt1 = paramInt3;
        j = paramInt2;
        if (localView.getVisibility() != 8)
        {
          int i6 = localView.getMeasuredWidth();
          int i7 = localView.getMeasuredHeight();
          i0.a localA = (i0.a)localView.getLayoutParams();
          if ((bool2) && (height != -1)) {
            paramInt1 = localView.getBaseline();
          } else {
            paramInt1 = -1;
          }
          int m = gravity;
          j = m;
          if (m < 0) {
            j = i4 & 0x70;
          }
          j &= 0x70;
          if (j != 16)
          {
            if (j != 48)
            {
              if (j != 80)
              {
                paramInt1 = k;
              }
              else
              {
                j = n - i1 - i7 - bottomMargin;
                if (paramInt1 != -1)
                {
                  m = localView.getMeasuredHeight();
                  paramInt1 = j - (arrayOfInt2[2] - (m - paramInt1));
                }
                else
                {
                  paramInt1 = j;
                }
              }
            }
            else
            {
              j = topMargin + k;
              if (paramInt1 != -1) {
                paramInt1 = j + (arrayOfInt1[1] - paramInt1);
              } else {
                paramInt1 = j;
              }
            }
          }
          else {
            paramInt1 = (n - k - i2 - i7) / 2 + k + topMargin - bottomMargin;
          }
          j = paramInt3;
          if (localLinearLayoutCompat.hasDividerBeforeChildAt(i5)) {
            j = paramInt3 + mDividerWidth;
          }
          paramInt3 = j + leftMargin;
          setChildFrame(localView, paramInt3 + getChildrenSkipCount(), paramInt1, i6, i7);
          paramInt1 = paramInt3 + (i6 + rightMargin + getNextLocationOffset());
          j = paramInt2 + measureNullChild();
        }
      }
      paramInt2 = j + 1;
    }
  }
  
  public void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = mGravity;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16)
    {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - mTotalLength;
      }
    }
    else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - mTotalLength) / 2;
    }
    paramInt2 = 0;
    for (;;)
    {
      LinearLayoutCompat localLinearLayoutCompat = this;
      if (paramInt2 >= n) {
        break;
      }
      View localView = localLinearLayoutCompat.getVirtualChildAt(paramInt2);
      if (localView == null)
      {
        paramInt3 = paramInt1 + hasDividerBeforeChildAt();
        paramInt4 = paramInt2;
      }
      else
      {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (localView.getVisibility() != 8)
        {
          int i3 = localView.getMeasuredWidth();
          int i2 = localView.getMeasuredHeight();
          i0.a localA = (i0.a)localView.getLayoutParams();
          paramInt4 = gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0) {
            paramInt3 = i1 & 0x800007;
          }
          paramInt3 = GravityCompat.getAbsoluteGravity(paramInt3, ViewCompat.getLayoutDirection(this)) & 0x7;
          if (paramInt3 != 1)
          {
            if (paramInt3 != 5) {
              paramInt3 = leftMargin + i;
            } else {
              paramInt3 = j - k - i3 - rightMargin;
            }
          }
          else {
            paramInt3 = (j - i - m - i3) / 2 + i + leftMargin - rightMargin;
          }
          paramInt4 = paramInt1;
          if (localLinearLayoutCompat.hasDividerBeforeChildAt(paramInt2)) {
            paramInt4 = paramInt1 + mDividerHeight;
          }
          paramInt1 = paramInt4 + topMargin;
          setChildFrame(localView, paramInt3, paramInt1 + getChildrenSkipCount(), i3, i2);
          paramInt3 = bottomMargin;
          i3 = getNextLocationOffset();
          paramInt4 = paramInt2 + measureNullChild();
          paramInt3 = paramInt1 + (i2 + paramInt3 + i3);
        }
      }
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    }
  }
  
  public void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void measureHorizontal(int paramInt1, int paramInt2)
  {
    mTotalLength = 0;
    int m = 0;
    int i12 = getVirtualChildCount();
    int i9 = View.MeasureSpec.getMode(paramInt1);
    int i13 = View.MeasureSpec.getMode(paramInt2);
    if ((mMaxAscent == null) || (mMaxDescent == null))
    {
      mMaxAscent = new int[4];
      mMaxDescent = new int[4];
    }
    int[] arrayOfInt1 = mMaxAscent;
    int[] arrayOfInt2 = mMaxDescent;
    arrayOfInt1[3] = -1;
    arrayOfInt1[2] = -1;
    arrayOfInt1[1] = -1;
    arrayOfInt1[0] = -1;
    arrayOfInt2[3] = -1;
    arrayOfInt2[2] = -1;
    arrayOfInt2[1] = -1;
    arrayOfInt2[0] = -1;
    boolean bool1 = mBaselineAligned;
    int n = 0;
    boolean bool2 = mUseLargestChild;
    int i2 = 0;
    int i6;
    if (i9 == 1073741824) {
      i6 = 1;
    } else {
      i6 = 0;
    }
    int i1 = 0;
    int i = 0;
    int i3 = 0;
    float f1 = 0.0F;
    int j = 1;
    int k = 0;
    int i8;
    int i7;
    Object localObject1;
    float f2;
    Object localObject2;
    for (int i4 = 0; i < i12; i4 = i7)
    {
      View localView = getVirtualChildAt(i);
      if (localView == null)
      {
        mTotalLength += hasDividerBeforeChildAt();
        i8 = k;
        i7 = i4;
      }
      else
      {
        i7 = i4;
        if (localView.getVisibility() == 8)
        {
          i += measureNullChild();
          i8 = k;
          i7 = i4;
        }
        else
        {
          if (hasDividerBeforeChildAt(i)) {
            mTotalLength += mDividerWidth;
          }
          localObject1 = (i0.a)localView.getLayoutParams();
          f2 = weight;
          f1 += f2;
          if ((i9 == 1073741824) && (width == 0) && (f2 > 0.0F))
          {
            if (i6 != 0)
            {
              mTotalLength += leftMargin + rightMargin;
            }
            else
            {
              i4 = mTotalLength;
              mTotalLength = Math.max(i4, leftMargin + i4 + rightMargin);
            }
            if (bool1)
            {
              i4 = View.MeasureSpec.makeMeasureSpec(0, 0);
              localView.measure(i4, i4);
              i4 = i1;
              i5 = i2;
            }
            else
            {
              i5 = 1;
              i4 = i1;
            }
          }
          else
          {
            if ((width == 0) && (weight > 0.0F))
            {
              width = -2;
              i4 = 0;
            }
            else
            {
              i4 = Integer.MIN_VALUE;
            }
            if (f1 == 0.0F) {
              i5 = mTotalLength;
            } else {
              i5 = 0;
            }
            measureChildBeforeLayout(localView, paramInt1, i5, paramInt2, 0);
            if (i4 != Integer.MIN_VALUE) {
              width = i4;
            }
            localObject2 = localObject1;
            i8 = localView.getMeasuredWidth();
            if (i6 != 0)
            {
              mTotalLength += leftMargin + i8 + rightMargin + getNextLocationOffset();
            }
            else
            {
              i4 = mTotalLength;
              mTotalLength = Math.max(i4, i4 + i8 + leftMargin + rightMargin + getNextLocationOffset());
            }
            i4 = i1;
            i5 = i2;
            if (bool2)
            {
              i4 = Math.max(i8, i1);
              i5 = i2;
            }
          }
          i1 = m;
          i8 = 0;
          m = n;
          i2 = i8;
          if (i13 != 1073741824)
          {
            m = n;
            i2 = i8;
            if (height == -1)
            {
              m = 1;
              i2 = 1;
            }
          }
          n = topMargin + bottomMargin;
          i8 = localView.getMeasuredHeight() + n;
          int i10 = View.combineMeasuredStates(k, localView.getMeasuredState());
          if (bool1)
          {
            int i14 = localView.getBaseline();
            if (i14 != -1)
            {
              int i11 = gravity;
              k = i11;
              if (i11 < 0) {
                k = mGravity;
              }
              k = ((k & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
              arrayOfInt1[k] = Math.max(arrayOfInt1[k], i14);
              arrayOfInt2[k] = Math.max(arrayOfInt2[k], i8 - i14);
            }
            else {}
          }
          i3 = Math.max(i3, i8);
          if ((j != 0) && (height == -1)) {
            j = 1;
          } else {
            j = 0;
          }
          if (weight > 0.0F)
          {
            if (i2 != 0) {
              i8 = n;
            }
            n = Math.max(i7, i8);
            k = i1;
          }
          else
          {
            if (i2 != 0) {
              i8 = n;
            }
            k = Math.max(i1, i8);
            n = i7;
          }
          i += measureNullChild();
          i8 = i10;
          i7 = n;
          i2 = i5;
          n = m;
          i1 = i4;
          m = k;
        }
      }
      i += 1;
      k = i8;
    }
    if ((mTotalLength > 0) && (hasDividerBeforeChildAt(i12))) {
      mTotalLength += mDividerWidth;
    }
    if ((arrayOfInt1[1] == -1) && (arrayOfInt1[0] == -1) && (arrayOfInt1[2] == -1) && (arrayOfInt1[3] == -1)) {
      i = i3;
    } else {
      i = Math.max(i3, Math.max(arrayOfInt1[3], Math.max(arrayOfInt1[0], Math.max(arrayOfInt1[1], arrayOfInt1[2]))) + Math.max(arrayOfInt2[3], Math.max(arrayOfInt2[0], Math.max(arrayOfInt2[1], arrayOfInt2[2]))));
    }
    if (bool2)
    {
      if ((i9 != Integer.MIN_VALUE) && (i9 != 0)) {
        break label1231;
      }
      mTotalLength = 0;
      i3 = 0;
      while (i3 < i12)
      {
        localObject1 = getVirtualChildAt(i3);
        if (localObject1 == null)
        {
          mTotalLength += hasDividerBeforeChildAt();
        }
        else if (((View)localObject1).getVisibility() == 8)
        {
          i3 += measureNullChild();
        }
        else
        {
          localObject1 = (i0.a)((View)localObject1).getLayoutParams();
          if (i6 != 0)
          {
            mTotalLength += i1 + leftMargin + rightMargin + getNextLocationOffset();
          }
          else
          {
            i5 = mTotalLength;
            mTotalLength = Math.max(i5, i5 + i1 + leftMargin + rightMargin + getNextLocationOffset());
          }
        }
        i3 += 1;
      }
    }
    label1231:
    i3 = i9;
    mTotalLength += getPaddingLeft() + getPaddingRight();
    i9 = View.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumWidth()), paramInt1, 0);
    int i5 = (i9 & 0xFFFFFF) - mTotalLength;
    if ((i2 == 0) && ((i5 == 0) || (f1 <= 0.0F)))
    {
      i2 = Math.max(m, i4);
      if ((bool2) && (i3 != 1073741824))
      {
        m = 0;
        while (m < i12)
        {
          localObject1 = getVirtualChildAt(m);
          if ((localObject1 != null) && (((View)localObject1).getVisibility() != 8)) {
            if (getLayoutParamsweight > 0.0F) {
              ((View)localObject1).measure(View.MeasureSpec.makeMeasureSpec(i1, 1073741824), View.MeasureSpec.makeMeasureSpec(((View)localObject1).getMeasuredHeight(), 1073741824));
            } else {}
          }
          m += 1;
        }
      }
      m = i2;
    }
    else
    {
      f2 = mWeightSum;
      if (f2 > 0.0F) {
        f1 = f2;
      }
      arrayOfInt1[3] = -1;
      arrayOfInt1[2] = -1;
      arrayOfInt1[1] = -1;
      arrayOfInt1[0] = -1;
      arrayOfInt2[3] = -1;
      arrayOfInt2[2] = -1;
      arrayOfInt2[1] = -1;
      arrayOfInt2[0] = -1;
      i2 = -1;
      mTotalLength = 0;
      i4 = 0;
      i1 = k;
      i = i5;
      k = j;
      j = i1;
      i1 = i2;
      while (i4 < i12)
      {
        localObject1 = getVirtualChildAt(i4);
        if ((localObject1 != null) && (((View)localObject1).getVisibility() != 8))
        {
          localObject2 = (i0.a)((View)localObject1).getLayoutParams();
          f2 = weight;
          if (f2 > 0.0F)
          {
            i5 = (int)(i * f2 / f1);
            f1 -= f2;
            i8 = ViewGroup.getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom() + topMargin + bottomMargin, height);
            if ((width == 0) && (i3 == 1073741824))
            {
              if (i5 > 0) {
                i2 = i5;
              } else {
                i2 = 0;
              }
              ((View)localObject1).measure(View.MeasureSpec.makeMeasureSpec(i2, 1073741824), i8);
            }
            else
            {
              i7 = ((View)localObject1).getMeasuredWidth() + i5;
              i2 = i7;
              if (i7 < 0) {
                i2 = 0;
              }
              ((View)localObject1).measure(View.MeasureSpec.makeMeasureSpec(i2, 1073741824), i8);
            }
            j = View.combineMeasuredStates(j, ((View)localObject1).getMeasuredState() & 0xFF000000);
            i -= i5;
          }
          if (i6 != 0)
          {
            mTotalLength += ((View)localObject1).getMeasuredWidth() + leftMargin + rightMargin + getNextLocationOffset();
          }
          else
          {
            i2 = mTotalLength;
            mTotalLength = Math.max(i2, ((View)localObject1).getMeasuredWidth() + i2 + leftMargin + rightMargin + getNextLocationOffset());
          }
          if ((i13 != 1073741824) && (height == -1)) {
            i2 = 1;
          } else {
            i2 = 0;
          }
          i8 = topMargin + bottomMargin;
          i7 = ((View)localObject1).getMeasuredHeight() + i8;
          i5 = Math.max(i1, i7);
          if (i2 != 0) {
            i1 = i8;
          } else {
            i1 = i7;
          }
          i1 = Math.max(m, i1);
          if ((k != 0) && (height == -1)) {
            k = 1;
          } else {
            k = 0;
          }
          if (bool1)
          {
            i8 = ((View)localObject1).getBaseline();
            if (i8 != -1)
            {
              i2 = gravity;
              m = i2;
              if (i2 < 0) {
                m = mGravity;
              }
              m = ((m & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
              arrayOfInt1[m] = Math.max(arrayOfInt1[m], i8);
              arrayOfInt2[m] = Math.max(arrayOfInt2[m], i7 - i8);
            }
            else {}
          }
          m = i1;
          i1 = i5;
        }
        i4 += 1;
      }
      mTotalLength += getPaddingLeft() + getPaddingRight();
      if ((arrayOfInt1[1] == -1) && (arrayOfInt1[0] == -1) && (arrayOfInt1[2] == -1))
      {
        i = i1;
        if (arrayOfInt1[3] == -1) {}
      }
      else
      {
        i = Math.max(i1, Math.max(arrayOfInt1[3], Math.max(arrayOfInt1[0], Math.max(arrayOfInt1[1], arrayOfInt1[2]))) + Math.max(arrayOfInt2[3], Math.max(arrayOfInt2[0], Math.max(arrayOfInt2[1], arrayOfInt2[2]))));
      }
      i1 = j;
      j = k;
      k = i1;
    }
    i1 = i;
    if (j == 0)
    {
      i1 = i;
      if (i13 != 1073741824) {
        i1 = m;
      }
    }
    setMeasuredDimension(0xFF000000 & k | i9, View.resolveSizeAndState(Math.max(i1 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), paramInt2, k << 16));
    if (n != 0) {
      forceUniformHeight(i12, paramInt1);
    }
  }
  
  public int measureNullChild()
  {
    return 0;
  }
  
  public void measureVertical(int paramInt1, int paramInt2)
  {
    mTotalLength = 0;
    int i3 = getVirtualChildCount();
    int i11 = View.MeasureSpec.getMode(paramInt1);
    int i9 = View.MeasureSpec.getMode(paramInt2);
    int i12 = mBaselineAlignedChildIndex;
    boolean bool = mUseLargestChild;
    int i5 = 0;
    int i4 = 0;
    int m = 0;
    float f1 = 0.0F;
    int k = 0;
    int i = 0;
    int i1 = 0;
    int i2 = 0;
    int n = 0;
    int j = 1;
    Object localObject2;
    Object localObject1;
    float f2;
    int i8;
    while (i < i3)
    {
      localObject2 = getVirtualChildAt(i);
      if (localObject2 == null)
      {
        mTotalLength += hasDividerBeforeChildAt();
        i6 = n;
      }
      else if (((View)localObject2).getVisibility() == 8)
      {
        i += measureNullChild();
        i6 = n;
      }
      else
      {
        if (hasDividerBeforeChildAt(i)) {
          mTotalLength += mDividerHeight;
        }
        localObject1 = (i0.a)((View)localObject2).getLayoutParams();
        f2 = weight;
        f1 += f2;
        if ((i9 == 1073741824) && (height == 0) && (f2 > 0.0F))
        {
          i5 = mTotalLength;
          mTotalLength = Math.max(i5, topMargin + i5 + bottomMargin);
          i6 = 1;
          i5 = n;
          n = i6;
          i6 = i;
          i = i5;
        }
        else
        {
          if ((height == 0) && (weight > 0.0F))
          {
            height = -2;
            i7 = 0;
          }
          else
          {
            i7 = Integer.MIN_VALUE;
          }
          if (f1 == 0.0F) {
            i8 = mTotalLength;
          } else {
            i8 = 0;
          }
          i6 = i;
          measureChildBeforeLayout((View)localObject2, paramInt1, 0, paramInt2, i8);
          if (i7 != Integer.MIN_VALUE) {
            height = i7;
          }
          i = ((View)localObject2).getMeasuredHeight();
          i7 = mTotalLength;
          mTotalLength = Math.max(i7, i7 + i + topMargin + bottomMargin + getNextLocationOffset());
          if (bool)
          {
            i = Math.max(i, n);
            n = i5;
          }
          else
          {
            i = n;
            n = i5;
          }
        }
        if ((i12 >= 0) && (i12 == i6 + 1)) {
          mBaselineChildTop = mTotalLength;
        }
        if ((i6 < i12) && (weight > 0.0F)) {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        }
        i8 = 0;
        i5 = i1;
        i7 = i8;
        if (i11 != 1073741824)
        {
          i5 = i1;
          i7 = i8;
          if (width == -1)
          {
            i5 = 1;
            i7 = 1;
          }
        }
        i1 = leftMargin + rightMargin;
        i8 = ((View)localObject2).getMeasuredWidth() + i1;
        int i10 = Math.max(m, i8);
        i4 = View.combineMeasuredStates(i4, ((View)localObject2).getMeasuredState());
        if ((j != 0) && (width == -1)) {
          j = 1;
        } else {
          j = 0;
        }
        if (weight > 0.0F)
        {
          if (i7 == 0) {
            i1 = i8;
          }
          m = Math.max(i2, i1);
        }
        else
        {
          m = i2;
          if (i7 == 0) {
            i1 = i8;
          }
          k = Math.max(k, i1);
        }
        i1 = measureNullChild();
        i7 = i6 + i1;
        i6 = i;
        i2 = m;
        i1 = i5;
        i = i7;
        m = i10;
        i5 = n;
      }
      i += 1;
      n = i6;
    }
    i = i4;
    if ((mTotalLength > 0) && (hasDividerBeforeChildAt(i3))) {
      mTotalLength += mDividerHeight;
    }
    int i6 = i3;
    if ((bool) && ((i9 == Integer.MIN_VALUE) || (i9 == 0)))
    {
      mTotalLength = 0;
      i3 = 0;
      while (i3 < i6)
      {
        localObject1 = getVirtualChildAt(i3);
        if (localObject1 == null)
        {
          mTotalLength += hasDividerBeforeChildAt();
        }
        else if (((View)localObject1).getVisibility() == 8)
        {
          i3 += measureNullChild();
        }
        else
        {
          localObject1 = (i0.a)((View)localObject1).getLayoutParams();
          i4 = mTotalLength;
          mTotalLength = Math.max(i4, i4 + n + topMargin + bottomMargin + getNextLocationOffset());
        }
        i3 += 1;
      }
    }
    mTotalLength += getPaddingTop() + getPaddingBottom();
    int i7 = View.resolveSizeAndState(Math.max(mTotalLength, getSuggestedMinimumHeight()), paramInt2, 0);
    i3 = (i7 & 0xFFFFFF) - mTotalLength;
    if ((i5 == 0) && ((i3 == 0) || (f1 <= 0.0F)))
    {
      i3 = Math.max(k, i2);
      i2 = i3;
      k = i3;
      if (bool) {
        if (i9 != 1073741824)
        {
          i3 = 0;
          k = i2;
          i2 = i3;
          while (i2 < i6)
          {
            localObject1 = getVirtualChildAt(i2);
            if ((localObject1 != null) && (((View)localObject1).getVisibility() != 8)) {
              if (getLayoutParamsweight > 0.0F) {
                ((View)localObject1).measure(View.MeasureSpec.makeMeasureSpec(((View)localObject1).getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824));
              } else {}
            }
            i2 += 1;
          }
        }
        else
        {
          k = i3;
        }
      }
    }
    else
    {
      f2 = mWeightSum;
      if (f2 > 0.0F) {
        f1 = f2;
      }
      mTotalLength = 0;
      i4 = 0;
      for (i2 = i3; i4 < i6; i2 = n)
      {
        localObject1 = getVirtualChildAt(i4);
        if (((View)localObject1).getVisibility() == 8)
        {
          n = i2;
        }
        else
        {
          localObject2 = (i0.a)((View)localObject1).getLayoutParams();
          float f3 = weight;
          n = i2;
          f2 = f1;
          i3 = i;
          if (f3 > 0.0F)
          {
            i3 = (int)(i2 * f3 / f1);
            f2 = f1 - f3;
            i8 = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + leftMargin + rightMargin, width);
            if ((height == 0) && (i9 == 1073741824))
            {
              if (i3 > 0) {
                n = i3;
              } else {
                n = 0;
              }
              ((View)localObject1).measure(i8, View.MeasureSpec.makeMeasureSpec(n, 1073741824));
            }
            else
            {
              i5 = ((View)localObject1).getMeasuredHeight() + i3;
              n = i5;
              if (i5 < 0) {
                n = 0;
              }
              ((View)localObject1).measure(i8, View.MeasureSpec.makeMeasureSpec(n, 1073741824));
            }
            i = View.combineMeasuredStates(i, ((View)localObject1).getMeasuredState() & 0xFF00);
            n = i2 - i3;
            i3 = i;
          }
          i2 = leftMargin + rightMargin;
          i5 = ((View)localObject1).getMeasuredWidth() + i2;
          m = Math.max(m, i5);
          if ((i11 != 1073741824) && (width == -1)) {
            i = 1;
          } else {
            i = 0;
          }
          if (i != 0) {
            i = i2;
          } else {
            i = i5;
          }
          k = Math.max(k, i);
          if ((j != 0) && (width == -1)) {
            i = 1;
          } else {
            i = 0;
          }
          j = mTotalLength;
          mTotalLength = Math.max(j, j + ((View)localObject1).getMeasuredHeight() + topMargin + bottomMargin + getNextLocationOffset());
          j = i;
          i = i3;
          f1 = f2;
        }
        i4 += 1;
      }
      mTotalLength += getPaddingTop() + getPaddingBottom();
    }
    n = m;
    if (j == 0)
    {
      n = m;
      if (i11 != 1073741824) {
        n = k;
      }
    }
    setMeasuredDimension(View.resolveSizeAndState(Math.max(n + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), paramInt1, i), i7);
    if (i1 != 0) {
      forceUniformWidth(i6, paramInt2);
    }
  }
  
  public i0.a onCreateView(AttributeSet paramAttributeSet)
  {
    return new i0.a(getContext(), paramAttributeSet);
  }
  
  public void onDraw(Canvas paramCanvas)
  {
    if (mDivider == null) {
      return;
    }
    if (mOrientation == 1)
    {
      drawDividersVertical(paramCanvas);
      return;
    }
    drawDividersHorizontal(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (mOrientation == 1)
    {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    if (mOrientation == 1)
    {
      measureVertical(paramInt1, paramInt2);
      return;
    }
    measureHorizontal(paramInt1, paramInt2);
  }
  
  public void setBaselineAligned(boolean paramBoolean)
  {
    mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < getChildCount()))
    {
      mBaselineAlignedChildIndex = paramInt;
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("base aligned child index out of range (0, ");
    localStringBuilder.append(getChildCount());
    localStringBuilder.append(")");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public final void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.layout(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }
  
  public void setDividerDrawable(Drawable paramDrawable)
  {
    if (paramDrawable == mDivider) {
      return;
    }
    mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null)
    {
      mDividerWidth = paramDrawable.getIntrinsicWidth();
      mDividerHeight = paramDrawable.getIntrinsicHeight();
    }
    else
    {
      mDividerWidth = 0;
      mDividerHeight = 0;
    }
    if (paramDrawable == null) {
      bool = true;
    }
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt)
  {
    mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt)
  {
    if (mGravity != paramInt)
    {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0) {
        i = paramInt | 0x800003;
      }
      paramInt = i;
      if ((i & 0x70) == 0) {
        paramInt = i | 0x30;
      }
      mGravity = paramInt;
      requestLayout();
    }
  }
  
  public void setHorizontalGravity(int paramInt)
  {
    paramInt &= 0x800007;
    int i = mGravity;
    if ((0x800007 & i) != paramInt)
    {
      mGravity = (0xFF7FFFF8 & i | paramInt);
      requestLayout();
    }
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean)
  {
    mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt)
  {
    if (mOrientation != paramInt)
    {
      mOrientation = paramInt;
      requestLayout();
    }
  }
  
  public void setShowDividers(int paramInt)
  {
    if (paramInt != mShowDividers) {
      requestLayout();
    }
    mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt)
  {
    paramInt &= 0x70;
    int i = mGravity;
    if ((i & 0x70) != paramInt)
    {
      mGravity = (i & 0xFFFFFF8F | paramInt);
      requestLayout();
    }
  }
  
  public void setWeightSum(float paramFloat)
  {
    mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return false;
  }
}
