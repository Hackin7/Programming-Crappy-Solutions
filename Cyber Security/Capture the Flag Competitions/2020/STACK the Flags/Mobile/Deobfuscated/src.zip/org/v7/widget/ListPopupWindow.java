package org.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import java.lang.reflect.Method;
import org.core.view.ViewCompat;
import org.v7.R.styleable;

public class ListPopupWindow
  implements org.v7.view.menu.ListPopupWindow
{
  public static Method sClipToWindowEnabledMethod;
  public static Method sComputeFitSystemWindowsMethod;
  public static Method sGetMaxAvailableHeightMethod;
  public boolean a;
  public boolean h;
  public ListAdapter mAdapter;
  public Rect mAnchorView;
  public Context mContext;
  public boolean mDropDownAlwaysVisible = false;
  public View mDropDownAnchorView;
  public int mDropDownGravity = 0;
  public int mDropDownHeight = -2;
  public int mDropDownHorizontalOffset;
  public ListViewCompat mDropDownList;
  public int mDropDownVerticalOffset;
  public boolean mDropDownVerticalOffsetSet;
  public int mDropDownWidth = -2;
  public int mDropDownWindowLayoutType = 1002;
  public boolean mForceIgnoreOutsideTouch = false;
  public final Handler mHandler;
  public final j0.c mHideSelector = new j0.c(this);
  public AdapterView.OnItemClickListener mItemClickListener;
  public int mListItemExpandMaximum = Integer.MAX_VALUE;
  public boolean mModal;
  public DataSetObserver mObserver;
  public PopupWindow mPopup;
  public int mPromptPosition = 0;
  public final j0.g mRunnable = new j0.g(this);
  public final j0.e mScrollListener = new j0.e(this);
  public final Rect mTempRect = new Rect();
  public final j0.f mTouchInterceptor = new j0.f(this);
  
  static
  {
    if (Build.VERSION.SDK_INT <= 28)
    {
      Object localObject1 = Boolean.TYPE;
      try
      {
        localObject1 = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { localObject1 });
        sClipToWindowEnabledMethod = (Method)localObject1;
      }
      catch (NoSuchMethodException localNoSuchMethodException1)
      {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      }
      try
      {
        Method localMethod = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
        sGetMaxAvailableHeightMethod = localMethod;
      }
      catch (NoSuchMethodException localNoSuchMethodException2)
      {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      }
    }
    if (Build.VERSION.SDK_INT <= 23)
    {
      Object localObject2 = Integer.TYPE;
      Class localClass = Boolean.TYPE;
      try
      {
        localObject2 = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, localObject2, localClass });
        sComputeFitSystemWindowsMethod = (Method)localObject2;
        return;
      }
      catch (NoSuchMethodException localNoSuchMethodException3)
      {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }
    }
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    mContext = paramContext;
    mHandler = new Handler(paramContext.getMainLooper());
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ListPopupWindow, paramInt1, paramInt2);
    mDropDownHorizontalOffset = localTypedArray.getDimensionPixelOffset(R.styleable.ListPopupWindow_android_dropDownHorizontalOffset, 0);
    int i = localTypedArray.getDimensionPixelOffset(R.styleable.ListPopupWindow_android_dropDownVerticalOffset, 0);
    mDropDownVerticalOffset = i;
    if (i != 0) {
      mDropDownVerticalOffsetSet = true;
    }
    localTypedArray.recycle();
    paramContext = new PopupWindowCompat(paramContext, paramAttributeSet, paramInt1, paramInt2);
    mPopup = paramContext;
    paramContext.setInputMethodMode(1);
  }
  
  public void b(boolean paramBoolean)
  {
    h = true;
    a = paramBoolean;
  }
  
  public final int buildDropDown()
  {
    int k = 0;
    Object localObject = mDropDownList;
    boolean bool = false;
    if (localObject == null)
    {
      localObject = mContext;
      new j0.a(this);
      localObject = e((Context)localObject, mModal ^ true);
      mDropDownList = ((ListViewCompat)localObject);
      ((ListView)localObject).setAdapter(mAdapter);
      mDropDownList.setOnItemClickListener(mItemClickListener);
      mDropDownList.setFocusable(true);
      mDropDownList.setFocusableInTouchMode(true);
      mDropDownList.setOnItemSelectedListener(new j0.b(this));
      mDropDownList.setOnScrollListener(mScrollListener);
      localObject = mDropDownList;
      mPopup.setContentView((View)localObject);
    }
    else
    {
      localObject = (ViewGroup)mPopup.getContentView();
    }
    localObject = mPopup.getBackground();
    int i;
    int j;
    if (localObject != null)
    {
      ((Drawable)localObject).getPadding(mTempRect);
      localObject = mTempRect;
      m = top;
      i = bottom + m;
      j = i;
      if (!mDropDownVerticalOffsetSet)
      {
        mDropDownVerticalOffset = (-m);
        j = i;
      }
    }
    else
    {
      mTempRect.setEmpty();
      j = 0;
    }
    if (mPopup.getInputMethodMode() == 2) {
      bool = true;
    }
    int m = getMaxAvailableHeight(getAnchorView(), mDropDownVerticalOffset, bool);
    if ((!mDropDownAlwaysVisible) && (mDropDownHeight != -1))
    {
      i = mDropDownWidth;
      if (i != -2)
      {
        if (i != -1)
        {
          i = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
        }
        else
        {
          i = mContext.getResources().getDisplayMetrics().widthPixels;
          localObject = mTempRect;
          i = View.MeasureSpec.makeMeasureSpec(i - (left + right), 1073741824);
        }
      }
      else
      {
        i = mContext.getResources().getDisplayMetrics().widthPixels;
        localObject = mTempRect;
        i = View.MeasureSpec.makeMeasureSpec(i - (left + right), Integer.MIN_VALUE);
      }
      m = mDropDownList.measureHeightOfChildrenCompat(i, m - 0, -1);
      i = k;
      if (m > 0) {
        i = 0 + (j + (mDropDownList.getPaddingTop() + mDropDownList.getPaddingBottom()));
      }
      return m + i;
    }
    return m + j;
  }
  
  public ListView c()
  {
    return mDropDownList;
  }
  
  public void clearListSelection()
  {
    ListViewCompat localListViewCompat = mDropDownList;
    if (localListViewCompat != null)
    {
      localListViewCompat.setListSelectionHidden(true);
      localListViewCompat.requestLayout();
    }
  }
  
  public void dismiss()
  {
    mPopup.dismiss();
    removePromptView();
    mPopup.setContentView(null);
    mDropDownList = null;
    mHandler.removeCallbacks(mRunnable);
  }
  
  public void dismiss(int paramInt)
  {
    mDropDownGravity = paramInt;
  }
  
  public ListViewCompat e(Context paramContext, boolean paramBoolean)
  {
    return new ListViewCompat(paramContext, paramBoolean);
  }
  
  public View getAnchorView()
  {
    return mDropDownAnchorView;
  }
  
  public Drawable getBackground()
  {
    return mPopup.getBackground();
  }
  
  public int getHorizontalOffset()
  {
    return mDropDownHorizontalOffset;
  }
  
  public final int getMaxAvailableHeight(View paramView, int paramInt, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT <= 23)
    {
      Object localObject = sComputeFitSystemWindowsMethod;
      if (localObject != null)
      {
        PopupWindow localPopupWindow = mPopup;
        try
        {
          localObject = ((Method)localObject).invoke(localPopupWindow, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
          localObject = (Integer)localObject;
          int i = ((Integer)localObject).intValue();
          return i;
        }
        catch (Exception localException)
        {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }
      }
      return mPopup.getMaxAvailableHeight(paramView, paramInt);
    }
    return mPopup.getMaxAvailableHeight(paramView, paramInt, paramBoolean);
  }
  
  public int getVerticalOffset()
  {
    if (!mDropDownVerticalOffsetSet) {
      return 0;
    }
    return mDropDownVerticalOffset;
  }
  
  public int getWidth()
  {
    return mDropDownWidth;
  }
  
  public boolean isInputMethodNotNeeded()
  {
    return mPopup.getInputMethodMode() == 2;
  }
  
  public boolean isModal()
  {
    return mModal;
  }
  
  public boolean isShowing()
  {
    return mPopup.isShowing();
  }
  
  public final void removePromptView() {}
  
  public void setAdapter(View paramView)
  {
    mDropDownAnchorView = paramView;
  }
  
  public void setAdapter(ListAdapter paramListAdapter)
  {
    DataSetObserver localDataSetObserver = mObserver;
    if (localDataSetObserver == null)
    {
      mObserver = new j0.d(this);
    }
    else
    {
      ListAdapter localListAdapter = mAdapter;
      if (localListAdapter != null) {
        localListAdapter.unregisterDataSetObserver(localDataSetObserver);
      }
    }
    mAdapter = paramListAdapter;
    if (paramListAdapter != null) {
      paramListAdapter.registerDataSetObserver(mObserver);
    }
    paramListAdapter = mDropDownList;
    if (paramListAdapter != null) {
      paramListAdapter.setAdapter(mAdapter);
    }
  }
  
  public void setAnimationStyle(int paramInt)
  {
    mPopup.setAnimationStyle(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    mPopup.setBackgroundDrawable(paramDrawable);
  }
  
  public void setContentWidth(int paramInt)
  {
    Object localObject = mPopup.getBackground();
    if (localObject != null)
    {
      ((Drawable)localObject).getPadding(mTempRect);
      localObject = mTempRect;
      mDropDownWidth = (left + right + paramInt);
      return;
    }
    setWidth(paramInt);
  }
  
  public void setHorizontalOffset(int paramInt)
  {
    mDropDownHorizontalOffset = paramInt;
  }
  
  public void setModal(boolean paramBoolean)
  {
    mModal = paramBoolean;
    mPopup.setFocusable(paramBoolean);
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    mPopup.setOnDismissListener(paramOnDismissListener);
  }
  
  public void setOnItemClickListener(AdapterView.OnItemClickListener paramOnItemClickListener)
  {
    mItemClickListener = paramOnItemClickListener;
  }
  
  public final void setPopupClipToScreenEnabled(boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT <= 28)
    {
      Method localMethod = sClipToWindowEnabledMethod;
      if (localMethod == null) {
        return;
      }
      PopupWindow localPopupWindow = mPopup;
      try
      {
        localMethod.invoke(localPopupWindow, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      }
      catch (Exception localException)
      {
        Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
        return;
      }
    }
    mPopup.setIsClippedToScreen(paramBoolean);
  }
  
  public void setPromptPosition(int paramInt)
  {
    mPromptPosition = paramInt;
  }
  
  public void setSelection(int paramInt)
  {
    ListViewCompat localListViewCompat = mDropDownList;
    if ((isShowing()) && (localListViewCompat != null))
    {
      localListViewCompat.setListSelectionHidden(false);
      localListViewCompat.setSelection(paramInt);
      if (localListViewCompat.getChoiceMode() != 0) {
        localListViewCompat.setItemChecked(paramInt, true);
      }
    }
  }
  
  public void setVerticalOffset(int paramInt)
  {
    mDropDownVerticalOffset = paramInt;
    mDropDownVerticalOffsetSet = true;
  }
  
  public void setWidth(int paramInt)
  {
    mDropDownWidth = paramInt;
  }
  
  public void show()
  {
    int j = buildDropDown();
    boolean bool2 = isInputMethodNotNeeded();
    org.core.widget.PopupWindowCompat.setWindowLayoutType(mPopup, mDropDownWindowLayoutType);
    boolean bool3 = mPopup.isShowing();
    boolean bool1 = true;
    Object localObject2;
    if (bool3)
    {
      if (!ViewCompat.isAttachedToWindow(getAnchorView())) {
        return;
      }
      i = mDropDownWidth;
      if (i == -1) {
        i = -1;
      } else if (i == -2) {
        i = getAnchorView().getWidth();
      } else {
        i = mDropDownWidth;
      }
      k = mDropDownHeight;
      if (k == -1)
      {
        if (!bool2) {
          j = -1;
        }
        if (bool2)
        {
          localObject1 = mPopup;
          if (mDropDownWidth == -1) {
            k = -1;
          } else {
            k = 0;
          }
          ((PopupWindow)localObject1).setWidth(k);
          mPopup.setHeight(0);
        }
        else
        {
          localObject1 = mPopup;
          if (mDropDownWidth == -1) {
            k = -1;
          } else {
            k = 0;
          }
          ((PopupWindow)localObject1).setWidth(k);
          mPopup.setHeight(-1);
        }
      }
      else if (k != -2)
      {
        j = mDropDownHeight;
      }
      localObject1 = mPopup;
      if ((mForceIgnoreOutsideTouch) || (mDropDownAlwaysVisible)) {
        bool1 = false;
      }
      ((PopupWindow)localObject1).setOutsideTouchable(bool1);
      localObject1 = mPopup;
      localObject2 = getAnchorView();
      int m = mDropDownHorizontalOffset;
      int n = mDropDownVerticalOffset;
      k = i;
      if (i < 0) {
        k = -1;
      }
      i = j;
      if (j < 0) {
        i = -1;
      }
      ((PopupWindow)localObject1).update((View)localObject2, m, n, k, i);
      return;
    }
    int i = mDropDownWidth;
    if (i == -1) {
      i = -1;
    } else if (i == -2) {
      i = getAnchorView().getWidth();
    } else {
      i = mDropDownWidth;
    }
    int k = mDropDownHeight;
    if (k == -1) {
      j = -1;
    } else if (k != -2) {
      j = mDropDownHeight;
    }
    mPopup.setWidth(i);
    mPopup.setHeight(j);
    setPopupClipToScreenEnabled(true);
    Object localObject1 = mPopup;
    if ((!mForceIgnoreOutsideTouch) && (!mDropDownAlwaysVisible)) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    ((PopupWindow)localObject1).setOutsideTouchable(bool1);
    mPopup.setTouchInterceptor(mTouchInterceptor);
    if (h) {
      org.core.widget.PopupWindowCompat.init(mPopup, a);
    }
    if (Build.VERSION.SDK_INT <= 28)
    {
      localObject1 = sGetMaxAvailableHeightMethod;
      if (localObject1 != null)
      {
        localObject2 = mPopup;
        Rect localRect = mAnchorView;
        try
        {
          ((Method)localObject1).invoke(localObject2, new Object[] { localRect });
        }
        catch (Exception localException)
        {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", localException);
        }
      }
    }
    else
    {
      mPopup.setEpicenterBounds(mAnchorView);
    }
    org.core.widget.PopupWindowCompat.showAsDropDown(mPopup, getAnchorView(), mDropDownHorizontalOffset, mDropDownVerticalOffset, mDropDownGravity);
    mDropDownList.setSelection(-1);
    if ((!mModal) || (mDropDownList.isInTouchMode())) {
      clearListSelection();
    }
    if (!mModal) {
      mHandler.post(mHideSelector);
    }
  }
  
  public void show(int paramInt)
  {
    mPopup.setInputMethodMode(paramInt);
  }
  
  public void show(Rect paramRect)
  {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    }
    mAnchorView = paramRect;
  }
}
