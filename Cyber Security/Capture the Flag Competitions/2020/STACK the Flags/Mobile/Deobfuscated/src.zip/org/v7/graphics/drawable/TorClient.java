package org.v7.graphics.drawable;

import android.graphics.drawable.Animatable;

public class TorClient
  extends Animator
{
  public final Animatable directoryDownloader;
  
  public TorClient(Animatable paramAnimatable)
  {
    super(null);
    directoryDownloader = paramAnimatable;
  }
  
  public void start()
  {
    directoryDownloader.start();
  }
  
  public void stop()
  {
    directoryDownloader.stop();
  }
}
