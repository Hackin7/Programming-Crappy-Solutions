package org.codehaus.ui;

import a.f.c.b;
import android.os.Build.VERSION;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import androidx.constraintlayout.widget.ConstraintLayout.a;
import java.util.HashMap;

public class h
{
  public final Plot a = new Plot();
  public HashMap<String, b> b = new HashMap();
  public final Frame h = new Frame();
  public int p;
  public final ClassWriter x = new ClassWriter();
  public final Switch y = new Switch();
  
  public h() {}
  
  public h a()
  {
    h localH = new h();
    x.init(x);
    y.a(y);
    h.a(h);
    a.a(a);
    p = p;
    return localH;
  }
  
  public final void a(int paramInt, f paramF)
  {
    init(paramInt, paramF);
    h.w = w;
    Plot localPlot = a;
    a = a;
    i = i;
    s = s;
    e = e;
    w = f;
    r = r;
    c = x;
    n = n;
    j = k;
    k = y;
    h = h;
    p = c;
  }
  
  public final void a(Label paramLabel, int paramInt, f paramF)
  {
    a(paramInt, paramF);
    if ((paramLabel instanceof Type))
    {
      paramF = x;
      v = 1;
      paramLabel = (Type)paramLabel;
      n = paramLabel.getType();
      x.o = paramLabel.getReferencedIds();
      x.r = paramLabel.getMargin();
    }
  }
  
  public final void init(int paramInt, ConstraintLayout.a paramA)
  {
    p = paramInt;
    ClassWriter localClassWriter = x;
    d = d;
    e = e;
    key = f;
    value = h;
    active = g;
    mode = l;
    name = j;
    icon = k;
    g = i;
    b = b;
    color = color;
    size = size;
    version = index;
    normalImpulse = y;
    tangentImpulse = next;
    data = data;
    length = min;
    i = n;
    h = m;
    type = type;
    state = state;
    id = id;
    x = c;
    s = o;
    p = p;
    q = width;
    j = height;
    c = leftMargin;
    index = rightMargin;
    wrap = topMargin;
    dir = bottomMargin;
    start = key;
    y = buffer;
    count = count;
    text = flags;
    w = w;
    a = z;
    cipher = top;
    digest = left;
    radius = N;
    pointCount = M;
    m_radius = A;
    m_count = H;
    max = L;
    min = r;
    t = time;
    K = t;
    M = s;
    normalMass = v;
    normal = u;
    points = x;
    L = q;
    paramInt = Build.VERSION.SDK_INT;
    out = paramA.getMarginEnd();
    x.image = paramA.getMarginStart();
  }
  
  public void init(ConstraintLayout.a paramA)
  {
    Object localObject = x;
    d = d;
    e = e;
    f = key;
    h = value;
    g = active;
    l = mode;
    j = name;
    k = icon;
    i = g;
    b = b;
    color = color;
    size = size;
    index = version;
    leftMargin = c;
    rightMargin = index;
    topMargin = wrap;
    bottomMargin = dir;
    x = points;
    q = L;
    t = K;
    s = M;
    y = normalImpulse;
    next = tangentImpulse;
    min = length;
    n = i;
    m = h;
    data = data;
    type = type;
    state = state;
    key = start;
    buffer = y;
    count = count;
    flags = text;
    w = w;
    z = a;
    top = cipher;
    left = digest;
    N = radius;
    M = pointCount;
    A = m_radius;
    H = m_count;
    L = max;
    r = min;
    id = id;
    c = x;
    o = s;
    p = p;
    width = q;
    height = j;
    localObject = t;
    if (localObject != null) {
      time = ((String)localObject);
    }
    paramA.setMarginStart(x.image);
    paramA.setMarginEnd(x.out);
    paramA.add();
  }
}
