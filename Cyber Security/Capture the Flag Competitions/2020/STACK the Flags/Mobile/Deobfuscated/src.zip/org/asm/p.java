package org.asm;

public class p
  implements m
{
  public p() {}
  
  public void b(l paramL) {}
  
  public void c(l paramL) {}
  
  public void d(l paramL) {}
}
