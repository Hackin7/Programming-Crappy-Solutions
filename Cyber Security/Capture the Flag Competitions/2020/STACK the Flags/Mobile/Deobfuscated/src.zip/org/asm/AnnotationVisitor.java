package org.asm;

import android.graphics.Path;

public abstract class AnnotationVisitor
{
  public AnnotationVisitor() {}
  
  public abstract Path getMarkPath(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}
