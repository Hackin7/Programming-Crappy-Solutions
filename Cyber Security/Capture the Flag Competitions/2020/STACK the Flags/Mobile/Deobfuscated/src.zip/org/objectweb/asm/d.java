package org.objectweb.asm;

public class d
{
  public int a;
  public int g;
  public int h;
  public int i = 0;
  public int q;
  
  public d() {}
  
  public int a(int paramInt1, int paramInt2)
  {
    if (paramInt1 > paramInt2) {
      return 1;
    }
    if (paramInt1 == paramInt2) {
      return 2;
    }
    return 4;
  }
  
  public void a(int paramInt)
  {
    i |= paramInt;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    a = paramInt1;
    h = paramInt2;
    g = paramInt3;
    q = paramInt4;
  }
  
  public boolean a()
  {
    int j = i;
    if (((j & 0x7) != 0) && ((j & a(g, a) << 0) == 0)) {
      return false;
    }
    j = i;
    if (((j & 0x70) != 0) && ((j & a(g, h) << 4) == 0)) {
      return false;
    }
    j = i;
    if (((j & 0x700) != 0) && ((j & a(q, a) << 8) == 0)) {
      return false;
    }
    j = i;
    return ((j & 0x7000) == 0) || ((j & a(q, h) << 12) != 0);
  }
  
  public void d()
  {
    i = 0;
  }
}
