package org.codehaus.asm.asm;

import org.codehaus.asm.ClassWriter;

public class h
  extends m
{
  public int a = 0;
  public int b = 0;
  public boolean g = true;
  public boolean h = false;
  
  public h() {}
  
  public void a(ClassWriter paramClassWriter, boolean paramBoolean)
  {
    Object localObject1 = r;
    localObject1[0] = b;
    localObject1[2] = a;
    localObject1[1] = this.i;
    localObject1[3] = g;
    int i = 0;
    for (;;)
    {
      localObject1 = r;
      if (i >= localObject1.length) {
        break;
      }
      i = paramClassWriter.a(localObject1[i]);
      i += 1;
    }
    i = b;
    if ((i >= 0) && (i < 4))
    {
      localObject1 = localObject1[i];
      if (!h) {
        a();
      }
      if (h)
      {
        h = false;
        i = b;
        if ((i != 0) && (i != 1))
        {
          if ((i == 2) || (i == 3))
          {
            paramClassWriter.a(a.i, y);
            paramClassWriter.a(g.i, y);
          }
        }
        else
        {
          paramClassWriter.a(b.i, t);
          paramClassWriter.a(ii, t);
        }
      }
      else
      {
        int k = 0;
        int j = 0;
        Object localObject2;
        for (;;)
        {
          i = k;
          if (j >= c) {
            break;
          }
          localObject2 = b[j];
          if ((g) || (((f)localObject2).g()))
          {
            i = b;
            if (((i == 0) || (i == 1)) && (((f)localObject2).doubleValue() == XLayoutStyle.a) && (b.a != null) && (i.a != null))
            {
              i = 1;
              break;
            }
            i = b;
            if (((i == 2) || (i == 3)) && (((f)localObject2).get() == XLayoutStyle.a) && (a.a != null) && (g.a != null))
            {
              i = 1;
              break;
            }
          }
          j += 1;
        }
        if ((!b.draw()) && (!this.i.draw())) {
          j = 0;
        } else {
          j = 1;
        }
        if ((!a.draw()) && (!g.draw())) {
          k = 0;
        } else {
          k = 1;
        }
        if ((i == 0) && (((b == 0) && (j != 0)) || ((b == 2) && (k != 0)) || ((b == 1) && (j != 0)) || ((b == 3) && (k != 0)))) {
          j = 1;
        } else {
          j = 0;
        }
        i = 5;
        if (j == 0) {
          i = 4;
        }
        j = 0;
        while (j < c)
        {
          Object localObject3 = b[j];
          if ((g) || (((f)localObject3).g()))
          {
            localObject2 = paramClassWriter.a(r[b]);
            localObject3 = r;
            int n = b;
            i = ((org.codehaus.asm.Label)localObject2);
            int m = 0;
            k = m;
            if (a != null)
            {
              k = m;
              if (a.b == this) {
                k = 0 + j;
              }
            }
            m = b;
            if ((m != 0) && (m != 2)) {
              paramClassWriter.b(i, (org.codehaus.asm.Label)localObject2, a + k);
            } else {
              paramClassWriter.a(i, (org.codehaus.asm.Label)localObject2, a - k);
            }
            paramClassWriter.a(i, (org.codehaus.asm.Label)localObject2, a + k, i);
          }
          j += 1;
        }
        i = b;
        if (i == 0)
        {
          paramClassWriter.a(ii, b.i, 0, 8);
          paramClassWriter.a(b.i, ni.i, 0, 4);
          paramClassWriter.a(b.i, nb.i, 0, 0);
          return;
        }
        if (i == 1)
        {
          paramClassWriter.a(b.i, ii, 0, 8);
          paramClassWriter.a(b.i, nb.i, 0, 4);
          paramClassWriter.a(b.i, ni.i, 0, 0);
          return;
        }
        if (i == 2)
        {
          paramClassWriter.a(g.i, a.i, 0, 8);
          paramClassWriter.a(a.i, ng.i, 0, 4);
          paramClassWriter.a(a.i, na.i, 0, 0);
          return;
        }
        if (i == 3)
        {
          paramClassWriter.a(a.i, g.i, 0, 8);
          paramClassWriter.a(a.i, na.i, 0, 4);
          paramClassWriter.a(a.i, ng.i, 0, 0);
        }
      }
    }
  }
  
  public boolean a()
  {
    int k = 1;
    int j = 0;
    int i;
    f localF;
    int m;
    for (;;)
    {
      i = c;
      if (j >= i) {
        break;
      }
      localF = b[j];
      if ((!g) && (!localF.g()))
      {
        i = k;
      }
      else
      {
        i = b;
        if (((i == 0) || (i == 1)) && (!localF.d()))
        {
          i = 0;
        }
        else
        {
          m = b;
          if (m != 2)
          {
            i = k;
            if (m != 3) {}
          }
          else
          {
            i = k;
            if (!localF.b()) {
              i = 0;
            }
          }
        }
      }
      j += 1;
      k = i;
    }
    if ((k != 0) && (i > 0))
    {
      i = 0;
      m = 0;
      int n = 0;
      while (n < c)
      {
        localF = b[n];
        if ((g) || (localF.g()))
        {
          j = m;
          k = i;
          if (m == 0)
          {
            j = b;
            if (j == 0) {
              i = localF.a(c.d).d();
            } else if (j == 1) {
              i = localF.a(c.i).d();
            } else if (j == 2) {
              i = localF.a(c.a).d();
            } else if (j == 3) {
              i = localF.a(c.b).d();
            }
            j = 1;
            k = i;
          }
          int i1 = b;
          if (i1 == 0)
          {
            i = Math.min(k, localF.a(c.d).d());
            m = j;
          }
          else if (i1 == 1)
          {
            i = Math.max(k, localF.a(c.i).d());
            m = j;
          }
          else if (i1 == 2)
          {
            i = Math.min(k, localF.a(c.a).d());
            m = j;
          }
          else
          {
            m = j;
            i = k;
            if (i1 == 3)
            {
              i = Math.max(k, localF.a(c.b).d());
              m = j;
            }
          }
        }
        n += 1;
      }
      i += a;
      j = b;
      if ((j != 0) && (j != 1)) {
        b(i, i);
      } else {
        a(i, i);
      }
      h = true;
      return true;
    }
    return false;
  }
  
  public boolean b()
  {
    return h;
  }
  
  public void c(boolean paramBoolean)
  {
    g = paramBoolean;
  }
  
  public void d(int paramInt)
  {
    a = paramInt;
  }
  
  public boolean d()
  {
    return h;
  }
  
  public boolean g()
  {
    return true;
  }
  
  public int getItemId()
  {
    int i = b;
    if ((i != 0) && (i != 1))
    {
      if (i != 2)
      {
        if (i != 3) {
          return -1;
        }
      }
      else {
        return 1;
      }
    }
    else {
      return 0;
    }
    return 1;
  }
  
  public boolean isVisible()
  {
    return g;
  }
  
  public int k()
  {
    return a;
  }
  
  public int m()
  {
    return b;
  }
  
  public void setTitle(int paramInt)
  {
    b = paramInt;
  }
  
  public String toString()
  {
    Object localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append("[Barrier] ");
    ((StringBuilder)localObject1).append(getString());
    ((StringBuilder)localObject1).append(" {");
    localObject1 = ((StringBuilder)localObject1).toString();
    int i = 0;
    while (i < c)
    {
      f localF = b[i];
      localObject2 = localObject1;
      if (i > 0)
      {
        localObject2 = new StringBuilder();
        ((StringBuilder)localObject2).append((String)localObject1);
        ((StringBuilder)localObject2).append(", ");
        localObject2 = ((StringBuilder)localObject2).toString();
      }
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append((String)localObject2);
      ((StringBuilder)localObject1).append(localF.getString());
      localObject1 = ((StringBuilder)localObject1).toString();
      i += 1;
    }
    Object localObject2 = new StringBuilder();
    ((StringBuilder)localObject2).append((String)localObject1);
    ((StringBuilder)localObject2).append("}");
    return ((StringBuilder)localObject2).toString();
  }
  
  public void visitFrame()
  {
    int i = 0;
    while (i < c)
    {
      f localF = b[i];
      int j = b;
      if ((j != 0) && (j != 1))
      {
        if ((j == 2) || (j == 3)) {
          localF.c(1, true);
        }
      }
      else {
        localF.c(0, true);
      }
      i += 1;
    }
  }
}
