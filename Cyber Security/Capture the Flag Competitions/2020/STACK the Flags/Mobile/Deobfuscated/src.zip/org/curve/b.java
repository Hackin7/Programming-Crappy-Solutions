package org.curve;

import a.a.a;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class b
{
  public boolean b;
  public CopyOnWriteArrayList<a> w = new CopyOnWriteArrayList();
  
  public b(boolean paramBoolean)
  {
    b = paramBoolean;
  }
  
  public void a(d paramD)
  {
    w.add(paramD);
  }
  
  public final void a(boolean paramBoolean)
  {
    b = paramBoolean;
  }
  
  public final boolean a()
  {
    return b;
  }
  
  public final void close()
  {
    Iterator localIterator = w.iterator();
    while (localIterator.hasNext()) {
      ((d)localIterator.next()).cancel();
    }
  }
  
  public void e(d paramD)
  {
    w.remove(paramD);
  }
  
  public abstract void run();
}
