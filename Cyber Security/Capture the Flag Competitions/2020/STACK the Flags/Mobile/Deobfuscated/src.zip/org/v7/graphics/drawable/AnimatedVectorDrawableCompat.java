package org.v7.graphics.drawable;

import a.b.m.a.a;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import org.core.asm.signature.EmptySignature;
import org.v7.util.OperatorReplay;
import org.v7.widget.AppCompatDrawableManager;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@SuppressLint({"RestrictedAPI"})
public class AnimatedVectorDrawableCompat
  extends VectorDrawableCompat
  implements EmptySignature
{
  public Animator a;
  public boolean state;
  public ByteVector this$0;
  public int x = -1;
  public int y = -1;
  
  static
  {
    a.class.getSimpleName();
  }
  
  public AnimatedVectorDrawableCompat()
  {
    this(null, null);
  }
  
  public AnimatedVectorDrawableCompat(ByteVector paramByteVector, Resources paramResources)
  {
    super(null);
    mutate(new ByteVector(paramByteVector, this, paramResources));
    onStateChange(getState());
    jumpToCurrentState();
  }
  
  public static AnimatedVectorDrawableCompat createFromXmlInner(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    Object localObject = paramXmlPullParser.getName();
    if (((String)localObject).equals("animated-selector"))
    {
      localObject = new AnimatedVectorDrawableCompat();
      ((AnimatedVectorDrawableCompat)localObject).initialize(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return localObject;
    }
    paramContext = new StringBuilder();
    paramContext.append(paramXmlPullParser.getPositionDescription());
    paramContext.append(": invalid animated-selector tag ");
    paramContext.append((String)localObject);
    throw new XmlPullParserException(paramContext.toString());
  }
  
  public ByteVector build()
  {
    return new ByteVector(this$0, this, null);
  }
  
  public final int create(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    Object localObject = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, OperatorReplay.AnimatedStateListDrawableTransition);
    int i = ((TypedArray)localObject).getResourceId(OperatorReplay.AnimatedStateListDrawableTransition_android_fromId, -1);
    int j = ((TypedArray)localObject).getResourceId(OperatorReplay.AnimatedStateListDrawableTransition_android_toId, -1);
    Drawable localDrawable = null;
    int k = ((TypedArray)localObject).getResourceId(OperatorReplay.AnimatedStateListDrawableTransition_android_drawable, -1);
    if (k > 0) {
      localDrawable = AppCompatDrawableManager.get().getDrawable(paramContext, k);
    }
    boolean bool = ((TypedArray)localObject).getBoolean(OperatorReplay.AnimatedStateListDrawableTransition_android_reversible, false);
    ((TypedArray)localObject).recycle();
    localObject = localDrawable;
    if (localDrawable == null)
    {
      do
      {
        k = paramXmlPullParser.next();
      } while (k == 4);
      if (k == 2)
      {
        if (paramXmlPullParser.getName().equals("animated-vector")) {
          localObject = org.greendroid.graphics.drawable.AnimatedVectorDrawableCompat.createFromXmlInner(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
        } else {
          localObject = Drawable.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
        }
      }
      else
      {
        paramContext = new StringBuilder();
        paramContext.append(paramXmlPullParser.getPositionDescription());
        paramContext.append(": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
        throw new XmlPullParserException(paramContext.toString());
      }
    }
    if (localObject != null)
    {
      if ((i != -1) && (j != -1)) {
        return this$0.add(i, j, (Drawable)localObject, bool);
      }
      paramContext = new StringBuilder();
      paramContext.append(paramXmlPullParser.getPositionDescription());
      paramContext.append(": <transition> tag requires 'fromId' & 'toId' attributes");
      throw new XmlPullParserException(paramContext.toString());
    }
    paramContext = new StringBuilder();
    paramContext.append(paramXmlPullParser.getPositionDescription());
    paramContext.append(": <transition> tag requires a 'drawable' attribute or child tag defining a drawable");
    throw new XmlPullParserException(paramContext.toString());
  }
  
  public final int inflate(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    Object localObject = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, OperatorReplay.AnimatedStateListDrawableItem);
    int i = ((TypedArray)localObject).getResourceId(OperatorReplay.AnimatedStateListDrawableItem_android_id, 0);
    Drawable localDrawable = null;
    int j = ((TypedArray)localObject).getResourceId(OperatorReplay.AnimatedStateListDrawableItem_android_drawable, -1);
    if (j > 0) {
      localDrawable = AppCompatDrawableManager.get().getDrawable(paramContext, j);
    }
    ((TypedArray)localObject).recycle();
    localObject = a(paramAttributeSet);
    paramContext = localDrawable;
    if (localDrawable == null)
    {
      do
      {
        j = paramXmlPullParser.next();
      } while (j == 4);
      if (j == 2)
      {
        if (paramXmlPullParser.getName().equals("vector")) {
          paramContext = org.greendroid.graphics.drawable.VectorDrawableCompat.create(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
        } else {
          paramContext = Drawable.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
        }
      }
      else
      {
        paramContext = new StringBuilder();
        paramContext.append(paramXmlPullParser.getPositionDescription());
        paramContext.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
        throw new XmlPullParserException(paramContext.toString());
      }
    }
    if (paramContext != null) {
      return this$0.add((int[])localObject, paramContext, i);
    }
    paramContext = new StringBuilder();
    paramContext.append(paramXmlPullParser.getPositionDescription());
    paramContext.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
    throw new XmlPullParserException(paramContext.toString());
  }
  
  public final void inflate(TypedArray paramTypedArray)
  {
    ByteVector localByteVector = this$0;
    flags |= paramTypedArray.getChangingConfigurations();
    localByteVector.set(paramTypedArray.getBoolean(OperatorReplay.AnimatedStateListDrawableCompat_android_variablePadding, b));
    localByteVector.write(paramTypedArray.getBoolean(OperatorReplay.AnimatedStateListDrawableCompat_android_constantSize, a));
    localByteVector.setEnterFadeDuration(paramTypedArray.getInt(OperatorReplay.AnimatedStateListDrawableCompat_android_enterFadeDuration, mMode));
    localByteVector.setExitFadeDuration(paramTypedArray.getInt(OperatorReplay.AnimatedStateListDrawableCompat_android_exitFadeDuration, mAlpha));
    setDither(paramTypedArray.getBoolean(OperatorReplay.AnimatedStateListDrawableCompat_android_dither, mDither));
  }
  
  public void initialize(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    TypedArray localTypedArray = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, OperatorReplay.AnimatedStateListDrawableCompat);
    setVisible(localTypedArray.getBoolean(OperatorReplay.AnimatedStateListDrawableCompat_android_visible, true), true);
    inflate(localTypedArray);
    inflate(paramResources);
    localTypedArray.recycle();
    process(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    setState();
  }
  
  public boolean isStateful()
  {
    return true;
  }
  
  public void jumpToCurrentState()
  {
    super.jumpToCurrentState();
    Animator localAnimator = a;
    if (localAnimator != null)
    {
      localAnimator.stop();
      a = null;
      draw(x);
      x = -1;
      y = -1;
    }
  }
  
  public Drawable mutate()
  {
    if (!state)
    {
      super.mutate();
      this$0.init();
      state = true;
    }
    return this;
  }
  
  public void mutate(DrawableContainer.DrawableContainerState paramDrawableContainerState)
  {
    super.mutate(paramDrawableContainerState);
    if ((paramDrawableContainerState instanceof ByteVector)) {
      this$0 = ((ByteVector)paramDrawableContainerState);
    }
  }
  
  public boolean onStateChange(int[] paramArrayOfInt)
  {
    int i = this$0.add(paramArrayOfInt);
    boolean bool1;
    if ((i != get()) && ((start(i)) || (draw(i)))) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    Drawable localDrawable = getCurrent();
    boolean bool2 = bool1;
    if (localDrawable != null) {
      bool2 = bool1 | localDrawable.setState(paramArrayOfInt);
    }
    return bool2;
  }
  
  public final void process(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    int i = paramXmlPullParser.getDepth() + 1;
    for (;;)
    {
      int j = paramXmlPullParser.next();
      if (j == 1) {
        break;
      }
      int k = paramXmlPullParser.getDepth();
      if ((k < i) && (j == 3)) {
        break;
      }
      if ((j == 2) && (k <= i)) {
        if (paramXmlPullParser.getName().equals("item")) {
          inflate(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
        } else if (paramXmlPullParser.getName().equals("transition")) {
          create(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
        }
      }
    }
  }
  
  public final void setState()
  {
    onStateChange(getState());
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    if ((a != null) && ((bool) || (paramBoolean2)))
    {
      if (paramBoolean1)
      {
        a.start();
        return bool;
      }
      jumpToCurrentState();
    }
    return bool;
  }
  
  public final boolean start(int paramInt)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: fail exe a15 = a14\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:92)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.exec(BaseAnalyze.java:1)\n\tat com.googlecode.dex2jar.ir.ts.Cfg.dfs(Cfg.java:255)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze0(BaseAnalyze.java:75)\n\tat com.googlecode.dex2jar.ir.ts.an.BaseAnalyze.analyze(BaseAnalyze.java:69)\n\tat com.googlecode.dex2jar.ir.ts.UnSSATransformer.transform(UnSSATransformer.java:274)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:163)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\nCaused by: java.lang.NullPointerException\n");
  }
}
