package org.v7.app;

import android.content.Context;
import android.content.IntentFilter;
import android.os.PowerManager;

public class b
  extends Item
{
  public final PowerManager b;
  
  public b(AppCompatDelegateImplV7 paramAppCompatDelegateImplV7, Context paramContext)
  {
    super(paramAppCompatDelegateImplV7);
    b = ((PowerManager)paramContext.getApplicationContext().getSystemService("power"));
  }
  
  public int a()
  {
    if (b.isPowerSaveMode()) {
      return 2;
    }
    return 1;
  }
  
  public void d()
  {
    a.d();
  }
  
  public IntentFilter init()
  {
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
    return localIntentFilter;
  }
}
