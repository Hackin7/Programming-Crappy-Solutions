package org.data;

import a.e.f;
import a.e.g;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Label<K, V>
  extends g<K, V>
  implements Map<K, V>
{
  public f<K, V> mCollections;
  
  public Label() {}
  
  public Label(int paramInt)
  {
    super(paramInt);
  }
  
  public Label(Context paramContext)
  {
    super(paramContext);
  }
  
  public Set entrySet()
  {
    return getCollection().getEntrySet();
  }
  
  public boolean equals(Collection paramCollection)
  {
    return MapCollections.retainAllHelper(this, paramCollection);
  }
  
  public final MapCollections getCollection()
  {
    if (mCollections == null) {
      mCollections = new TDoubleDoubleMapDecorator(this);
    }
    return mCollections;
  }
  
  public Set keySet()
  {
    return getCollection().getKeySet();
  }
  
  public void putAll(Map paramMap)
  {
    add(size + paramMap.size());
    paramMap = paramMap.entrySet().iterator();
    while (paramMap.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)paramMap.next();
      put(localEntry.getKey(), localEntry.getValue());
    }
  }
  
  public Collection values()
  {
    return getCollection().getValues();
  }
}
