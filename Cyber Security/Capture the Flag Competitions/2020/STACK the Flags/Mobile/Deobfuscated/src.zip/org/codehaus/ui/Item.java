package org.codehaus.ui;

import a.f.c.e.a;
import a.f.c.j;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintLayout.a;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.codehaus.converters.lookup.SignatureReader;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class Item
{
  public static final int[] h = { 0, 4, 8 };
  public static SparseIntArray mAlphaIndexer;
  public HashMap<String, a.f.c.b> a = new HashMap();
  public HashMap<Integer, e.a> b = new HashMap();
  public boolean c = true;
  
  static
  {
    SparseIntArray localSparseIntArray = new SparseIntArray();
    mAlphaIndexer = localSparseIntArray;
    localSparseIntArray.append(IpAddress.Constraint_layout_constraintLeft_toLeftOf, 25);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintLeft_toRightOf, 26);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintRight_toLeftOf, 29);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintRight_toRightOf, 30);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintTop_toTopOf, 36);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintTop_toBottomOf, 35);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintBottom_toTopOf, 4);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintBottom_toBottomOf, 3);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintBaseline_toBaselineOf, 1);
    mAlphaIndexer.append(IpAddress.Constraint_layout_editor_absoluteX, 6);
    mAlphaIndexer.append(IpAddress.Constraint_layout_editor_absoluteY, 7);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintGuide_begin, 17);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintGuide_end, 18);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintGuide_percent, 19);
    mAlphaIndexer.append(IpAddress.Constraint_android_orientation, 27);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintStart_toEndOf, 32);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintStart_toStartOf, 33);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintEnd_toStartOf, 10);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintEnd_toEndOf, 9);
    mAlphaIndexer.append(IpAddress.Constraint_layout_goneMarginLeft, 13);
    mAlphaIndexer.append(IpAddress.Constraint_layout_goneMarginTop, 16);
    mAlphaIndexer.append(IpAddress.Constraint_layout_goneMarginRight, 14);
    mAlphaIndexer.append(IpAddress.Constraint_layout_goneMarginBottom, 11);
    mAlphaIndexer.append(IpAddress.Constraint_layout_goneMarginStart, 15);
    mAlphaIndexer.append(IpAddress.Constraint_layout_goneMarginEnd, 12);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintVertical_weight, 40);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHorizontal_weight, 39);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHorizontal_chainStyle, 41);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintVertical_chainStyle, 42);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHorizontal_bias, 20);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintVertical_bias, 37);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintDimensionRatio, 5);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintLeft_creator, 82);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintTop_creator, 82);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintRight_creator, 82);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintBottom_creator, 82);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintBaseline_creator, 82);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_marginLeft, 24);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_marginRight, 28);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_marginStart, 31);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_marginEnd, 8);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_marginTop, 34);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_marginBottom, 2);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_width, 23);
    mAlphaIndexer.append(IpAddress.Constraint_android_layout_height, 21);
    mAlphaIndexer.append(IpAddress.Constraint_android_visibility, 22);
    mAlphaIndexer.append(IpAddress.Constraint_android_alpha, 43);
    mAlphaIndexer.append(IpAddress.Constraint_android_elevation, 44);
    mAlphaIndexer.append(IpAddress.Constraint_android_rotationX, 45);
    mAlphaIndexer.append(IpAddress.Constraint_android_rotationY, 46);
    mAlphaIndexer.append(IpAddress.Constraint_android_rotation, 60);
    mAlphaIndexer.append(IpAddress.Constraint_android_scaleX, 47);
    mAlphaIndexer.append(IpAddress.Constraint_android_scaleY, 48);
    mAlphaIndexer.append(IpAddress.Constraint_android_transformPivotX, 49);
    mAlphaIndexer.append(IpAddress.Constraint_android_transformPivotY, 50);
    mAlphaIndexer.append(IpAddress.Constraint_android_translationX, 51);
    mAlphaIndexer.append(IpAddress.Constraint_android_translationY, 52);
    mAlphaIndexer.append(IpAddress.Constraint_android_translationZ, 53);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintWidth_default, 54);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHeight_default, 55);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintWidth_max, 56);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHeight_max, 57);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintWidth_min, 58);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHeight_min, 59);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintCircle, 61);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintCircleRadius, 62);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintCircleAngle, 63);
    mAlphaIndexer.append(IpAddress.Constraint_animate_relativeTo, 64);
    mAlphaIndexer.append(IpAddress.Constraint_transitionEasing, 65);
    mAlphaIndexer.append(IpAddress.Constraint_drawPath, 66);
    mAlphaIndexer.append(IpAddress.Constraint_transitionPathRotate, 67);
    mAlphaIndexer.append(IpAddress.Constraint_motionStagger, 79);
    mAlphaIndexer.append(IpAddress.Constraint_android_id, 38);
    mAlphaIndexer.append(IpAddress.Constraint_motionProgress, 68);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintWidth_percent, 69);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintHeight_percent, 70);
    mAlphaIndexer.append(IpAddress.Constraint_chainUseRtl, 71);
    mAlphaIndexer.append(IpAddress.Constraint_barrierDirection, 72);
    mAlphaIndexer.append(IpAddress.Constraint_barrierMargin, 73);
    mAlphaIndexer.append(IpAddress.Constraint_constraint_referenced_ids, 74);
    mAlphaIndexer.append(IpAddress.Constraint_barrierAllowsGoneWidgets, 75);
    mAlphaIndexer.append(IpAddress.Constraint_pathMotionArc, 76);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constraintTag, 77);
    mAlphaIndexer.append(IpAddress.Constraint_visibilityMode, 78);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constrainedWidth, 80);
    mAlphaIndexer.append(IpAddress.Constraint_layout_constrainedHeight, 81);
  }
  
  public Item() {}
  
  public static int valueOf(TypedArray paramTypedArray, int paramInt1, int paramInt2)
  {
    paramInt2 = paramTypedArray.getResourceId(paramInt1, paramInt2);
    if (paramInt2 == -1) {
      return paramTypedArray.getInt(paramInt1, -1);
    }
    return paramInt2;
  }
  
  public final h a(Context paramContext, AttributeSet paramAttributeSet)
  {
    h localH = new h();
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.Constraint);
    init(localH, paramContext);
    paramContext.recycle();
    return localH;
  }
  
  public void a(Context paramContext, int paramInt)
  {
    XmlResourceParser localXmlResourceParser = paramContext.getResources().getXml(paramInt);
    try
    {
      for (paramInt = localXmlResourceParser.getEventType(); paramInt != 1; paramInt = localXmlResourceParser.next()) {
        if (paramInt != 0)
        {
          if (paramInt != 2)
          {
            if (paramInt != 3) {}
          }
          else
          {
            Object localObject = localXmlResourceParser.getName();
            h localH = a(paramContext, Xml.asAttributeSet(localXmlResourceParser));
            boolean bool = ((String)localObject).equalsIgnoreCase("Guideline");
            if (bool) {
              x.m = true;
            }
            localObject = b;
            paramInt = p;
            ((HashMap)localObject).put(Integer.valueOf(paramInt), localH);
          }
        }
        else {
          localXmlResourceParser.getName();
        }
      }
      return;
    }
    catch (IOException paramContext)
    {
      paramContext.printStackTrace();
      return;
    }
    catch (XmlPullParserException paramContext)
    {
      paramContext.printStackTrace();
    }
  }
  
  public void a(Context paramContext, XmlPullParser paramXmlPullParser)
  {
    Object localObject1 = null;
    try
    {
      for (int i = paramXmlPullParser.getEventType(); i != 1; i = paramXmlPullParser.next()) {
        if (i != 0)
        {
          int j = 3;
          Object localObject2;
          boolean bool;
          if (i != 2)
          {
            if (i == 3)
            {
              localObject2 = paramXmlPullParser.getName();
              bool = "ConstraintSet".equals(localObject2);
              if (bool) {
                return;
              }
              bool = ((String)localObject2).equalsIgnoreCase("Constraint");
              localObject2 = localObject1;
              if (bool)
              {
                localObject2 = b;
                i = p;
                ((HashMap)localObject2).put(Integer.valueOf(i), localObject1);
                localObject2 = null;
              }
              localObject1 = localObject2;
            }
          }
          else
          {
            localObject2 = paramXmlPullParser.getName();
            i = ((String)localObject2).hashCode();
            switch (i)
            {
            default: 
              break;
            }
            for (;;)
            {
              break;
              bool = ((String)localObject2).equals("Constraint");
              if (bool)
              {
                i = 0;
                break label371;
                bool = ((String)localObject2).equals("CustomAttribute");
                if (bool)
                {
                  i = 7;
                  break label371;
                  bool = ((String)localObject2).equals("Barrier");
                  if (bool)
                  {
                    i = 2;
                    break label371;
                    bool = ((String)localObject2).equals("Guideline");
                    if (bool)
                    {
                      i = 1;
                      break label371;
                      bool = ((String)localObject2).equals("Transform");
                      if (bool)
                      {
                        i = 4;
                        break label371;
                        bool = ((String)localObject2).equals("PropertySet");
                        if (bool)
                        {
                          i = j;
                          break label371;
                          bool = ((String)localObject2).equals("Motion");
                          if (bool)
                          {
                            i = 6;
                            break label371;
                            bool = ((String)localObject2).equals("Layout");
                            if (bool)
                            {
                              i = 5;
                              break label371;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            i = -1;
            switch (i)
            {
            default: 
              break;
            case 7: 
              if (localObject1 != null)
              {
                localObject2 = b;
                b.parse(paramContext, paramXmlPullParser, (HashMap)localObject2);
              }
              else
              {
                paramContext = new StringBuilder();
                paramContext.append("XML parser error must be within a Constraint ");
                paramContext.append(paramXmlPullParser.getLineNumber());
                paramContext = new RuntimeException(paramContext.toString());
                throw paramContext;
              }
              break;
            case 6: 
              if (localObject1 != null)
              {
                localObject2 = y;
                ((Switch)localObject2).applyStyle(paramContext, Xml.asAttributeSet(paramXmlPullParser));
              }
              else
              {
                paramContext = new StringBuilder();
                paramContext.append("XML parser error must be within a Constraint ");
                paramContext.append(paramXmlPullParser.getLineNumber());
                paramContext = new RuntimeException(paramContext.toString());
                throw paramContext;
              }
              break;
            case 5: 
              if (localObject1 != null)
              {
                localObject2 = x;
                ((ClassWriter)localObject2).init(paramContext, Xml.asAttributeSet(paramXmlPullParser));
              }
              else
              {
                paramContext = new StringBuilder();
                paramContext.append("XML parser error must be within a Constraint ");
                paramContext.append(paramXmlPullParser.getLineNumber());
                paramContext = new RuntimeException(paramContext.toString());
                throw paramContext;
              }
              break;
            case 4: 
              if (localObject1 != null)
              {
                localObject2 = a;
                ((Plot)localObject2).a(paramContext, Xml.asAttributeSet(paramXmlPullParser));
              }
              else
              {
                paramContext = new StringBuilder();
                paramContext.append("XML parser error must be within a Constraint ");
                paramContext.append(paramXmlPullParser.getLineNumber());
                paramContext = new RuntimeException(paramContext.toString());
                throw paramContext;
              }
              break;
            case 3: 
              if (localObject1 != null)
              {
                localObject2 = h;
                ((Frame)localObject2).a(paramContext, Xml.asAttributeSet(paramXmlPullParser));
              }
              else
              {
                paramContext = new StringBuilder();
                paramContext.append("XML parser error must be within a Constraint ");
                paramContext.append(paramXmlPullParser.getLineNumber());
                paramContext = new RuntimeException(paramContext.toString());
                throw paramContext;
              }
              break;
            case 2: 
              localObject2 = a(paramContext, Xml.asAttributeSet(paramXmlPullParser));
              localObject1 = localObject2;
              x.v = 1;
              break;
            case 1: 
              localObject2 = a(paramContext, Xml.asAttributeSet(paramXmlPullParser));
              localObject1 = localObject2;
              x.m = true;
              x.k = true;
              break;
            case 0: 
              label371:
              localObject1 = a(paramContext, Xml.asAttributeSet(paramXmlPullParser));
            }
          }
        }
        else
        {
          paramXmlPullParser.getName();
        }
      }
      return;
    }
    catch (IOException paramContext)
    {
      ((IOException)paramContext).printStackTrace();
      return;
    }
    catch (XmlPullParserException paramContext)
    {
      paramContext.printStackTrace();
    }
  }
  
  public void a(ConstraintLayout paramConstraintLayout)
  {
    int j = paramConstraintLayout.getChildCount();
    b.clear();
    int i = 0;
    while (i < j)
    {
      Object localObject1 = paramConstraintLayout.getChildAt(i);
      Object localObject2 = (ConstraintLayout.a)((View)localObject1).getLayoutParams();
      int k = ((View)localObject1).getId();
      if ((c) && (k == -1)) {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      }
      if (!b.containsKey(Integer.valueOf(k))) {
        b.put(Integer.valueOf(k), new h());
      }
      h localH = (h)b.get(Integer.valueOf(k));
      b = b.a(a, (View)localObject1);
      h.a(localH, k, (ConstraintLayout.a)localObject2);
      h.a = ((View)localObject1).getVisibility();
      h.w = ((View)localObject1).getAlpha();
      a.a = ((View)localObject1).getRotation();
      a.i = ((View)localObject1).getRotationX();
      a.s = ((View)localObject1).getRotationY();
      a.e = ((View)localObject1).getScaleX();
      a.w = ((View)localObject1).getScaleY();
      float f1 = ((View)localObject1).getPivotX();
      float f2 = ((View)localObject1).getPivotY();
      if ((f1 != 0.0D) || (f2 != 0.0D))
      {
        localObject2 = a;
        r = f1;
        c = f2;
      }
      a.n = ((View)localObject1).getTranslationX();
      a.j = ((View)localObject1).getTranslationY();
      a.k = ((View)localObject1).getTranslationZ();
      localObject2 = a;
      if (p) {
        h = ((View)localObject1).getElevation();
      }
      if ((localObject1 instanceof Type))
      {
        localObject1 = (Type)localObject1;
        x.A = ((Type)localObject1).j();
        x.o = ((Label)localObject1).getReferencedIds();
        x.n = ((Type)localObject1).getType();
        x.r = ((Type)localObject1).getMargin();
      }
      i += 1;
    }
  }
  
  public void a(ConstraintLayout paramConstraintLayout, boolean paramBoolean)
  {
    int j = paramConstraintLayout.getChildCount();
    Object localObject1 = new HashSet(b.keySet());
    int i = 0;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    Object localObject6;
    while (i < j)
    {
      localObject2 = paramConstraintLayout.getChildAt(i);
      int k = ((View)localObject2).getId();
      if (!b.containsKey(Integer.valueOf(k)))
      {
        localObject3 = new StringBuilder();
        ((StringBuilder)localObject3).append("id unknown ");
        ((StringBuilder)localObject3).append(SignatureReader.a((View)localObject2));
        Log.w("ConstraintSet", ((StringBuilder)localObject3).toString());
      }
      else
      {
        if ((c) && (k == -1)) {
          throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
        }
        if (k != -1) {
          if (b.containsKey(Integer.valueOf(k)))
          {
            ((HashSet)localObject1).remove(Integer.valueOf(k));
            localObject3 = (h)b.get(Integer.valueOf(k));
            if ((localObject2 instanceof Type)) {
              x.v = 1;
            }
            int m = x.v;
            if ((m != -1) && (m == 1))
            {
              localObject4 = (Type)localObject2;
              ((View)localObject4).setId(k);
              ((Type)localObject4).setType(x.n);
              ((Type)localObject4).setMargin(x.r);
              ((Type)localObject4).setAllowsGoneWidget(x.A);
              localObject5 = x;
              localObject6 = o;
              if (localObject6 != null)
              {
                ((Label)localObject4).setReferencedIds((int[])localObject6);
              }
              else
              {
                localObject6 = u;
                if (localObject6 != null)
                {
                  o = doInBackground((View)localObject4, (String)localObject6);
                  ((Label)localObject4).setReferencedIds(x.o);
                }
              }
            }
            localObject4 = (ConstraintLayout.a)((View)localObject2).getLayoutParams();
            ((ConstraintLayout.a)localObject4).add();
            ((h)localObject3).init((ConstraintLayout.a)localObject4);
            if (paramBoolean) {
              b.a((View)localObject2, b);
            }
            ((View)localObject2).setLayoutParams((ViewGroup.LayoutParams)localObject4);
            localObject4 = h;
            if (i == 0) {
              ((View)localObject2).setVisibility(a);
            }
            ((View)localObject2).setAlpha(h.w);
            ((View)localObject2).setRotation(a.a);
            ((View)localObject2).setRotationX(a.i);
            ((View)localObject2).setRotationY(a.s);
            ((View)localObject2).setScaleX(a.e);
            ((View)localObject2).setScaleY(a.w);
            if (!Float.isNaN(a.r)) {
              ((View)localObject2).setPivotX(a.r);
            }
            if (!Float.isNaN(a.c)) {
              ((View)localObject2).setPivotY(a.c);
            }
            ((View)localObject2).setTranslationX(a.n);
            ((View)localObject2).setTranslationY(a.j);
            ((View)localObject2).setTranslationZ(a.k);
            localObject3 = a;
            if (p) {
              ((View)localObject2).setElevation(h);
            }
          }
          else
          {
            localObject2 = new StringBuilder();
            ((StringBuilder)localObject2).append("WARNING NO CONSTRAINTS for view ");
            ((StringBuilder)localObject2).append(k);
            Log.v("ConstraintSet", ((StringBuilder)localObject2).toString());
          }
        }
      }
      i += 1;
    }
    localObject1 = ((HashSet)localObject1).iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject3 = (Integer)((Iterator)localObject1).next();
      localObject2 = (h)b.get(localObject3);
      i = x.v;
      if ((i != -1) && (i == 1))
      {
        localObject4 = new Type(paramConstraintLayout.getContext());
        ((View)localObject4).setId(((Integer)localObject3).intValue());
        localObject5 = x;
        localObject6 = o;
        if (localObject6 != null)
        {
          ((Label)localObject4).setReferencedIds((int[])localObject6);
        }
        else
        {
          localObject6 = u;
          if (localObject6 != null)
          {
            o = doInBackground((View)localObject4, (String)localObject6);
            ((Label)localObject4).setReferencedIds(x.o);
          }
        }
        ((Type)localObject4).setType(x.n);
        ((Type)localObject4).setMargin(x.r);
        localObject5 = paramConstraintLayout.putShort();
        ((Label)localObject4).a();
        ((h)localObject2).init((ConstraintLayout.a)localObject5);
        paramConstraintLayout.addView((View)localObject4, (ViewGroup.LayoutParams)localObject5);
      }
      if (x.m)
      {
        localObject4 = new ProgressBar(paramConstraintLayout.getContext());
        ((View)localObject4).setId(((Integer)localObject3).intValue());
        localObject3 = paramConstraintLayout.putShort();
        ((h)localObject2).init((ConstraintLayout.a)localObject3);
        paramConstraintLayout.addView((View)localObject4, (ViewGroup.LayoutParams)localObject3);
      }
    }
  }
  
  public void a(Toolbar paramToolbar)
  {
    int j = paramToolbar.getChildCount();
    b.clear();
    int i = 0;
    while (i < j)
    {
      View localView = paramToolbar.getChildAt(i);
      f localF = (f)localView.getLayoutParams();
      int k = localView.getId();
      if ((c) && (k == -1)) {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      }
      if (!b.containsKey(Integer.valueOf(k))) {
        b.put(Integer.valueOf(k), new h());
      }
      h localH = (h)b.get(Integer.valueOf(k));
      if ((localView instanceof Label)) {
        h.a(localH, (Label)localView, k, localF);
      }
      h.a(localH, k, localF);
      i += 1;
    }
  }
  
  public void b(Context paramContext, int paramInt)
  {
    a((ConstraintLayout)LayoutInflater.from(paramContext).inflate(paramInt, null));
  }
  
  public final int[] doInBackground(View paramView, String paramString)
  {
    String[] arrayOfString = paramString.split(",");
    Context localContext = paramView.getContext();
    paramString = new int[arrayOfString.length];
    int k = 0;
    int m = 0;
    while (m < arrayOfString.length)
    {
      Object localObject = arrayOfString[m].trim();
      int j = 0;
      try
      {
        i = j.class.getField((String)localObject).getInt(null);
        j = i;
      }
      catch (Exception localException) {}
      int i = j;
      if (j == 0) {
        i = localContext.getResources().getIdentifier((String)localObject, "id", localContext.getPackageName());
      }
      j = i;
      if (i == 0)
      {
        j = i;
        if (paramView.isInEditMode())
        {
          j = i;
          if ((paramView.getParent() instanceof ConstraintLayout))
          {
            localObject = ((ConstraintLayout)paramView.getParent()).a(0, localObject);
            j = i;
            if (localObject != null)
            {
              j = i;
              if ((localObject instanceof Integer)) {
                j = ((Integer)localObject).intValue();
              }
            }
          }
        }
      }
      paramString[k] = j;
      m += 1;
      k += 1;
    }
    paramView = paramString;
    if (k != arrayOfString.length) {
      paramView = Arrays.copyOf(paramString, k);
    }
    return paramView;
  }
  
  public final void init(h paramH, TypedArray paramTypedArray)
  {
    int j = paramTypedArray.getIndexCount();
    int i = 0;
    while (i < j)
    {
      int k = paramTypedArray.getIndex(i);
      if ((k != IpAddress.Constraint_android_id) && (IpAddress.Constraint_android_layout_marginStart != k) && (IpAddress.Constraint_android_layout_marginEnd != k))
      {
        y.i = true;
        x.k = true;
        h.e = true;
        a.d = true;
      }
      Object localObject;
      switch (mAlphaIndexer.get(k))
      {
      default: 
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append("Unknown attribute 0x");
        ((StringBuilder)localObject).append(Integer.toHexString(k));
        ((StringBuilder)localObject).append("   ");
        ((StringBuilder)localObject).append(mAlphaIndexer.get(k));
        Log.w("ConstraintSet", ((StringBuilder)localObject).toString());
        break;
      case 82: 
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append("unused attribute 0x");
        ((StringBuilder)localObject).append(Integer.toHexString(k));
        ((StringBuilder)localObject).append("   ");
        ((StringBuilder)localObject).append(mAlphaIndexer.get(k));
        Log.w("ConstraintSet", ((StringBuilder)localObject).toString());
        break;
      case 81: 
        localObject = x;
        a = paramTypedArray.getBoolean(k, a);
        break;
      case 80: 
        localObject = x;
        w = paramTypedArray.getBoolean(k, w);
        break;
      case 79: 
        localObject = y;
        h = paramTypedArray.getFloat(k, h);
        break;
      case 78: 
        localObject = h;
        i = paramTypedArray.getInt(k, i);
        break;
      case 77: 
        x.t = paramTypedArray.getString(k);
        break;
      case 76: 
        localObject = y;
        y = paramTypedArray.getInt(k, y);
        break;
      case 75: 
        localObject = x;
        A = paramTypedArray.getBoolean(k, A);
        break;
      case 74: 
        x.u = paramTypedArray.getString(k);
        break;
      case 73: 
        localObject = x;
        r = paramTypedArray.getDimensionPixelSize(k, r);
        break;
      case 72: 
        localObject = x;
        n = paramTypedArray.getInt(k, n);
        break;
      case 71: 
        Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
        break;
      case 70: 
        x.min = paramTypedArray.getFloat(k, 1.0F);
        break;
      case 69: 
        x.max = paramTypedArray.getFloat(k, 1.0F);
        break;
      case 68: 
        localObject = h;
        h = paramTypedArray.getFloat(k, h);
        break;
      case 67: 
        localObject = y;
        w = paramTypedArray.getFloat(k, w);
        break;
      case 66: 
        y.a = paramTypedArray.getInt(k, 0);
        break;
      case 65: 
        if (peekValuetype == 3) {
          y.c = paramTypedArray.getString(k);
        } else {
          y.c = org.codehaus.converters.special.Unit.type[paramTypedArray.getInteger(k, 0)];
        }
        break;
      case 64: 
        localObject = y;
        type = valueOf(paramTypedArray, k, type);
        break;
      case 63: 
        localObject = x;
        h = paramTypedArray.getFloat(k, h);
        break;
      case 62: 
        localObject = x;
        i = paramTypedArray.getDimensionPixelSize(k, i);
        break;
      case 61: 
        localObject = x;
        length = valueOf(paramTypedArray, k, length);
        break;
      case 60: 
        localObject = a;
        a = paramTypedArray.getFloat(k, a);
        break;
      case 59: 
        localObject = x;
        m_count = paramTypedArray.getDimensionPixelSize(k, m_count);
        break;
      case 58: 
        localObject = x;
        m_radius = paramTypedArray.getDimensionPixelSize(k, m_radius);
        break;
      case 57: 
        localObject = x;
        pointCount = paramTypedArray.getDimensionPixelSize(k, pointCount);
        break;
      case 56: 
        localObject = x;
        radius = paramTypedArray.getDimensionPixelSize(k, radius);
        break;
      case 55: 
        localObject = x;
        digest = paramTypedArray.getInt(k, digest);
        break;
      case 54: 
        localObject = x;
        cipher = paramTypedArray.getInt(k, cipher);
        break;
      case 53: 
        localObject = a;
        k = paramTypedArray.getDimension(k, k);
        break;
      case 52: 
        localObject = a;
        j = paramTypedArray.getDimension(k, j);
        break;
      case 51: 
        localObject = a;
        n = paramTypedArray.getDimension(k, n);
        break;
      case 50: 
        localObject = a;
        c = paramTypedArray.getDimension(k, c);
        break;
      case 49: 
        localObject = a;
        r = paramTypedArray.getDimension(k, r);
        break;
      case 48: 
        localObject = a;
        w = paramTypedArray.getFloat(k, w);
        break;
      case 47: 
        localObject = a;
        e = paramTypedArray.getFloat(k, e);
        break;
      case 46: 
        localObject = a;
        s = paramTypedArray.getFloat(k, s);
        break;
      case 45: 
        localObject = a;
        i = paramTypedArray.getFloat(k, i);
        break;
      case 44: 
        localObject = a;
        p = true;
        h = paramTypedArray.getDimension(k, h);
        break;
      case 43: 
        localObject = h;
        w = paramTypedArray.getFloat(k, w);
        break;
      case 42: 
        localObject = x;
        count = paramTypedArray.getInt(k, count);
        break;
      case 41: 
        localObject = x;
        text = paramTypedArray.getInt(k, text);
        break;
      case 40: 
        localObject = x;
        start = paramTypedArray.getFloat(k, start);
        break;
      case 39: 
        localObject = x;
        y = paramTypedArray.getFloat(k, y);
        break;
      case 38: 
        p = paramTypedArray.getResourceId(k, p);
        break;
      case 37: 
        localObject = x;
        tangentImpulse = paramTypedArray.getFloat(k, tangentImpulse);
        break;
      case 36: 
        localObject = x;
        active = valueOf(paramTypedArray, k, active);
        break;
      case 35: 
        localObject = x;
        mode = valueOf(paramTypedArray, k, mode);
        break;
      case 34: 
        localObject = x;
        wrap = paramTypedArray.getDimensionPixelSize(k, wrap);
        break;
      case 33: 
        localObject = x;
        color = valueOf(paramTypedArray, k, color);
        break;
      case 32: 
        localObject = x;
        b = valueOf(paramTypedArray, k, b);
        break;
      case 31: 
        localObject = x;
        image = paramTypedArray.getDimensionPixelSize(k, image);
        break;
      case 30: 
        localObject = x;
        value = valueOf(paramTypedArray, k, value);
        break;
      case 29: 
        localObject = x;
        key = valueOf(paramTypedArray, k, key);
        break;
      case 28: 
        localObject = x;
        index = paramTypedArray.getDimensionPixelSize(k, index);
        break;
      case 27: 
        localObject = x;
        id = paramTypedArray.getInt(k, id);
        break;
      case 26: 
        localObject = x;
        e = valueOf(paramTypedArray, k, e);
        break;
      case 25: 
        localObject = x;
        d = valueOf(paramTypedArray, k, d);
        break;
      case 24: 
        localObject = x;
        c = paramTypedArray.getDimensionPixelSize(k, c);
        break;
      case 23: 
        localObject = x;
        q = paramTypedArray.getLayoutDimension(k, q);
        break;
      case 22: 
        localObject = h;
        a = paramTypedArray.getInt(k, a);
        localObject = h;
        a = h[a];
        break;
      case 21: 
        localObject = x;
        j = paramTypedArray.getLayoutDimension(k, j);
        break;
      case 20: 
        localObject = x;
        normalImpulse = paramTypedArray.getFloat(k, normalImpulse);
        break;
      case 19: 
        localObject = x;
        x = paramTypedArray.getFloat(k, x);
        break;
      case 18: 
        localObject = x;
        p = paramTypedArray.getDimensionPixelOffset(k, p);
        break;
      case 17: 
        localObject = x;
        s = paramTypedArray.getDimensionPixelOffset(k, s);
        break;
      case 16: 
        localObject = x;
        K = paramTypedArray.getDimensionPixelSize(k, K);
        break;
      case 15: 
        localObject = x;
        points = paramTypedArray.getDimensionPixelSize(k, points);
        break;
      case 14: 
        localObject = x;
        normal = paramTypedArray.getDimensionPixelSize(k, normal);
        break;
      case 13: 
        localObject = x;
        normalMass = paramTypedArray.getDimensionPixelSize(k, normalMass);
        break;
      case 12: 
        localObject = x;
        L = paramTypedArray.getDimensionPixelSize(k, L);
        break;
      case 11: 
        localObject = x;
        M = paramTypedArray.getDimensionPixelSize(k, M);
        break;
      case 10: 
        localObject = x;
        size = valueOf(paramTypedArray, k, size);
        break;
      case 9: 
        localObject = x;
        version = valueOf(paramTypedArray, k, version);
        break;
      case 8: 
        localObject = x;
        out = paramTypedArray.getDimensionPixelSize(k, out);
        break;
      case 7: 
        localObject = x;
        state = paramTypedArray.getDimensionPixelOffset(k, state);
        break;
      case 6: 
        localObject = x;
        type = paramTypedArray.getDimensionPixelOffset(k, type);
        break;
      case 5: 
        x.data = paramTypedArray.getString(k);
        break;
      case 4: 
        localObject = x;
        name = valueOf(paramTypedArray, k, name);
        break;
      case 3: 
        localObject = x;
        icon = valueOf(paramTypedArray, k, icon);
        break;
      case 2: 
        localObject = x;
        dir = paramTypedArray.getDimensionPixelSize(k, dir);
        break;
      case 1: 
        localObject = x;
        g = valueOf(paramTypedArray, k, g);
      }
      i += 1;
    }
  }
}
