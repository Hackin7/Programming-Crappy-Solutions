package org.v7.widget;

public abstract interface Field
{
  public abstract CharSequence getMessage();
}
