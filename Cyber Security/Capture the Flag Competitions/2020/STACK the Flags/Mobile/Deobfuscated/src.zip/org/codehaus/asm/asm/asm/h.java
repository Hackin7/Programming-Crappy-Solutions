package org.codehaus.asm.asm.asm;

import java.util.List;
import org.codehaus.asm.asm.XLayoutStyle;

public abstract class h
  implements l
{
  public Label a = new Label(this);
  public org.codehaus.asm.asm.f b;
  public Label c = new Label(this);
  public c d = new c(this);
  public int e = 0;
  public boolean f = false;
  public int g;
  public AllowedSolution i = AllowedSolution.ANY_SIDE;
  public XLayoutStyle p;
  public e q;
  
  public h(org.codehaus.asm.asm.f paramF)
  {
    b = paramF;
  }
  
  public final Label a(org.codehaus.asm.asm.Label paramLabel)
  {
    paramLabel = a;
    if (paramLabel == null) {
      return null;
    }
    org.codehaus.asm.asm.f localF = b;
    int j = d.ordinal();
    if (j != 1)
    {
      if (j != 2)
      {
        if (j != 3)
        {
          if (j != 4)
          {
            if (j != 5) {
              return null;
            }
            return e.a;
          }
          return e.c;
        }
        return f.c;
      }
      return e.a;
    }
    return f.a;
  }
  
  public final Label a(org.codehaus.asm.asm.Label paramLabel, int paramInt)
  {
    Object localObject = a;
    if (localObject == null) {
      return null;
    }
    localObject = b;
    if (paramInt == 0) {
      localObject = f;
    } else {
      localObject = e;
    }
    paramInt = a.d.ordinal();
    if ((paramInt != 1) && (paramInt != 2))
    {
      if ((paramInt != 3) && (paramInt != 4)) {
        return null;
      }
      return c;
    }
    return a;
  }
  
  public abstract void a();
  
  public final void a(int paramInt1, int paramInt2)
  {
    int j = g;
    if (j != 0)
    {
      if (j != 1)
      {
        Object localObject2;
        Object localObject1;
        float f1;
        if (j != 2)
        {
          if (j != 3) {
            return;
          }
          localObject2 = b;
          f localF = f;
          XLayoutStyle localXLayoutStyle = p;
          localObject1 = XLayoutStyle.a;
          if ((localXLayoutStyle == localObject1) && (g == 3))
          {
            localObject2 = e;
            if ((p == localObject1) && (g == 3)) {
              return;
            }
          }
          localObject1 = b;
          if (paramInt1 == 0) {
            localObject1 = e;
          } else {
            localObject1 = f;
          }
          if (d.c)
          {
            f1 = b.i();
            if (paramInt1 == 1) {
              paramInt1 = (int)(d.d / f1 + 0.5F);
            } else {
              paramInt1 = (int)(d.d * f1 + 0.5F);
            }
            d.a(paramInt1);
          }
        }
        else
        {
          localObject1 = b.l();
          if (localObject1 != null)
          {
            if (paramInt1 == 0) {
              localObject1 = f;
            } else {
              localObject1 = e;
            }
            if (d.c)
            {
              localObject2 = b;
              if (paramInt1 == 0) {
                f1 = j;
              } else {
                f1 = q;
              }
              paramInt2 = (int)(d.d * f1 + 0.5F);
              d.a(b(paramInt2, paramInt1));
            }
          }
        }
      }
      else
      {
        paramInt1 = b(d.d, paramInt1);
        d.a(Math.min(paramInt1, paramInt2));
      }
    }
    else {
      d.a(b(paramInt2, paramInt1));
    }
  }
  
  public void a(org.codehaus.asm.asm.Label paramLabel1, org.codehaus.asm.asm.Label paramLabel2, int paramInt)
  {
    Label localLabel1 = a(paramLabel1);
    Label localLabel2 = a(paramLabel2);
    if (c)
    {
      if (!c) {
        return;
      }
      int k = d + paramLabel1.b();
      int j = d - paramLabel2.b();
      int m = j - k;
      if ((!d.c) && (p == XLayoutStyle.a)) {
        a(paramInt, m);
      }
      paramLabel1 = d;
      if (!c) {
        return;
      }
      if (d == m)
      {
        a.a(k);
        c.a(j);
        return;
      }
      paramLabel1 = b;
      float f1;
      if (paramInt == 0) {
        f1 = paramLabel1.width();
      } else {
        f1 = paramLabel1.height();
      }
      paramInt = k;
      if (localLabel1 == localLabel2)
      {
        paramInt = d;
        j = d;
        f1 = 0.5F;
      }
      k = d.d;
      a.a((int)(paramInt + 0.5F + (j - paramInt - k) * f1));
      c.a(a.d + d.d);
    }
  }
  
  public final void a(Label paramLabel1, Label paramLabel2, int paramInt)
  {
    a.add(paramLabel2);
    j = paramInt;
    f.add(paramLabel1);
  }
  
  public final void a(Label paramLabel1, Label paramLabel2, int paramInt, c paramC)
  {
    a.add(paramLabel2);
    a.add(d);
    h = paramInt;
    x = paramC;
    f.add(paramLabel1);
    f.add(paramLabel1);
  }
  
  public void a(l paramL) {}
  
  public final int b(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
    {
      localF = b;
      j = o;
      paramInt2 = Math.max(l, paramInt1);
      if (j > 0) {
        paramInt2 = Math.min(j, paramInt1);
      }
      j = paramInt1;
      if (paramInt2 != paramInt1) {
        j = paramInt2;
      }
      return j;
    }
    org.codehaus.asm.asm.f localF = b;
    int j = p;
    paramInt2 = Math.max(m, paramInt1);
    if (j > 0) {
      paramInt2 = Math.min(j, paramInt1);
    }
    if (paramInt2 != paramInt1) {
      return paramInt2;
    }
    return paramInt1;
  }
  
  public long c()
  {
    c localC = d;
    if (c) {
      return d;
    }
    return 0L;
  }
  
  public abstract void d();
  
  public abstract void e();
  
  public boolean f()
  {
    return f;
  }
  
  public abstract boolean k();
  
  public void notifyDataSetChanged() {}
  
  public void setTitle() {}
}
