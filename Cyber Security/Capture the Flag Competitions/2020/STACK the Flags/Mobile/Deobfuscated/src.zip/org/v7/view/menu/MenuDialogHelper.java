package org.v7.view.menu;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import org.v7.R.layout;
import org.v7.app.AlertDialog;
import org.v7.app.AlertDialog.Builder;
import org.v7.app.AppCompatDialog;

public class MenuDialogHelper
  implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, l.a
{
  public AlertDialog mDialog;
  public MenuBuilder mMenu;
  public e mPresenter;
  
  public MenuDialogHelper(MenuBuilder paramMenuBuilder)
  {
    mMenu = paramMenuBuilder;
  }
  
  public void dismiss()
  {
    AlertDialog localAlertDialog = mDialog;
    if (localAlertDialog != null) {
      localAlertDialog.dismiss();
    }
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    mMenu.performItemAction((MenuItemImpl)((e.a)mPresenter.a()).getItem(paramInt), 0);
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    if ((paramBoolean) || (paramMenuBuilder == mMenu)) {
      dismiss();
    }
  }
  
  public void onDismiss(DialogInterface paramDialogInterface)
  {
    mPresenter.a(mMenu, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 82) || (paramInt == 4)) {
      if ((paramKeyEvent.getAction() == 0) && (paramKeyEvent.getRepeatCount() == 0))
      {
        paramDialogInterface = mDialog.getWindow();
        if (paramDialogInterface != null)
        {
          paramDialogInterface = paramDialogInterface.getDecorView();
          if (paramDialogInterface != null)
          {
            paramDialogInterface = paramDialogInterface.getKeyDispatcherState();
            if (paramDialogInterface != null)
            {
              paramDialogInterface.startTracking(paramKeyEvent, this);
              return true;
            }
          }
        }
      }
      else if ((paramKeyEvent.getAction() == 1) && (!paramKeyEvent.isCanceled()))
      {
        Object localObject = mDialog.getWindow();
        if (localObject != null)
        {
          localObject = ((Window)localObject).getDecorView();
          if (localObject != null)
          {
            localObject = ((View)localObject).getKeyDispatcherState();
            if ((localObject != null) && (((KeyEvent.DispatcherState)localObject).isTracking(paramKeyEvent)))
            {
              mMenu.close(true);
              paramDialogInterface.dismiss();
              return true;
            }
          }
        }
      }
    }
    return mMenu.performShortcut(paramInt, paramKeyEvent, 0);
  }
  
  public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
  {
    return false;
  }
  
  public void show(IBinder paramIBinder)
  {
    Object localObject1 = mMenu;
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(((MenuBuilder)localObject1).getContext());
    Object localObject2 = new e(localBuilder.getContext(), R.layout.abc_list_menu_item_layout);
    mPresenter = ((e)localObject2);
    ((e)localObject2).setCallback(this);
    mMenu.addMenuPresenter(mPresenter);
    localBuilder.setAdapter(mPresenter.a(), this);
    localObject2 = ((MenuBuilder)localObject1).getHeaderView();
    if (localObject2 != null)
    {
      localBuilder.setCustomTitle((View)localObject2);
    }
    else
    {
      localBuilder.setIcon(((MenuBuilder)localObject1).getHeaderIcon());
      localBuilder.setTitle(((MenuBuilder)localObject1).getHeaderTitle());
    }
    localBuilder.setOnKeyListener(this);
    localObject1 = localBuilder.create();
    mDialog = ((AlertDialog)localObject1);
    ((Dialog)localObject1).setOnDismissListener(this);
    localObject1 = mDialog.getWindow().getAttributes();
    type = 1003;
    if (paramIBinder != null) {
      token = paramIBinder;
    }
    flags |= 0x20000;
    mDialog.show();
  }
}
