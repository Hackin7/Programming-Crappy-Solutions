package org.v7.graphics.drawable;

public abstract class Animator
{
  public Animator() {}
  
  public boolean draw()
  {
    return false;
  }
  
  public void setDuration() {}
  
  public abstract void start();
  
  public abstract void stop();
}
