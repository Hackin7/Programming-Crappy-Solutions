package org.v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AbsSeekBar;
import android.widget.SeekBar;
import org.v7.R.attr;

public class SwitchCompat
  extends SeekBar
{
  public final AppCompatTextHelper mThumbDrawable;
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.seekBarStyle);
  }
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    ThemeUtils.init(this, getContext());
    paramContext = new AppCompatTextHelper(this);
    mThumbDrawable = paramContext;
    paramContext.loadFromAttributes(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged()
  {
    super.drawableStateChanged();
    mThumbDrawable.setState();
  }
  
  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    mThumbDrawable.jumpToCurrentState();
  }
  
  public void onDraw(Canvas paramCanvas)
  {
    try
    {
      super.onDraw(paramCanvas);
      mThumbDrawable.draw(paramCanvas);
      return;
    }
    catch (Throwable paramCanvas)
    {
      throw paramCanvas;
    }
  }
}
