package org.codehaus.asm.asm;

import a.f.b.i.e.a;

public enum XLayoutStyle
{
  static
  {
    a = new XLayoutStyle("MATCH_CONSTRAINT", 2);
    XLayoutStyle localXLayoutStyle = new XLayoutStyle("MATCH_PARENT", 3);
    r = localXLayoutStyle;
    $VALUES = new XLayoutStyle[] { b, c, a, localXLayoutStyle };
  }
}
