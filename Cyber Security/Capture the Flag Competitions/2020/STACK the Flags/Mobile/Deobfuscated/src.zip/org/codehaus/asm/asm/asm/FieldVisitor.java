package org.codehaus.asm.asm.asm;

import java.lang.ref.WeakReference;
import org.codehaus.asm.ClassWriter;
import org.codehaus.asm.asm.f;

public class FieldVisitor
{
  public FieldVisitor(i paramI, f paramF, ClassWriter paramClassWriter, int paramInt)
  {
    new WeakReference(paramF);
    paramClassWriter.b(b);
    paramClassWriter.b(a);
    paramClassWriter.b(i);
    paramClassWriter.b(g);
    paramClassWriter.b(u);
  }
}
