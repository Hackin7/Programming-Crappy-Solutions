package org.codehaus.asm.asm.asm;

import a.f.b.i.e;
import a.f.b.i.m.o.a;
import java.util.ArrayList;
import java.util.Iterator;
import org.codehaus.asm.ClassWriter;
import org.codehaus.asm.asm.ClassReader;
import org.codehaus.asm.asm.MethodWriter;
import org.codehaus.asm.asm.f;

public class i
{
  public static int a = 0;
  public int b = -1;
  public ArrayList<e> c = new ArrayList();
  public ArrayList<o.a> j = null;
  public int k = -1;
  public int l = 0;
  
  public i(int paramInt)
  {
    int i = a;
    a = i + 1;
    b = i;
    l = paramInt;
  }
  
  public int a()
  {
    return b;
  }
  
  public int a(ClassWriter paramClassWriter, int paramInt)
  {
    if (c.size() == 0) {
      return 0;
    }
    return a(paramClassWriter, c, paramInt);
  }
  
  public final int a(ClassWriter paramClassWriter, ArrayList paramArrayList, int paramInt)
  {
    MethodWriter localMethodWriter = (MethodWriter)((f)paramArrayList.get(0)).l();
    paramClassWriter.b();
    localMethodWriter.a(paramClassWriter, false);
    int i = 0;
    while (i < paramArrayList.size())
    {
      ((f)paramArrayList.get(i)).a(paramClassWriter, false);
      i += 1;
    }
    if ((paramInt == 0) && (r > 0)) {
      ClassReader.a(localMethodWriter, paramClassWriter, paramArrayList, 0);
    }
    if ((paramInt == 1) && (n > 0)) {
      ClassReader.a(localMethodWriter, paramClassWriter, paramArrayList, 1);
    }
    try
    {
      paramClassWriter.d();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    j = new ArrayList();
    i = 0;
    while (i < paramArrayList.size())
    {
      FieldVisitor localFieldVisitor = new FieldVisitor(this, (f)paramArrayList.get(i), paramClassWriter, paramInt);
      j.add(localFieldVisitor);
      i += 1;
    }
    if (paramInt == 0)
    {
      paramInt = paramClassWriter.b(b);
      i = paramClassWriter.b(i);
      paramClassWriter.b();
      return i - paramInt;
    }
    paramInt = paramClassWriter.b(a);
    i = paramClassWriter.b(g);
    paramClassWriter.b();
    return i - paramInt;
  }
  
  public void a(int paramInt)
  {
    l = paramInt;
  }
  
  public void a(int paramInt, i paramI)
  {
    Iterator localIterator = c.iterator();
    while (localIterator.hasNext())
    {
      f localF = (f)localIterator.next();
      paramI.a(localF);
      if (paramInt == 0) {
        B = paramI.a();
      } else {
        Q = paramI.a();
      }
    }
    k = b;
  }
  
  public void a(ArrayList paramArrayList)
  {
    int m = c.size();
    if ((k != -1) && (m > 0))
    {
      int i = 0;
      while (i < paramArrayList.size())
      {
        i localI = (i)paramArrayList.get(i);
        if (k == b) {
          a(l, localI);
        }
        i += 1;
      }
    }
    if (m == 0) {
      paramArrayList.remove(this);
    }
  }
  
  public void a(boolean paramBoolean) {}
  
  public boolean a(f paramF)
  {
    if (c.contains(paramF)) {
      return false;
    }
    c.add(paramF);
    return true;
  }
  
  public final String getItem()
  {
    int i = l;
    if (i == 0) {
      return "Horizontal";
    }
    if (i == 1) {
      return "Vertical";
    }
    if (i == 2) {
      return "Both";
    }
    return "Unknown";
  }
  
  public int i()
  {
    return l;
  }
  
  public String toString()
  {
    Object localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append(getItem());
    ((StringBuilder)localObject1).append(" [");
    ((StringBuilder)localObject1).append(b);
    ((StringBuilder)localObject1).append("] <");
    localObject1 = ((StringBuilder)localObject1).toString();
    Object localObject2 = c.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      f localF = (f)((Iterator)localObject2).next();
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append((String)localObject1);
      localStringBuilder.append(" ");
      localStringBuilder.append(localF.getString());
      localObject1 = localStringBuilder.toString();
    }
    localObject2 = new StringBuilder();
    ((StringBuilder)localObject2).append((String)localObject1);
    ((StringBuilder)localObject2).append(" >");
    return ((StringBuilder)localObject2).toString();
  }
}
