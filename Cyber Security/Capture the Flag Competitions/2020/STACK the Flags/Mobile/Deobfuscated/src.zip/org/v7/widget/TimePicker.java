package org.v7.widget;

import android.content.res.ColorStateList;
import android.content.res.Resources.NotFoundException;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Locale;
import org.core.view.ViewCompat;
import org.core.widget.Label;
import org.core.widget.MonthAdapter.CalendarDay;
import org.v7.R.styleable;

public class TimePicker
{
  public final Slider a;
  public boolean i;
  public int icon = -1;
  public TintInfo mBackgroundTint;
  public TintInfo mDrawableBottomTint;
  public TintInfo mDrawableEndTint;
  public TintInfo mDrawableLeftTint;
  public TintInfo mDrawableRightTint;
  public TintInfo mDrawableStartTint;
  public TintInfo mDrawableTopTint;
  public Typeface mTypeface;
  public final TextView textView;
  public int type = 0;
  
  public TimePicker(TextView paramTextView)
  {
    textView = paramTextView;
    a = new Slider(textView);
  }
  
  public static TintInfo createTintInfo(android.content.Context paramContext, Context paramContext1, int paramInt)
  {
    paramContext = paramContext1.getTintList(paramContext, paramInt);
    if (paramContext != null)
    {
      paramContext1 = new TintInfo();
      mHasTintList = true;
      mTintList = paramContext;
      return paramContext1;
    }
    return null;
  }
  
  public final void applyCompoundDrawableTint(Drawable paramDrawable, TintInfo paramTintInfo)
  {
    if ((paramDrawable != null) && (paramTintInfo != null)) {
      Context.tintDrawable(paramDrawable, paramTintInfo, textView.getDrawableState());
    }
  }
  
  public void applyCompoundDrawablesTints()
  {
    Drawable[] arrayOfDrawable;
    if ((mDrawableEndTint != null) || (mDrawableLeftTint != null) || (mDrawableTopTint != null) || (mDrawableRightTint != null))
    {
      arrayOfDrawable = textView.getCompoundDrawables();
      applyCompoundDrawableTint(arrayOfDrawable[0], mDrawableEndTint);
      applyCompoundDrawableTint(arrayOfDrawable[1], mDrawableLeftTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], mDrawableTopTint);
      applyCompoundDrawableTint(arrayOfDrawable[3], mDrawableRightTint);
    }
    if ((mDrawableBottomTint != null) || (mDrawableStartTint != null))
    {
      arrayOfDrawable = textView.getCompoundDrawablesRelative();
      applyCompoundDrawableTint(arrayOfDrawable[0], mDrawableBottomTint);
      applyCompoundDrawableTint(arrayOfDrawable[2], mDrawableStartTint);
    }
  }
  
  public int applyStyle()
  {
    return a.start();
  }
  
  public void applyStyle(android.content.Context paramContext, int paramInt)
  {
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramInt, R.styleable.TextAppearance);
    if (localTintTypedArray.hasValue(R.styleable.TextAppearance_textAllCaps)) {
      setEnabled(localTintTypedArray.getBoolean(R.styleable.TextAppearance_textAllCaps, false));
    }
    if ((Build.VERSION.SDK_INT < 23) && (localTintTypedArray.hasValue(R.styleable.TextAppearance_android_textColor)))
    {
      ColorStateList localColorStateList = localTintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
      if (localColorStateList != null) {
        textView.setTextColor(localColorStateList);
      }
    }
    if ((localTintTypedArray.hasValue(R.styleable.TextAppearance_android_textSize)) && (localTintTypedArray.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0)) {
      textView.setTextSize(0, 0.0F);
    }
    init(paramContext, localTintTypedArray);
    if ((Build.VERSION.SDK_INT >= 26) && (localTintTypedArray.hasValue(R.styleable.TextAppearance_fontVariationSettings)))
    {
      paramContext = localTintTypedArray.getString(R.styleable.TextAppearance_fontVariationSettings);
      if (paramContext != null) {
        textView.setFontVariationSettings(paramContext);
      }
    }
    localTintTypedArray.recycle();
    paramContext = mTypeface;
    if (paramContext != null) {
      textView.setTypeface(paramContext, type);
    }
  }
  
  public int getCurrentHour()
  {
    return a.compareTo();
  }
  
  public int[] getHour()
  {
    return a.get();
  }
  
  public int getHours()
  {
    return a.getValue();
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    TintInfo localTintInfo = mBackgroundTint;
    if (localTintInfo != null) {
      return mTintMode;
    }
    return null;
  }
  
  public ColorStateList getTypeface()
  {
    TintInfo localTintInfo = mBackgroundTint;
    if (localTintInfo != null) {
      return mTintList;
    }
    return null;
  }
  
  public final void init(android.content.Context paramContext, TintTypedArray paramTintTypedArray)
  {
    type = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textStyle, type);
    int j = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    TimePicker localTimePicker = this;
    if (j >= 28)
    {
      j = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textFontWeight, -1);
      icon = j;
      localTimePicker = this;
      if (j != -1)
      {
        j = type;
        localTimePicker = this;
        type = (j & 0x2 | 0x0);
      }
    }
    if ((!paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_fontFamily)) && (!paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)))
    {
      if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_typeface))
      {
        i = false;
        j = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_typeface, 1);
        if (j != 1)
        {
          if (j != 2)
          {
            if (j != 3) {
              return;
            }
            mTypeface = Typeface.MONOSPACE;
            return;
          }
          mTypeface = Typeface.SERIF;
          return;
        }
        mTypeface = Typeface.SANS_SERIF;
      }
    }
    else
    {
      mTypeface = null;
      if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
        j = R.styleable.TextAppearance_fontFamily;
      } else {
        j = R.styleable.TextAppearance_android_fontFamily;
      }
      int k = icon;
      int m = type;
      boolean bool1;
      if (!paramContext.isRestricted())
      {
        paramContext = new ClassWriter(localTimePicker, k, m, new WeakReference(textView));
        k = type;
        try
        {
          paramContext = paramTintTypedArray.getString(j, k, paramContext);
          if (paramContext != null) {
            if ((Build.VERSION.SDK_INT >= 28) && (icon != -1))
            {
              paramContext = Typeface.create(paramContext, 0);
              k = icon;
              if ((type & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              }
              paramContext = Typeface.create(paramContext, k, bool1);
              mTypeface = paramContext;
            }
            else
            {
              mTypeface = paramContext;
            }
          }
          if (mTypeface == null) {
            bool1 = true;
          } else {
            bool1 = false;
          }
          i = bool1;
        }
        catch (Resources.NotFoundException paramContext) {}catch (UnsupportedOperationException paramContext) {}
      }
      if (mTypeface == null)
      {
        paramTintTypedArray = paramTintTypedArray.getString(j);
        if (paramTintTypedArray != null)
        {
          paramContext = localTimePicker;
          if (Build.VERSION.SDK_INT >= 28)
          {
            j = icon;
            paramContext = localTimePicker;
            if (j != -1)
            {
              paramContext = Typeface.create(paramTintTypedArray, 0);
              j = icon;
              bool1 = bool2;
              if ((0x2 & type) != 0) {
                bool1 = true;
              }
              mTypeface = Typeface.create(paramContext, j, bool1);
              return;
            }
          }
          mTypeface = Typeface.create(paramTintTypedArray, type);
        }
      }
    }
  }
  
  public void init(AttributeSet paramAttributeSet, int paramInt)
  {
    android.content.Context localContext1 = textView.getContext();
    Context localContext = Context.get();
    Object localObject1 = TintTypedArray.obtainStyledAttributes(localContext1, paramAttributeSet, R.styleable.AppCompatTextHelper, paramInt, 0);
    Object localObject2 = textView;
    ViewCompat.obtainStyledAttributes((View)localObject2, ((View)localObject2).getContext(), R.styleable.AppCompatTextHelper, paramAttributeSet, ((TintTypedArray)localObject1).getResourceId(), paramInt, 0);
    int m = ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_textAppearance, -1);
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableLeft)) {
      mDrawableEndTint = createTintInfo(localContext1, localContext, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableLeft, 0));
    }
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableTop)) {
      mDrawableLeftTint = createTintInfo(localContext1, localContext, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableTop, 0));
    }
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableRight)) {
      mDrawableTopTint = createTintInfo(localContext1, localContext, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableRight, 0));
    }
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableBottom)) {
      mDrawableRightTint = createTintInfo(localContext1, localContext, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableBottom, 0));
    }
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableStart)) {
      mDrawableBottomTint = createTintInfo(localContext1, localContext, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableStart, 0));
    }
    if (((TintTypedArray)localObject1).hasValue(R.styleable.AppCompatTextHelper_android_drawableEnd)) {
      mDrawableStartTint = createTintInfo(localContext1, localContext, ((TintTypedArray)localObject1).getResourceId(R.styleable.AppCompatTextHelper_android_drawableEnd, 0));
    }
    ((TintTypedArray)localObject1).recycle();
    boolean bool3 = textView.getTransformationMethod() instanceof PasswordTransformationMethod;
    boolean bool1 = false;
    boolean bool2 = false;
    int j = 0;
    int k = 0;
    Object localObject11 = null;
    localObject2 = null;
    Object localObject9 = null;
    Object localObject10 = null;
    localObject1 = null;
    TintTypedArray localTintTypedArray1 = null;
    Object localObject5 = null;
    Object localObject8 = null;
    Object localObject3 = null;
    Object localObject6 = null;
    Object localObject4 = null;
    Object localObject7 = null;
    if (m != -1)
    {
      TintTypedArray localTintTypedArray2 = TintTypedArray.obtainStyledAttributes(localContext1, m, R.styleable.TextAppearance);
      bool1 = bool2;
      j = k;
      if (!bool3)
      {
        bool1 = bool2;
        j = k;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_textAllCaps))
        {
          j = 1;
          bool1 = localTintTypedArray2.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
        }
      }
      init(localContext1, localTintTypedArray2);
      localObject2 = localObject11;
      localObject1 = localObject10;
      localObject5 = localObject8;
      if (Build.VERSION.SDK_INT < 23)
      {
        localObject3 = localObject9;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColor)) {
          localObject3 = localTintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColor);
        }
        localObject4 = localTintTypedArray1;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColorHint)) {
          localObject4 = localTintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
        }
        localObject2 = localObject3;
        localObject1 = localObject4;
        localObject5 = localObject8;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColorLink))
        {
          localObject5 = localTintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
          localObject1 = localObject4;
          localObject2 = localObject3;
        }
      }
      localObject4 = localObject7;
      if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_textLocale)) {
        localObject4 = localTintTypedArray2.getString(R.styleable.TextAppearance_textLocale);
      }
      localObject3 = localObject6;
      if (Build.VERSION.SDK_INT >= 26)
      {
        localObject3 = localObject6;
        if (localTintTypedArray2.hasValue(R.styleable.TextAppearance_fontVariationSettings)) {
          localObject3 = localTintTypedArray2.getString(R.styleable.TextAppearance_fontVariationSettings);
        }
      }
      localTintTypedArray2.recycle();
    }
    localTintTypedArray1 = TintTypedArray.obtainStyledAttributes(localContext1, paramAttributeSet, R.styleable.TextAppearance, paramInt, 0);
    bool2 = bool1;
    k = j;
    if (!bool3)
    {
      bool2 = bool1;
      k = j;
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_textAllCaps))
      {
        bool2 = localTintTypedArray1.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
        k = 1;
      }
    }
    localObject6 = localObject2;
    localObject7 = localObject1;
    localObject8 = localObject5;
    if (Build.VERSION.SDK_INT < 23)
    {
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textColor)) {
        localObject2 = localTintTypedArray1.getColorStateList(R.styleable.TextAppearance_android_textColor);
      }
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textColorHint)) {
        localObject1 = localTintTypedArray1.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
      }
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textColorLink))
      {
        localObject8 = localTintTypedArray1.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
        localObject6 = localObject2;
        localObject7 = localObject1;
      }
      else
      {
        localObject6 = localObject2;
        localObject7 = localObject1;
        localObject8 = localObject5;
      }
    }
    if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_textLocale)) {
      localObject4 = localTintTypedArray1.getString(R.styleable.TextAppearance_textLocale);
    }
    localObject1 = localObject3;
    if (Build.VERSION.SDK_INT >= 26)
    {
      localObject1 = localObject3;
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_fontVariationSettings)) {
        localObject1 = localTintTypedArray1.getString(R.styleable.TextAppearance_fontVariationSettings);
      }
    }
    if (Build.VERSION.SDK_INT >= 28) {
      if (localTintTypedArray1.hasValue(R.styleable.TextAppearance_android_textSize))
      {
        if (localTintTypedArray1.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0) {
          textView.setTextSize(0, 0.0F);
        }
      }
      else {}
    }
    init(localContext1, localTintTypedArray1);
    localTintTypedArray1.recycle();
    if (localObject6 != null) {
      textView.setTextColor((ColorStateList)localObject6);
    }
    if (localObject7 != null) {
      textView.setHintTextColor(localObject7);
    }
    if (localObject8 != null) {
      textView.setLinkTextColor((ColorStateList)localObject8);
    }
    if ((!bool3) && (k != 0)) {
      setEnabled(bool2);
    }
    localObject2 = mTypeface;
    if (localObject2 != null) {
      if (icon == -1) {
        textView.setTypeface((Typeface)localObject2, type);
      } else {
        textView.setTypeface((Typeface)localObject2);
      }
    }
    if (localObject1 != null) {
      textView.setFontVariationSettings((String)localObject1);
    }
    if (localObject4 != null) {
      if (Build.VERSION.SDK_INT >= 24)
      {
        textView.setTextLocales(LocaleList.forLanguageTags((String)localObject4));
      }
      else
      {
        localObject1 = ((String)localObject4).substring(0, ((String)localObject4).indexOf(','));
        textView.setTextLocale(Locale.forLanguageTag((String)localObject1));
      }
    }
    a.init(paramAttributeSet, paramInt);
    if (MonthAdapter.CalendarDay.$assertionsDisabled) {
      if (a.setValue() != 0)
      {
        localObject1 = a.get();
        if (localObject1.length > 0) {
          if (textView.getAutoSizeStepGranularity() != -1.0F) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(a.getValue(), a.compareTo(), a.start(), 0);
          } else {
            textView.setAutoSizeTextTypeUniformWithPresetSizes((int[])localObject1, 0);
          }
        }
      }
      else {}
    }
    localObject6 = TintTypedArray.obtainStyledAttributes(localContext1, paramAttributeSet, R.styleable.AppCompatTextView);
    localObject4 = null;
    localObject5 = null;
    paramAttributeSet = null;
    paramInt = R.styleable.AppCompatTextView_drawableLeftCompat;
    localObject1 = null;
    paramInt = ((TintTypedArray)localObject6).getResourceId(paramInt, -1);
    if (paramInt != -1) {
      paramAttributeSet = localContext.getDrawable(localContext1, paramInt);
    }
    paramInt = R.styleable.AppCompatTextView_drawableTopCompat;
    localObject2 = null;
    paramInt = ((TintTypedArray)localObject6).getResourceId(paramInt, -1);
    if (paramInt != -1) {
      localObject1 = localContext.getDrawable(localContext1, paramInt);
    }
    paramInt = ((TintTypedArray)localObject6).getResourceId(R.styleable.AppCompatTextView_drawableRightCompat, -1);
    if (paramInt != -1) {
      localObject2 = localContext.getDrawable(localContext1, paramInt);
    }
    paramInt = ((TintTypedArray)localObject6).getResourceId(R.styleable.AppCompatTextView_drawableBottomCompat, -1);
    if (paramInt != -1) {
      localObject3 = localContext.getDrawable(localContext1, paramInt);
    } else {
      localObject3 = null;
    }
    paramInt = ((TintTypedArray)localObject6).getResourceId(R.styleable.AppCompatTextView_drawableStartCompat, -1);
    if (paramInt != -1) {
      localObject4 = localContext.getDrawable(localContext1, paramInt);
    }
    paramInt = ((TintTypedArray)localObject6).getResourceId(R.styleable.AppCompatTextView_drawableEndCompat, -1);
    if (paramInt != -1) {
      localObject5 = localContext.getDrawable(localContext1, paramInt);
    }
    update(paramAttributeSet, (Drawable)localObject1, (Drawable)localObject2, (Drawable)localObject3, (Drawable)localObject4, (Drawable)localObject5);
    if (((TintTypedArray)localObject6).hasValue(R.styleable.AppCompatTextView_drawableTint))
    {
      paramAttributeSet = ((TintTypedArray)localObject6).getColorStateList(R.styleable.AppCompatTextView_drawableTint);
      Label.setup(textView, paramAttributeSet);
    }
    if (((TintTypedArray)localObject6).hasValue(R.styleable.AppCompatTextView_drawableTintMode))
    {
      paramAttributeSet = DrawableUtils.parseTintMode(((TintTypedArray)localObject6).getInt(R.styleable.AppCompatTextView_drawableTintMode, -1), null);
      Label.setup(textView, paramAttributeSet);
    }
    paramInt = ((TintTypedArray)localObject6).getDimensionPixelSize(R.styleable.AppCompatTextView_firstBaselineToTopHeight, -1);
    j = ((TintTypedArray)localObject6).getDimensionPixelSize(R.styleable.AppCompatTextView_lastBaselineToBottomHeight, -1);
    k = ((TintTypedArray)localObject6).getDimensionPixelSize(R.styleable.AppCompatTextView_lineHeight, -1);
    ((TintTypedArray)localObject6).recycle();
    if (paramInt != -1) {
      Label.a(textView, paramInt);
    }
    if (j != -1) {
      Label.setText(textView, j);
    }
    if (k != -1) {
      Label.setup(textView, k);
    }
  }
  
  public void init(WeakReference paramWeakReference, Typeface paramTypeface)
  {
    if (i)
    {
      mTypeface = paramTypeface;
      paramWeakReference = (TextView)paramWeakReference.get();
      if (paramWeakReference != null) {
        paramWeakReference.setTypeface(paramTypeface, type);
      }
    }
  }
  
  public final void loadFromAttributes()
  {
    TintInfo localTintInfo = mBackgroundTint;
    mDrawableEndTint = localTintInfo;
    mDrawableLeftTint = localTintInfo;
    mDrawableTopTint = localTintInfo;
    mDrawableRightTint = localTintInfo;
    mDrawableBottomTint = localTintInfo;
    mDrawableStartTint = localTintInfo;
  }
  
  public int onSaveInstanceState()
  {
    return a.setValue();
  }
  
  public void onSaveInstanceState(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    a.draw(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds()
  {
    applyCompoundDrawablesTints();
  }
  
  public void setCurrentHour(int paramInt)
  {
    a.draw(paramInt);
  }
  
  public void setEnabled()
  {
    a.draw();
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    textView.setAllCaps(paramBoolean);
  }
  
  public void setEnabled(int[] paramArrayOfInt, int paramInt)
  {
    a.init(paramArrayOfInt, paramInt);
  }
  
  public void setMinute(ColorStateList paramColorStateList)
  {
    if (mBackgroundTint == null) {
      mBackgroundTint = new TintInfo();
    }
    TintInfo localTintInfo = mBackgroundTint;
    mTintList = paramColorStateList;
    boolean bool;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    }
    mHasTintList = bool;
    loadFromAttributes();
  }
  
  public void setMinute(PorterDuff.Mode paramMode)
  {
    if (mBackgroundTint == null) {
      mBackgroundTint = new TintInfo();
    }
    TintInfo localTintInfo = mBackgroundTint;
    mTintMode = paramMode;
    boolean bool;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    }
    mHasTintMode = bool;
    loadFromAttributes();
  }
  
  public void setTime()
  {
    if (!MonthAdapter.CalendarDay.$assertionsDisabled) {
      setEnabled();
    }
  }
  
  public void setTime(int paramInt, float paramFloat)
  {
    if ((!MonthAdapter.CalendarDay.$assertionsDisabled) && (!update())) {
      update(paramInt, paramFloat);
    }
  }
  
  public final void update(int paramInt, float paramFloat)
  {
    a.init(paramInt, paramFloat);
  }
  
  public final void update(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6)
  {
    if ((paramDrawable5 == null) && (paramDrawable6 == null))
    {
      if ((paramDrawable1 == null) && (paramDrawable2 == null) && (paramDrawable3 == null) && (paramDrawable4 == null)) {
        return;
      }
      paramDrawable5 = textView.getCompoundDrawablesRelative();
      if ((paramDrawable5[0] == null) && (paramDrawable5[2] == null))
      {
        paramDrawable6 = textView.getCompoundDrawables();
        paramDrawable5 = textView;
        if (paramDrawable1 == null) {
          paramDrawable1 = paramDrawable6[0];
        }
        if (paramDrawable2 == null) {
          paramDrawable2 = paramDrawable6[1];
        }
        if (paramDrawable3 == null) {
          paramDrawable3 = paramDrawable6[2];
        }
        if (paramDrawable4 == null) {
          paramDrawable4 = paramDrawable6[3];
        }
        paramDrawable5.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
        return;
      }
      paramDrawable1 = textView;
      paramDrawable3 = paramDrawable5[0];
      if (paramDrawable2 == null) {
        paramDrawable2 = paramDrawable5[1];
      }
      paramDrawable6 = paramDrawable5[2];
      if (paramDrawable4 == null) {
        paramDrawable4 = paramDrawable5[3];
      }
      paramDrawable1.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable3, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    }
    Drawable[] arrayOfDrawable = textView.getCompoundDrawablesRelative();
    TextView localTextView = textView;
    if (paramDrawable5 != null) {
      paramDrawable1 = paramDrawable5;
    } else {
      paramDrawable1 = arrayOfDrawable[0];
    }
    if (paramDrawable2 == null) {
      paramDrawable2 = arrayOfDrawable[1];
    }
    if (paramDrawable6 != null) {
      paramDrawable3 = paramDrawable6;
    } else {
      paramDrawable3 = arrayOfDrawable[2];
    }
    if (paramDrawable4 == null) {
      paramDrawable4 = arrayOfDrawable[3];
    }
    localTextView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }
  
  public boolean update()
  {
    return a.create();
  }
}
