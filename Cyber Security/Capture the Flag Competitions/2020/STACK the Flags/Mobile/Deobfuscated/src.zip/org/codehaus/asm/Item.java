package org.codehaus.asm;

import a.f.b.b;
import a.f.b.e;
import a.f.b.h;

public class Item
{
  public e<b> a = new MethodWriter(256);
  public e<h> b = new MethodWriter(256);
  public e<b> c = new MethodWriter(256);
  public Label[] d = new Label[32];
  
  public Item() {}
}
