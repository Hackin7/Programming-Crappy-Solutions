package org.v7.widget;

import android.content.Context;
import android.view.View;
import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import org.core.data.Item;

public final class ClassReader
{
  public TextView a;
  public TextClassifier b;
  
  public ClassReader(TextView paramTextView)
  {
    Item.invoke(paramTextView);
    a = ((TextView)paramTextView);
  }
  
  public TextClassifier a()
  {
    TextClassifier localTextClassifier = b;
    Object localObject = localTextClassifier;
    if (localTextClassifier == null)
    {
      localObject = (TextClassificationManager)a.getContext().getSystemService(TextClassificationManager.class);
      if (localObject != null) {
        return ((TextClassificationManager)localObject).getTextClassifier();
      }
      localObject = TextClassifier.NO_OP;
    }
    return localObject;
  }
  
  public void b(TextClassifier paramTextClassifier)
  {
    b = paramTextClassifier;
  }
}
