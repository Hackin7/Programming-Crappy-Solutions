package org.jdom;

public abstract interface CharSequence {}
