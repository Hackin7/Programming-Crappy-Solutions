package org.util;

import a.m.c;
import a.m.f;
import androidx.lifecycle.CompositeGeneratedAdaptersObserver;
import androidx.lifecycle.FullLifecycleObserverAdapter;
import androidx.lifecycle.ReflectiveGenericLifecycleObserver;
import androidx.lifecycle.SingleGeneratedAdapterObserver;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Frame
{
  public static Map<Class, List<Constructor<? extends c>>> b = new HashMap();
  public static Map<Class, Integer> c = new HashMap();
  
  public static int a(Class paramClass)
  {
    if (paramClass.getCanonicalName() == null) {
      return 1;
    }
    Object localObject1 = get(paramClass);
    if (localObject1 != null)
    {
      b.put(paramClass, Collections.singletonList(localObject1));
      return 2;
    }
    if (ClassWriter.b.a(paramClass)) {
      return 1;
    }
    Object localObject2 = paramClass.getSuperclass();
    localObject1 = null;
    if (isPrimitive((Class)localObject2))
    {
      if (d((Class)localObject2) == 1) {
        return 1;
      }
      localObject1 = new ArrayList((Collection)b.get(localObject2));
    }
    Class[] arrayOfClass = paramClass.getInterfaces();
    int j = arrayOfClass.length;
    int i = 0;
    while (i < j)
    {
      Class localClass = arrayOfClass[i];
      if (isPrimitive(localClass))
      {
        if (d(localClass) == 1) {
          return 1;
        }
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new ArrayList();
        }
        ((List)localObject2).addAll((Collection)b.get(localClass));
        localObject1 = localObject2;
      }
      i += 1;
    }
    if (localObject1 != null)
    {
      b.put(paramClass, localObject1);
      return 2;
    }
    return 1;
  }
  
  public static MenuItem a(Object paramObject)
  {
    boolean bool1 = paramObject instanceof MenuItem;
    boolean bool2 = paramObject instanceof h;
    if ((bool1) && (bool2)) {
      return new FullLifecycleObserverAdapter((h)paramObject, (MenuItem)paramObject);
    }
    if (bool2) {
      return new FullLifecycleObserverAdapter((h)paramObject, null);
    }
    if (bool1) {
      return (MenuItem)paramObject;
    }
    Object localObject = paramObject.getClass();
    if (d((Class)localObject) == 2)
    {
      localObject = (List)b.get(localObject);
      if (((List)localObject).size() == 1) {
        return new SingleGeneratedAdapterObserver(get((Constructor)((List)localObject).get(0), paramObject));
      }
      Attribute[] arrayOfAttribute = new Attribute[((List)localObject).size()];
      int i = 0;
      while (i < ((List)localObject).size())
      {
        arrayOfAttribute[i] = get((Constructor)((List)localObject).get(i), paramObject);
        i += 1;
      }
      return new CompositeGeneratedAdaptersObserver(arrayOfAttribute);
    }
    return new ReflectiveGenericLifecycleObserver(paramObject);
  }
  
  public static int d(Class paramClass)
  {
    Integer localInteger = (Integer)c.get(paramClass);
    if (localInteger != null) {
      return localInteger.intValue();
    }
    int i = a(paramClass);
    c.put(paramClass, Integer.valueOf(i));
    return i;
  }
  
  public static String get(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramString.replace(".", "_"));
    localStringBuilder.append("_LifecycleAdapter");
    return localStringBuilder.toString();
  }
  
  public static Constructor get(Class paramClass)
  {
    try
    {
      Object localObject = paramClass.getPackage();
      String str = paramClass.getCanonicalName();
      if (localObject != null) {
        localObject = ((Package)localObject).getName();
      } else {
        localObject = "";
      }
      boolean bool = ((String)localObject).isEmpty();
      if (!bool)
      {
        int i = ((String)localObject).length();
        str = str.substring(i + 1);
      }
      str = get(str);
      bool = ((String)localObject).isEmpty();
      if (bool)
      {
        localObject = str;
      }
      else
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append((String)localObject);
        localStringBuilder.append(".");
        localStringBuilder.append(str);
        localObject = localStringBuilder.toString();
      }
      localObject = Class.forName((String)localObject);
      paramClass = ((Class)localObject).getDeclaredConstructor(new Class[] { paramClass });
      bool = paramClass.isAccessible();
      if (!bool)
      {
        paramClass.setAccessible(true);
        return paramClass;
      }
    }
    catch (NoSuchMethodException paramClass)
    {
      throw new RuntimeException(paramClass);
    }
    catch (ClassNotFoundException paramClass)
    {
      return null;
    }
    return paramClass;
  }
  
  public static Attribute get(Constructor paramConstructor, Object paramObject)
  {
    try
    {
      paramConstructor = paramConstructor.newInstance(new Object[] { paramObject });
      return (Attribute)paramConstructor;
    }
    catch (InvocationTargetException paramConstructor)
    {
      throw new RuntimeException(paramConstructor);
    }
    catch (InstantiationException paramConstructor)
    {
      throw new RuntimeException(paramConstructor);
    }
    catch (IllegalAccessException paramConstructor)
    {
      throw new RuntimeException(paramConstructor);
    }
  }
  
  public static boolean isPrimitive(Class paramClass)
  {
    return (paramClass != null) && (f.class.isAssignableFrom(paramClass));
  }
}
