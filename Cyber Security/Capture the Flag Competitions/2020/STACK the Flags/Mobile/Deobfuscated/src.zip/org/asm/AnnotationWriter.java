package org.asm;

public class AnnotationWriter
  extends p
{
  public AnnotationWriter(h paramH, l paramL) {}
  
  public void a(l paramL)
  {
    h.draw();
    paramL.b(this);
  }
}
