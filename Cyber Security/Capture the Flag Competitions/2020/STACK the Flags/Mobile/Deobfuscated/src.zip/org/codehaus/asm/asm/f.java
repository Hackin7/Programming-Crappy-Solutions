package org.codehaus.asm.asm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.codehaus.asm.ClassWriter;
import org.codehaus.asm.Item;
import org.codehaus.asm.asm.asm.m;

public class f
{
  public static float threshold = 0.5F;
  public float[] A;
  public int B;
  public boolean[] C = { 1, 1 };
  public int D;
  public float E;
  public int[] FILL = { 0, 0, 0, 0 };
  public boolean[] G;
  public f[] H;
  public boolean I = false;
  public boolean J = false;
  public boolean K = true;
  public Label M = new Label(this, c.f);
  public Label N;
  public int[] P = new int[2];
  public int Q;
  public Label V = new Label(this, c.c);
  public Label a = new Label(this, c.a);
  public Label b = new Label(this, c.d);
  public int bottom;
  public XLayoutStyle[] c;
  public int count;
  public boolean d = false;
  public int[] data = { Integer.MAX_VALUE, Integer.MAX_VALUE };
  public org.codehaus.asm.asm.asm.d e = null;
  public org.codehaus.asm.asm.asm.f f = null;
  public int flags = -1;
  public Label g = new Label(this, c.b);
  public int h = 0;
  public boolean header = false;
  public float height;
  public Label i = new Label(this, c.i);
  public int idx = 0;
  public int index;
  public float j = 1.0F;
  public int k = 0;
  public int l = 0;
  public boolean last = false;
  public int left;
  public m length;
  public int m = 0;
  public boolean mOverrideVisibleItems;
  public f n;
  public m next;
  public int o = 0;
  public int p = 0;
  public String parent;
  public int ptr = 0;
  public float q = 1.0F;
  public Label[] r;
  public f[] right;
  public int s;
  public float scale = 0.0F;
  public float size;
  public boolean state = true;
  public int t;
  public ArrayList<a.f.b.i.d> this$0;
  public int top;
  public int type = -1;
  public Label u = new Label(this, c.g);
  public Object userData;
  public int v;
  public String value;
  public boolean w = false;
  public int width;
  public int x = -1;
  public int y;
  public float z = 1.0F;
  
  public f()
  {
    Object localObject = new Label(this, c.l);
    N = ((Label)localObject);
    r = new Label[] { b, i, a, g, u, localObject };
    this$0 = new ArrayList();
    G = new boolean[2];
    localObject = XLayoutStyle.b;
    c = new XLayoutStyle[] { localObject, localObject };
    n = null;
    s = 0;
    v = 0;
    E = 0.0F;
    D = -1;
    t = 0;
    y = 0;
    bottom = 0;
    size = 0.5F;
    height = 0.5F;
    left = 0;
    value = null;
    parent = null;
    index = 0;
    count = 0;
    A = new float[] { -1.0F, -1.0F };
    H = new f[] { null, null };
    right = new f[] { null, null };
    B = -1;
    Q = -1;
    reset();
  }
  
  public Label a(c paramC)
  {
    switch (paramC.ordinal())
    {
    default: 
      throw new AssertionError(paramC.name());
    case 0: 
      return null;
    case 8: 
      return M;
    case 7: 
      return V;
    case 6: 
      return N;
    case 5: 
      return u;
    case 4: 
      return g;
    case 3: 
      return i;
    case 2: 
      return a;
    }
    return b;
  }
  
  public void a(int paramInt1, int paramInt2)
  {
    b.a(paramInt1);
    i.a(paramInt2);
    t = paramInt1;
    s = (paramInt2 - paramInt1);
    J = true;
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, float paramFloat)
  {
    h = paramInt1;
    m = paramInt2;
    if (paramInt3 == Integer.MAX_VALUE) {
      paramInt3 = 0;
    }
    p = paramInt3;
    q = paramFloat;
    if ((paramFloat > 0.0F) && (paramFloat < 1.0F) && (h == 0)) {
      h = 2;
    }
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i1 = paramInt3 - paramInt1;
    paramInt3 = paramInt4 - paramInt2;
    t = paramInt1;
    y = paramInt2;
    if (left == 8)
    {
      s = 0;
      v = 0;
      return;
    }
    paramInt1 = i1;
    if (c[0] == XLayoutStyle.b)
    {
      paramInt1 = i1;
      if (i1 < s) {
        paramInt1 = s;
      }
    }
    paramInt2 = paramInt3;
    if (c[1] == XLayoutStyle.b)
    {
      paramInt2 = paramInt3;
      if (paramInt3 < v) {
        paramInt2 = v;
      }
    }
    s = paramInt1;
    v = paramInt2;
    paramInt1 = width;
    if (paramInt2 < paramInt1) {
      v = paramInt1;
    }
    paramInt1 = s;
    paramInt2 = top;
    if (paramInt1 < paramInt2) {
      s = paramInt2;
    }
  }
  
  public void a(Object paramObject)
  {
    userData = paramObject;
  }
  
  public void a(ClassWriter paramClassWriter, boolean paramBoolean)
  {
    org.codehaus.asm.Label localLabel1 = paramClassWriter.a(b);
    org.codehaus.asm.Label localLabel2 = paramClassWriter.a(i);
    Object localObject5 = paramClassWriter.a(a);
    Object localObject4 = paramClassWriter.a(g);
    Object localObject3 = paramClassWriter.a(u);
    Object localObject1 = n;
    boolean bool1;
    boolean bool4;
    boolean bool3;
    if (localObject1 != null)
    {
      if ((localObject1 != null) && (c[0] == XLayoutStyle.c)) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      bool4 = bool1;
      localObject1 = n;
      if ((localObject1 != null) && (c[1] == XLayoutStyle.c)) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      bool3 = bool1;
    }
    else
    {
      bool4 = false;
      bool3 = false;
    }
    if ((left == 8) && (!add()))
    {
      localObject1 = G;
      if ((localObject1[0] == 0) && (localObject1[1] == 0)) {
        return;
      }
    }
    if ((J) || (w))
    {
      if (J)
      {
        paramClassWriter.a(localLabel1, t);
        paramClassWriter.a(localLabel2, t + s);
        if (bool4)
        {
          localObject1 = n;
          if (localObject1 != null) {
            if (K)
            {
              localObject1 = (MethodWriter)localObject1;
              ((MethodWriter)localObject1).b(b);
              ((MethodWriter)localObject1).e(i);
            }
            else
            {
              paramClassWriter.b(paramClassWriter.a(i), localLabel2, 0, 5);
            }
          }
        }
      }
      if (w)
      {
        paramClassWriter.a((org.codehaus.asm.Label)localObject5, y);
        paramClassWriter.a((org.codehaus.asm.Label)localObject4, y + v);
        if (u.add()) {
          paramClassWriter.a((org.codehaus.asm.Label)localObject3, y + bottom);
        }
        if (bool3)
        {
          localObject1 = n;
          if (localObject1 != null) {
            if (K)
            {
              localObject1 = (MethodWriter)localObject1;
              ((MethodWriter)localObject1).b(a);
              ((MethodWriter)localObject1).a(g);
            }
            else
            {
              paramClassWriter.b(paramClassWriter.a(g), (org.codehaus.asm.Label)localObject4, 0, 5);
            }
          }
        }
      }
      if ((J) && (w))
      {
        J = false;
        w = false;
        return;
      }
    }
    if (paramBoolean)
    {
      localObject1 = f;
      if (localObject1 != null)
      {
        localObject2 = e;
        if (localObject2 != null)
        {
          localObject6 = a;
          if ((c) && (c.c) && (a.c) && (c.c))
          {
            paramClassWriter.a(localLabel1, d);
            paramClassWriter.a(localLabel2, f.c.d);
            paramClassWriter.a((org.codehaus.asm.Label)localObject5, e.a.d);
            paramClassWriter.a((org.codehaus.asm.Label)localObject4, e.c.d);
            paramClassWriter.a((org.codehaus.asm.Label)localObject3, e.a.d);
            if (n != null)
            {
              if ((bool4) && (C[0] != 0) && (!f())) {
                paramClassWriter.b(paramClassWriter.a(n.i), localLabel2, 0, 8);
              }
              if ((bool3) && (C[1] != 0) && (!c())) {
                paramClassWriter.b(paramClassWriter.a(n.g), (org.codehaus.asm.Label)localObject4, 0, 8);
              }
            }
            J = false;
            w = false;
            return;
          }
        }
      }
    }
    boolean bool2;
    boolean bool5;
    if (n != null)
    {
      if (getColor(0))
      {
        ((MethodWriter)n).a(this, 0);
        bool1 = true;
      }
      else
      {
        bool1 = f();
      }
      if (getColor(1))
      {
        ((MethodWriter)n).a(this, 1);
        bool2 = true;
      }
      else
      {
        bool2 = c();
      }
      if ((!bool1) && (bool4) && (left != 8) && (b.a == null) && (i.a == null)) {
        paramClassWriter.b(paramClassWriter.a(n.i), localLabel2, 0, 1);
      }
      if ((!bool2) && (bool3) && (left != 8) && (a.a == null) && (g.a == null) && (u == null)) {
        paramClassWriter.b(paramClassWriter.a(n.g), (org.codehaus.asm.Label)localObject4, 0, 1);
      }
      bool5 = bool1;
    }
    else
    {
      bool5 = false;
      bool2 = false;
    }
    int i1 = s;
    int i2 = i1;
    if (i1 < top) {
      i2 = top;
    }
    i1 = v;
    int i3 = i1;
    if (i1 < width) {
      i3 = width;
    }
    if (c[0] != XLayoutStyle.a) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    if (c[1] != XLayoutStyle.a) {
      bool6 = true;
    } else {
      bool6 = false;
    }
    int i7 = 0;
    x = D;
    float f1 = E;
    z = f1;
    int i5 = k;
    int i6 = h;
    int i8;
    if ((f1 > 0.0F) && (left != 8))
    {
      int i9 = 1;
      i1 = i5;
      if (c[0] == XLayoutStyle.a)
      {
        i1 = i5;
        if (i5 == 0) {
          i1 = 3;
        }
      }
      i4 = i6;
      if (c[1] == XLayoutStyle.a)
      {
        i4 = i6;
        if (i6 == 0) {
          i4 = 3;
        }
      }
      localObject1 = c;
      i8 = i2;
      localObject2 = localObject1[0];
      localObject6 = XLayoutStyle.a;
      i6 = i3;
      if ((localObject2 == localObject6) && (localObject1[1] == localObject6) && (i1 == 3) && (i4 == 3))
      {
        add(bool1, bool6);
        i6 = i4;
        i5 = i1;
        i7 = i9;
      }
      else
      {
        localObject1 = c;
        localObject2 = localObject1[0];
        localObject6 = XLayoutStyle.a;
        if ((localObject2 == localObject6) && (i1 == 3))
        {
          x = 0;
          i3 = (int)(z * v);
          if (localObject1[1] != localObject6)
          {
            i1 = 0;
            i5 = 4;
            i2 = i6;
            break label1407;
          }
          i7 = 1;
          i5 = i1;
          i2 = i6;
          i1 = i7;
          break label1407;
        }
        i6 = i4;
        i5 = i1;
        i7 = i9;
        if (c[1] == XLayoutStyle.a)
        {
          i6 = i4;
          i5 = i1;
          i7 = i9;
          if (i4 == 3)
          {
            x = 1;
            if (D == -1) {
              z = (1.0F / z);
            }
            i2 = (int)(z * s);
            if (c[0] != XLayoutStyle.a)
            {
              i4 = 4;
              i3 = 0;
              i5 = i1;
              i1 = i3;
              i3 = i8;
              break label1407;
            }
            i3 = 1;
            i5 = i1;
            i1 = i3;
            i3 = i8;
            break label1407;
          }
        }
      }
    }
    i1 = i2;
    i2 = i3;
    i3 = i1;
    i1 = i7;
    int i4 = i6;
    label1407:
    localObject1 = P;
    localObject1[0] = i5;
    localObject1[1] = i4;
    if (i1 != 0)
    {
      i6 = x;
      if ((i6 == 0) || (i6 == -1))
      {
        bool7 = true;
        break label1456;
      }
    }
    boolean bool7 = false;
    label1456:
    if (i1 != 0)
    {
      i6 = x;
      if ((i6 == 1) || (i6 == -1))
      {
        bool6 = true;
        break label1488;
      }
    }
    boolean bool6 = false;
    label1488:
    boolean bool8;
    if ((c[0] == XLayoutStyle.c) && ((this instanceof MethodWriter))) {
      bool8 = true;
    } else {
      bool8 = false;
    }
    if (bool8) {
      i3 = 0;
    }
    if (N.put()) {
      bool1 = false;
    } else {
      bool1 = true;
    }
    localObject1 = G;
    int i12 = localObject1[0];
    int i11 = localObject1[1];
    Label localLabel3;
    Label localLabel4;
    if ((type != 2) && (!J))
    {
      if (paramBoolean)
      {
        localObject1 = f;
        if (localObject1 != null)
        {
          localObject2 = a;
          if ((c) && (c.c))
          {
            if (paramBoolean)
            {
              paramClassWriter.a(localLabel1, d);
              paramClassWriter.a(localLabel2, f.c.d);
              if (n != null)
              {
                if ((bool4) && (C[0] != 0) && (!f())) {
                  paramClassWriter.b(paramClassWriter.a(n.i), localLabel2, 0, 8);
                }
              }
              else {}
            }
            break label1910;
          }
        }
      }
      localObject1 = n;
      if (localObject1 != null) {
        localObject1 = paramClassWriter.a(i);
      } else {
        localObject1 = null;
      }
      localObject2 = n;
      if (localObject2 != null) {
        localObject2 = paramClassWriter.a(b);
      } else {
        localObject2 = null;
      }
      int i13 = C[0];
      localObject6 = c;
      localObject7 = localObject6[0];
      localLabel3 = b;
      localLabel4 = i;
      i6 = t;
      i7 = top;
      i8 = data[0];
      f1 = size;
      boolean bool9;
      if (localObject6[1] == XLayoutStyle.a) {
        bool9 = true;
      } else {
        bool9 = false;
      }
      a(paramClassWriter, true, bool4, bool3, i13, (org.codehaus.asm.Label)localObject2, (org.codehaus.asm.Label)localObject1, (XLayoutStyle)localObject7, bool8, localLabel3, localLabel4, i6, i3, i7, i8, f1, bool7, bool9, bool5, bool2, i12, i5, i4, l, o, j, bool1);
    }
    label1910:
    Object localObject2 = localObject5;
    localObject1 = localObject4;
    i3 = 1;
    if (paramBoolean)
    {
      localObject4 = e;
      if (localObject4 != null)
      {
        localObject5 = a;
        if ((c) && (c.c))
        {
          paramClassWriter.a((org.codehaus.asm.Label)localObject2, d);
          paramClassWriter.a((org.codehaus.asm.Label)localObject1, e.c.d);
          paramClassWriter.a((org.codehaus.asm.Label)localObject3, e.a.d);
          localObject4 = n;
          if (localObject4 != null) {
            if ((!bool2) && (bool3)) {
              if (C[1] != 0) {
                paramClassWriter.b(paramClassWriter.a(g), (org.codehaus.asm.Label)localObject1, 0, 8);
              } else {}
            }
          }
          i3 = 0;
        }
      }
    }
    localObject4 = paramClassWriter;
    Object localObject7 = localObject3;
    localObject3 = this;
    localObject5 = localObject2;
    Object localObject6 = localObject1;
    if (flags == 2) {
      i3 = 0;
    }
    if ((i3 != 0) && (!w))
    {
      if ((c[1] == XLayoutStyle.c) && ((localObject3 instanceof MethodWriter))) {
        paramBoolean = true;
      } else {
        paramBoolean = false;
      }
      if (paramBoolean) {
        i2 = 0;
      }
      localObject1 = n;
      if (localObject1 != null) {
        localObject1 = ((ClassWriter)localObject4).a(g);
      } else {
        localObject1 = null;
      }
      localObject2 = n;
      if (localObject2 != null) {
        localObject2 = ((ClassWriter)localObject4).a(a);
      } else {
        localObject2 = null;
      }
      if ((bottom > 0) || (left == 8)) {
        if (u.a != null)
        {
          ((ClassWriter)localObject4).a((org.codehaus.asm.Label)localObject7, (org.codehaus.asm.Label)localObject5, newClass(), 8);
          ((ClassWriter)localObject4).a((org.codehaus.asm.Label)localObject7, ((ClassWriter)localObject4).a(u.a), 0, 8);
          if (bool3) {
            ((ClassWriter)localObject4).b((org.codehaus.asm.Label)localObject1, ((ClassWriter)localObject4).a(g), 0, 5);
          }
          bool1 = false;
        }
        else if (left == 8)
        {
          ((ClassWriter)localObject4).a((org.codehaus.asm.Label)localObject7, (org.codehaus.asm.Label)localObject5, 0, 8);
        }
        else
        {
          ((ClassWriter)localObject4).a((org.codehaus.asm.Label)localObject7, (org.codehaus.asm.Label)localObject5, newClass(), 8);
        }
      }
      int i10 = C[1];
      localObject7 = c;
      localLabel3 = localObject7[1];
      localLabel4 = a;
      Label localLabel5 = g;
      i3 = y;
      i6 = width;
      i7 = data[1];
      f1 = height;
      if (localObject7[0] == XLayoutStyle.a) {
        bool7 = true;
      } else {
        bool7 = false;
      }
      a(paramClassWriter, false, bool3, bool4, i10, (org.codehaus.asm.Label)localObject2, (org.codehaus.asm.Label)localObject1, localLabel3, paramBoolean, localLabel4, localLabel5, i3, i2, i6, i7, f1, bool6, bool7, bool2, bool5, i11, i4, i5, m, p, q, bool1);
    }
    if (i1 != 0) {
      if (x == 1) {
        paramClassWriter.a((org.codehaus.asm.Label)localObject6, (org.codehaus.asm.Label)localObject5, localLabel2, localLabel1, z, 8);
      } else {
        paramClassWriter.a(localLabel2, localLabel1, (org.codehaus.asm.Label)localObject6, (org.codehaus.asm.Label)localObject5, z, 8);
      }
    }
    if (N.put()) {
      ((ClassWriter)localObject4).a((f)localObject3, N.getText().getName(), (float)Math.toRadians(scale + 90.0F), N.b());
    }
    J = false;
    w = false;
  }
  
  public final void a(ClassWriter paramClassWriter, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, org.codehaus.asm.Label paramLabel1, org.codehaus.asm.Label paramLabel2, XLayoutStyle paramXLayoutStyle, boolean paramBoolean5, Label paramLabel3, Label paramLabel4, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8, boolean paramBoolean9, boolean paramBoolean10, int paramInt5, int paramInt6, int paramInt7, int paramInt8, float paramFloat2, boolean paramBoolean11)
  {
    org.codehaus.asm.Label localLabel1 = paramClassWriter.a(paramLabel3);
    Object localObject2 = paramClassWriter.a(paramLabel4);
    org.codehaus.asm.Label localLabel2 = paramClassWriter.a(paramLabel3.getText());
    org.codehaus.asm.Label localLabel3 = paramClassWriter.a(paramLabel4.getText());
    ClassWriter.visitField();
    boolean bool1 = paramLabel3.put();
    boolean bool2 = paramLabel4.put();
    boolean bool3 = N.put();
    int i1 = 0;
    if (bool1) {
      i1 = 0 + 1;
    }
    int i2 = i1;
    if (bool2) {
      i2 = i1 + 1;
    }
    i1 = i2;
    if (bool3) {
      i1 = i2 + 1;
    }
    int i3 = paramInt5;
    if (paramBoolean6) {
      i3 = 3;
    }
    paramInt5 = paramXLayoutStyle.ordinal();
    if (paramInt5 != 0)
    {
      if (paramInt5 != 1)
      {
        if (paramInt5 != 2)
        {
          if (paramInt5 != 3) {
            paramInt5 = 0;
          } else {
            paramInt5 = 0;
          }
        }
        else if (i3 != 4) {
          paramInt5 = 1;
        } else {
          paramInt5 = 0;
        }
      }
      else {
        paramInt5 = 0;
      }
    }
    else {
      paramInt5 = 0;
    }
    if (left == 8)
    {
      paramInt2 = 0;
      paramInt5 = 0;
    }
    if (paramBoolean11) {
      if ((!bool1) && (!bool2) && (!bool3)) {
        paramClassWriter.a(localLabel1, paramInt1);
      } else if ((bool1) && (!bool2)) {
        paramClassWriter.a(localLabel1, localLabel2, paramLabel3.b(), 8);
      }
    }
    Object localObject3;
    if (paramInt5 == 0)
    {
      if (paramBoolean5)
      {
        paramClassWriter.a((org.codehaus.asm.Label)localObject2, localLabel1, 0, 3);
        if (paramInt3 > 0) {
          paramClassWriter.b((org.codehaus.asm.Label)localObject2, localLabel1, paramInt3, 8);
        }
        if (paramInt4 < Integer.MAX_VALUE) {
          paramClassWriter.c((org.codehaus.asm.Label)localObject2, localLabel1, paramInt4, 8);
        }
      }
      else
      {
        paramClassWriter.a((org.codehaus.asm.Label)localObject2, localLabel1, paramInt2, 8);
      }
      i2 = paramInt7;
      paramInt1 = paramInt8;
      paramBoolean5 = paramBoolean4;
      paramInt7 = paramInt5;
    }
    else if ((i1 != 2) && (!paramBoolean6) && ((i3 == 1) || (i3 == 0)))
    {
      paramInt2 = Math.max(paramInt7, paramInt2);
      paramInt1 = paramInt2;
      if (paramInt8 > 0) {
        paramInt1 = Math.min(paramInt8, paramInt2);
      }
      paramClassWriter.a((org.codehaus.asm.Label)localObject2, localLabel1, paramInt1, 8);
      i2 = paramInt7;
      paramInt1 = paramInt8;
      paramInt7 = 0;
      paramBoolean5 = paramBoolean4;
    }
    else
    {
      if (paramInt7 == -2) {
        i2 = paramInt2;
      } else {
        i2 = paramInt7;
      }
      if (paramInt8 == -2) {
        paramInt1 = paramInt2;
      } else {
        paramInt1 = paramInt8;
      }
      paramInt4 = paramInt2;
      if (paramInt2 > 0)
      {
        paramInt4 = paramInt2;
        if (i3 != 1) {
          paramInt4 = 0;
        }
      }
      paramInt2 = paramInt4;
      if (i2 > 0)
      {
        paramClassWriter.b((org.codehaus.asm.Label)localObject2, localLabel1, i2, 8);
        paramInt2 = Math.max(paramInt4, i2);
      }
      paramInt4 = paramInt2;
      if (paramInt1 > 0)
      {
        paramInt7 = 1;
        paramInt4 = paramInt7;
        if (paramBoolean2)
        {
          paramInt4 = paramInt7;
          if (i3 == 1) {
            paramInt4 = 0;
          }
        }
        if (paramInt4 != 0) {
          paramClassWriter.c((org.codehaus.asm.Label)localObject2, localLabel1, paramInt1, 8);
        }
        paramInt4 = Math.min(paramInt2, paramInt1);
      }
      if (i3 == 1)
      {
        if (paramBoolean2)
        {
          paramClassWriter.a((org.codehaus.asm.Label)localObject2, localLabel1, paramInt4, 8);
        }
        else if (paramBoolean8)
        {
          paramClassWriter.a((org.codehaus.asm.Label)localObject2, localLabel1, paramInt4, 5);
          paramClassWriter.c((org.codehaus.asm.Label)localObject2, localLabel1, paramInt4, 8);
        }
        else
        {
          paramClassWriter.a((org.codehaus.asm.Label)localObject2, localLabel1, paramInt4, 5);
          paramClassWriter.c((org.codehaus.asm.Label)localObject2, localLabel1, paramInt4, 8);
        }
        paramBoolean5 = paramBoolean4;
        paramInt7 = paramInt5;
      }
      else if (i3 == 2)
      {
        if ((paramLabel3.e() != c.a) && (paramLabel3.e() != c.b))
        {
          paramXLayoutStyle = paramClassWriter.a(n.a(c.d));
          localObject1 = paramClassWriter.a(n.a(c.i));
        }
        else
        {
          paramXLayoutStyle = paramClassWriter.a(n.a(c.a));
          localObject1 = paramClassWriter.a(n.a(c.b));
        }
        localObject3 = paramClassWriter.c();
        ((org.codehaus.asm.h)localObject3).add((org.codehaus.asm.Label)localObject2, localLabel1, (org.codehaus.asm.Label)localObject1, paramXLayoutStyle, paramFloat2);
        paramClassWriter.a((org.codehaus.asm.h)localObject3);
        paramInt7 = 0;
        paramBoolean5 = paramBoolean4;
      }
      else
      {
        paramBoolean5 = true;
        paramInt7 = paramInt5;
      }
    }
    Object localObject1 = localObject2;
    if ((paramBoolean11) && (!paramBoolean8))
    {
      if ((!bool1) && (!bool2) && (!bool3))
      {
        paramBoolean4 = paramBoolean2;
      }
      else if ((bool1) && (!bool2))
      {
        paramBoolean4 = paramBoolean2;
      }
      else if ((!bool1) && (bool2))
      {
        paramClassWriter.a((org.codehaus.asm.Label)localObject1, localLabel3, -paramLabel4.b(), 8);
        if (paramBoolean2)
        {
          if ((header) && (c))
          {
            paramXLayoutStyle = n;
            if (paramXLayoutStyle != null)
            {
              paramLabel1 = (MethodWriter)paramXLayoutStyle;
              if (paramBoolean1) {
                paramLabel1.d(paramLabel3);
              } else {
                paramLabel1.b(paramLabel3);
              }
              paramBoolean4 = paramBoolean2;
              break label2239;
            }
          }
          paramClassWriter.b(localLabel1, paramLabel1, 0, 5);
          paramBoolean4 = paramBoolean2;
        }
        else
        {
          paramBoolean4 = paramBoolean2;
        }
      }
      else
      {
        paramBoolean4 = paramBoolean2;
        if (bool1)
        {
          paramBoolean4 = paramBoolean2;
          if (bool2)
          {
            paramInt8 = 0;
            paramInt5 = 0;
            int i5 = 0;
            int i4 = 0;
            paramInt2 = 4;
            i1 = 6;
            if (!paramBoolean2) {}
            paramInt4 = 5;
            paramXLayoutStyle = a.b;
            localObject2 = a.b;
            localObject3 = l();
            if (paramInt7 != 0)
            {
              if (i3 == 0)
              {
                if ((paramInt1 == 0) && (i2 == 0))
                {
                  paramInt8 = 1;
                  if ((c) && (c))
                  {
                    paramClassWriter.a(localLabel1, localLabel2, paramLabel3.b(), 8);
                    paramClassWriter.a((org.codehaus.asm.Label)localObject1, localLabel3, -paramLabel4.b(), 8);
                    return;
                  }
                  paramInt1 = 0;
                  paramInt4 = 8;
                  paramInt2 = 8;
                  paramInt5 = i4;
                }
                else
                {
                  paramInt1 = 1;
                  paramInt6 = 1;
                  paramInt4 = 5;
                  paramInt2 = 5;
                  paramInt8 = paramInt5;
                  paramInt5 = paramInt6;
                }
                if ((!(paramXLayoutStyle instanceof h)) && (!(localObject2 instanceof h)))
                {
                  paramInt6 = i1;
                }
                else
                {
                  paramInt2 = 4;
                  paramInt6 = i1;
                }
              }
              else if (i3 == 1)
              {
                paramInt5 = 1;
                paramInt4 = 8;
                paramInt1 = 1;
                paramInt6 = i1;
              }
              else if (i3 == 3)
              {
                if (x == -1)
                {
                  paramInt5 = 1;
                  paramInt8 = 1;
                  paramInt4 = 8;
                  paramInt2 = 5;
                  if (paramBoolean9)
                  {
                    paramInt2 = 5;
                    paramInt6 = 4;
                    if (paramBoolean2)
                    {
                      paramInt6 = 5;
                      paramInt1 = 1;
                    }
                    else
                    {
                      paramInt1 = 1;
                    }
                  }
                  else
                  {
                    paramInt6 = 8;
                    paramInt1 = 1;
                  }
                }
                else
                {
                  paramInt5 = 1;
                  paramInt8 = 1;
                  if (paramBoolean6)
                  {
                    if ((paramInt6 != 2) && (paramInt6 != 1)) {
                      paramInt1 = 0;
                    } else {
                      paramInt1 = 1;
                    }
                    if (paramInt1 == 0)
                    {
                      paramInt4 = 8;
                      paramInt2 = 5;
                    }
                    paramInt1 = 1;
                    paramInt6 = i1;
                  }
                  else
                  {
                    paramInt4 = 5;
                    if (paramInt1 > 0)
                    {
                      paramInt2 = 5;
                      paramInt1 = 1;
                      paramInt6 = i1;
                    }
                    else if ((paramInt1 == 0) && (i2 == 0))
                    {
                      if (!paramBoolean9)
                      {
                        paramInt2 = 8;
                        paramInt1 = 1;
                        paramInt6 = i1;
                      }
                      else
                      {
                        if ((paramXLayoutStyle != localObject3) && (localObject2 != localObject3)) {
                          paramInt4 = 4;
                        } else {
                          paramInt4 = 5;
                        }
                        paramInt2 = 4;
                        paramInt1 = 1;
                        paramInt6 = i1;
                      }
                    }
                    else
                    {
                      paramInt1 = 1;
                      paramInt6 = i1;
                    }
                  }
                }
              }
              else
              {
                paramInt1 = 0;
                paramInt5 = i5;
                paramInt6 = i1;
              }
            }
            else
            {
              paramInt1 = 1;
              if ((c) && (c))
              {
                paramClassWriter.a(localLabel1, localLabel2, paramLabel3.b(), paramFloat1, localLabel3, (org.codehaus.asm.Label)localObject1, paramLabel4.b(), 8);
                if ((paramBoolean2) && (paramBoolean5))
                {
                  paramInt1 = 0;
                  if (a != null) {
                    paramInt1 = paramLabel4.b();
                  }
                  if (localLabel3 == paramLabel2) {
                    return;
                  }
                  paramClassWriter.b(paramLabel2, (org.codehaus.asm.Label)localObject1, paramInt1, 5);
                }
                return;
              }
              paramInt5 = 1;
              paramInt6 = i1;
            }
            i1 = 1;
            if ((paramInt5 != 0) && (localLabel2 == localLabel3))
            {
              i4 = paramInt5;
              if (paramXLayoutStyle != localObject3)
              {
                i1 = 0;
                i4 = 0;
              }
            }
            else
            {
              i4 = paramInt5;
            }
            if (paramInt1 != 0)
            {
              i5 = paramInt6;
              paramInt1 = paramInt4;
              paramBoolean4 = paramBoolean2;
              paramInt5 = i1;
              if (paramInt7 == 0)
              {
                i5 = paramInt6;
                paramInt1 = paramInt4;
                paramBoolean4 = paramBoolean2;
                paramInt5 = i1;
                if (!paramBoolean7)
                {
                  i5 = paramInt6;
                  paramInt1 = paramInt4;
                  paramBoolean4 = paramBoolean2;
                  paramInt5 = i1;
                  if (!paramBoolean9)
                  {
                    i5 = paramInt6;
                    paramInt1 = paramInt4;
                    paramBoolean4 = paramBoolean2;
                    paramInt5 = i1;
                    if (localLabel2 == paramLabel1)
                    {
                      i5 = paramInt6;
                      paramInt1 = paramInt4;
                      paramBoolean4 = paramBoolean2;
                      paramInt5 = i1;
                      if (localLabel3 == paramLabel2)
                      {
                        i5 = 8;
                        paramInt1 = 8;
                        paramInt5 = 0;
                        paramBoolean4 = false;
                      }
                    }
                  }
                }
              }
              paramClassWriter.a(localLabel1, localLabel2, paramLabel3.b(), paramFloat1, localLabel3, (org.codehaus.asm.Label)localObject1, paramLabel4.b(), i5);
              paramInt4 = paramInt1;
              paramBoolean2 = paramBoolean4;
              i1 = paramInt5;
            }
            if ((left == 8) && (!paramLabel4.add())) {
              return;
            }
            if (i4 != 0)
            {
              if ((paramBoolean2) && (localLabel2 != localLabel3) && (paramInt7 == 0))
              {
                if (!(paramXLayoutStyle instanceof h)) {
                  if (!(localObject2 instanceof h)) {
                    break label1837;
                  }
                }
                paramInt1 = 6;
                break label1841;
              }
              label1837:
              paramInt1 = paramInt4;
              label1841:
              paramClassWriter.b(localLabel1, localLabel2, paramLabel3.b(), paramInt1);
              paramClassWriter.c((org.codehaus.asm.Label)localObject1, localLabel3, -paramLabel4.b(), paramInt1);
              paramInt4 = paramInt1;
            }
            if ((paramBoolean2) && (paramBoolean10) && (!(paramXLayoutStyle instanceof h)) && (!(localObject2 instanceof h)))
            {
              i1 = 1;
              paramInt1 = 6;
              paramInt4 = 6;
            }
            else
            {
              paramInt1 = paramInt2;
            }
            if (i1 != 0)
            {
              paramInt2 = paramInt1;
              if (paramInt8 != 0) {
                if (paramBoolean9)
                {
                  paramInt2 = paramInt1;
                  if (!paramBoolean3) {}
                }
                else
                {
                  paramInt2 = paramInt1;
                  if ((paramXLayoutStyle == localObject3) || (localObject2 == localObject3)) {
                    paramInt2 = 6;
                  }
                  if (((paramXLayoutStyle instanceof i)) || ((localObject2 instanceof i))) {
                    paramInt2 = 5;
                  }
                  if (((paramXLayoutStyle instanceof h)) || ((localObject2 instanceof h))) {
                    paramInt2 = 5;
                  }
                  if (paramBoolean9) {
                    paramInt2 = 5;
                  }
                  paramInt2 = Math.max(paramInt2, paramInt1);
                }
              }
              paramInt1 = paramInt2;
              if (paramBoolean2)
              {
                paramInt2 = Math.min(paramInt4, paramInt2);
                paramInt1 = paramInt2;
                if (paramBoolean6)
                {
                  paramInt1 = paramInt2;
                  if (!paramBoolean9) {
                    if (paramXLayoutStyle != localObject3)
                    {
                      paramInt1 = paramInt2;
                      if (localObject2 != localObject3) {}
                    }
                    else
                    {
                      paramInt1 = 4;
                    }
                  }
                }
              }
              paramClassWriter.a(localLabel1, localLabel2, paramLabel3.b(), paramInt1);
              paramClassWriter.a((org.codehaus.asm.Label)localObject1, localLabel3, -paramLabel4.b(), paramInt1);
            }
            if (paramBoolean2)
            {
              paramInt1 = 0;
              if (paramLabel1 == localLabel2) {
                paramInt1 = paramLabel3.b();
              }
              if (localLabel2 != paramLabel1) {
                paramClassWriter.b(localLabel1, paramLabel1, paramInt1, 5);
              } else {}
            }
            if ((paramBoolean2) && (paramInt7 != 0))
            {
              if ((paramInt3 == 0) && (i2 == 0))
              {
                if (paramInt7 != 0) {
                  if (i3 == 3)
                  {
                    paramClassWriter.b((org.codehaus.asm.Label)localObject1, localLabel1, 0, 8);
                    paramBoolean4 = paramBoolean2;
                    break label2239;
                  }
                }
                paramClassWriter.b((org.codehaus.asm.Label)localObject1, localLabel1, 0, 5);
                paramBoolean4 = paramBoolean2;
              }
              else
              {
                paramBoolean4 = paramBoolean2;
              }
            }
            else {
              paramBoolean4 = paramBoolean2;
            }
          }
        }
      }
      label2239:
      if ((paramBoolean4) && (paramBoolean5))
      {
        paramInt1 = 0;
        if (a != null) {
          paramInt1 = paramLabel4.b();
        }
        if (localLabel3 == paramLabel2) {
          return;
        }
        if ((header) && (c))
        {
          paramLabel1 = n;
          if (paramLabel1 != null)
          {
            paramClassWriter = (MethodWriter)paramLabel1;
            if (paramBoolean1)
            {
              paramClassWriter.e(paramLabel4);
              return;
            }
            paramClassWriter.a(paramLabel4);
            return;
          }
        }
        paramClassWriter.b(paramLabel2, (org.codehaus.asm.Label)localObject1, paramInt1, 5);
      }
    }
    else if ((i1 < 2) && (paramBoolean2) && (paramBoolean5))
    {
      paramClassWriter.b(localLabel1, paramLabel1, 0, 8);
      if ((!paramBoolean1) && (u.a != null)) {
        paramInt1 = 0;
      } else {
        paramInt1 = 1;
      }
      paramInt2 = paramInt1;
      if (!paramBoolean1)
      {
        paramLabel1 = u.a;
        paramInt2 = paramInt1;
        if (paramLabel1 != null)
        {
          paramLabel1 = b;
          if (E != 0.0F)
          {
            paramLabel1 = c;
            paramXLayoutStyle = paramLabel1[0];
            paramLabel3 = XLayoutStyle.a;
            if ((paramXLayoutStyle == paramLabel3) && (paramLabel1[1] == paramLabel3))
            {
              paramInt2 = 1;
              break label2474;
            }
          }
          paramInt2 = 0;
        }
      }
      label2474:
      if (paramInt2 != 0) {
        paramClassWriter.b(paramLabel2, (org.codehaus.asm.Label)localObject1, 0, 8);
      }
    }
  }
  
  public void a(Item paramItem)
  {
    b.setText();
    a.setText();
    i.setText();
    g.setText();
    u.setText();
    N.setText();
    V.setText();
    M.setText();
  }
  
  public void a(MethodWriter paramMethodWriter, ClassWriter paramClassWriter, HashSet paramHashSet, int paramInt, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (!paramHashSet.contains(this)) {
        return;
      }
      Frame.a(paramMethodWriter, paramClassWriter, this);
      paramHashSet.remove(this);
      a(paramClassWriter, paramMethodWriter.a(64));
    }
    if (paramInt == 0)
    {
      localObject = b.get();
      if (localObject != null)
      {
        localObject = ((HashSet)localObject).iterator();
        while (((Iterator)localObject).hasNext()) {
          nextb.a(paramMethodWriter, paramClassWriter, paramHashSet, paramInt, true);
        }
      }
      localObject = i.get();
      if (localObject != null)
      {
        localObject = ((HashSet)localObject).iterator();
        while (((Iterator)localObject).hasNext()) {
          nextb.a(paramMethodWriter, paramClassWriter, paramHashSet, paramInt, true);
        }
      }
      return;
    }
    Object localObject = a.get();
    if (localObject != null)
    {
      localObject = ((HashSet)localObject).iterator();
      while (((Iterator)localObject).hasNext()) {
        nextb.a(paramMethodWriter, paramClassWriter, paramHashSet, paramInt, true);
      }
    }
    localObject = g.get();
    if (localObject != null)
    {
      localObject = ((HashSet)localObject).iterator();
      while (((Iterator)localObject).hasNext()) {
        nextb.a(paramMethodWriter, paramClassWriter, paramHashSet, paramInt, true);
      }
    }
    localObject = u.get();
    if (localObject != null) {
      localObject = ((HashSet)localObject).iterator();
    }
    while (((Iterator)localObject).hasNext())
    {
      f localF = nextb;
      try
      {
        localF.a(paramMethodWriter, paramClassWriter, paramHashSet, paramInt, true);
      }
      catch (Throwable paramMethodWriter)
      {
        throw paramMethodWriter;
      }
    }
    return;
  }
  
  public void a(XLayoutStyle paramXLayoutStyle)
  {
    c[1] = paramXLayoutStyle;
  }
  
  public void a(c paramC1, f paramF, c paramC2, int paramInt1, int paramInt2)
  {
    a(paramC1).a(paramF.a(paramC2), paramInt1, paramInt2, true);
  }
  
  public void a(f paramF, float paramFloat, int paramInt)
  {
    c localC = c.l;
    a(localC, paramF, localC, paramInt, 0);
    scale = paramFloat;
  }
  
  public void a(boolean paramBoolean)
  {
    I = paramBoolean;
  }
  
  public void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool2 = paramBoolean1 & f.f();
    boolean bool1 = paramBoolean2 & e.f();
    org.codehaus.asm.asm.asm.f localF = f;
    int i1 = a.d;
    org.codehaus.asm.asm.asm.d localD = e;
    int i2 = a.d;
    int i4 = c.d;
    int i5 = c.d;
    int i3;
    if ((i4 - i1 >= 0) && (i5 - i2 >= 0) && (i1 != Integer.MIN_VALUE) && (i1 != Integer.MAX_VALUE) && (i2 != Integer.MIN_VALUE) && (i2 != Integer.MAX_VALUE) && (i4 != Integer.MIN_VALUE) && (i4 != Integer.MAX_VALUE) && (i5 != Integer.MIN_VALUE))
    {
      i3 = i5;
      if (i5 != Integer.MAX_VALUE) {}
    }
    else
    {
      i1 = 0;
      i2 = 0;
      i4 = 0;
      i3 = 0;
    }
    i4 -= i1;
    i3 -= i2;
    if (bool2) {
      t = i1;
    }
    if (bool1) {
      y = i2;
    }
    if (left == 8)
    {
      s = 0;
      v = 0;
      return;
    }
    if (bool2)
    {
      i1 = i4;
      if (c[0] == XLayoutStyle.b)
      {
        i1 = i4;
        if (i4 < s) {
          i1 = s;
        }
      }
      s = i1;
      i2 = top;
      if (i1 < i2) {
        s = i2;
      }
    }
    if (bool1)
    {
      i1 = i3;
      if (c[1] == XLayoutStyle.b)
      {
        i1 = i3;
        if (i3 < v) {
          i1 = v;
        }
      }
      v = i1;
      i2 = width;
      if (i1 < i2) {
        v = i2;
      }
    }
  }
  
  public int accept()
  {
    int i1 = 0;
    if (b != null) {
      i1 = 0 + a.j;
    }
    int i2 = i1;
    if (i != null) {
      i2 = i1 + g.j;
    }
    return i2;
  }
  
  public void add(float paramFloat)
  {
    size = paramFloat;
  }
  
  public void add(int paramInt)
  {
    v = paramInt;
    int i1 = width;
    if (paramInt < i1) {
      v = i1;
    }
  }
  
  public void add(int paramInt1, int paramInt2)
  {
    y = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    v = paramInt1;
    paramInt2 = width;
    if (paramInt1 < paramInt2) {
      v = paramInt2;
    }
  }
  
  public void add(XLayoutStyle paramXLayoutStyle)
  {
    c[0] = paramXLayoutStyle;
  }
  
  public void add(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (x == -1) {
      if ((paramBoolean1) && (!paramBoolean2))
      {
        x = 0;
      }
      else if ((!paramBoolean1) && (paramBoolean2))
      {
        x = 1;
        if (D == -1) {
          z = (1.0F / z);
        }
      }
    }
    if ((x == 0) && ((!a.put()) || (!g.put()))) {
      x = 1;
    } else if ((x == 1) && ((!b.put()) || (!i.put()))) {
      x = 0;
    }
    if ((x == -1) && ((!a.put()) || (!g.put()) || (!b.put()) || (!i.put()))) {
      if ((a.put()) && (g.put()))
      {
        x = 0;
      }
      else if ((b.put()) && (i.put()))
      {
        z = (1.0F / z);
        x = 1;
      }
    }
    if (x == -1)
    {
      if ((l > 0) && (m == 0))
      {
        x = 0;
        return;
      }
      if ((l == 0) && (m > 0))
      {
        z = (1.0F / z);
        x = 1;
      }
    }
  }
  
  public boolean add()
  {
    int i1 = 0;
    int i2 = this$0.size();
    while (i1 < i2)
    {
      if (((Label)this$0.get(i1)).add()) {
        return true;
      }
      i1 += 1;
    }
    return false;
  }
  
  public void append(int paramInt)
  {
    s = paramInt;
    int i1 = top;
    if (paramInt < i1) {
      s = i1;
    }
  }
  
  public void b(float paramFloat)
  {
    A[1] = paramFloat;
  }
  
  public void b(int paramInt)
  {
    if (!I) {
      return;
    }
    int i1 = paramInt - bottom;
    int i2 = v;
    y = i1;
    a.a(i1);
    g.a(i2 + i1);
    u.a(paramInt);
    w = true;
  }
  
  public void b(int paramInt1, int paramInt2)
  {
    a.a(paramInt1);
    g.a(paramInt2);
    y = paramInt1;
    v = (paramInt2 - paramInt1);
    if (I) {
      u.a(bottom + paramInt1);
    }
    w = true;
  }
  
  public void b(int paramInt1, int paramInt2, int paramInt3, float paramFloat)
  {
    k = paramInt1;
    l = paramInt2;
    if (paramInt3 == Integer.MAX_VALUE) {
      paramInt3 = 0;
    }
    o = paramInt3;
    j = paramFloat;
    if ((paramFloat > 0.0F) && (paramFloat < 1.0F) && (k == 0)) {
      k = 2;
    }
  }
  
  public void b(String paramString)
  {
    value = paramString;
  }
  
  public void b(ClassWriter paramClassWriter)
  {
    paramClassWriter.a(b);
    paramClassWriter.a(a);
    paramClassWriter.a(i);
    paramClassWriter.a(g);
    if (bottom > 0) {
      paramClassWriter.a(u);
    }
  }
  
  public void b(ClassWriter paramClassWriter, boolean paramBoolean)
  {
    int i2 = paramClassWriter.b(b);
    int i5 = paramClassWriter.b(a);
    int i4 = paramClassWriter.b(i);
    int i6 = paramClassWriter.b(g);
    int i3 = i2;
    int i1 = i4;
    Object localObject;
    if (paramBoolean)
    {
      localObject = f;
      i3 = i2;
      i1 = i4;
      if (localObject != null)
      {
        paramClassWriter = a;
        i3 = i2;
        i1 = i4;
        if (c)
        {
          localObject = c;
          i3 = i2;
          i1 = i4;
          if (c)
          {
            i3 = d;
            i1 = d;
          }
        }
      }
    }
    i4 = i5;
    i2 = i6;
    if (paramBoolean)
    {
      localObject = e;
      i4 = i5;
      i2 = i6;
      if (localObject != null)
      {
        paramClassWriter = a;
        i4 = i5;
        i2 = i6;
        if (c)
        {
          localObject = c;
          i4 = i5;
          i2 = i6;
          if (c)
          {
            i4 = d;
            i2 = d;
          }
        }
      }
    }
    if ((i1 - i3 >= 0) && (i2 - i4 >= 0) && (i3 != Integer.MIN_VALUE) && (i3 != Integer.MAX_VALUE) && (i4 != Integer.MIN_VALUE) && (i4 != Integer.MAX_VALUE) && (i1 != Integer.MIN_VALUE) && (i1 != Integer.MAX_VALUE) && (i2 != Integer.MIN_VALUE))
    {
      i5 = i1;
      i1 = i2;
      if (i2 != Integer.MAX_VALUE) {}
    }
    else
    {
      i3 = 0;
      i4 = 0;
      i5 = 0;
      i1 = 0;
    }
    a(i3, i4, i5, i1);
  }
  
  public boolean b()
  {
    return (w) || ((a.equals()) && (g.equals()));
  }
  
  public void c(int paramInt, boolean paramBoolean)
  {
    G[paramInt] = paramBoolean;
  }
  
  public void c(f paramF)
  {
    n = paramF;
  }
  
  public boolean c()
  {
    Label localLabel1 = a;
    Label localLabel2 = a;
    if ((localLabel2 == null) || (a != localLabel1))
    {
      localLabel1 = g;
      localLabel2 = a;
    }
    return (localLabel2 != null) && (a == localLabel1);
  }
  
  public boolean c(int paramInt)
  {
    int i1;
    if (paramInt == 0)
    {
      if (b.a != null) {
        paramInt = 1;
      } else {
        paramInt = 0;
      }
      if (i.a != null) {
        i1 = 1;
      } else {
        i1 = 0;
      }
      return paramInt + i1 < 2;
    }
    if (a.a != null) {
      paramInt = 1;
    } else {
      paramInt = 0;
    }
    if (g.a != null) {
      i1 = 1;
    } else {
      i1 = 0;
    }
    int i2;
    if (u.a != null) {
      i2 = 1;
    } else {
      i2 = 0;
    }
    return paramInt + i1 + i2 < 2;
  }
  
  public int clear()
  {
    return top;
  }
  
  public void clear(int paramInt)
  {
    data[0] = paramInt;
  }
  
  public void close(int paramInt)
  {
    b.a(paramInt);
    t = paramInt;
  }
  
  public void close(int paramInt1, int paramInt2)
  {
    ptr = paramInt1;
    idx = paramInt2;
    close(false);
  }
  
  public void close(boolean paramBoolean)
  {
    state = paramBoolean;
  }
  
  public void create(int paramInt)
  {
    if (paramInt < 0)
    {
      width = 0;
      return;
    }
    width = paramInt;
  }
  
  public void d(float paramFloat)
  {
    A[0] = paramFloat;
  }
  
  public void d(int paramInt1, int paramInt2)
  {
    t = paramInt1;
    y = paramInt2;
  }
  
  public void d(boolean paramBoolean)
  {
    mOverrideVisibleItems = paramBoolean;
  }
  
  public boolean d()
  {
    return (J) || ((b.equals()) && (i.equals()));
  }
  
  public XLayoutStyle doubleValue()
  {
    return c[0];
  }
  
  public int e()
  {
    f localF = n;
    if ((localF != null) && ((localF instanceof MethodWriter))) {
      return i + t;
    }
    return t;
  }
  
  public f e(int paramInt)
  {
    Label localLabel1;
    Label localLabel2;
    if (paramInt == 0)
    {
      localLabel1 = b;
      localLabel2 = a;
      if ((localLabel2 != null) && (a == localLabel1)) {
        return b;
      }
    }
    else if (paramInt == 1)
    {
      localLabel1 = a;
      localLabel2 = a;
      if ((localLabel2 != null) && (a == localLabel1)) {
        return b;
      }
    }
    return null;
  }
  
  public void e(boolean paramBoolean)
  {
    last = paramBoolean;
  }
  
  public f f(int paramInt)
  {
    Label localLabel1;
    Label localLabel2;
    if (paramInt == 0)
    {
      localLabel1 = i;
      localLabel2 = a;
      if ((localLabel2 != null) && (a == localLabel1)) {
        return b;
      }
    }
    else if (paramInt == 1)
    {
      localLabel1 = g;
      localLabel2 = a;
      if ((localLabel2 != null) && (a == localLabel1)) {
        return b;
      }
    }
    return null;
  }
  
  public boolean f()
  {
    Label localLabel1 = b;
    Label localLabel2 = a;
    if ((localLabel2 == null) || (a != localLabel1))
    {
      localLabel1 = i;
      localLabel2 = a;
    }
    return (localLabel2 != null) && (a == localLabel1);
  }
  
  public int findItem()
  {
    int i1 = 0;
    Label localLabel = b;
    if (localLabel != null) {
      i1 = 0 + j;
    }
    localLabel = i;
    int i2 = i1;
    if (localLabel != null) {
      i2 = i1 + j;
    }
    return i2;
  }
  
  public void format(String paramString)
  {
    if ((paramString != null) && (paramString.length() != 0))
    {
      int i1 = -1;
      float f2 = 0.0F;
      float f4 = 0.0F;
      float f3 = 0.0F;
      int i3 = paramString.length();
      int i2 = paramString.indexOf(',');
      String str;
      if ((i2 > 0) && (i2 < i3 - 1))
      {
        str = paramString.substring(0, i2);
        if (str.equalsIgnoreCase("W")) {
          i1 = 0;
        } else if (str.equalsIgnoreCase("H")) {
          i1 = 1;
        }
        i2 += 1;
      }
      else
      {
        i2 = 0;
      }
      int i4 = paramString.indexOf(':');
      float f1;
      if ((i4 >= 0) && (i4 < i3 - 1))
      {
        str = paramString.substring(i2, i4);
        paramString = paramString.substring(i4 + 1);
        f1 = f2;
        if (str.length() > 0)
        {
          f1 = f2;
          if (paramString.length() > 0) {
            try
            {
              f4 = Float.parseFloat(str);
              float f5 = Float.parseFloat(paramString);
              f1 = f3;
              if (f4 > 0.0F)
              {
                f1 = f3;
                if (f5 > 0.0F) {
                  if (i1 == 1)
                  {
                    f1 = f5 / f4;
                    f1 = Math.abs(f1);
                  }
                  else
                  {
                    f1 = f4 / f5;
                    f1 = Math.abs(f1);
                  }
                }
              }
            }
            catch (NumberFormatException paramString)
            {
              f1 = f2;
            }
          }
        }
      }
      else
      {
        paramString = paramString.substring(i2);
        f1 = f4;
        if (paramString.length() > 0) {
          try
          {
            f1 = Float.parseFloat(paramString);
          }
          catch (NumberFormatException paramString)
          {
            f1 = f4;
          }
        }
      }
      if (f1 > 0.0F)
      {
        E = f1;
        D = i1;
      }
    }
    else
    {
      E = 0.0F;
    }
  }
  
  public void g(int paramInt)
  {
    t = paramInt;
  }
  
  public boolean g()
  {
    return left != 8;
  }
  
  public XLayoutStyle get()
  {
    return c[1];
  }
  
  public final boolean getColor(int paramInt)
  {
    paramInt *= 2;
    Label[] arrayOfLabel = r;
    return (a != null) && (a.a != arrayOfLabel[paramInt]) && (1a != null) && (1a.a == arrayOfLabel[(paramInt + 1)]);
  }
  
  public int getItem()
  {
    return data[0];
  }
  
  public org.codehaus.asm.asm.asm.h getItem(int paramInt)
  {
    if (paramInt == 0) {
      return f;
    }
    if (paramInt == 1) {
      return e;
    }
    return null;
  }
  
  public int getOrdering()
  {
    return idx;
  }
  
  public String getString()
  {
    return value;
  }
  
  public int getTitle()
  {
    f localF = n;
    if ((localF != null) && ((localF instanceof MethodWriter))) {
      return e + y;
    }
    return y;
  }
  
  public Object getUserData()
  {
    return userData;
  }
  
  public int getValue()
  {
    if (left == 8) {
      return 0;
    }
    return s;
  }
  
  public XLayoutStyle getValue(int paramInt)
  {
    if (paramInt == 0) {
      return doubleValue();
    }
    if (paramInt == 1) {
      return get();
    }
    return null;
  }
  
  public int getVisibleItems()
  {
    return ptr;
  }
  
  public int getWidth()
  {
    return width;
  }
  
  public int h()
  {
    return getTitle() + v;
  }
  
  public boolean hasVisibleItems()
  {
    return mOverrideVisibleItems;
  }
  
  public float height()
  {
    return height;
  }
  
  public float i()
  {
    return E;
  }
  
  public int indexOf()
  {
    return index;
  }
  
  public void init()
  {
    b.a();
    a.a();
    i.a();
    g.a();
    u.a();
    V.a();
    M.a();
    N.a();
    n = null;
    scale = 0.0F;
    s = 0;
    v = 0;
    E = 0.0F;
    D = -1;
    t = 0;
    y = 0;
    bottom = 0;
    top = 0;
    width = 0;
    size = 0.5F;
    height = 0.5F;
    Object localObject = c;
    XLayoutStyle localXLayoutStyle = XLayoutStyle.b;
    localObject[0] = localXLayoutStyle;
    localObject[1] = localXLayoutStyle;
    userData = null;
    left = 0;
    parent = null;
    index = 0;
    count = 0;
    localObject = A;
    localObject[0] = -1.0F;
    localObject[1] = -1.0F;
    type = -1;
    flags = -1;
    localObject = data;
    localObject[0] = Integer.MAX_VALUE;
    localObject[1] = Integer.MAX_VALUE;
    k = 0;
    h = 0;
    j = 1.0F;
    q = 1.0F;
    o = Integer.MAX_VALUE;
    p = Integer.MAX_VALUE;
    l = 0;
    m = 0;
    x = -1;
    z = 1.0F;
    localObject = C;
    localObject[0] = 1;
    localObject[1] = 1;
    last = false;
    localObject = G;
    localObject[0] = 0;
    localObject[1] = 0;
    state = true;
  }
  
  public boolean isPrimitive()
  {
    return ((this instanceof Type)) || ((this instanceof i));
  }
  
  public boolean j()
  {
    return I;
  }
  
  public f l()
  {
    return n;
  }
  
  public void l(int paramInt)
  {
    data[1] = paramInt;
  }
  
  public int length()
  {
    return left;
  }
  
  public int newClass()
  {
    return bottom;
  }
  
  public boolean next()
  {
    return (state) && (left != 8);
  }
  
  public boolean o()
  {
    XLayoutStyle[] arrayOfXLayoutStyle = c;
    XLayoutStyle localXLayoutStyle1 = arrayOfXLayoutStyle[0];
    XLayoutStyle localXLayoutStyle2 = XLayoutStyle.a;
    return (localXLayoutStyle1 == localXLayoutStyle2) && (arrayOfXLayoutStyle[1] == localXLayoutStyle2);
  }
  
  public int p()
  {
    return e() + s;
  }
  
  public void p(int paramInt)
  {
    if (paramInt < 0)
    {
      top = 0;
      return;
    }
    top = paramInt;
  }
  
  public void p(int paramInt1, int paramInt2)
  {
    t = paramInt1;
    paramInt1 = paramInt2 - paramInt1;
    s = paramInt1;
    paramInt2 = top;
    if (paramInt1 < paramInt2) {
      s = paramInt2;
    }
  }
  
  public void put(float paramFloat)
  {
    height = paramFloat;
  }
  
  public void putInt(int paramInt)
  {
    index = paramInt;
  }
  
  public void putShort(int paramInt)
  {
    bottom = paramInt;
    boolean bool;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    }
    I = bool;
  }
  
  public boolean q()
  {
    return last;
  }
  
  public int r()
  {
    return D;
  }
  
  public void read()
  {
    J = false;
    w = false;
    int i1 = 0;
    int i2 = this$0.size();
    while (i1 < i2)
    {
      ((Label)this$0.get(i1)).setIcon();
      i1 += 1;
    }
  }
  
  public int readByte()
  {
    return data[1];
  }
  
  public int remove(int paramInt)
  {
    if (paramInt == 0) {
      return getValue();
    }
    if (paramInt == 1) {
      return size();
    }
    return 0;
  }
  
  public final void reset()
  {
    this$0.add(b);
    this$0.add(a);
    this$0.add(i);
    this$0.add(g);
    this$0.add(V);
    this$0.add(M);
    this$0.add(N);
    this$0.add(u);
  }
  
  public void set(int paramInt)
  {
    a.a(paramInt);
    y = paramInt;
  }
  
  public void setText(int paramInt)
  {
    y = paramInt;
  }
  
  public void setTitle()
  {
    if (f == null) {
      f = new org.codehaus.asm.asm.asm.f(this);
    }
    if (e == null) {
      e = new org.codehaus.asm.asm.asm.d(this);
    }
  }
  
  public void setVisibility(int paramInt)
  {
    left = paramInt;
  }
  
  public int show()
  {
    return count;
  }
  
  public float size(int paramInt)
  {
    if (paramInt == 0) {
      return size;
    }
    if (paramInt == 1) {
      return height;
    }
    return -1.0F;
  }
  
  public int size()
  {
    if (left == 8) {
      return 0;
    }
    return v;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    Object localObject = parent;
    String str = "";
    if (localObject != null)
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("type: ");
      ((StringBuilder)localObject).append(parent);
      ((StringBuilder)localObject).append(" ");
      localObject = ((StringBuilder)localObject).toString();
    }
    else
    {
      localObject = "";
    }
    localStringBuilder.append((String)localObject);
    localObject = str;
    if (value != null)
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("id: ");
      ((StringBuilder)localObject).append(value);
      ((StringBuilder)localObject).append(" ");
      localObject = ((StringBuilder)localObject).toString();
    }
    localStringBuilder.append((String)localObject);
    localStringBuilder.append("(");
    localStringBuilder.append(t);
    localStringBuilder.append(", ");
    localStringBuilder.append(y);
    localStringBuilder.append(") - (");
    localStringBuilder.append(s);
    localStringBuilder.append(" x ");
    localStringBuilder.append(v);
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
  
  public float width()
  {
    return size;
  }
  
  public void writeInt(int paramInt)
  {
    count = paramInt;
  }
}
