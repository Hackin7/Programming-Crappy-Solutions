package org.asm;

import a.r.c.k;
import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;
import org.core.view.ViewCompat;

public class f
  extends l
{
  public static final Property<View, PointF> b = new TShortLinkedList(PointF.class, "topLeft");
  public static final String[] c = { "android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY" };
  public static final Property<View, PointF> d = new MaterialRippleLayout.1(PointF.class, "position");
  public static IntEvaluator g = new IntEvaluator();
  public static final Property<c.k, PointF> h;
  public static final Property<c.k, PointF> i;
  public static final Property<View, PointF> m;
  public static final Property<Drawable, PointF> s = new OverlayList(PointF.class, "boundsOrigin");
  public int[] a = new int[2];
  public boolean e = false;
  public boolean f = false;
  
  static
  {
    i = new CircularProgressDrawable.1(PointF.class, "topLeft");
    h = new MaterialRippleLayout.5(PointF.class, "bottomRight");
    m = new Contact(PointF.class, "bottomRight");
  }
  
  public f() {}
  
  public Animator a(ViewGroup paramViewGroup, Label paramLabel1, Label paramLabel2)
  {
    if (paramLabel1 != null)
    {
      if (paramLabel2 == null) {
        return null;
      }
      Object localObject1 = c;
      Object localObject2 = c;
      localObject1 = (ViewGroup)((Map)localObject1).get("android:changeBounds:parent");
      Object localObject3 = (ViewGroup)((Map)localObject2).get("android:changeBounds:parent");
      if ((localObject1 != null) && (localObject3 != null))
      {
        localObject2 = a;
        int i1;
        int n;
        int k;
        int j;
        if (c((View)localObject1, (View)localObject3))
        {
          paramViewGroup = (Rect)c.get("android:changeBounds:bounds");
          localObject1 = (Rect)c.get("android:changeBounds:bounds");
          i1 = left;
          int i2 = left;
          int i3 = top;
          int i4 = top;
          int i5 = right;
          int i6 = right;
          int i7 = bottom;
          int i8 = bottom;
          int i9 = i5 - i1;
          int i10 = i7 - i3;
          int i11 = i6 - i2;
          int i12 = i8 - i4;
          localObject1 = (Rect)c.get("android:changeBounds:clip");
          localObject3 = (Rect)c.get("android:changeBounds:clip");
          n = 0;
          k = 0;
          if ((i9 == 0) || (i10 == 0))
          {
            j = n;
            if (i11 != 0)
            {
              j = n;
              if (i12 == 0) {}
            }
          }
          else
          {
            if ((i1 != i2) || (i3 != i4)) {
              k = 0 + 1;
            }
            if (i5 == i6)
            {
              j = k;
              if (i7 == i8) {}
            }
            else
            {
              j = k + 1;
            }
          }
          if ((localObject1 == null) || (((Rect)localObject1).equals(localObject3)))
          {
            k = j;
            if (localObject1 == null)
            {
              k = j;
              if (localObject3 == null) {}
            }
          }
          else
          {
            k = j + 1;
          }
          if (k > 0)
          {
            if (!e)
            {
              Log.set((View)localObject2, i1, i3, i5, i7);
              if (k == 2)
              {
                if ((i9 == i11) && (i10 == i12))
                {
                  paramViewGroup = visitAnnotation().getMarkPath(i1, i3, i2, i4);
                  paramViewGroup = n.a(localObject2, d, paramViewGroup);
                }
                else
                {
                  paramLabel1 = new ClassWriter((View)localObject2);
                  paramViewGroup = visitAnnotation().getMarkPath(i1, i3, i2, i4);
                  paramLabel2 = n.a(paramLabel1, i, paramViewGroup);
                  paramViewGroup = visitAnnotation().getMarkPath(i5, i7, i6, i8);
                  localObject1 = n.a(paramLabel1, h, paramViewGroup);
                  paramViewGroup = new AnimatorSet();
                  paramViewGroup.playTogether(new Animator[] { paramLabel2, localObject1 });
                  paramViewGroup.addListener(new LayoutManager(this, paramLabel1));
                }
              }
              else if ((i1 == i2) && (i3 == i4))
              {
                paramViewGroup = visitAnnotation().getMarkPath(i5, i7, i6, i8);
                paramViewGroup = n.a(localObject2, m, paramViewGroup);
              }
              else
              {
                paramViewGroup = visitAnnotation().getMarkPath(i1, i3, i2, i4);
                paramViewGroup = n.a(localObject2, b, paramViewGroup);
              }
            }
            else
            {
              Log.set((View)localObject2, i1, i3, i1 + Math.max(i9, i11), i3 + Math.max(i10, i12));
              if ((i1 == i2) && (i3 == i4))
              {
                paramViewGroup = null;
              }
              else
              {
                paramViewGroup = visitAnnotation().getMarkPath(i1, i3, i2, i4);
                paramViewGroup = n.a(localObject2, d, paramViewGroup);
              }
              paramLabel1 = (Label)localObject1;
              if (localObject1 == null) {
                paramLabel1 = new Rect(0, 0, i9, i10);
              }
              if (localObject3 == null) {
                paramLabel2 = new Rect(0, 0, i11, i12);
              } else {
                paramLabel2 = (Label)localObject3;
              }
              localObject1 = null;
              if (!paramLabel1.equals(paramLabel2))
              {
                ViewCompat.set((View)localObject2, paramLabel1);
                localObject1 = ObjectAnimator.ofObject(localObject2, "clipBounds", g, new Object[] { paramLabel1, paramLabel2 });
                ((Animator)localObject1).addListener(new ScrollingTabContainerView.VisibilityAnimListener(this, (View)localObject2, (Rect)localObject3, i2, i4, i6, i8));
              }
              paramViewGroup = c.a(paramViewGroup, (Animator)localObject1);
            }
            if (!(((View)localObject2).getParent() instanceof ViewGroup)) {
              return paramViewGroup;
            }
            paramLabel1 = (ViewGroup)((View)localObject2).getParent();
            Type.a(paramLabel1, true);
            a(new b(this, paramLabel1));
            return paramViewGroup;
          }
        }
        else
        {
          j = ((Integer)c.get("android:changeBounds:windowX")).intValue();
          k = ((Integer)c.get("android:changeBounds:windowY")).intValue();
          n = ((Integer)c.get("android:changeBounds:windowX")).intValue();
          i1 = ((Integer)c.get("android:changeBounds:windowY")).intValue();
          if ((j != n) || (k != i1)) {
            break label956;
          }
        }
        return null;
        label956:
        paramViewGroup.getLocationInWindow(a);
        paramLabel1 = Bitmap.createBitmap(((View)localObject2).getWidth(), ((View)localObject2).getHeight(), Bitmap.Config.ARGB_8888);
        ((View)localObject2).draw(new Canvas(paramLabel1));
        paramLabel1 = new BitmapDrawable(paramLabel1);
        float f1 = Log.set((View)localObject2);
        Log.put((View)localObject2, 0.0F);
        ((SwipeDismissListViewTouchListener.PendingDismissData)Log.setText(paramViewGroup)).set(paramLabel1);
        paramLabel2 = visitAnnotation();
        localObject1 = a;
        paramLabel2 = paramLabel2.getMarkPath(j - localObject1[0], k - localObject1[1], n - localObject1[0], i1 - localObject1[1]);
        paramLabel2 = ObjectAnimator.ofPropertyValuesHolder(paramLabel1, new PropertyValuesHolder[] { k.ofObject(s, paramLabel2) });
        paramLabel2.addListener(new MainActivity.3(this, paramViewGroup, paramLabel1, (View)localObject2, f1));
        return paramLabel2;
      }
    }
    return null;
    return paramViewGroup;
  }
  
  public void a(Label paramLabel)
  {
    draw(paramLabel);
  }
  
  public void b(Label paramLabel)
  {
    draw(paramLabel);
  }
  
  public final boolean c(View paramView1, View paramView2)
  {
    if (f)
    {
      Label localLabel = b(paramView1, true);
      if (localLabel == null) {
        return paramView1 == paramView2;
      }
      return paramView2 == a;
    }
    return true;
  }
  
  public String[] c()
  {
    return c;
  }
  
  public final void draw(Label paramLabel)
  {
    View localView = a;
    if ((ViewCompat.get(localView)) || (localView.getWidth() != 0) || (localView.getHeight() != 0))
    {
      c.put("android:changeBounds:bounds", new Rect(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom()));
      c.put("android:changeBounds:parent", a.getParent());
      if (f)
      {
        a.getLocationInWindow(a);
        c.put("android:changeBounds:windowX", Integer.valueOf(a[0]));
        c.put("android:changeBounds:windowY", Integer.valueOf(a[1]));
      }
      if (e) {
        c.put("android:changeBounds:clip", ViewCompat.getClipBounds(localView));
      }
    }
  }
}
