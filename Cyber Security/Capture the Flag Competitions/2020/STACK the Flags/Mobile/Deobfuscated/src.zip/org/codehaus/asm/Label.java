package org.codehaus.asm;

import java.util.Arrays;

public class Label
{
  public static int line = 1;
  public float a;
  public h[] b = new h[16];
  public boolean c = false;
  public boolean d = false;
  public int e = 0;
  public int f = -1;
  public float g = 0.0F;
  public String h;
  public c i;
  public float[] j = new float[9];
  public int k = 0;
  public float[] m = new float[9];
  public int n = -1;
  public int p = -1;
  public boolean t;
  public int v = 0;
  
  public Label(c paramC)
  {
    i = paramC;
  }
  
  public static void accept()
  {
    line += 1;
  }
  
  public void a()
  {
    h = null;
    i = c.e;
    k = 0;
    n = -1;
    f = -1;
    a = 0.0F;
    c = false;
    d = false;
    p = -1;
    g = 0.0F;
    int i2 = e;
    int i1 = 0;
    while (i1 < i2)
    {
      b[i1] = null;
      i1 += 1;
    }
    e = 0;
    v = 0;
    t = false;
    Arrays.fill(m, 0.0F);
  }
  
  public void a(ClassWriter paramClassWriter, float paramFloat)
  {
    a = paramFloat;
    c = true;
    d = false;
    p = -1;
    g = 0.0F;
    int i2 = e;
    f = -1;
    int i1 = 0;
    while (i1 < i2)
    {
      b[i1].b(paramClassWriter, this, false);
      i1 += 1;
    }
    e = 0;
  }
  
  public final void a(ClassWriter paramClassWriter, h paramH)
  {
    int i2 = e;
    int i1 = 0;
    while (i1 < i2)
    {
      b[i1].a(paramClassWriter, paramH, false);
      i1 += 1;
    }
    e = 0;
  }
  
  public void a(c paramC)
  {
    i = paramC;
  }
  
  public final void a(h paramH)
  {
    int i2 = e;
    int i1 = 0;
    while (i1 < i2)
    {
      if (b[i1] == paramH)
      {
        while (i1 < i2 - 1)
        {
          paramH = b;
          paramH[i1] = paramH[(i1 + 1)];
          i1 += 1;
        }
        e -= 1;
        return;
      }
      i1 += 1;
    }
  }
  
  public final void b(h paramH)
  {
    int i1 = 0;
    int i2;
    for (;;)
    {
      i2 = e;
      if (i1 >= i2) {
        break;
      }
      if (b[i1] == paramH) {
        return;
      }
      i1 += 1;
    }
    h[] arrayOfH = b;
    if (i2 >= arrayOfH.length) {
      b = ((h[])Arrays.copyOf(arrayOfH, arrayOfH.length * 2));
    }
    arrayOfH = b;
    i1 = e;
    arrayOfH[i1] = paramH;
    e = (i1 + 1);
  }
  
  public String toString()
  {
    if (h != null)
    {
      localStringBuilder = new StringBuilder();
      localStringBuilder.append("");
      localStringBuilder.append(h);
      return localStringBuilder.toString();
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("");
    localStringBuilder.append(n);
    return localStringBuilder.toString();
  }
}
