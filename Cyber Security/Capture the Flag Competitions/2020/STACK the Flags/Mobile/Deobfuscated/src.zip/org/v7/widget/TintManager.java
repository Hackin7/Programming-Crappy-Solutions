package org.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import org.core.asm.ColorUtils;
import org.v7.R.attr;
import org.v7.R.color;
import org.v7.R.drawable;
import org.v7.internal.util.Resources;

public class TintManager
  implements m0.e
{
  public final int[] COLORFILTER_COLOR_BACKGROUND_MULTIPLY = { R.drawable.abc_popup_background_mtrl_mult, R.drawable.abc_cab_background_internal_bg, R.drawable.abc_menu_hardkey_panel_mtrl_mult };
  public final int[] COLORFILTER_COLOR_CONTROL_ACTIVATED = { R.drawable.abc_textfield_activated_mtrl_alpha, R.drawable.abc_textfield_search_activated_mtrl_alpha, R.drawable.abc_cab_background_top_mtrl_alpha, R.drawable.abc_text_cursor_material, R.drawable.abc_text_select_handle_left_mtrl_dark, R.drawable.abc_text_select_handle_middle_mtrl_dark, R.drawable.abc_text_select_handle_right_mtrl_dark, R.drawable.abc_text_select_handle_left_mtrl_light, R.drawable.abc_text_select_handle_middle_mtrl_light, R.drawable.abc_text_select_handle_right_mtrl_light };
  public final int[] COLORFILTER_TINT_COLOR_CONTROL_NORMAL = { R.drawable.abc_textfield_search_default_mtrl_alpha, R.drawable.abc_textfield_default_mtrl_alpha, R.drawable.abc_ab_share_pack_mtrl_alpha };
  public final int[] TINT_CHECKABLE_BUTTON_LIST = { R.drawable.abc_btn_check_material, R.drawable.abc_btn_radio_material, R.drawable.abc_btn_check_material_anim, R.drawable.abc_btn_radio_material_anim };
  public final int[] TINT_COLOR_CONTROL_NORMAL = { R.drawable.abc_ic_commit_search_api_mtrl_alpha, R.drawable.abc_seekbar_tick_mark_material, R.drawable.abc_ic_menu_share_mtrl_alpha, R.drawable.abc_ic_menu_copy_mtrl_am_alpha, R.drawable.abc_ic_menu_cut_mtrl_alpha, R.drawable.abc_ic_menu_selectall_mtrl_alpha, R.drawable.abc_ic_menu_paste_mtrl_am_alpha };
  public final int[] TINT_COLOR_CONTROL_STATE_LIST = { R.drawable.abc_tab_indicator_material, R.drawable.abc_textfield_search_material };
  
  public TintManager() {}
  
  public final boolean arrayContains(int[] paramArrayOfInt, int paramInt)
  {
    int j = paramArrayOfInt.length;
    int i = 0;
    while (i < j)
    {
      if (paramArrayOfInt[i] == paramInt) {
        return true;
      }
      i += 1;
    }
    return false;
  }
  
  public final ColorStateList createBorderlessButtonColorStateList(android.content.Context paramContext)
  {
    return createButtonColorStateList(paramContext, 0);
  }
  
  public final ColorStateList createButtonColorStateList(android.content.Context paramContext, int paramInt)
  {
    int[][] arrayOfInt = new int[4][];
    int[] arrayOfInt1 = new int[4];
    int i = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlHighlight);
    int j = ThemeUtils.getDisabledThemeAttrColor(paramContext, R.attr.colorButtonNormal);
    arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
    arrayOfInt1[0] = j;
    j = 0 + 1;
    arrayOfInt[j] = ThemeUtils.PRESSED_STATE_SET;
    arrayOfInt1[j] = ColorUtils.compositeColors(i, paramInt);
    j += 1;
    arrayOfInt[j] = ThemeUtils.FOCUSED_STATE_SET;
    arrayOfInt1[j] = ColorUtils.compositeColors(i, paramInt);
    i = j + 1;
    arrayOfInt[i] = ThemeUtils.EMPTY_STATE_SET;
    arrayOfInt1[i] = paramInt;
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
  
  public final ColorStateList createColoredButtonColorStateList(android.content.Context paramContext)
  {
    return createButtonColorStateList(paramContext, ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorAccent));
  }
  
  public final ColorStateList createDefaultButtonColorStateList(android.content.Context paramContext)
  {
    return createButtonColorStateList(paramContext, ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorButtonNormal));
  }
  
  public final ColorStateList createSwitchThumbColorStateList(android.content.Context paramContext)
  {
    int[][] arrayOfInt = new int[3][];
    int[] arrayOfInt1 = new int[3];
    ColorStateList localColorStateList = ThemeUtils.getThemeAttrColorStateList(paramContext, R.attr.colorSwitchThumbNormal);
    int i;
    if ((localColorStateList != null) && (localColorStateList.isStateful()))
    {
      arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
      arrayOfInt1[0] = localColorStateList.getColorForState(arrayOfInt[0], 0);
      i = 0 + 1;
      arrayOfInt[i] = ThemeUtils.CHECKED_STATE_SET;
      arrayOfInt1[i] = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated);
      i += 1;
      arrayOfInt[i] = ThemeUtils.EMPTY_STATE_SET;
      arrayOfInt1[i] = localColorStateList.getDefaultColor();
    }
    else
    {
      arrayOfInt[0] = ThemeUtils.DISABLED_STATE_SET;
      arrayOfInt1[0] = ThemeUtils.getDisabledThemeAttrColor(paramContext, R.attr.colorSwitchThumbNormal);
      i = 0 + 1;
      arrayOfInt[i] = ThemeUtils.CHECKED_STATE_SET;
      arrayOfInt1[i] = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated);
      i += 1;
      arrayOfInt[i] = ThemeUtils.EMPTY_STATE_SET;
      arrayOfInt1[i] = ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorSwitchThumbNormal);
    }
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
  
  public Drawable getDrawable(AppCompatDrawableManager paramAppCompatDrawableManager, android.content.Context paramContext, int paramInt)
  {
    if (paramInt == R.drawable.abc_cab_background_top_material) {
      return new LayerDrawable(new Drawable[] { paramAppCompatDrawableManager.getDrawable(paramContext, R.drawable.abc_cab_background_internal_bg), paramAppCompatDrawableManager.getDrawable(paramContext, R.drawable.abc_cab_background_top_mtrl_alpha) });
    }
    return null;
  }
  
  public ColorStateList getTintList(android.content.Context paramContext, int paramInt)
  {
    if (paramInt == R.drawable.abc_edit_text_material) {
      return Resources.onCreateView(paramContext, R.color.abc_tint_edittext);
    }
    if (paramInt == R.drawable.abc_switch_track_mtrl_alpha) {
      return Resources.onCreateView(paramContext, R.color.abc_tint_switch_track);
    }
    if (paramInt == R.drawable.abc_switch_thumb_material) {
      return createSwitchThumbColorStateList(paramContext);
    }
    if (paramInt == R.drawable.abc_btn_default_mtrl_shape) {
      return createDefaultButtonColorStateList(paramContext);
    }
    if (paramInt == R.drawable.abc_btn_borderless_material) {
      return createBorderlessButtonColorStateList(paramContext);
    }
    if (paramInt == R.drawable.abc_btn_colored_material) {
      return createColoredButtonColorStateList(paramContext);
    }
    if ((paramInt != R.drawable.abc_spinner_mtrl_am_alpha) && (paramInt != R.drawable.abc_spinner_textfield_background_material))
    {
      if (arrayContains(TINT_COLOR_CONTROL_NORMAL, paramInt)) {
        return ThemeUtils.getThemeAttrColorStateList(paramContext, R.attr.colorControlNormal);
      }
      if (arrayContains(TINT_COLOR_CONTROL_STATE_LIST, paramInt)) {
        return Resources.onCreateView(paramContext, R.color.abc_tint_default);
      }
      if (arrayContains(TINT_CHECKABLE_BUTTON_LIST, paramInt)) {
        return Resources.onCreateView(paramContext, R.color.abc_tint_btn_checkable);
      }
      if (paramInt == R.drawable.abc_seekbar_thumb_material) {
        return Resources.onCreateView(paramContext, R.color.abc_tint_seek_thumb);
      }
      return null;
    }
    return Resources.onCreateView(paramContext, R.color.abc_tint_spinner);
  }
  
  public PorterDuff.Mode getTintMode(int paramInt)
  {
    if (paramInt == R.drawable.abc_switch_thumb_material) {
      return PorterDuff.Mode.MULTIPLY;
    }
    return null;
  }
  
  public final void setPorterDuffColorFilter(Drawable paramDrawable, int paramInt, PorterDuff.Mode paramMode)
  {
    Drawable localDrawable = paramDrawable;
    if (DrawableUtils.canSafelyMutateDrawable(paramDrawable)) {
      localDrawable = paramDrawable.mutate();
    }
    paramDrawable = paramMode;
    if (paramMode == null) {
      paramDrawable = Context.getThemeAttrColor();
    }
    localDrawable.setColorFilter(Context.get(paramInt, paramDrawable));
  }
  
  public boolean tintDrawable(android.content.Context paramContext, int paramInt, Drawable paramDrawable)
  {
    if (paramInt == R.drawable.abc_seekbar_track_material)
    {
      paramDrawable = (LayerDrawable)paramDrawable;
      setPorterDuffColorFilter(paramDrawable.findDrawableByLayerId(16908288), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlNormal), Context.getThemeAttrColor());
      setPorterDuffColorFilter(paramDrawable.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlNormal), Context.getThemeAttrColor());
      setPorterDuffColorFilter(paramDrawable.findDrawableByLayerId(16908301), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated), Context.getThemeAttrColor());
      return true;
    }
    if ((paramInt != R.drawable.abc_ratingbar_material) && (paramInt != R.drawable.abc_ratingbar_indicator_material) && (paramInt != R.drawable.abc_ratingbar_small_material)) {
      return false;
    }
    paramDrawable = (LayerDrawable)paramDrawable;
    setPorterDuffColorFilter(paramDrawable.findDrawableByLayerId(16908288), ThemeUtils.getDisabledThemeAttrColor(paramContext, R.attr.colorControlNormal), Context.getThemeAttrColor());
    setPorterDuffColorFilter(paramDrawable.findDrawableByLayerId(16908303), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated), Context.getThemeAttrColor());
    setPorterDuffColorFilter(paramDrawable.findDrawableByLayerId(16908301), ThemeUtils.getThemeAttrColor(paramContext, R.attr.colorControlActivated), Context.getThemeAttrColor());
    return true;
  }
  
  public boolean tintDrawableUsingColorFilter(android.content.Context paramContext, int paramInt, Drawable paramDrawable)
  {
    Object localObject2 = Context.getThemeAttrColor();
    int i = 0;
    int j = 0;
    int m = -1;
    Object localObject1;
    int k;
    if (arrayContains(COLORFILTER_TINT_COLOR_CONTROL_NORMAL, paramInt))
    {
      j = R.attr.colorControlNormal;
      i = 1;
      localObject1 = localObject2;
      k = m;
    }
    else if (arrayContains(COLORFILTER_COLOR_CONTROL_ACTIVATED, paramInt))
    {
      j = R.attr.colorControlActivated;
      i = 1;
      localObject1 = localObject2;
      k = m;
    }
    else if (arrayContains(COLORFILTER_COLOR_BACKGROUND_MULTIPLY, paramInt))
    {
      j = 16842801;
      i = 1;
      localObject1 = PorterDuff.Mode.MULTIPLY;
      k = m;
    }
    else if (paramInt == R.drawable.abc_list_divider_mtrl_alpha)
    {
      j = 16842800;
      i = 1;
      k = Math.round(40.8F);
      localObject1 = localObject2;
    }
    else
    {
      localObject1 = localObject2;
      k = m;
      if (paramInt == R.drawable.abc_dialog_material_background)
      {
        j = 16842801;
        i = 1;
        k = m;
        localObject1 = localObject2;
      }
    }
    if (i != 0)
    {
      localObject2 = paramDrawable;
      if (DrawableUtils.canSafelyMutateDrawable(paramDrawable)) {
        localObject2 = paramDrawable.mutate();
      }
      ((Drawable)localObject2).setColorFilter(Context.get(ThemeUtils.getThemeAttrColor(paramContext, j), (PorterDuff.Mode)localObject1));
      if (k != -1) {
        ((Drawable)localObject2).setAlpha(k);
      }
      return true;
    }
    return false;
  }
}
