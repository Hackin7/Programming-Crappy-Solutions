package org.asm;

import android.view.ViewGroup;

public class Type
{
  public static Item a(ViewGroup paramViewGroup)
  {
    return new ByteVector(paramViewGroup);
  }
  
  public static void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    w.a(paramViewGroup, paramBoolean);
  }
}
