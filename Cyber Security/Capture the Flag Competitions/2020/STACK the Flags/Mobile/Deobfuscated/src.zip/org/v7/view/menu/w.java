package org.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import org.core.view.ViewCompat;
import org.v7.R.dimen;
import org.v7.R.layout;
import org.v7.widget.ListPopupWindow;

public final class w
  extends k
  implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, l, View.OnKeyListener
{
  public static final int width = R.layout.abc_popup_menu_item_layout;
  public boolean G;
  public final View.OnAttachStateChangeListener P = new PopupMenuHelper(this);
  public final ViewTreeObserver.OnGlobalLayoutListener W = new ActivityChooserView.2(this);
  public View a;
  public final boolean b;
  public final Context c;
  public final MenuBuilder f;
  public final int h;
  public final int i;
  public l.a k;
  public final x mAdapter;
  public int mContentWidth;
  public boolean mHasContentWidth;
  public PopupWindow.OnDismissListener mOnDismissListener;
  public final org.v7.widget.i mPopup;
  public ViewTreeObserver mTreeObserver;
  public int s = 0;
  public final int t;
  public boolean top;
  public View v;
  
  public w(Context paramContext, MenuBuilder paramMenuBuilder, View paramView, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    c = paramContext;
    f = paramMenuBuilder;
    b = paramBoolean;
    mAdapter = new x(paramMenuBuilder, LayoutInflater.from(paramContext), b, width);
    i = paramInt1;
    h = paramInt2;
    Resources localResources = paramContext.getResources();
    t = Math.max(getDisplayMetricswidthPixels / 2, localResources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    v = paramView;
    mPopup = new org.v7.widget.i(c, null, i, h);
    paramMenuBuilder.addMenuPresenter(this, paramContext);
  }
  
  public void a(int paramInt)
  {
    s = paramInt;
  }
  
  public void a(View paramView)
  {
    v = paramView;
  }
  
  public void a(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    mOnDismissListener = paramOnDismissListener;
  }
  
  public void a(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    if (paramMenuBuilder != f) {
      return;
    }
    dismiss();
    l.a localA = k;
    if (localA != null) {
      localA.onCloseMenu(paramMenuBuilder, paramBoolean);
    }
  }
  
  public void a(boolean paramBoolean)
  {
    mAdapter.a(paramBoolean);
  }
  
  public final boolean a()
  {
    if (isShowing()) {
      return true;
    }
    if (!top)
    {
      Object localObject1 = v;
      if (localObject1 == null) {
        return false;
      }
      a = ((View)localObject1);
      mPopup.setOnDismissListener(this);
      mPopup.setOnItemClickListener(this);
      mPopup.setModal(true);
      localObject1 = a;
      int j;
      if (mTreeObserver == null) {
        j = 1;
      } else {
        j = 0;
      }
      Object localObject2 = ((View)localObject1).getViewTreeObserver();
      mTreeObserver = ((ViewTreeObserver)localObject2);
      if (j != 0) {
        ((ViewTreeObserver)localObject2).addOnGlobalLayoutListener(W);
      }
      ((View)localObject1).addOnAttachStateChangeListener(P);
      mPopup.setAdapter((View)localObject1);
      mPopup.dismiss(s);
      if (!mHasContentWidth)
      {
        mContentWidth = k.measureContentWidth(mAdapter, null, c, t);
        mHasContentWidth = true;
      }
      mPopup.setContentWidth(mContentWidth);
      mPopup.show(2);
      mPopup.show(get());
      mPopup.show();
      localObject1 = mPopup.c();
      ((View)localObject1).setOnKeyListener(this);
      if ((G) && (f.getHeaderTitle() != null))
      {
        localObject2 = (FrameLayout)LayoutInflater.from(c).inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup)localObject1, false);
        TextView localTextView = (TextView)((View)localObject2).findViewById(16908310);
        if (localTextView != null) {
          localTextView.setText(f.getHeaderTitle());
        }
        ((View)localObject2).setEnabled(false);
        ((ListView)localObject1).addHeaderView((View)localObject2, null, false);
      }
      mPopup.setAdapter(mAdapter);
      mPopup.show();
      return true;
    }
    return false;
  }
  
  public ListView c()
  {
    return mPopup.c();
  }
  
  public void c(int paramInt)
  {
    mPopup.setVerticalOffset(paramInt);
  }
  
  public void c(boolean paramBoolean)
  {
    G = paramBoolean;
  }
  
  public void dismiss()
  {
    if (isShowing()) {
      mPopup.dismiss();
    }
  }
  
  public boolean flagActionItems()
  {
    return false;
  }
  
  public boolean isShowing()
  {
    return (!top) && (mPopup.isShowing());
  }
  
  public void onDismiss()
  {
    top = true;
    f.close();
    Object localObject = mTreeObserver;
    if (localObject != null)
    {
      if (!((ViewTreeObserver)localObject).isAlive()) {
        mTreeObserver = a.getViewTreeObserver();
      }
      mTreeObserver.removeGlobalOnLayoutListener(W);
      mTreeObserver = null;
    }
    a.removeOnAttachStateChangeListener(P);
    localObject = mOnDismissListener;
    if (localObject != null) {
      ((PopupWindow.OnDismissListener)localObject).onDismiss();
    }
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramKeyEvent.getAction() == 1) && (paramInt == 82))
    {
      dismiss();
      return true;
    }
    return false;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    if (paramSubMenuBuilder.hasVisibleItems())
    {
      Object localObject = new i(c, paramSubMenuBuilder, a, b, i, h);
      ((i)localObject).a(k);
      ((i)localObject).a(k.onSubMenuSelected(paramSubMenuBuilder));
      ((i)localObject).setOnDismissListener(mOnDismissListener);
      mOnDismissListener = null;
      f.close(false);
      int m = mPopup.getHorizontalOffset();
      int j = m;
      int n = mPopup.getVerticalOffset();
      if ((Gravity.getAbsoluteGravity(s, ViewCompat.getLayoutDirection(v)) & 0x7) == 5) {
        j = m + v.getWidth();
      }
      if (((i)localObject).a(j, n))
      {
        localObject = k;
        if (localObject != null) {
          ((l.a)localObject).onOpenSubMenu(paramSubMenuBuilder);
        }
        return true;
      }
    }
    return false;
  }
  
  public void setCallback(l.a paramA)
  {
    k = paramA;
  }
  
  public void setTitle(MenuBuilder paramMenuBuilder) {}
  
  public void show()
  {
    if (a()) {
      return;
    }
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void show(int paramInt)
  {
    mPopup.setHorizontalOffset(paramInt);
  }
  
  public void updateMenuView(boolean paramBoolean)
  {
    mHasContentWidth = false;
    x localX = mAdapter;
    if (localX != null) {
      localX.notifyDataSetChanged();
    }
  }
}
