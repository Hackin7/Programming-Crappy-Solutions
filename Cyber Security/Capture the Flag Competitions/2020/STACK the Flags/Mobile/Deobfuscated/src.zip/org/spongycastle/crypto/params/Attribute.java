package org.spongycastle.crypto.params;

import a.c.a.b.b.c;
import java.util.Map.Entry;

public class Attribute<K, V>
  implements Map.Entry<K, V>
{
  public b.c<K, V> a;
  public b.c<K, V> b;
  public final V d;
  public final K x;
  
  public Attribute(Object paramObject1, Object paramObject2)
  {
    x = paramObject1;
    d = paramObject2;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Attribute)) {
      return false;
    }
    paramObject = (Attribute)paramObject;
    return (x.equals(x)) && (d.equals(d));
  }
  
  public Object getKey()
  {
    return x;
  }
  
  public Object getValue()
  {
    return d;
  }
  
  public int hashCode()
  {
    return x.hashCode() ^ d.hashCode();
  }
  
  public Object setValue(Object paramObject)
  {
    throw new UnsupportedOperationException("An entry modification is not supported");
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(x);
    localStringBuilder.append("=");
    localStringBuilder.append(d);
    return localStringBuilder.toString();
  }
}
