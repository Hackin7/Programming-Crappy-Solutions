package org.asm;

import android.util.Log;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class NumberPicker
  extends Attribute
{
  public static boolean a;
  public static boolean b;
  public static Method c;
  public static Method d;
  
  public NumberPicker() {}
  
  public void a(View paramView) {}
  
  public final void init()
  {
    if (!b)
    {
      Object localObject = Float.TYPE;
      try
      {
        localObject = View.class.getDeclaredMethod("setTransitionAlpha", new Class[] { localObject });
        c = (Method)localObject;
        ((Method)localObject).setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.i("ViewUtilsApi19", "Failed to retrieve setTransitionAlpha method", localNoSuchMethodException);
      }
      b = true;
    }
  }
  
  public float setValue(View paramView)
  {
    setValue();
    Object localObject = d;
    if (localObject != null) {
      try
      {
        localObject = ((Method)localObject).invoke(paramView, new Object[0]);
        localObject = (Float)localObject;
        float f = ((Float)localObject).floatValue();
        return f;
      }
      catch (InvocationTargetException paramView)
      {
        throw new RuntimeException(paramView.getCause());
      }
      catch (IllegalAccessException localIllegalAccessException) {}
    }
    return super.setValue(paramView);
  }
  
  public final void setValue()
  {
    if (!a)
    {
      try
      {
        Method localMethod = View.class.getDeclaredMethod("getTransitionAlpha", new Class[0]);
        d = localMethod;
        localMethod.setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        Log.i("ViewUtilsApi19", "Failed to retrieve getTransitionAlpha method", localNoSuchMethodException);
      }
      a = true;
    }
  }
  
  public void setValue(View paramView, float paramFloat)
  {
    init();
    Method localMethod = c;
    if (localMethod != null) {
      try
      {
        localMethod.invoke(paramView, new Object[] { Float.valueOf(paramFloat) });
        return;
      }
      catch (InvocationTargetException paramView)
      {
        throw new RuntimeException(paramView.getCause());
      }
      catch (IllegalAccessException paramView)
      {
        return;
      }
    }
    paramView.setAlpha(paramFloat);
  }
  
  public void write(View paramView) {}
}
