package org.asm;

import android.view.View;

public class MethodVisitor
{
  public static void a(View paramView, MethodVisitor paramMethodVisitor)
  {
    paramView.setTag(R.id.transition_current_scene, paramMethodVisitor);
  }
  
  public static MethodVisitor getContentView(View paramView)
  {
    return (MethodVisitor)paramView.getTag(R.id.transition_current_scene);
  }
  
  public void invoke()
  {
    throw new NullPointerException("Null throw statement replaced by Soot");
  }
}
