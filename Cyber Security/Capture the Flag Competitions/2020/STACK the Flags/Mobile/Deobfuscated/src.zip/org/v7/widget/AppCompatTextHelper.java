package org.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AbsSeekBar;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import org.core.asm.signature.DrawableCompat;
import org.core.view.ViewCompat;
import org.v7.R.styleable;

public class AppCompatTextHelper
  extends AppCompatProgressBarHelper
{
  public ColorStateList mButtonTintList = null;
  public PorterDuff.Mode mButtonTintMode = null;
  public Drawable mDrawable;
  public boolean mHasButtonTint = false;
  public boolean mHasButtonTintMode = false;
  public final SeekBar mView;
  
  public AppCompatTextHelper(SeekBar paramSeekBar)
  {
    super(paramSeekBar);
    mView = paramSeekBar;
  }
  
  public final void applyButtonTint()
  {
    if ((mDrawable != null) && ((mHasButtonTint) || (mHasButtonTintMode)))
    {
      Drawable localDrawable = DrawableCompat.wrap(mDrawable.mutate());
      mDrawable = localDrawable;
      if (mHasButtonTint) {
        DrawableCompat.setTintList(localDrawable, mButtonTintList);
      }
      if (mHasButtonTintMode) {
        DrawableCompat.setTintMode(mDrawable, mButtonTintMode);
      }
      if (mDrawable.isStateful()) {
        mDrawable.setState(mView.getDrawableState());
      }
    }
  }
  
  public void draw(Canvas paramCanvas)
  {
    if (mDrawable != null)
    {
      int k = mView.getMax();
      int j = 1;
      if (k > 1)
      {
        int i = mDrawable.getIntrinsicWidth();
        int m = mDrawable.getIntrinsicHeight();
        if (i >= 0) {
          i /= 2;
        } else {
          i = 1;
        }
        if (m >= 0) {
          j = m / 2;
        }
        mDrawable.setBounds(-i, -j, i, j);
        float f = (mView.getWidth() - mView.getPaddingLeft() - mView.getPaddingRight()) / k;
        j = paramCanvas.save();
        paramCanvas.translate(mView.getPaddingLeft(), mView.getHeight() / 2);
        i = 0;
        while (i <= k)
        {
          mDrawable.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
          i += 1;
        }
        paramCanvas.restoreToCount(j);
      }
    }
  }
  
  public void jumpToCurrentState()
  {
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      localDrawable.jumpToCurrentState();
    }
  }
  
  public void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt)
  {
    super.loadFromAttributes(paramAttributeSet, paramInt);
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(mView.getContext(), paramAttributeSet, R.styleable.AppCompatSeekBar, paramInt, 0);
    SeekBar localSeekBar = mView;
    ViewCompat.obtainStyledAttributes(localSeekBar, localSeekBar.getContext(), R.styleable.AppCompatSeekBar, paramAttributeSet, localTintTypedArray.getResourceId(), paramInt, 0);
    paramAttributeSet = localTintTypedArray.getDrawableIfKnown(R.styleable.AppCompatSeekBar_android_thumb);
    if (paramAttributeSet != null) {
      mView.setThumb(paramAttributeSet);
    }
    setStatusBarBackground(localTintTypedArray.getDrawable(R.styleable.AppCompatSeekBar_tickMark));
    if (localTintTypedArray.hasValue(R.styleable.AppCompatSeekBar_tickMarkTintMode))
    {
      mButtonTintMode = DrawableUtils.parseTintMode(localTintTypedArray.getInt(R.styleable.AppCompatSeekBar_tickMarkTintMode, -1), mButtonTintMode);
      mHasButtonTintMode = true;
    }
    if (localTintTypedArray.hasValue(R.styleable.AppCompatSeekBar_tickMarkTint))
    {
      mButtonTintList = localTintTypedArray.getColorStateList(R.styleable.AppCompatSeekBar_tickMarkTint);
      mHasButtonTint = true;
    }
    localTintTypedArray.recycle();
    applyButtonTint();
  }
  
  public void setState()
  {
    Drawable localDrawable = mDrawable;
    if ((localDrawable != null) && (localDrawable.isStateful()) && (localDrawable.setState(mView.getDrawableState()))) {
      mView.invalidateDrawable(localDrawable);
    }
  }
  
  public void setStatusBarBackground(Drawable paramDrawable)
  {
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      localDrawable.setCallback(null);
    }
    mDrawable = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(mView);
      DrawableCompat.setLayoutDirection(paramDrawable, ViewCompat.getLayoutDirection(mView));
      if (paramDrawable.isStateful()) {
        paramDrawable.setState(mView.getDrawableState());
      }
      applyButtonTint();
    }
    mView.invalidate();
  }
}
