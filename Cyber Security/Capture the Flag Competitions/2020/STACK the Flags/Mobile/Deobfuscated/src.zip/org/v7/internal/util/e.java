package org.v7.internal.util;

import android.content.res.ColorStateList;
import android.content.res.Configuration;

public class e
{
  public final ColorStateList c;
  public final Configuration d;
  
  public e(ColorStateList paramColorStateList, Configuration paramConfiguration)
  {
    c = paramColorStateList;
    d = paramConfiguration;
  }
}
