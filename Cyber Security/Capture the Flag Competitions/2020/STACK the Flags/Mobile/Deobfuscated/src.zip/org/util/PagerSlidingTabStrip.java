package org.util;

import androidx.lifecycle.LiveData;

public class PagerSlidingTabStrip<T>
  extends LiveData<T>
{
  public PagerSlidingTabStrip() {}
  
  public void a(Object paramObject)
  {
    super.a(paramObject);
  }
}
