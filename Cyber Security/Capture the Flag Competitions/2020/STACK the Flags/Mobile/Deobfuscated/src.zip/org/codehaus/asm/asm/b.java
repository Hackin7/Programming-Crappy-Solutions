package org.codehaus.asm.asm;

import a.f.b.i.e;
import java.util.ArrayList;
import org.codehaus.asm.Item;

public class b
  extends f
{
  public ArrayList<e> a = new ArrayList();
  
  public b() {}
  
  public void a()
  {
    Object localObject = a;
    if (localObject == null) {
      return;
    }
    int j = ((ArrayList)localObject).size();
    int i = 0;
    while (i < j)
    {
      localObject = (f)a.get(i);
      if ((localObject instanceof b)) {
        ((b)localObject).a();
      }
      i += 1;
    }
  }
  
  public void a(Item paramItem)
  {
    super.a(paramItem);
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((f)a.get(i)).a(paramItem);
      i += 1;
    }
  }
  
  public void a(f paramF)
  {
    a.add(paramF);
    if (paramF.l() != null) {
      ((b)paramF.l()).close(paramF);
    }
    paramF.c(this);
  }
  
  public void close()
  {
    a.clear();
  }
  
  public void close(f paramF)
  {
    a.remove(paramF);
    paramF.c(null);
  }
  
  public void init()
  {
    a.clear();
    super.init();
  }
  
  public ArrayList m()
  {
    return a;
  }
}
