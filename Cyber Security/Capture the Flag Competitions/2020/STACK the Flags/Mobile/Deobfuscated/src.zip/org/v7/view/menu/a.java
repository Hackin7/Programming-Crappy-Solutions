package org.v7.view.menu;

import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import java.util.Iterator;
import java.util.List;
import org.v7.widget.ListPopupWindow;

public class a
  implements ViewTreeObserver.OnGlobalLayoutListener
{
  public a(d paramD) {}
  
  public void onGlobalLayout()
  {
    if ((a.isShowing()) && (a.a.size() > 0) && (!a.a.get(0)).a.isModal()))
    {
      Object localObject = a.view;
      if ((localObject != null) && (((View)localObject).isShown())) {
        localObject = a.a.iterator();
      }
      while (((Iterator)localObject).hasNext())
      {
        nexta.show();
        continue;
        a.dismiss();
      }
    }
  }
}
