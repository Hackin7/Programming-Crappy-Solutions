package org.data;

public class Item<E>
  implements Cloneable
{
  public static final Object d = new Object();
  public Object[] a;
  public boolean b = false;
  public long[] c;
  public int i;
  
  public Item()
  {
    this(10);
  }
  
  public Item(int paramInt)
  {
    if (paramInt == 0)
    {
      c = ContainerHelpers.c;
      a = ContainerHelpers.a;
      return;
    }
    paramInt = ContainerHelpers.idealLongArraySize(paramInt);
    c = new long[paramInt];
    a = new Object[paramInt];
  }
  
  public void a()
  {
    int k = i;
    Object[] arrayOfObject = a;
    int j = 0;
    while (j < k)
    {
      arrayOfObject[j] = null;
      j += 1;
    }
    i = 0;
    b = false;
  }
  
  public void a(int paramInt)
  {
    Object[] arrayOfObject = a;
    Object localObject1 = arrayOfObject[paramInt];
    Object localObject2 = d;
    if (localObject1 != localObject2)
    {
      arrayOfObject[paramInt] = localObject2;
      b = true;
    }
  }
  
  public void a(long paramLong)
  {
    int j = ContainerHelpers.get(c, i, paramLong);
    if (j >= 0)
    {
      Object[] arrayOfObject = a;
      Object localObject1 = arrayOfObject[j];
      Object localObject2 = d;
      if (localObject1 != localObject2)
      {
        arrayOfObject[j] = localObject2;
        b = true;
      }
    }
  }
  
  public void a(long paramLong, Object paramObject)
  {
    int j = ContainerHelpers.get(c, i, paramLong);
    if (j >= 0)
    {
      a[j] = paramObject;
      return;
    }
    int k = j;
    Object localObject1;
    if (k < i)
    {
      localObject1 = a;
      if (localObject1[k] == d)
      {
        c[k] = paramLong;
        localObject1[k] = paramObject;
        return;
      }
    }
    j = k;
    if (b)
    {
      j = k;
      if (i >= c.length)
      {
        d();
        j = ContainerHelpers.get(c, i, paramLong);
      }
    }
    k = i;
    if (k >= c.length)
    {
      k = ContainerHelpers.idealLongArraySize(k + 1);
      localObject1 = new long[k];
      Object[] arrayOfObject = new Object[k];
      Object localObject2 = c;
      System.arraycopy(localObject2, 0, localObject1, 0, localObject2.length);
      localObject2 = a;
      System.arraycopy(localObject2, 0, arrayOfObject, 0, localObject2.length);
      c = ((long[])localObject1);
      a = arrayOfObject;
    }
    k = i;
    if (k - j != 0)
    {
      localObject1 = c;
      System.arraycopy(localObject1, j, localObject1, j + 1, k - j);
      localObject1 = a;
      System.arraycopy(localObject1, j, localObject1, j + 1, i - j);
    }
    c[j] = paramLong;
    a[j] = paramObject;
    i += 1;
  }
  
  public boolean add(long paramLong)
  {
    return remove(paramLong) >= 0;
  }
  
  public int b()
  {
    if (b) {
      d();
    }
    return i;
  }
  
  public Object b(int paramInt)
  {
    if (b) {
      d();
    }
    return a[paramInt];
  }
  
  public final void d()
  {
    int n = i;
    int k = 0;
    long[] arrayOfLong = c;
    Object[] arrayOfObject = a;
    int j = 0;
    while (j < n)
    {
      Object localObject = arrayOfObject[j];
      int m = k;
      if (localObject != d)
      {
        if (j != k)
        {
          arrayOfLong[k] = arrayOfLong[j];
          arrayOfObject[k] = localObject;
          arrayOfObject[j] = null;
        }
        m = k + 1;
      }
      j += 1;
      k = m;
    }
    b = false;
    i = k;
  }
  
  public long get(int paramInt)
  {
    if (b) {
      d();
    }
    return c[paramInt];
  }
  
  public Object get(long paramLong)
  {
    return get(paramLong, null);
  }
  
  public Object get(long paramLong, Object paramObject)
  {
    int j = ContainerHelpers.get(c, i, paramLong);
    Object localObject = paramObject;
    if (j >= 0)
    {
      localObject = a;
      if (localObject[j] == d) {
        return paramObject;
      }
      localObject = localObject[j];
    }
    return localObject;
  }
  
  public int remove(long paramLong)
  {
    if (b) {
      d();
    }
    return ContainerHelpers.get(c, i, paramLong);
  }
  
  public Item set()
  {
    try
    {
      Object localObject1 = super.clone();
      localObject1 = (Item)localObject1;
      Object localObject2 = c;
      localObject2 = localObject2.clone();
      c = ((long[])localObject2);
      localObject2 = a;
      localObject2 = localObject2.clone();
      a = ((Object[])localObject2);
      return localObject1;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new AssertionError(localCloneNotSupportedException);
    }
  }
  
  public void set(long paramLong, Object paramObject)
  {
    int j = i;
    if ((j != 0) && (paramLong <= c[(j - 1)]))
    {
      a(paramLong, paramObject);
      return;
    }
    if ((b) && (i >= c.length)) {
      d();
    }
    j = i;
    if (j >= c.length)
    {
      int k = ContainerHelpers.idealLongArraySize(j + 1);
      long[] arrayOfLong = new long[k];
      Object[] arrayOfObject = new Object[k];
      Object localObject = c;
      System.arraycopy(localObject, 0, arrayOfLong, 0, localObject.length);
      localObject = a;
      System.arraycopy(localObject, 0, arrayOfObject, 0, localObject.length);
      c = arrayOfLong;
      a = arrayOfObject;
    }
    c[j] = paramLong;
    a[j] = paramObject;
    i = (j + 1);
  }
  
  public String toString()
  {
    if (b() <= 0) {
      return "{}";
    }
    StringBuilder localStringBuilder = new StringBuilder(i * 28);
    localStringBuilder.append('{');
    int j = 0;
    while (j < i)
    {
      if (j > 0) {
        localStringBuilder.append(", ");
      }
      localStringBuilder.append(get(j));
      localStringBuilder.append('=');
      Object localObject = b(j);
      if (localObject != this) {
        localStringBuilder.append(localObject);
      } else {
        localStringBuilder.append("(this Map)");
      }
      j += 1;
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}
