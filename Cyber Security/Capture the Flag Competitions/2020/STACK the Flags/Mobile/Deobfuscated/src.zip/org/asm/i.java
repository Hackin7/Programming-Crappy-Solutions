package org.asm;

public class i
  extends h
{
  public i()
  {
    setIcon();
  }
  
  public final void setIcon()
  {
    c(1);
    a(new q(2));
    a(new f());
    a(new q(1));
  }
}
