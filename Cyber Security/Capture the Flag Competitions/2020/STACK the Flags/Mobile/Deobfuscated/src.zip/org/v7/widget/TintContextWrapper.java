package org.v7.widget;

import android.content.Context;
import android.content.ContextWrapper;

public class TintContextWrapper
  extends ContextWrapper
{
  public static final Object IMPORTER_TAG = new Object();
  
  public static boolean shouldWrap(Context paramContext)
  {
    if ((!(paramContext instanceof TintContextWrapper)) && (!(paramContext.getResources() instanceof SystemSettings_)))
    {
      if ((paramContext.getResources() instanceof Log)) {
        return false;
      }
      Log.i();
    }
    return false;
  }
  
  public static Context wrap(Context paramContext)
  {
    shouldWrap(paramContext);
    return paramContext;
  }
}
