package org.objectweb.asm;

public abstract interface MethodVisitor {}
