package org.codehaus.asm;

import a.f.b.e;

public class MethodWriter<T>
  implements e<T>
{
  public final Object[] b;
  public int i;
  
  public MethodWriter(int paramInt)
  {
    if (paramInt > 0)
    {
      b = new Object[paramInt];
      return;
    }
    throw new IllegalArgumentException("The max pool size must be > 0");
  }
  
  public void a(Object[] paramArrayOfObject, int paramInt)
  {
    int j = paramInt;
    if (paramInt > paramArrayOfObject.length) {
      j = paramArrayOfObject.length;
    }
    paramInt = 0;
    while (paramInt < j)
    {
      Object localObject = paramArrayOfObject[paramInt];
      int k = i;
      Object[] arrayOfObject = b;
      if (k < arrayOfObject.length)
      {
        arrayOfObject[k] = localObject;
        i = (k + 1);
      }
      paramInt += 1;
    }
  }
  
  public boolean a(Object paramObject)
  {
    int j = i;
    Object[] arrayOfObject = b;
    if (j < arrayOfObject.length)
    {
      arrayOfObject[j] = paramObject;
      i = (j + 1);
      return true;
    }
    return false;
  }
  
  public Object b()
  {
    int j = i;
    if (j > 0)
    {
      int k = j - 1;
      Object[] arrayOfObject = b;
      Object localObject = arrayOfObject[k];
      arrayOfObject[k] = null;
      i = (j - 1);
      return localObject;
    }
    return null;
  }
}
