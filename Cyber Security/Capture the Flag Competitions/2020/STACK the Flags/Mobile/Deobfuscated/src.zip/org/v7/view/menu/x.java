package org.v7.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.util.ArrayList;

public class x
  extends BaseAdapter
{
  public final boolean a;
  public MenuBuilder b;
  public int c = -1;
  public final int d;
  public boolean f;
  public final LayoutInflater i;
  
  public x(MenuBuilder paramMenuBuilder, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt)
  {
    a = paramBoolean;
    i = paramLayoutInflater;
    b = paramMenuBuilder;
    d = paramInt;
    a();
  }
  
  public MenuItemImpl a(int paramInt)
  {
    ArrayList localArrayList;
    if (a) {
      localArrayList = b.getNonActionItems();
    } else {
      localArrayList = b.getVisibleItems();
    }
    int k = c;
    int j = paramInt;
    if (k >= 0)
    {
      j = paramInt;
      if (paramInt >= k) {
        j = paramInt + 1;
      }
    }
    return (MenuItemImpl)localArrayList.get(j);
  }
  
  public void a()
  {
    MenuItemImpl localMenuItemImpl = b.getExpandedItem();
    if (localMenuItemImpl != null)
    {
      ArrayList localArrayList = b.getNonActionItems();
      int k = localArrayList.size();
      int j = 0;
      while (j < k)
      {
        if ((MenuItemImpl)localArrayList.get(j) == localMenuItemImpl)
        {
          c = j;
          return;
        }
        j += 1;
      }
    }
    c = -1;
  }
  
  public void a(boolean paramBoolean)
  {
    f = paramBoolean;
  }
  
  public int getCount()
  {
    ArrayList localArrayList;
    if (a) {
      localArrayList = b.getNonActionItems();
    } else {
      localArrayList = b.getVisibleItems();
    }
    if (c < 0) {
      return localArrayList.size();
    }
    return localArrayList.size() - 1;
  }
  
  public long getItemId(int paramInt)
  {
    return paramInt;
  }
  
  public MenuBuilder getValue()
  {
    return b;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    View localView = paramView;
    if (paramView == null) {
      localView = i.inflate(d, paramViewGroup, false);
    }
    int k = a(paramInt).getGroupId();
    int j;
    if (paramInt - 1 >= 0) {
      j = a(paramInt - 1).getGroupId();
    } else {
      j = k;
    }
    paramView = (ListMenuItemView)localView;
    boolean bool;
    if ((b.collapseItemActionView()) && (k != j)) {
      bool = true;
    } else {
      bool = false;
    }
    paramView.setGroupDividerEnabled(bool);
    paramView = (MenuView.ItemView)localView;
    if (f) {
      ((ListMenuItemView)localView).setForceShowIcon(true);
    }
    paramView.initialize(a(paramInt), 0);
    return localView;
  }
  
  public void notifyDataSetChanged()
  {
    a();
    super.notifyDataSetChanged();
  }
}
