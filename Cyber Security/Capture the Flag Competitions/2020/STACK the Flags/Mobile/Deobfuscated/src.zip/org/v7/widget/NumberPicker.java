package org.v7.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnHoverListener;
import android.view.View.OnLongClickListener;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import org.core.view.ClassWriter;
import org.core.view.ViewCompat;

public class NumberPicker
  implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener
{
  public static NumberPicker u;
  public static NumberPicker x;
  public final Runnable a = new a1.a(this);
  public final int b;
  public Label c;
  public boolean e;
  public final CharSequence h;
  public int p;
  public final Runnable r = new a1.b(this);
  public int s;
  public final View this$0;
  
  public NumberPicker(View paramView, CharSequence paramCharSequence)
  {
    this$0 = paramView;
    h = paramCharSequence;
    b = ClassWriter.get(ViewConfiguration.get(paramView.getContext()));
    reset();
    this$0.setOnLongClickListener(this);
    this$0.setOnHoverListener(this);
  }
  
  public static void init(View paramView, CharSequence paramCharSequence)
  {
    NumberPicker localNumberPicker = u;
    if ((localNumberPicker != null) && (this$0 == paramView)) {
      reset(null);
    }
    if (TextUtils.isEmpty(paramCharSequence))
    {
      paramCharSequence = x;
      if ((paramCharSequence != null) && (this$0 == paramView)) {
        paramCharSequence.add();
      }
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    }
    new NumberPicker(paramView, paramCharSequence);
  }
  
  public static void reset(NumberPicker paramNumberPicker)
  {
    NumberPicker localNumberPicker = u;
    if (localNumberPicker != null) {
      localNumberPicker.onClick();
    }
    u = paramNumberPicker;
    if (paramNumberPicker != null) {
      paramNumberPicker.init();
    }
  }
  
  public void add()
  {
    if (x == this)
    {
      x = null;
      Label localLabel = c;
      if (localLabel != null)
      {
        localLabel.a();
        c = null;
        reset();
        this$0.removeOnAttachStateChangeListener(this);
      }
      else
      {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      }
    }
    if (u == this) {
      reset(null);
    }
    this$0.removeCallbacks(r);
  }
  
  public final void init()
  {
    this$0.postDelayed(a, ViewConfiguration.getLongPressTimeout());
  }
  
  public void init(boolean paramBoolean)
  {
    if (!ViewCompat.isAttachedToWindow(this$0)) {
      return;
    }
    reset(null);
    Object localObject = x;
    if (localObject != null) {
      ((NumberPicker)localObject).add();
    }
    x = this;
    e = paramBoolean;
    localObject = new Label(this$0.getContext());
    c = ((Label)localObject);
    ((Label)localObject).a(this$0, p, s, e, h);
    this$0.addOnAttachStateChangeListener(this);
    long l;
    if (e) {
      l = 2500L;
    } else if ((ViewCompat.getWindowSystemUiVisibility(this$0) & 0x1) == 1) {
      l = 3000L - ViewConfiguration.getLongPressTimeout();
    } else {
      l = 15000L - ViewConfiguration.getLongPressTimeout();
    }
    this$0.removeCallbacks(r);
    this$0.postDelayed(r, l);
  }
  
  public final void onClick()
  {
    this$0.removeCallbacks(a);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent)
  {
    if ((c != null) && (e)) {
      return false;
    }
    paramView = (AccessibilityManager)this$0.getContext().getSystemService("accessibility");
    if ((paramView.isEnabled()) && (paramView.isTouchExplorationEnabled())) {
      return false;
    }
    int i = paramMotionEvent.getAction();
    if (i != 7)
    {
      if (i != 10) {
        return false;
      }
      reset();
      add();
      return false;
    }
    if ((this$0.isEnabled()) && (c == null) && (onTouchEvent(paramMotionEvent))) {
      reset(this);
    }
    return false;
  }
  
  public boolean onLongClick(View paramView)
  {
    p = (paramView.getWidth() / 2);
    s = (paramView.getHeight() / 2);
    init(true);
    return true;
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if ((Math.abs(i - p) <= b) && (Math.abs(j - s) <= b)) {
      return false;
    }
    p = i;
    s = j;
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView)
  {
    add();
  }
  
  public final void reset()
  {
    p = Integer.MAX_VALUE;
    s = Integer.MAX_VALUE;
  }
}
