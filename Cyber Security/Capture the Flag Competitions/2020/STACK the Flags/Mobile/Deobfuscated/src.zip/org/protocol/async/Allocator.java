package org.protocol.async;

import java.io.Closeable;

public abstract interface Allocator
  extends Closeable
{}
