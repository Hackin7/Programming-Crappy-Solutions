package org.codehaus.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.widget.ConstraintLayout.a;

public class f
  extends ConstraintLayout.a
{
  public float a = 0.0F;
  public boolean c = false;
  public float e = 1.0F;
  public float f = 1.0F;
  public float h = 0.0F;
  public float i = 0.0F;
  public float k = 0.0F;
  public float n = 0.0F;
  public float r = 0.0F;
  public float s = 0.0F;
  public float w = 1.0F;
  public float x = 0.0F;
  public float y = 0.0F;
  
  public f(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
  }
  
  public f(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.ConstraintSet);
    int m = paramContext.getIndexCount();
    int j = 0;
    while (j < m)
    {
      int i1 = paramContext.getIndex(j);
      if (i1 == IpAddress.ConstraintSet_android_alpha)
      {
        w = paramContext.getFloat(i1, w);
      }
      else if (i1 == IpAddress.ConstraintSet_android_elevation)
      {
        h = paramContext.getFloat(i1, h);
        c = true;
      }
      else if (i1 == IpAddress.ConstraintSet_android_rotationX)
      {
        i = paramContext.getFloat(i1, i);
      }
      else if (i1 == IpAddress.ConstraintSet_android_rotationY)
      {
        s = paramContext.getFloat(i1, s);
      }
      else if (i1 == IpAddress.ConstraintSet_android_rotation)
      {
        a = paramContext.getFloat(i1, a);
      }
      else if (i1 == IpAddress.ConstraintSet_android_scaleX)
      {
        e = paramContext.getFloat(i1, e);
      }
      else if (i1 == IpAddress.ConstraintSet_android_scaleY)
      {
        f = paramContext.getFloat(i1, f);
      }
      else if (i1 == IpAddress.ConstraintSet_android_transformPivotX)
      {
        r = paramContext.getFloat(i1, r);
      }
      else if (i1 == IpAddress.ConstraintSet_android_transformPivotY)
      {
        x = paramContext.getFloat(i1, x);
      }
      else if (i1 == IpAddress.ConstraintSet_android_translationX)
      {
        n = paramContext.getFloat(i1, n);
      }
      else if (i1 == IpAddress.ConstraintSet_android_translationY)
      {
        k = paramContext.getFloat(i1, k);
      }
      else if (i1 == IpAddress.ConstraintSet_android_translationZ)
      {
        y = paramContext.getFloat(i1, y);
      }
      j += 1;
    }
    paramContext.recycle();
  }
}
