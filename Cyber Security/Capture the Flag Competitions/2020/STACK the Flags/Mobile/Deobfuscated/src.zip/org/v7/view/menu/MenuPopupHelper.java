package org.v7.view.menu;

import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewTreeObserver;

public class MenuPopupHelper
  implements View.OnAttachStateChangeListener
{
  public MenuPopupHelper(d paramD) {}
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView)
  {
    Object localObject = mAdapter.y;
    if (localObject != null)
    {
      if (!((ViewTreeObserver)localObject).isAlive()) {
        mAdapter.y = paramView.getViewTreeObserver();
      }
      localObject = mAdapter;
      y.removeGlobalOnLayoutListener(this$0);
    }
    paramView.removeOnAttachStateChangeListener(this);
  }
}
