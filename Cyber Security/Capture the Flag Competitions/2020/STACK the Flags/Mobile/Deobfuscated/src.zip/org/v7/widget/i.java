package org.v7.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MenuItem;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import org.v7.view.menu.MenuBuilder;

public class i
  extends ListPopupWindow
  implements ByteVector
{
  public static Method b;
  public ByteVector l;
  
  static
  {
    Object localObject;
    if (Build.VERSION.SDK_INT <= 28) {
      localObject = Boolean.TYPE;
    }
    try
    {
      localObject = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { localObject });
      b = (Method)localObject;
      return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    }
  }
  
  public i(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void a(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    ByteVector localByteVector = l;
    if (localByteVector != null) {
      localByteVector.a(paramMenuBuilder, paramMenuItem);
    }
  }
  
  public void a(ByteVector paramByteVector)
  {
    l = paramByteVector;
  }
  
  public void a(boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT <= 28)
    {
      Method localMethod = b;
      if (localMethod == null) {
        return;
      }
      PopupWindow localPopupWindow = mPopup;
      try
      {
        localMethod.invoke(localPopupWindow, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      }
      catch (Exception localException)
      {
        Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
        return;
      }
    }
    mPopup.setTouchModal(paramBoolean);
  }
  
  public void b(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    ByteVector localByteVector = l;
    if (localByteVector != null) {
      localByteVector.b(paramMenuBuilder, paramMenuItem);
    }
  }
  
  public ListViewCompat e(Context paramContext, boolean paramBoolean)
  {
    paramContext = new l0.a(paramContext, paramBoolean);
    paramContext.setHoverListener(this);
    return paramContext;
  }
  
  public void init(Object paramObject)
  {
    if (Build.VERSION.SDK_INT >= 23) {
      mPopup.setExitTransition((Transition)paramObject);
    }
  }
  
  public void show(Object paramObject)
  {
    if (Build.VERSION.SDK_INT >= 23) {
      mPopup.setEnterTransition((Transition)paramObject);
    }
  }
}
