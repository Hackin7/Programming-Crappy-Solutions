package org.codehaus.asm.asm.asm;

import a.f.b.i.e;
import androidx.constraintlayout.widget.ConstraintLayout.b;
import java.util.ArrayList;
import org.codehaus.asm.asm.AnnotationWriter;
import org.codehaus.asm.asm.Frame;
import org.codehaus.asm.asm.MethodWriter;
import org.codehaus.asm.asm.Type;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.c;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.i;

public class b
{
  public MethodWriter a;
  public a b = new a();
  public final ArrayList<e> c = new ArrayList();
  
  public b(MethodWriter paramMethodWriter)
  {
    a = paramMethodWriter;
  }
  
  public long a(MethodWriter paramMethodWriter, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    Object localObject = paramMethodWriter.visitTypeAnnotation();
    int m = a.size();
    int i2 = paramMethodWriter.getValue();
    int i3 = paramMethodWriter.size();
    boolean bool = Frame.b(paramInt1, 128);
    if ((!bool) && (!Frame.b(paramInt1, 64))) {
      i = 0;
    } else {
      i = 1;
    }
    paramInt1 = i;
    f localF;
    int j;
    int k;
    if (i != 0)
    {
      paramInt1 = 0;
      while (paramInt1 < m)
      {
        localF = (f)a.get(paramInt1);
        if (localF.doubleValue() == XLayoutStyle.a) {
          j = 1;
        } else {
          j = 0;
        }
        if (localF.get() == XLayoutStyle.a) {
          k = 1;
        } else {
          k = 0;
        }
        if ((j != 0) && (k != 0) && (localF.i() > 0.0F)) {
          j = 1;
        } else {
          j = 0;
        }
        if ((localF.f()) && (j != 0))
        {
          paramInt1 = 0;
          break label246;
        }
        if ((localF.c()) && (j != 0))
        {
          paramInt1 = 0;
          break label246;
        }
        if ((localF instanceof Type))
        {
          paramInt1 = 0;
          break label246;
        }
        if ((!localF.f()) && (!localF.c()))
        {
          paramInt1 += 1;
        }
        else
        {
          paramInt1 = 0;
          break label246;
        }
      }
      paramInt1 = i;
    }
    label246:
    if ((paramInt1 == 0) || (((paramInt2 == 1073741824) && (paramInt4 == 1073741824)) || (bool))) {
      i = 1;
    } else {
      i = 0;
    }
    int i4 = i & paramInt1;
    int i = 0;
    paramInt1 = 0;
    int i9;
    if (i4 != 0)
    {
      paramInt3 = Math.min(paramMethodWriter.getItem(), paramInt3);
      paramInt5 = Math.min(paramMethodWriter.readByte(), paramInt5);
      if ((paramInt2 == 1073741824) && (paramMethodWriter.getValue() != paramInt3))
      {
        paramMethodWriter.append(paramInt3);
        paramMethodWriter.visitAnnotation();
      }
      if ((paramInt4 == 1073741824) && (paramMethodWriter.size() != paramInt5))
      {
        paramMethodWriter.add(paramInt5);
        paramMethodWriter.visitAnnotation();
      }
      int i10;
      if ((paramInt2 == 1073741824) && (paramInt4 == 1073741824))
      {
        paramInt1 = 2;
        i9 = paramMethodWriter.c(bool);
      }
      else
      {
        i10 = paramMethodWriter.b(bool);
        i9 = i10;
        if (paramInt2 == 1073741824)
        {
          i9 = i10 & paramMethodWriter.b(bool, 0);
          paramInt1 = 0 + 1;
        }
        if (paramInt4 == 1073741824)
        {
          i9 &= paramMethodWriter.b(bool, 1);
          paramInt1 += 1;
        }
      }
      if (i9 != 0)
      {
        if (paramInt2 == 1073741824) {
          i10 = 1;
        } else {
          i10 = 0;
        }
        if (paramInt4 == 1073741824) {
          bool = true;
        } else {
          bool = false;
        }
        paramMethodWriter.a(i10, bool);
      }
    }
    else
    {
      i9 = 0;
      paramInt1 = i;
    }
    if ((i9 != 0) && (paramInt1 == 2)) {
      return 0L;
    }
    paramInt1 = paramMethodWriter.remove();
    paramInt3 = paramInt1;
    if (m > 0) {
      a(paramMethodWriter);
    }
    int i5 = c.size();
    if (m > 0) {
      a(paramMethodWriter, i2, i3);
    }
    if (i5 > 0)
    {
      if (paramMethodWriter.doubleValue() == XLayoutStyle.c) {
        i = 1;
      } else {
        i = 0;
      }
      if (paramMethodWriter.get() == XLayoutStyle.c) {
        j = 1;
      } else {
        j = 0;
      }
      paramInt2 = Math.max(paramMethodWriter.getValue(), a.clear());
      paramInt1 = Math.max(paramMethodWriter.size(), a.getWidth());
      paramInt4 = 0;
      k = 0;
      int i1;
      int n;
      while (k < i5)
      {
        localF = (f)c.get(k);
        if ((localF instanceof Type))
        {
          paramInt5 = localF.getValue();
          m = localF.size();
          i9 = a((Item)localObject, localF, true);
          i1 = localF.getValue();
          n = localF.size();
          if (i1 != paramInt5)
          {
            localF.append(i1);
            paramInt4 = paramInt2;
            if (i != 0) {
              if (localF.p() > paramInt2) {
                paramInt4 = Math.max(paramInt2, localF.p() + localF.a(c.i).b());
              } else {
                paramInt4 = paramInt2;
              }
            }
            paramInt5 = 1;
            paramInt2 = paramInt4;
          }
          else
          {
            paramInt5 = paramInt4 | i9;
          }
          paramInt4 = paramInt1;
          if (n != m)
          {
            localF.add(n);
            paramInt4 = paramInt1;
            if (j != 0)
            {
              paramInt4 = paramInt1;
              if (localF.h() > paramInt1) {
                paramInt4 = Math.max(paramInt1, localF.h() + localF.a(c.b).b());
              }
            }
            paramInt5 = 1;
          }
          paramInt5 = ((Type)localF).isArray() | paramInt5;
          paramInt1 = paramInt4;
          paramInt4 = paramInt5;
        }
        k += 1;
      }
      k = paramInt3;
      m = 0;
      paramInt3 = paramInt4;
      while (m < 2)
      {
        n = 0;
        while (n < i5)
        {
          localF = (f)c.get(n);
          if ((((localF instanceof AnnotationWriter)) && (!(localF instanceof Type))) || ((localF instanceof i)) || (localF.length() == 8) || ((i4 != 0) && (f.d.c) && (e.d.c)) || ((localF instanceof Type)))
          {
            paramInt5 = paramInt3;
            i1 = paramInt2;
          }
          else
          {
            int i7 = localF.getValue();
            paramInt5 = localF.size();
            int i6 = localF.newClass();
            paramInt4 = paramInt3 | a((Item)localObject, localF, true);
            int i8 = localF.getValue();
            i1 = localF.size();
            paramInt3 = paramInt2;
            if (i8 != i7)
            {
              localF.append(i8);
              paramInt3 = paramInt2;
              if (i != 0) {
                if (localF.p() > paramInt2) {
                  paramInt3 = Math.max(paramInt2, localF.p() + localF.a(c.i).b());
                } else {
                  paramInt3 = paramInt2;
                }
              }
              paramInt4 = 1;
            }
            paramInt2 = paramInt1;
            if (i1 != paramInt5)
            {
              localF.add(i1);
              paramInt2 = paramInt1;
              if (j != 0)
              {
                paramInt2 = paramInt1;
                if (localF.h() > paramInt1) {
                  paramInt2 = Math.max(paramInt1, localF.h() + localF.a(c.b).b());
                }
              }
              paramInt4 = 1;
            }
            paramInt5 = paramInt4;
            paramInt1 = paramInt2;
            i1 = paramInt3;
            if (localF.j())
            {
              paramInt5 = paramInt4;
              paramInt1 = paramInt2;
              i1 = paramInt3;
              if (i6 != localF.newClass())
              {
                paramInt5 = 1;
                i1 = paramInt3;
                paramInt1 = paramInt2;
              }
            }
          }
          n += 1;
          paramInt3 = paramInt5;
          paramInt2 = i1;
        }
        if (paramInt3 != 0)
        {
          a(paramMethodWriter, i2, i3);
          paramInt3 = 0;
          m += 1;
        }
        else
        {
          paramInt4 = paramInt1;
          break label1307;
        }
      }
      paramInt4 = paramInt1;
      label1307:
      localObject = paramMethodWriter;
      paramInt1 = k;
      if (paramInt3 != 0)
      {
        a((MethodWriter)localObject, i2, i3);
        paramInt1 = 0;
        if (paramMethodWriter.getValue() < paramInt2)
        {
          ((f)localObject).append(paramInt2);
          paramInt1 = 1;
        }
        paramInt2 = paramInt1;
        if (paramMethodWriter.size() < paramInt4)
        {
          ((f)localObject).add(paramInt4);
          paramInt2 = 1;
        }
        paramInt1 = k;
        if (paramInt2 != 0)
        {
          a((MethodWriter)localObject, i2, i3);
          paramInt1 = k;
        }
      }
    }
    paramMethodWriter.d(paramInt1);
    return 0L;
  }
  
  public final void a(MethodWriter paramMethodWriter)
  {
    Object localObject1 = a;
    int n = ((ArrayList)localObject1).size();
    boolean bool = paramMethodWriter.a(64);
    localObject1 = paramMethodWriter.visitTypeAnnotation();
    int m = 0;
    while (m < n)
    {
      Object localObject2 = a;
      localObject2 = (f)((ArrayList)localObject2).get(m);
      if ((!(localObject2 instanceof i)) && (!(localObject2 instanceof org.codehaus.asm.asm.h)) && (!((f)localObject2).q()))
      {
        if (bool)
        {
          localObject3 = f;
          if (localObject3 != null)
          {
            localObject4 = e;
            if ((localObject4 != null) && (d.c) && (d.c)) {
              break label344;
            }
          }
        }
        Object localObject3 = ((f)localObject2).getValue(0);
        Object localObject4 = ((f)localObject2).getValue(1);
        XLayoutStyle localXLayoutStyle = XLayoutStyle.a;
        int i;
        if ((localObject3 == localXLayoutStyle) && (k != 1) && (localObject4 == localXLayoutStyle) && (h != 1)) {
          i = 1;
        } else {
          i = 0;
        }
        int k = i;
        if (i == 0)
        {
          k = i;
          if (paramMethodWriter.a(1))
          {
            k = i;
            if (!(localObject2 instanceof Type))
            {
              localXLayoutStyle = XLayoutStyle.a;
              int j = i;
              if (localObject3 == localXLayoutStyle)
              {
                j = i;
                if (k == 0)
                {
                  j = i;
                  if (localObject4 != localXLayoutStyle)
                  {
                    j = i;
                    if (!((f)localObject2).f()) {
                      j = 1;
                    }
                  }
                }
              }
              localXLayoutStyle = XLayoutStyle.a;
              k = j;
              if (localObject4 == localXLayoutStyle)
              {
                k = j;
                if (h == 0)
                {
                  k = j;
                  if (localObject3 != localXLayoutStyle)
                  {
                    k = j;
                    if (!((f)localObject2).f()) {
                      k = 1;
                    }
                  }
                }
              }
            }
          }
        }
        if (k == 0) {
          a((Item)localObject1, (f)localObject2, false);
        }
      }
      label344:
      m += 1;
    }
    ((ConstraintLayout.b)localObject1).b();
  }
  
  public final void a(MethodWriter paramMethodWriter, int paramInt1, int paramInt2)
  {
    int i = paramMethodWriter.clear();
    int j = paramMethodWriter.getWidth();
    paramMethodWriter.p(0);
    paramMethodWriter.create(0);
    paramMethodWriter.append(paramInt1);
    paramMethodWriter.add(paramInt2);
    paramMethodWriter.p(i);
    paramMethodWriter.create(j);
    a.a();
  }
  
  public final boolean a(Item paramItem, f paramF, boolean paramBoolean)
  {
    b.b = paramF.doubleValue();
    b.a = paramF.get();
    b.c = paramF.getValue();
    b.i = paramF.size();
    a localA = b;
    o = false;
    h = paramBoolean;
    int j;
    if (b == XLayoutStyle.a) {
      j = 1;
    } else {
      j = 0;
    }
    int i;
    if (b.a == XLayoutStyle.a) {
      i = 1;
    } else {
      i = 0;
    }
    if ((j != 0) && (E > 0.0F)) {
      j = 1;
    } else {
      j = 0;
    }
    if ((i != 0) && (E > 0.0F)) {
      i = 1;
    } else {
      i = 0;
    }
    if ((j != 0) && (P[0] == 4)) {
      b.b = XLayoutStyle.b;
    }
    if ((i != 0) && (P[1] == 4)) {
      b.a = XLayoutStyle.b;
    }
    localA = b;
    ((ConstraintLayout.b)paramItem).a(paramF, localA);
    paramF.append(b.j);
    paramF.add(b.k);
    paramF.a(b.p);
    paramF.putShort(b.l);
    paramItem = b;
    h = false;
    return o;
  }
  
  public void b(MethodWriter paramMethodWriter)
  {
    c.clear();
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      f localF = (f)a.get(i);
      if ((localF.doubleValue() == XLayoutStyle.a) || (localF.get() == XLayoutStyle.a)) {
        c.add(localF);
      }
      i += 1;
    }
    paramMethodWriter.visitAnnotation();
  }
}
