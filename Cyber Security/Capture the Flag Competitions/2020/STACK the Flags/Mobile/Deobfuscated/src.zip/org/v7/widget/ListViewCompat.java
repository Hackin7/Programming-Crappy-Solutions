package org.v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.lang.reflect.Field;
import org.core.asm.signature.DrawableCompat;
import org.core.view.ViewPropertyAnimatorCompat;
import org.core.widget.ListViewAutoScrollHelper;
import org.core.widget.i;
import org.v7.R.attr;

public class ListViewCompat
  extends ListView
{
  public f0.b b;
  public ViewPropertyAnimatorCompat mClickAnimation;
  public boolean mDrawsInPressedState;
  public boolean mHijackFocus;
  public Field mIsChildViewEnabled;
  public boolean mListSelectionHidden;
  public int mMotionPosition;
  public ListViewAutoScrollHelper mScrollHelper;
  public int mSelectionBottomPadding = 0;
  public int mSelectionLeftPadding = 0;
  public int mSelectionRightPadding = 0;
  public int mSelectionTopPadding = 0;
  public f0.a mSelector;
  public final Rect mSelectorRect = new Rect();
  
  public ListViewCompat(Context paramContext, boolean paramBoolean)
  {
    super(paramContext, null, R.attr.dropDownListViewStyle);
    mHijackFocus = paramBoolean;
    setCacheColorHint(0);
    try
    {
      paramContext = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      mIsChildViewEnabled = paramContext;
      paramContext.setAccessible(true);
      return;
    }
    catch (NoSuchFieldException paramContext)
    {
      paramContext.printStackTrace();
    }
  }
  
  private void setSelectorEnabled(boolean paramBoolean)
  {
    f0.a localA = mSelector;
    if (localA != null) {
      localA.setEnabled(paramBoolean);
    }
  }
  
  public final void clearPressedItem()
  {
    mDrawsInPressedState = false;
    setPressed(false);
    drawableStateChanged();
    Object localObject = getChildAt(mMotionPosition - getFirstVisiblePosition());
    if (localObject != null) {
      ((View)localObject).setPressed(false);
    }
    localObject = mClickAnimation;
    if (localObject != null)
    {
      ((ViewPropertyAnimatorCompat)localObject).cancel();
      mClickAnimation = null;
    }
  }
  
  public final void clickPressedItem(View paramView, int paramInt)
  {
    performItemClick(paramView, paramInt, getItemIdAtPosition(paramInt));
  }
  
  public void dispatchDraw(Canvas paramCanvas)
  {
    drawSelectorCompat(paramCanvas);
    super.dispatchDraw(paramCanvas);
  }
  
  public final void drawSelectorCompat(Canvas paramCanvas)
  {
    if (!mSelectorRect.isEmpty())
    {
      Drawable localDrawable = getSelector();
      if (localDrawable != null)
      {
        localDrawable.setBounds(mSelectorRect);
        localDrawable.draw(paramCanvas);
      }
    }
  }
  
  public void drawableStateChanged()
  {
    if (b != null) {
      return;
    }
    super.drawableStateChanged();
    setSelectorEnabled(true);
    updateSelectorStateCompat();
  }
  
  public boolean hasFocus()
  {
    return (mHijackFocus) || (super.hasFocus());
  }
  
  public boolean hasWindowFocus()
  {
    return (mHijackFocus) || (super.hasWindowFocus());
  }
  
  public boolean isFocused()
  {
    return (mHijackFocus) || (super.isFocused());
  }
  
  public boolean isInTouchMode()
  {
    return ((mHijackFocus) && (mListSelectionHidden)) || (super.isInTouchMode());
  }
  
  public int measureHeightOfChildrenCompat(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = getListPaddingTop();
    int k = getListPaddingBottom();
    int j = getDividerHeight();
    Object localObject1 = getDivider();
    ListAdapter localListAdapter = getAdapter();
    if (localListAdapter == null) {
      return i + k;
    }
    i += k;
    if ((j <= 0) || (localObject1 == null)) {
      j = 0;
    }
    int m = 0;
    localObject1 = null;
    int i1 = 0;
    int i3 = localListAdapter.getCount();
    k = 0;
    while (k < i3)
    {
      int i2 = localListAdapter.getItemViewType(k);
      int n = i1;
      if (i2 != i1)
      {
        localObject1 = null;
        n = i2;
      }
      View localView = localListAdapter.getView(k, (View)localObject1, this);
      localObject1 = localView;
      Object localObject2 = localView.getLayoutParams();
      if (localObject2 == null)
      {
        ViewGroup.LayoutParams localLayoutParams = generateDefaultLayoutParams();
        localObject2 = localLayoutParams;
        localView.setLayoutParams(localLayoutParams);
      }
      i1 = height;
      if (i1 > 0) {
        i1 = View.MeasureSpec.makeMeasureSpec(i1, 1073741824);
      } else {
        i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
      }
      localView.measure(paramInt1, i1);
      localView.forceLayout();
      i1 = i;
      if (k > 0) {
        i1 = i + j;
      }
      i = i1 + localView.getMeasuredHeight();
      if (i >= paramInt2)
      {
        if ((paramInt3 >= 0) && (k > paramInt3) && (m > 0) && (i != paramInt2)) {
          return m;
        }
        return paramInt2;
      }
      i1 = m;
      if (paramInt3 >= 0)
      {
        i1 = m;
        if (k >= paramInt3) {
          i1 = i;
        }
      }
      k += 1;
      m = i1;
      i1 = n;
    }
    return i;
  }
  
  public void onDetachedFromWindow()
  {
    b = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onForwardedEvent(MotionEvent paramMotionEvent, int paramInt)
  {
    boolean bool2 = true;
    boolean bool1 = true;
    int i = 0;
    int j = paramMotionEvent.getActionMasked();
    if (j != 1)
    {
      if (j != 2)
      {
        if (j != 3)
        {
          bool1 = bool2;
          paramInt = i;
          break label164;
        }
        bool1 = false;
        paramInt = i;
        break label164;
      }
    }
    else {
      bool1 = false;
    }
    int k = paramMotionEvent.findPointerIndex(paramInt);
    if (k < 0)
    {
      bool1 = false;
      paramInt = i;
    }
    else
    {
      paramInt = (int)paramMotionEvent.getX(k);
      int m = (int)paramMotionEvent.getY(k);
      k = pointToPosition(paramInt, m);
      if (k == -1)
      {
        paramInt = 1;
      }
      else
      {
        View localView = getChildAt(k - getFirstVisiblePosition());
        setPressedItem(localView, k, paramInt, m);
        bool2 = true;
        bool1 = bool2;
        paramInt = i;
        if (j == 1)
        {
          clickPressedItem(localView, k);
          paramInt = i;
          bool1 = bool2;
        }
      }
    }
    label164:
    if ((!bool1) || (paramInt != 0)) {
      clearPressedItem();
    }
    if (bool1)
    {
      if (mScrollHelper == null) {
        mScrollHelper = new ListViewAutoScrollHelper(this);
      }
      mScrollHelper.a(true);
      mScrollHelper.onTouch(this, paramMotionEvent);
      return bool1;
    }
    paramMotionEvent = mScrollHelper;
    if (paramMotionEvent != null) {
      paramMotionEvent.a(false);
    }
    return bool1;
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    if (Build.VERSION.SDK_INT < 26) {
      return super.onHoverEvent(paramMotionEvent);
    }
    int i = paramMotionEvent.getActionMasked();
    if ((i == 10) && (b == null))
    {
      f0.b localB = new f0.b(this);
      b = localB;
      localB.refreshView();
    }
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if ((i != 9) && (i != 7))
    {
      setSelection(-1);
      return bool;
    }
    i = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    if ((i != -1) && (i != getSelectedItemPosition()))
    {
      paramMotionEvent = getChildAt(i - getFirstVisiblePosition());
      if (paramMotionEvent.isEnabled()) {
        setSelectionFromTop(i, paramMotionEvent.getTop() - getTop());
      }
      updateSelectorStateCompat();
    }
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (paramMotionEvent.getAction() == 0) {
      mMotionPosition = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    }
    f0.b localB = b;
    if (localB != null) {
      localB.remove();
    }
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public final void positionSelectorCompat(int paramInt, View paramView)
  {
    Object localObject = mSelectorRect;
    ((Rect)localObject).set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    left -= mSelectionLeftPadding;
    top -= mSelectionTopPadding;
    right += mSelectionRightPadding;
    bottom += mSelectionBottomPadding;
    localObject = mIsChildViewEnabled;
    try
    {
      boolean bool1 = ((Field)localObject).getBoolean(this);
      boolean bool2 = paramView.isEnabled();
      if (bool2 != bool1)
      {
        paramView = mIsChildViewEnabled;
        if (!bool1) {
          bool1 = true;
        } else {
          bool1 = false;
        }
        paramView.set(this, Boolean.valueOf(bool1));
        if (paramInt != -1) {
          refreshDrawableState();
        }
      }
      return;
    }
    catch (IllegalAccessException paramView)
    {
      paramView.printStackTrace();
    }
  }
  
  public final void positionSelectorLikeFocusCompat(int paramInt, View paramView)
  {
    Drawable localDrawable = getSelector();
    boolean bool = true;
    int i;
    if ((localDrawable != null) && (paramInt != -1)) {
      i = 1;
    } else {
      i = 0;
    }
    if (i != 0) {
      localDrawable.setVisible(false, false);
    }
    positionSelectorCompat(paramInt, paramView);
    if (i != 0)
    {
      paramView = mSelectorRect;
      float f1 = paramView.exactCenterX();
      float f2 = paramView.exactCenterY();
      if (getVisibility() != 0) {
        bool = false;
      }
      localDrawable.setVisible(bool, false);
      DrawableCompat.setHotspot(localDrawable, f1, f2);
    }
  }
  
  public final void positionSelectorLikeTouchCompat(int paramInt, View paramView, float paramFloat1, float paramFloat2)
  {
    positionSelectorLikeFocusCompat(paramInt, paramView);
    paramView = getSelector();
    if ((paramView != null) && (paramInt != -1)) {
      DrawableCompat.setHotspot(paramView, paramFloat1, paramFloat2);
    }
  }
  
  public void setListSelectionHidden(boolean paramBoolean)
  {
    mListSelectionHidden = paramBoolean;
  }
  
  public final void setPressedItem(View paramView, int paramInt, float paramFloat1, float paramFloat2)
  {
    mDrawsInPressedState = true;
    drawableHotspotChanged(paramFloat1, paramFloat2);
    if (!isPressed()) {
      setPressed(true);
    }
    layoutChildren();
    int i = mMotionPosition;
    if (i != -1)
    {
      View localView = getChildAt(i - getFirstVisiblePosition());
      if ((localView != null) && (localView != paramView) && (localView.isPressed())) {
        localView.setPressed(false);
      }
    }
    mMotionPosition = paramInt;
    paramView.drawableHotspotChanged(paramFloat1 - paramView.getLeft(), paramFloat2 - paramView.getTop());
    if (!paramView.isPressed()) {
      paramView.setPressed(true);
    }
    positionSelectorLikeTouchCompat(paramInt, paramView, paramFloat1, paramFloat2);
    setSelectorEnabled(false);
    refreshDrawableState();
  }
  
  public void setSelector(Drawable paramDrawable)
  {
    if (paramDrawable != null) {
      localObject = new f0.a(paramDrawable);
    } else {
      localObject = null;
    }
    mSelector = ((f0.a)localObject);
    super.setSelector((Drawable)localObject);
    Object localObject = new Rect();
    if (paramDrawable != null) {
      paramDrawable.getPadding((Rect)localObject);
    }
    mSelectionLeftPadding = left;
    mSelectionTopPadding = top;
    mSelectionRightPadding = right;
    mSelectionBottomPadding = bottom;
  }
  
  public final boolean shouldShowSelectorCompat()
  {
    return mDrawsInPressedState;
  }
  
  public final void updateSelectorStateCompat()
  {
    Drawable localDrawable = getSelector();
    if ((localDrawable != null) && (shouldShowSelectorCompat()) && (isPressed())) {
      localDrawable.setState(getDrawableState());
    }
  }
}
