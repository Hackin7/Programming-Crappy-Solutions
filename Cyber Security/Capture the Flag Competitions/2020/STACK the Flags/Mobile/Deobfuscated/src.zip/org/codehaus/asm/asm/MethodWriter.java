package org.codehaus.asm.asm;

import androidx.constraintlayout.widget.ConstraintLayout.b;
import java.io.PrintStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import org.codehaus.asm.asm.asm.Item;
import org.codehaus.asm.asm.asm.a;
import org.codehaus.asm.asm.asm.g;

public class MethodWriter
  extends b
{
  public org.codehaus.asm.ClassWriter a = new org.codehaus.asm.ClassWriter();
  public org.codehaus.asm.asm.asm.ClassWriter b = new org.codehaus.asm.asm.asm.ClassWriter(this);
  public org.codehaus.asm.asm.asm.b c = new org.codehaus.asm.asm.asm.b(this);
  public d[] d = new d[4];
  public int e;
  public boolean f = false;
  public WeakReference<a.f.b.i.d> h = null;
  public int i;
  public a j = new a();
  public Item k = null;
  public boolean l = false;
  public boolean m = false;
  public int n = 0;
  public d[] p = new d[4];
  public int q = 257;
  public int r = 0;
  public WeakReference<a.f.b.i.d> s = null;
  public WeakReference<a.f.b.i.d> t = null;
  public WeakReference<a.f.b.i.d> v = null;
  
  public MethodWriter() {}
  
  public static boolean a(f paramF, Item paramItem, a paramA, boolean paramBoolean)
  {
    if (paramItem == null) {
      return false;
    }
    b = paramF.doubleValue();
    a = paramF.get();
    c = paramF.getValue();
    i = paramF.size();
    o = false;
    h = paramBoolean;
    if (b == XLayoutStyle.a) {
      i1 = 1;
    } else {
      i1 = 0;
    }
    int i2;
    if (a == XLayoutStyle.a) {
      i2 = 1;
    } else {
      i2 = 0;
    }
    int i5;
    if ((i1 != 0) && (E > 0.0F)) {
      i5 = 1;
    } else {
      i5 = 0;
    }
    int i4;
    if ((i2 != 0) && (E > 0.0F)) {
      i4 = 1;
    } else {
      i4 = 0;
    }
    int i3 = i1;
    if (i1 != 0)
    {
      i3 = i1;
      if (paramF.c(0))
      {
        i3 = i1;
        if (k == 0)
        {
          i3 = i1;
          if (i5 == 0)
          {
            i1 = 0;
            b = XLayoutStyle.c;
            i3 = i1;
            if (i2 != 0)
            {
              i3 = i1;
              if (h == 0)
              {
                b = XLayoutStyle.b;
                i3 = i1;
              }
            }
          }
        }
      }
    }
    int i1 = i2;
    if (i2 != 0)
    {
      i1 = i2;
      if (paramF.c(1))
      {
        i1 = i2;
        if (h == 0)
        {
          i1 = i2;
          if (i4 == 0)
          {
            i2 = 0;
            a = XLayoutStyle.c;
            i1 = i2;
            if (i3 != 0)
            {
              i1 = i2;
              if (k == 0)
              {
                a = XLayoutStyle.b;
                i1 = i2;
              }
            }
          }
        }
      }
    }
    if (paramF.d())
    {
      i3 = 0;
      b = XLayoutStyle.b;
    }
    if (paramF.b())
    {
      i1 = 0;
      a = XLayoutStyle.b;
    }
    if (i5 != 0) {
      if (P[0] == 4)
      {
        b = XLayoutStyle.b;
      }
      else if (i1 == 0)
      {
        if (a == XLayoutStyle.b)
        {
          i1 = i;
        }
        else
        {
          b = XLayoutStyle.c;
          ((ConstraintLayout.b)paramItem).a(paramF, paramA);
          i1 = k;
        }
        b = XLayoutStyle.b;
        i2 = D;
        if ((i2 != 0) && (i2 != -1)) {
          c = ((int)(paramF.i() / i1));
        } else {
          c = ((int)(paramF.i() * i1));
        }
      }
    }
    if (i4 != 0) {
      if (P[1] == 4)
      {
        a = XLayoutStyle.b;
      }
      else if (i3 == 0)
      {
        if (b == XLayoutStyle.b)
        {
          i1 = c;
        }
        else
        {
          a = XLayoutStyle.c;
          ((ConstraintLayout.b)paramItem).a(paramF, paramA);
          i1 = j;
        }
        a = XLayoutStyle.b;
        i2 = D;
        if ((i2 != 0) && (i2 != -1)) {
          i = ((int)(i1 * paramF.i()));
        } else {
          i = ((int)(i1 / paramF.i()));
        }
      }
    }
    ((ConstraintLayout.b)paramItem).a(paramF, paramA);
    paramF.append(j);
    paramF.add(k);
    paramF.a(p);
    paramF.putShort(l);
    h = false;
    return o;
  }
  
  public long a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    i = paramInt8;
    e = paramInt9;
    c.a(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    return 0L;
  }
  
  public void a()
  {
    t = 0;
    y = 0;
    m = false;
    l = false;
    int i10 = a.size();
    int i2 = Math.max(0, getValue());
    int i4 = i2;
    int i6 = Math.max(0, size());
    int i3 = i6;
    Object localObject2 = c;
    Object localObject1 = localObject2[1];
    localObject2 = localObject2[0];
    Object localObject4;
    Object localObject5;
    Object localObject6;
    if (Frame.b(q, 1))
    {
      g.a(this, visitTypeAnnotation());
      i1 = 0;
      while (i1 < i10)
      {
        localObject3 = (f)a.get(i1);
        if ((((f)localObject3).next()) && (!(localObject3 instanceof i)) && (!(localObject3 instanceof h)) && (!(localObject3 instanceof Type)) && (!((f)localObject3).q()))
        {
          localObject4 = ((f)localObject3).getValue(0);
          localObject5 = ((f)localObject3).getValue(1);
          localObject6 = XLayoutStyle.a;
          if ((localObject4 == localObject6) && (k != 1) && (localObject5 == localObject6) && (h != 1)) {
            i5 = 1;
          } else {
            i5 = 0;
          }
          if (i5 == 0)
          {
            localObject4 = new a();
            a((f)localObject3, k, (a)localObject4, false);
          }
        }
        i1 += 1;
      }
    }
    if (i10 > 2)
    {
      localObject3 = XLayoutStyle.c;
      if (((localObject2 == localObject3) || (localObject1 == localObject3)) && (Frame.b(q, 1024)) && (org.codehaus.asm.asm.asm.ClassReader.a(this, visitTypeAnnotation())))
      {
        i1 = i4;
        if (localObject2 == XLayoutStyle.c) {
          if ((i2 < getValue()) && (i2 > 0))
          {
            append(i2);
            m = true;
            i1 = i4;
          }
          else
          {
            i1 = getValue();
          }
        }
        i2 = i3;
        if (localObject1 == XLayoutStyle.c) {
          if ((i6 < size()) && (i6 > 0))
          {
            add(i6);
            l = true;
            i2 = i3;
          }
          else
          {
            i2 = size();
          }
        }
        i3 = 1;
        i5 = i1;
        i6 = i2;
        i1 = i3;
        break label404;
      }
    }
    int i1 = 0;
    int i5 = i2;
    label404:
    if ((!a(64)) && (!a(128))) {
      i2 = 0;
    } else {
      i2 = 1;
    }
    Object localObject3 = a;
    i = false;
    f = false;
    if ((q != 0) && (i2 != 0)) {
      f = true;
    }
    localObject3 = a;
    int i7;
    if ((doubleValue() != XLayoutStyle.c) && (get() != XLayoutStyle.c)) {
      i7 = 0;
    } else {
      i7 = 1;
    }
    visitIntInsn();
    i3 = 0;
    i2 = 0;
    while (i2 < i10)
    {
      localObject4 = (f)a.get(i2);
      if ((localObject4 instanceof b)) {
        ((b)localObject4).a();
      }
      i2 += 1;
    }
    boolean bool = a(64);
    i4 = 1;
    i2 = i3;
    while (i4 != 0)
    {
      int i8 = i2 + 1;
      localObject4 = a;
      i2 = i4;
      try
      {
        ((org.codehaus.asm.ClassWriter)localObject4).b();
        i2 = i4;
        visitIntInsn();
        localObject4 = a;
        i2 = i4;
        b((org.codehaus.asm.ClassWriter)localObject4);
        i3 = 0;
        while (i3 < i10)
        {
          localObject4 = a;
          i2 = i4;
          localObject4 = ((ArrayList)localObject4).get(i3);
          localObject4 = (f)localObject4;
          localObject5 = a;
          i2 = i4;
          ((f)localObject4).b((org.codehaus.asm.ClassWriter)localObject5);
          i3 += 1;
        }
        localObject4 = a;
        i2 = i4;
        a((org.codehaus.asm.ClassWriter)localObject4);
        i4 = 1;
        i3 = 1;
        if (v != null)
        {
          localObject4 = v;
          i2 = i3;
          localObject4 = ((WeakReference)localObject4).get();
          if (localObject4 != null)
          {
            localObject4 = v;
            i2 = i3;
            localObject4 = ((WeakReference)localObject4).get();
            localObject4 = (Label)localObject4;
            localObject5 = a;
            localObject6 = a;
            i2 = i3;
            a((Label)localObject4, ((org.codehaus.asm.ClassWriter)localObject5).a(localObject6));
            v = null;
          }
        }
        if (s != null)
        {
          localObject4 = s;
          i2 = i3;
          localObject4 = ((WeakReference)localObject4).get();
          if (localObject4 != null)
          {
            localObject4 = s;
            i2 = i3;
            localObject4 = ((WeakReference)localObject4).get();
            localObject4 = (Label)localObject4;
            localObject5 = a;
            localObject6 = g;
            i2 = i3;
            b((Label)localObject4, ((org.codehaus.asm.ClassWriter)localObject5).a(localObject6));
            s = null;
          }
        }
        if (t != null)
        {
          localObject4 = t;
          i2 = i3;
          localObject4 = ((WeakReference)localObject4).get();
          if (localObject4 != null)
          {
            localObject4 = t;
            i2 = i3;
            localObject4 = ((WeakReference)localObject4).get();
            localObject4 = (Label)localObject4;
            localObject5 = a;
            localObject6 = b;
            i2 = i3;
            a((Label)localObject4, ((org.codehaus.asm.ClassWriter)localObject5).a(localObject6));
            t = null;
          }
        }
        if (h != null)
        {
          localObject4 = h;
          i2 = i3;
          localObject4 = ((WeakReference)localObject4).get();
          if (localObject4 != null)
          {
            localObject4 = h;
            i2 = i3;
            localObject4 = ((WeakReference)localObject4).get();
            localObject4 = (Label)localObject4;
            localObject5 = a;
            localObject6 = i;
            i2 = i3;
            b((Label)localObject4, ((org.codehaus.asm.ClassWriter)localObject5).a(localObject6));
            h = null;
          }
        }
        localObject4 = a;
        i2 = i3;
        ((org.codehaus.asm.ClassWriter)localObject4).d();
        i2 = i4;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        localObject5 = System.out;
        localObject6 = new StringBuilder();
        ((StringBuilder)localObject6).append("EXCEPTION : ");
        ((StringBuilder)localObject6).append(localException);
        ((PrintStream)localObject5).println(((StringBuilder)localObject6).toString());
      }
      if (i2 != 0)
      {
        a(a, Frame.d);
      }
      else
      {
        b(a, bool);
        i2 = 0;
        while (i2 < i10)
        {
          ((f)a.get(i2)).b(a, bool);
          i2 += 1;
        }
      }
      int i9 = 0;
      if ((i7 != 0) && (i8 < 8) && (Frame.d[2] != 0))
      {
        i4 = 0;
        i3 = 0;
        i2 = 0;
        while (i2 < i10)
        {
          f localF = (f)a.get(i2);
          i4 = Math.max(i4, t + localF.getValue());
          i3 = Math.max(i3, y + localF.size());
          i2 += 1;
        }
        i2 = Math.max(top, i4);
        int i11 = Math.max(width, i3);
        i4 = i1;
        i3 = i9;
        if (localObject2 == XLayoutStyle.c)
        {
          i4 = i1;
          i3 = i9;
          if (getValue() < i2)
          {
            append(i2);
            c[0] = XLayoutStyle.c;
            i4 = 1;
            i3 = 1;
          }
        }
        i1 = i4;
        i2 = i3;
        if (localObject1 == XLayoutStyle.c)
        {
          i1 = i4;
          i2 = i3;
          if (size() < i11)
          {
            add(i11);
            c[1] = XLayoutStyle.c;
            i1 = 1;
            i2 = 1;
          }
        }
      }
      else
      {
        i2 = 0;
      }
      i3 = Math.max(top, getValue());
      if (i3 > getValue())
      {
        append(i3);
        c[0] = XLayoutStyle.b;
        i1 = 1;
        i2 = 1;
      }
      i3 = Math.max(width, size());
      if (i3 > size())
      {
        add(i3);
        c[1] = XLayoutStyle.b;
        i1 = 1;
        i2 = 1;
      }
      i3 = i1;
      i4 = i2;
      if (i1 == 0)
      {
        i3 = i1;
        i4 = i2;
        if (c[0] == XLayoutStyle.c)
        {
          i3 = i1;
          i4 = i2;
          if (i5 > 0)
          {
            i3 = i1;
            i4 = i2;
            if (getValue() > i5)
            {
              m = true;
              i3 = 1;
              c[0] = XLayoutStyle.b;
              append(i5);
              i4 = 1;
            }
          }
        }
        if ((c[1] == XLayoutStyle.c) && (i6 > 0) && (size() > i6))
        {
          l = true;
          i3 = 1;
          c[1] = XLayoutStyle.b;
          add(i6);
          i4 = 1;
        }
        else {}
      }
      i2 = i8;
      i1 = i3;
    }
    a = ((ArrayList)localObject3);
    if (i1 != 0)
    {
      localObject3 = c;
      localObject3[0] = localObject2;
      localObject3[1] = localObject1;
    }
    a(a.get());
  }
  
  public void a(org.codehaus.asm.ClassWriter paramClassWriter, boolean[] paramArrayOfBoolean)
  {
    paramArrayOfBoolean[2] = false;
    boolean bool = a(64);
    b(paramClassWriter, bool);
    int i2 = a.size();
    int i1 = 0;
    while (i1 < i2)
    {
      ((f)a.get(i1)).b(paramClassWriter, bool);
      i1 += 1;
    }
  }
  
  public void a(Label paramLabel)
  {
    WeakReference localWeakReference = s;
    if ((localWeakReference == null) || (localWeakReference.get() == null) || (paramLabel.d() > ((Label)s.get()).d())) {
      s = new WeakReference(paramLabel);
    }
  }
  
  public final void a(Label paramLabel, org.codehaus.asm.Label paramLabel1)
  {
    paramLabel = a.a(paramLabel);
    a.b(paramLabel, paramLabel1, 0, 5);
  }
  
  public void a(Item paramItem)
  {
    k = paramItem;
    b.b(paramItem);
  }
  
  public void a(f paramF, int paramInt)
  {
    if (paramInt == 0)
    {
      b(paramF);
      return;
    }
    if (paramInt == 1) {
      d(paramF);
    }
  }
  
  public void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    super.a(paramBoolean1, paramBoolean2);
    int i2 = a.size();
    int i1 = 0;
    while (i1 < i2)
    {
      ((f)a.get(i1)).a(paramBoolean1, paramBoolean2);
      i1 += 1;
    }
  }
  
  public boolean a(int paramInt)
  {
    return (q & paramInt) == paramInt;
  }
  
  public boolean a(org.codehaus.asm.ClassWriter paramClassWriter)
  {
    boolean bool = a(64);
    a(paramClassWriter, bool);
    int i3 = a.size();
    int i2 = 0;
    int i1 = 0;
    Object localObject1;
    while (i1 < i3)
    {
      localObject1 = (f)a.get(i1);
      ((f)localObject1).c(0, false);
      ((f)localObject1).c(1, false);
      if ((localObject1 instanceof h)) {
        i2 = 1;
      }
      i1 += 1;
    }
    if (i2 != 0)
    {
      i1 = 0;
      while (i1 < i3)
      {
        localObject1 = (f)a.get(i1);
        if ((localObject1 instanceof h)) {
          ((h)localObject1).visitFrame();
        }
        i1 += 1;
      }
    }
    i1 = 0;
    while (i1 < i3)
    {
      localObject1 = (f)a.get(i1);
      if (((f)localObject1).isPrimitive()) {
        ((f)localObject1).a(paramClassWriter, bool);
      }
      i1 += 1;
    }
    f localF;
    if (org.codehaus.asm.ClassWriter.r)
    {
      localObject1 = new HashSet();
      i1 = 0;
      while (i1 < i3)
      {
        localF = (f)a.get(i1);
        if (!localF.isPrimitive()) {
          ((HashSet)localObject1).add(localF);
        }
        i1 += 1;
      }
      if (doubleValue() == XLayoutStyle.c) {
        i1 = 0;
      } else {
        i1 = 1;
      }
      a(this, paramClassWriter, (HashSet)localObject1, i1, false);
      localObject1 = ((HashSet)localObject1).iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localF = (f)((Iterator)localObject1).next();
        Frame.a(this, paramClassWriter, localF);
        localF.a(paramClassWriter, bool);
      }
    }
    else
    {
      i1 = 0;
      while (i1 < i3)
      {
        localObject1 = (f)a.get(i1);
        if ((localObject1 instanceof MethodWriter))
        {
          Object localObject2 = c;
          localF = localObject2[0];
          localObject2 = localObject2[1];
          if (localF == XLayoutStyle.c) {
            ((f)localObject1).add(XLayoutStyle.b);
          }
          if (localObject2 == XLayoutStyle.c) {
            ((f)localObject1).a(XLayoutStyle.b);
          }
          ((f)localObject1).a(paramClassWriter, bool);
          if (localF == XLayoutStyle.c) {
            ((f)localObject1).add(localF);
          }
          if (localObject2 == XLayoutStyle.c) {
            ((f)localObject1).a((XLayoutStyle)localObject2);
          }
        }
        else
        {
          Frame.a(this, paramClassWriter, (f)localObject1);
          if (!((f)localObject1).isPrimitive()) {
            ((f)localObject1).a(paramClassWriter, bool);
          }
        }
        i1 += 1;
      }
    }
    if (r > 0) {
      ClassReader.a(this, paramClassWriter, null, 0);
    }
    if (n > 0) {
      ClassReader.a(this, paramClassWriter, null, 1);
    }
    return true;
  }
  
  public void b(Label paramLabel)
  {
    WeakReference localWeakReference = v;
    if ((localWeakReference == null) || (localWeakReference.get() == null) || (paramLabel.d() > ((Label)v.get()).d())) {
      v = new WeakReference(paramLabel);
    }
  }
  
  public final void b(Label paramLabel, org.codehaus.asm.Label paramLabel1)
  {
    paramLabel = a.a(paramLabel);
    a.b(paramLabel1, paramLabel, 0, 5);
  }
  
  public final void b(f paramF)
  {
    int i1 = r;
    d[] arrayOfD = p;
    if (i1 + 1 >= arrayOfD.length) {
      p = ((d[])Arrays.copyOf(arrayOfD, arrayOfD.length * 2));
    }
    p[r] = new d(paramF, 0, visitParameterAnnotation());
    r += 1;
  }
  
  public boolean b(boolean paramBoolean)
  {
    return b.b();
  }
  
  public boolean b(boolean paramBoolean, int paramInt)
  {
    return b.a(paramBoolean, paramInt);
  }
  
  public boolean c(boolean paramBoolean)
  {
    return b.a(paramBoolean);
  }
  
  public void d(int paramInt)
  {
    q = paramInt;
    org.codehaus.asm.ClassWriter.r = a(512);
  }
  
  public void d(Label paramLabel)
  {
    WeakReference localWeakReference = t;
    if ((localWeakReference == null) || (localWeakReference.get() == null) || (paramLabel.d() > ((Label)t.get()).d())) {
      t = new WeakReference(paramLabel);
    }
  }
  
  public final void d(f paramF)
  {
    int i1 = n;
    d[] arrayOfD = d;
    if (i1 + 1 >= arrayOfD.length) {
      d = ((d[])Arrays.copyOf(arrayOfD, arrayOfD.length * 2));
    }
    d[n] = new d(paramF, 1, visitParameterAnnotation());
    n += 1;
  }
  
  public void e(Label paramLabel)
  {
    WeakReference localWeakReference = h;
    if ((localWeakReference == null) || (localWeakReference.get() == null) || (paramLabel.d() > ((Label)h.get()).d())) {
      h = new WeakReference(paramLabel);
    }
  }
  
  public boolean getSize()
  {
    return l;
  }
  
  public void init()
  {
    a.b();
    i = 0;
    e = 0;
    super.init();
  }
  
  public void put(boolean paramBoolean)
  {
    f = paramBoolean;
  }
  
  public boolean put()
  {
    return m;
  }
  
  public int remove()
  {
    return q;
  }
  
  public void visitAnnotation()
  {
    b.visitInnerClass();
  }
  
  public final void visitIntInsn()
  {
    r = 0;
    n = 0;
  }
  
  public void visitInvokeDynamicInsn()
  {
    c.b(this);
  }
  
  public void visitLocalVariable()
  {
    b.newUTF8();
  }
  
  public org.codehaus.asm.ClassWriter visitLocalVariableAnnotation()
  {
    return a;
  }
  
  public boolean visitParameterAnnotation()
  {
    return f;
  }
  
  public Item visitTypeAnnotation()
  {
    return k;
  }
}
