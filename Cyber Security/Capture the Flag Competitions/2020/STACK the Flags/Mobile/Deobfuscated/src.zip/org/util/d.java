package org.util;

public abstract interface d
{
  public abstract Log getLifecycle();
}
