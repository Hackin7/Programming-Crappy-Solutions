package org.spongycastle.crypto.util;

public abstract class f
{
  public f() {}
  
  public abstract void close(Runnable paramRunnable);
  
  public abstract boolean close();
  
  public abstract void remove(Runnable paramRunnable);
}
