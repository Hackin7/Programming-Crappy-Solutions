package org.v7.view.menu;

import android.os.Handler;
import android.os.SystemClock;
import android.view.MenuItem;
import java.util.List;
import org.v7.widget.ByteVector;

public class Label
  implements ByteVector
{
  public Label(d paramD) {}
  
  public void a(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    e.B.removeCallbacksAndMessages(null);
    int k = -1;
    int i = 0;
    int m = e.a.size();
    int j;
    for (;;)
    {
      j = k;
      if (i >= m) {
        break;
      }
      if (paramMenuBuilder == e.a.get(i)).c)
      {
        j = i;
        break;
      }
      i += 1;
    }
    if (j == -1) {
      return;
    }
    i = j + 1;
    h localH;
    if (i < e.a.size()) {
      localH = (h)e.a.get(i);
    } else {
      localH = null;
    }
    paramMenuItem = new d.c.a(this, localH, paramMenuItem, paramMenuBuilder);
    long l = SystemClock.uptimeMillis();
    e.B.postAtTime(paramMenuItem, paramMenuBuilder, l + 200L);
  }
  
  public void b(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    e.B.removeCallbacksAndMessages(paramMenuBuilder);
  }
}
