package org.v7.app;

public abstract interface x
{
  public abstract void onCloseMenu(boolean paramBoolean);
}
