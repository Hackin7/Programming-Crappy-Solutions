package org.greendroid.graphics.drawable;

import a.e.a;
import a.s.a.a.g.e;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.core.asm.PathParser;
import org.core.asm.PathParser.PathDataNode;
import org.core.asm.signature.DrawableCompat;
import org.core.fonts.data.ClassWriter;
import org.core.fonts.data.d;
import org.data.Context;
import org.data.Label;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class VectorDrawableCompat
  extends VectorDrawableCommon
{
  public static final PorterDuff.Mode DEFAULT_TINT_MODE = PorterDuff.Mode.SRC_IN;
  public boolean mAllowCaching = true;
  public ColorFilter mColorFilter;
  public boolean mMutated;
  public PorterDuffColorFilter mTintFilter;
  public final Rect mTmpBounds = new Rect();
  public final float[] mTmpFloats = new float[9];
  public final Matrix mTmpMatrix = new Matrix();
  public VectorDrawableCompatState mVectorState;
  
  public VectorDrawableCompat()
  {
    mVectorState = new VectorDrawableCompatState();
  }
  
  public VectorDrawableCompat(VectorDrawableCompatState paramVectorDrawableCompatState)
  {
    mVectorState = paramVectorDrawableCompatState;
    mTintFilter = updateTintFilter(mTint, mTintMode);
  }
  
  public static int access$getAlpha(int paramInt, float paramFloat)
  {
    return paramInt & 0xFFFFFF | (int)(Color.alpha(paramInt) * paramFloat) << 24;
  }
  
  public static VectorDrawableCompat create(Resources paramResources, int paramInt, Resources.Theme paramTheme)
  {
    Object localObject;
    if (Build.VERSION.SDK_INT >= 24)
    {
      localObject = new VectorDrawableCompat();
      mDelegateDrawable = ClassWriter.getDrawable(paramResources, paramInt, paramTheme);
      new AnimatedVectorDrawableCompat.AnimatedVectorDrawableDelegateState(mDelegateDrawable.getConstantState());
      return localObject;
    }
    try
    {
      localObject = paramResources.getXml(paramInt);
      AttributeSet localAttributeSet = Xml.asAttributeSet((XmlPullParser)localObject);
      do
      {
        paramInt = ((XmlPullParser)localObject).next();
      } while ((paramInt != 2) && (paramInt != 1));
      if (paramInt == 2)
      {
        paramResources = create(paramResources, (XmlPullParser)localObject, localAttributeSet, paramTheme);
        return paramResources;
      }
      paramResources = new XmlPullParserException("No start tag found");
      throw paramResources;
    }
    catch (IOException paramResources)
    {
      Log.e("VectorDrawableCompat", "parser error", paramResources);
    }
    catch (XmlPullParserException paramResources)
    {
      Log.e("VectorDrawableCompat", "parser error", paramResources);
    }
    return null;
  }
  
  public static VectorDrawableCompat create(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    VectorDrawableCompat localVectorDrawableCompat = new VectorDrawableCompat();
    localVectorDrawableCompat.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    return localVectorDrawableCompat;
  }
  
  public static PorterDuff.Mode parseTintModeCompat(int paramInt, PorterDuff.Mode paramMode)
  {
    if (paramInt != 3)
    {
      if (paramInt != 5)
      {
        if (paramInt != 9)
        {
          switch (paramInt)
          {
          default: 
            return paramMode;
          case 16: 
            return PorterDuff.Mode.ADD;
          case 15: 
            return PorterDuff.Mode.SCREEN;
          }
          return PorterDuff.Mode.MULTIPLY;
        }
        return PorterDuff.Mode.SRC_ATOP;
      }
      return PorterDuff.Mode.SRC_IN;
    }
    return PorterDuff.Mode.SRC_OVER;
  }
  
  public boolean canApplyTheme()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      DrawableCompat.canApplyTheme(localDrawable);
    }
    return false;
  }
  
  public void draw(Canvas paramCanvas)
  {
    Object localObject1 = mDelegateDrawable;
    if (localObject1 != null)
    {
      ((Drawable)localObject1).draw(paramCanvas);
      return;
    }
    copyBounds(mTmpBounds);
    if (mTmpBounds.width() > 0)
    {
      if (mTmpBounds.height() <= 0) {
        return;
      }
      Object localObject2 = mColorFilter;
      localObject1 = localObject2;
      if (localObject2 == null) {
        localObject1 = mTintFilter;
      }
      paramCanvas.getMatrix(mTmpMatrix);
      mTmpMatrix.getValues(mTmpFloats);
      float f1 = Math.abs(mTmpFloats[0]);
      float f2 = Math.abs(mTmpFloats[4]);
      float f4 = Math.abs(mTmpFloats[1]);
      float f3 = Math.abs(mTmpFloats[3]);
      if ((f4 != 0.0F) || (f3 != 0.0F))
      {
        f1 = 1.0F;
        f2 = 1.0F;
      }
      int i = (int)(mTmpBounds.width() * f1);
      int j = (int)(mTmpBounds.height() * f2);
      i = Math.min(2048, i);
      j = Math.min(2048, j);
      if (i > 0)
      {
        if (j <= 0) {
          return;
        }
        int k = paramCanvas.save();
        localObject2 = mTmpBounds;
        paramCanvas.translate(left, top);
        if (needMirroring())
        {
          paramCanvas.translate(mTmpBounds.width(), 0.0F);
          paramCanvas.scale(-1.0F, 1.0F);
        }
        mTmpBounds.offsetTo(0, 0);
        mVectorState.createCachedBitmapIfNeeded(i, j);
        if (!mAllowCaching)
        {
          mVectorState.updateCachedBitmap(i, j);
        }
        else if (!mVectorState.canReuseCache())
        {
          mVectorState.updateCachedBitmap(i, j);
          mVectorState.updateCacheStates();
        }
        mVectorState.drawCachedBitmapWithRootAlpha(paramCanvas, (ColorFilter)localObject1, mTmpBounds);
        paramCanvas.restoreToCount(k);
      }
    }
  }
  
  public int getAlpha()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return DrawableCompat.getAlpha(localDrawable);
    }
    return mVectorState.mVPathRenderer.getRootAlpha();
  }
  
  public int getChangingConfigurations()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return localDrawable.getChangingConfigurations();
    }
    return super.getChangingConfigurations() | mVectorState.getChangingConfigurations();
  }
  
  public ColorFilter getColorFilter()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return DrawableCompat.getColorFilter(localDrawable);
    }
    return mColorFilter;
  }
  
  public Drawable.ConstantState getConstantState()
  {
    if ((mDelegateDrawable != null) && (Build.VERSION.SDK_INT >= 24)) {
      return new AnimatedVectorDrawableCompat.AnimatedVectorDrawableDelegateState(mDelegateDrawable.getConstantState());
    }
    mVectorState.mChangingConfigurations = getChangingConfigurations();
    return mVectorState;
  }
  
  public int getIntrinsicHeight()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return localDrawable.getIntrinsicHeight();
    }
    return (int)mVectorState.mVPathRenderer.mBaseHeight;
  }
  
  public int getIntrinsicWidth()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return localDrawable.getIntrinsicWidth();
    }
    return (int)mVectorState.mVPathRenderer.mBaseWidth;
  }
  
  public int getOpacity()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return localDrawable.getOpacity();
    }
    return -3;
  }
  
  public Object getTargetByName(String paramString)
  {
    return mVectorState.mVPathRenderer.mVGTargetsMap.get(paramString);
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
      return;
    }
    inflate(paramResources, paramXmlPullParser, paramAttributeSet, null);
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    Object localObject = mDelegateDrawable;
    if (localObject != null)
    {
      DrawableCompat.inflate((Drawable)localObject, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    }
    localObject = mVectorState;
    mVPathRenderer = new VPathRenderer();
    TypedArray localTypedArray = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.styleable_VectorDrawableTypeArray);
    updateStateFromTypedArray(localTypedArray, paramXmlPullParser, paramTheme);
    localTypedArray.recycle();
    mChangingConfigurations = getChangingConfigurations();
    mCacheDirty = true;
    inflateInternal(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    mTintFilter = updateTintFilter(mTint, mTintMode);
  }
  
  public final void inflateInternal(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    VectorDrawableCompatState localVectorDrawableCompatState = mVectorState;
    VPathRenderer localVPathRenderer = mVPathRenderer;
    int i = 1;
    ArrayDeque localArrayDeque = new ArrayDeque();
    localArrayDeque.push(mRootGroup);
    int k = paramXmlPullParser.getEventType();
    int m = paramXmlPullParser.getDepth();
    while ((k != 1) && ((paramXmlPullParser.getDepth() >= m + 1) || (k != 3)))
    {
      int j;
      if (k == 2)
      {
        Object localObject = paramXmlPullParser.getName();
        VGroup localVGroup = (VGroup)localArrayDeque.peek();
        if ("path".equals(localObject))
        {
          localObject = new VFullPath();
          ((VFullPath)localObject).inflate(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
          mChildren.add(localObject);
          if (((VPath)localObject).getPathName() != null) {
            mVGTargetsMap.put(((VPath)localObject).getPathName(), localObject);
          }
          j = 0;
          mChangingConfigurations |= mChangingConfigurations;
        }
        else if ("clip-path".equals(localObject))
        {
          localObject = new VClipPath();
          ((VClipPath)localObject).inflate(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
          mChildren.add(localObject);
          if (((VPath)localObject).getPathName() != null) {
            mVGTargetsMap.put(((VPath)localObject).getPathName(), localObject);
          }
          mChangingConfigurations |= mChangingConfigurations;
          j = i;
        }
        else
        {
          j = i;
          if ("group".equals(localObject))
          {
            localObject = new VGroup();
            ((VGroup)localObject).inflate(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
            mChildren.add(localObject);
            localArrayDeque.push(localObject);
            if (((VGroup)localObject).getGroupName() != null) {
              mVGTargetsMap.put(((VGroup)localObject).getGroupName(), localObject);
            }
            mChangingConfigurations |= mChangingConfigurations;
            j = i;
          }
        }
      }
      for (;;)
      {
        break;
        j = i;
        if (k == 3)
        {
          j = i;
          if ("group".equals(paramXmlPullParser.getName()))
          {
            localArrayDeque.pop();
            j = i;
          }
        }
      }
      k = paramXmlPullParser.next();
      i = j;
    }
    if (i == 0) {
      return;
    }
    throw new XmlPullParserException("no path defined");
  }
  
  public void invalidateSelf()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.invalidateSelf();
      return;
    }
    super.invalidateSelf();
  }
  
  public boolean isAutoMirrored()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return DrawableCompat.isAutoMirrored(localDrawable);
    }
    return mVectorState.mAutoMirrored;
  }
  
  public boolean isStateful()
  {
    Object localObject = mDelegateDrawable;
    if (localObject != null) {
      return ((Drawable)localObject).isStateful();
    }
    if (!super.isStateful())
    {
      localObject = mVectorState;
      if (localObject != null)
      {
        if (!((VectorDrawableCompatState)localObject).updateCachedBitmap())
        {
          localObject = mVectorState.mTint;
          if ((localObject != null) && (((ColorStateList)localObject).isStateful())) {}
        }
      }
      else {
        return false;
      }
    }
    return true;
  }
  
  public Drawable mutate()
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.mutate();
      return this;
    }
    if ((!mMutated) && (super.mutate() == this))
    {
      mVectorState = new VectorDrawableCompatState(mVectorState);
      mMutated = true;
    }
    return this;
  }
  
  public final boolean needMirroring()
  {
    return (isAutoMirrored()) && (DrawableCompat.getLayoutDirection(this) == 1);
  }
  
  public void onBoundsChange(Rect paramRect)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      localDrawable.setBounds(paramRect);
    }
  }
  
  public boolean onStateChange(int[] paramArrayOfInt)
  {
    Object localObject = mDelegateDrawable;
    if (localObject != null) {
      return ((Drawable)localObject).setState(paramArrayOfInt);
    }
    boolean bool2 = false;
    localObject = mVectorState;
    ColorStateList localColorStateList = mTint;
    boolean bool1 = bool2;
    if (localColorStateList != null)
    {
      PorterDuff.Mode localMode = mTintMode;
      bool1 = bool2;
      if (localMode != null)
      {
        mTintFilter = updateTintFilter(localColorStateList, localMode);
        invalidateSelf();
        bool1 = true;
      }
    }
    if ((((VectorDrawableCompatState)localObject).updateCachedBitmap()) && (((VectorDrawableCompatState)localObject).draw(paramArrayOfInt)))
    {
      invalidateSelf();
      return true;
    }
    return bool1;
  }
  
  public void scheduleSelf(Runnable paramRunnable, long paramLong)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.scheduleSelf(paramRunnable, paramLong);
      return;
    }
    super.scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAllowCaching(boolean paramBoolean)
  {
    mAllowCaching = paramBoolean;
  }
  
  public void setAlpha(int paramInt)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.setAlpha(paramInt);
      return;
    }
    if (mVectorState.mVPathRenderer.getRootAlpha() != paramInt)
    {
      mVectorState.mVPathRenderer.setRootAlpha(paramInt);
      invalidateSelf();
    }
  }
  
  public void setAutoMirrored(boolean paramBoolean)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      DrawableCompat.setAutoMirrored(localDrawable, paramBoolean);
      return;
    }
    mVectorState.mAutoMirrored = paramBoolean;
  }
  
  public void setColorFilter(ColorFilter paramColorFilter)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.setColorFilter(paramColorFilter);
      return;
    }
    mColorFilter = paramColorFilter;
    invalidateSelf();
  }
  
  public void setTint(int paramInt)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      DrawableCompat.setTint(localDrawable, paramInt);
      return;
    }
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList)
  {
    Object localObject = mDelegateDrawable;
    if (localObject != null)
    {
      DrawableCompat.setTintList((Drawable)localObject, paramColorStateList);
      return;
    }
    localObject = mVectorState;
    if (mTint != paramColorStateList)
    {
      mTint = paramColorStateList;
      mTintFilter = updateTintFilter(paramColorStateList, mTintMode);
      invalidateSelf();
    }
  }
  
  public void setTintMode(PorterDuff.Mode paramMode)
  {
    Object localObject = mDelegateDrawable;
    if (localObject != null)
    {
      DrawableCompat.setTintMode((Drawable)localObject, paramMode);
      return;
    }
    localObject = mVectorState;
    if (mTintMode != paramMode)
    {
      mTintMode = paramMode;
      mTintFilter = updateTintFilter(mTint, paramMode);
      invalidateSelf();
    }
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null) {
      return localDrawable.setVisible(paramBoolean1, paramBoolean2);
    }
    return super.setVisible(paramBoolean1, paramBoolean2);
  }
  
  public void unscheduleSelf(Runnable paramRunnable)
  {
    Drawable localDrawable = mDelegateDrawable;
    if (localDrawable != null)
    {
      localDrawable.unscheduleSelf(paramRunnable);
      return;
    }
    super.unscheduleSelf(paramRunnable);
  }
  
  public final void updateStateFromTypedArray(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme)
  {
    VectorDrawableCompatState localVectorDrawableCompatState = mVectorState;
    VPathRenderer localVPathRenderer = mVPathRenderer;
    mTintMode = parseTintModeCompat(org.core.fonts.data.StringBuilder.getString(paramTypedArray, paramXmlPullParser, "tintMode", 6, -1), PorterDuff.Mode.SRC_IN);
    paramTheme = org.core.fonts.data.StringBuilder.a(paramTypedArray, paramXmlPullParser, paramTheme, "tint", 1);
    if (paramTheme != null) {
      mTint = paramTheme;
    }
    mAutoMirrored = org.core.fonts.data.StringBuilder.getNamedBoolean(paramTypedArray, paramXmlPullParser, "autoMirrored", 5, mAutoMirrored);
    mViewportWidth = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "viewportWidth", 7, mViewportWidth);
    float f = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "viewportHeight", 8, mViewportHeight);
    mViewportHeight = f;
    if (mViewportWidth > 0.0F)
    {
      if (f > 0.0F)
      {
        mBaseWidth = paramTypedArray.getDimension(3, mBaseWidth);
        f = paramTypedArray.getDimension(2, mBaseHeight);
        mBaseHeight = f;
        if (mBaseWidth > 0.0F)
        {
          if (f > 0.0F)
          {
            localVPathRenderer.setAlpha(org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "alpha", 4, localVPathRenderer.getAlpha()));
            paramTypedArray = paramTypedArray.getString(0);
            if (paramTypedArray != null)
            {
              mRootName = paramTypedArray;
              mVGTargetsMap.put(paramTypedArray, localVPathRenderer);
            }
          }
          else
          {
            paramXmlPullParser = new StringBuilder();
            paramXmlPullParser.append(paramTypedArray.getPositionDescription());
            paramXmlPullParser.append("<vector> tag requires height > 0");
            throw new XmlPullParserException(paramXmlPullParser.toString());
          }
        }
        else
        {
          paramXmlPullParser = new StringBuilder();
          paramXmlPullParser.append(paramTypedArray.getPositionDescription());
          paramXmlPullParser.append("<vector> tag requires width > 0");
          throw new XmlPullParserException(paramXmlPullParser.toString());
        }
      }
      else
      {
        paramXmlPullParser = new StringBuilder();
        paramXmlPullParser.append(paramTypedArray.getPositionDescription());
        paramXmlPullParser.append("<vector> tag requires viewportHeight > 0");
        throw new XmlPullParserException(paramXmlPullParser.toString());
      }
    }
    else
    {
      paramXmlPullParser = new StringBuilder();
      paramXmlPullParser.append(paramTypedArray.getPositionDescription());
      paramXmlPullParser.append("<vector> tag requires viewportWidth > 0");
      throw new XmlPullParserException(paramXmlPullParser.toString());
    }
  }
  
  public PorterDuffColorFilter updateTintFilter(ColorStateList paramColorStateList, PorterDuff.Mode paramMode)
  {
    if ((paramColorStateList != null) && (paramMode != null)) {
      return new PorterDuffColorFilter(paramColorStateList.getColorForState(getState(), 0), paramMode);
    }
    return null;
  }
  
  public class VClipPath
    extends VectorDrawableCompat.VPath
  {
    public VClipPath() {}
    
    public VClipPath()
    {
      super();
    }
    
    public void inflate(Resources paramResources, AttributeSet paramAttributeSet, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser)
    {
      if (!org.core.fonts.data.StringBuilder.get(paramXmlPullParser, "pathData")) {
        return;
      }
      paramResources = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.styleable_VectorDrawableClipPath);
      updateStateFromTypedArray(paramResources, paramXmlPullParser);
      paramResources.recycle();
    }
    
    public boolean isClipPath()
    {
      return true;
    }
    
    public final void updateStateFromTypedArray(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser)
    {
      String str = paramTypedArray.getString(0);
      if (str != null) {
        mPathName = str;
      }
      str = paramTypedArray.getString(1);
      if (str != null) {
        mNodes = PathParser.createNodesFromPathData(str);
      }
      mFillColor = org.core.fonts.data.StringBuilder.getString(paramTypedArray, paramXmlPullParser, "fillType", 2, 0);
    }
  }
  
  public class VFullPath
    extends VectorDrawableCompat.VPath
  {
    public d a;
    public float mFillAlpha = 1.0F;
    public float mStrokeAlpha = 1.0F;
    public d mStrokeColor;
    public Paint.Cap mStrokeLineCap = Paint.Cap.BUTT;
    public Paint.Join mStrokeLineJoin = Paint.Join.MITER;
    public float mStrokeMiterlimit = 4.0F;
    public float mStrokeWidth = 0.0F;
    public int[] mThemeAttrs;
    public float mTrimPathEnd = 1.0F;
    public float mTrimPathOffset = 0.0F;
    public float mTrimPathStart = 0.0F;
    
    public VFullPath() {}
    
    public VFullPath()
    {
      super();
      mThemeAttrs = mThemeAttrs;
      mStrokeColor = mStrokeColor;
      mStrokeWidth = mStrokeWidth;
      mStrokeAlpha = mStrokeAlpha;
      a = a;
      mFillColor = mFillColor;
      mFillAlpha = mFillAlpha;
      mTrimPathStart = mTrimPathStart;
      mTrimPathEnd = mTrimPathEnd;
      mTrimPathOffset = mTrimPathOffset;
      mStrokeLineCap = mStrokeLineCap;
      mStrokeLineJoin = mStrokeLineJoin;
      mStrokeMiterlimit = mStrokeMiterlimit;
    }
    
    public boolean draw()
    {
      return (a.a()) || (mStrokeColor.a());
    }
    
    public boolean draw(int[] paramArrayOfInt)
    {
      return a.a(paramArrayOfInt) | mStrokeColor.a(paramArrayOfInt);
    }
    
    public float getFillAlpha()
    {
      return mFillAlpha;
    }
    
    public int getFillColor()
    {
      return a.getColor();
    }
    
    public float getStrokeAlpha()
    {
      return mStrokeAlpha;
    }
    
    public int getStrokeColor()
    {
      return mStrokeColor.getColor();
    }
    
    public final Paint.Cap getStrokeLineCap(int paramInt, Paint.Cap paramCap)
    {
      if (paramInt != 0)
      {
        if (paramInt != 1)
        {
          if (paramInt != 2) {
            return paramCap;
          }
          return Paint.Cap.SQUARE;
        }
        return Paint.Cap.ROUND;
      }
      return Paint.Cap.BUTT;
    }
    
    public final Paint.Join getStrokeLineJoin(int paramInt, Paint.Join paramJoin)
    {
      if (paramInt != 0)
      {
        if (paramInt != 1)
        {
          if (paramInt != 2) {
            return paramJoin;
          }
          return Paint.Join.BEVEL;
        }
        return Paint.Join.ROUND;
      }
      return Paint.Join.MITER;
    }
    
    public float getStrokeWidth()
    {
      return mStrokeWidth;
    }
    
    public float getTrimPathEnd()
    {
      return mTrimPathEnd;
    }
    
    public float getTrimPathOffset()
    {
      return mTrimPathOffset;
    }
    
    public float getTrimPathStart()
    {
      return mTrimPathStart;
    }
    
    public void inflate(Resources paramResources, AttributeSet paramAttributeSet, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser)
    {
      paramResources = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.ColorDrawable);
      updateStateFromTypedArray(paramResources, paramXmlPullParser, paramTheme);
      paramResources.recycle();
    }
    
    public void setFillAlpha(float paramFloat)
    {
      mFillAlpha = paramFloat;
    }
    
    public void setFillColor(int paramInt)
    {
      a.setColor(paramInt);
    }
    
    public void setStrokeAlpha(float paramFloat)
    {
      mStrokeAlpha = paramFloat;
    }
    
    public void setStrokeColor(int paramInt)
    {
      mStrokeColor.setColor(paramInt);
    }
    
    public void setStrokeWidth(float paramFloat)
    {
      mStrokeWidth = paramFloat;
    }
    
    public void setTrimPathEnd(float paramFloat)
    {
      mTrimPathEnd = paramFloat;
    }
    
    public void setTrimPathOffset(float paramFloat)
    {
      mTrimPathOffset = paramFloat;
    }
    
    public void setTrimPathStart(float paramFloat)
    {
      mTrimPathStart = paramFloat;
    }
    
    public final void updateStateFromTypedArray(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme)
    {
      mThemeAttrs = null;
      if (!org.core.fonts.data.StringBuilder.get(paramXmlPullParser, "pathData")) {
        return;
      }
      String str = paramTypedArray.getString(0);
      if (str != null) {
        mPathName = str;
      }
      str = paramTypedArray.getString(2);
      if (str != null) {
        mNodes = PathParser.createNodesFromPathData(str);
      }
      a = org.core.fonts.data.StringBuilder.a(paramTypedArray, paramXmlPullParser, paramTheme, "fillColor", 1, 0);
      mFillAlpha = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "fillAlpha", 12, mFillAlpha);
      mStrokeLineCap = getStrokeLineCap(org.core.fonts.data.StringBuilder.getString(paramTypedArray, paramXmlPullParser, "strokeLineCap", 8, -1), mStrokeLineCap);
      mStrokeLineJoin = getStrokeLineJoin(org.core.fonts.data.StringBuilder.getString(paramTypedArray, paramXmlPullParser, "strokeLineJoin", 9, -1), mStrokeLineJoin);
      mStrokeMiterlimit = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "strokeMiterLimit", 10, mStrokeMiterlimit);
      mStrokeColor = org.core.fonts.data.StringBuilder.a(paramTypedArray, paramXmlPullParser, paramTheme, "strokeColor", 3, 0);
      mStrokeAlpha = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "strokeAlpha", 11, mStrokeAlpha);
      mStrokeWidth = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "strokeWidth", 4, mStrokeWidth);
      mTrimPathEnd = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "trimPathEnd", 6, mTrimPathEnd);
      mTrimPathOffset = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "trimPathOffset", 7, mTrimPathOffset);
      mTrimPathStart = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "trimPathStart", 5, mTrimPathStart);
      mFillColor = org.core.fonts.data.StringBuilder.getString(paramTypedArray, paramXmlPullParser, "fillType", 13, mFillColor);
    }
  }
  
  public class VGroup
    extends Series
  {
    public int mChangingConfigurations;
    public final ArrayList<g.e> mChildren = new ArrayList();
    public String mGroupName = null;
    public final Matrix mLocalMatrix = new Matrix();
    public float mPivotX = 0.0F;
    public float mPivotY = 0.0F;
    public float mRotate = 0.0F;
    public float mScaleX = 1.0F;
    public float mScaleY = 1.0F;
    public final Matrix mStackedMatrix = new Matrix();
    public int[] mThemeAttrs;
    public float mTranslateX = 0.0F;
    public float mTranslateY = 0.0F;
    
    public VGroup()
    {
      super();
    }
    
    public VGroup(Label paramLabel) {}
    
    public boolean draw()
    {
      int i = 0;
      while (i < mChildren.size())
      {
        if (((Series)mChildren.get(i)).draw()) {
          return true;
        }
        i += 1;
      }
      return false;
    }
    
    public boolean draw(int[] paramArrayOfInt)
    {
      boolean bool = false;
      int i = 0;
      while (i < mChildren.size())
      {
        bool |= ((Series)mChildren.get(i)).draw(paramArrayOfInt);
        i += 1;
      }
      return bool;
    }
    
    public String getGroupName()
    {
      return mGroupName;
    }
    
    public Matrix getLocalMatrix()
    {
      return mLocalMatrix;
    }
    
    public float getPivotX()
    {
      return mPivotX;
    }
    
    public float getPivotY()
    {
      return mPivotY;
    }
    
    public float getRotation()
    {
      return mRotate;
    }
    
    public float getScaleX()
    {
      return mScaleX;
    }
    
    public float getScaleY()
    {
      return mScaleY;
    }
    
    public float getTranslateX()
    {
      return mTranslateX;
    }
    
    public float getTranslateY()
    {
      return mTranslateY;
    }
    
    public void inflate(Resources paramResources, AttributeSet paramAttributeSet, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser)
    {
      paramResources = org.core.fonts.data.StringBuilder.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.LayerDrawable);
      updateStateFromTypedArray(paramResources, paramXmlPullParser);
      paramResources.recycle();
    }
    
    public void setPivotX(float paramFloat)
    {
      if (paramFloat != mPivotX)
      {
        mPivotX = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public void setPivotY(float paramFloat)
    {
      if (paramFloat != mPivotY)
      {
        mPivotY = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public void setRotation(float paramFloat)
    {
      if (paramFloat != mRotate)
      {
        mRotate = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public void setScaleX(float paramFloat)
    {
      if (paramFloat != mScaleX)
      {
        mScaleX = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public void setScaleY(float paramFloat)
    {
      if (paramFloat != mScaleY)
      {
        mScaleY = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public void setTranslateX(float paramFloat)
    {
      if (paramFloat != mTranslateX)
      {
        mTranslateX = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public void setTranslateY(float paramFloat)
    {
      if (paramFloat != mTranslateY)
      {
        mTranslateY = paramFloat;
        updateLocalMatrix();
      }
    }
    
    public final void updateLocalMatrix()
    {
      mLocalMatrix.reset();
      mLocalMatrix.postTranslate(-mPivotX, -mPivotY);
      mLocalMatrix.postScale(mScaleX, mScaleY);
      mLocalMatrix.postRotate(mRotate, 0.0F, 0.0F);
      mLocalMatrix.postTranslate(mTranslateX + mPivotX, mTranslateY + mPivotY);
    }
    
    public final void updateStateFromTypedArray(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser)
    {
      mThemeAttrs = null;
      mRotate = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "rotation", 5, mRotate);
      mPivotX = paramTypedArray.getFloat(1, mPivotX);
      mPivotY = paramTypedArray.getFloat(2, mPivotY);
      mScaleX = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "scaleX", 3, mScaleX);
      mScaleY = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "scaleY", 4, mScaleY);
      mTranslateX = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "translateX", 6, mTranslateX);
      mTranslateY = org.core.fonts.data.StringBuilder.getNamedFloat(paramTypedArray, paramXmlPullParser, "translateY", 7, mTranslateY);
      paramTypedArray = paramTypedArray.getString(0);
      if (paramTypedArray != null) {
        mGroupName = paramTypedArray;
      }
      updateLocalMatrix();
    }
  }
  
  public abstract class VPath
    extends Series
  {
    public int mChangingConfigurations;
    public int mFillColor = 0;
    public PathParser.PathDataNode[] mNodes = null;
    public String mPathName;
    
    public VPath()
    {
      super();
    }
    
    public VPath()
    {
      super();
      mPathName = mPathName;
      mChangingConfigurations = mChangingConfigurations;
      mNodes = PathParser.deepCopyNodes(mNodes);
    }
    
    public PathParser.PathDataNode[] getPathData()
    {
      return mNodes;
    }
    
    public String getPathName()
    {
      return mPathName;
    }
    
    public boolean isClipPath()
    {
      return false;
    }
    
    public void setPathData(PathParser.PathDataNode[] paramArrayOfPathDataNode)
    {
      if (!PathParser.canMorph(mNodes, paramArrayOfPathDataNode))
      {
        mNodes = PathParser.deepCopyNodes(paramArrayOfPathDataNode);
        return;
      }
      PathParser.updateNodes(mNodes, paramArrayOfPathDataNode);
    }
    
    public void toPath(Path paramPath)
    {
      paramPath.reset();
      PathParser.PathDataNode[] arrayOfPathDataNode = mNodes;
      if (arrayOfPathDataNode != null) {
        PathParser.PathDataNode.nodesToPath(arrayOfPathDataNode, paramPath);
      }
    }
  }
  
  public class VPathRenderer
  {
    public static final Matrix IDENTITY_MATRIX = new Matrix();
    public float mBaseHeight = 0.0F;
    public float mBaseWidth = 0.0F;
    public int mChangingConfigurations;
    public Paint mFillPaint;
    public final Matrix mFinalPathMatrix = new Matrix();
    public Boolean mGenerated = null;
    public final Path mPath;
    public PathMeasure mPathMeasure;
    public final Path mRenderPath;
    public int mRootAlpha = 255;
    public final VectorDrawableCompat.VGroup mRootGroup;
    public String mRootName = null;
    public Paint mStrokePaint;
    public final a<String, Object> mVGTargetsMap;
    public float mViewportHeight = 0.0F;
    public float mViewportWidth = 0.0F;
    
    public VPathRenderer()
    {
      mVGTargetsMap = new Label();
      mRootGroup = new VectorDrawableCompat.VGroup();
      mPath = new Path();
      mRenderPath = new Path();
    }
    
    public VPathRenderer()
    {
      Object localObject = new Label();
      mVGTargetsMap = ((Label)localObject);
      mRootGroup = new VectorDrawableCompat.VGroup(mRootGroup, (Label)localObject);
      mPath = new Path(mPath);
      mRenderPath = new Path(mRenderPath);
      mBaseWidth = mBaseWidth;
      mBaseHeight = mBaseHeight;
      mViewportWidth = mViewportWidth;
      mViewportHeight = mViewportHeight;
      mChangingConfigurations = mChangingConfigurations;
      mRootAlpha = mRootAlpha;
      mRootName = mRootName;
      localObject = mRootName;
      if (localObject != null) {
        mVGTargetsMap.put(localObject, this);
      }
      mGenerated = mGenerated;
    }
    
    public static float cross(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
    {
      return paramFloat1 * paramFloat4 - paramFloat2 * paramFloat3;
    }
    
    public void draw(Canvas paramCanvas, int paramInt1, int paramInt2, ColorFilter paramColorFilter)
    {
      drawGroupTree(mRootGroup, IDENTITY_MATRIX, paramCanvas, paramInt1, paramInt2, paramColorFilter);
    }
    
    public boolean draw()
    {
      if (mGenerated == null) {
        mGenerated = Boolean.valueOf(mRootGroup.draw());
      }
      return mGenerated.booleanValue();
    }
    
    public boolean draw(int[] paramArrayOfInt)
    {
      return mRootGroup.draw(paramArrayOfInt);
    }
    
    public final void drawGroupTree(VectorDrawableCompat.VGroup paramVGroup, Matrix paramMatrix, Canvas paramCanvas, int paramInt1, int paramInt2, ColorFilter paramColorFilter)
    {
      mStackedMatrix.set(paramMatrix);
      mStackedMatrix.preConcat(mLocalMatrix);
      paramCanvas.save();
      int i = 0;
      while (i < mChildren.size())
      {
        paramMatrix = (Series)mChildren.get(i);
        if ((paramMatrix instanceof VectorDrawableCompat.VGroup)) {
          drawGroupTree((VectorDrawableCompat.VGroup)paramMatrix, mStackedMatrix, paramCanvas, paramInt1, paramInt2, paramColorFilter);
        } else if ((paramMatrix instanceof VectorDrawableCompat.VPath)) {
          drawPath(paramVGroup, (VectorDrawableCompat.VPath)paramMatrix, paramCanvas, paramInt1, paramInt2, paramColorFilter);
        }
        i += 1;
      }
      paramCanvas.restore();
    }
    
    public final void drawPath(VectorDrawableCompat.VGroup paramVGroup, VectorDrawableCompat.VPath paramVPath, Canvas paramCanvas, int paramInt1, int paramInt2, ColorFilter paramColorFilter)
    {
      float f2 = paramInt1 / mViewportWidth;
      float f3 = paramInt2 / mViewportHeight;
      float f1 = Math.min(f2, f3);
      paramVGroup = mStackedMatrix;
      mFinalPathMatrix.set(paramVGroup);
      mFinalPathMatrix.postScale(f2, f3);
      f2 = getMatrixScale(paramVGroup);
      if (f2 == 0.0F) {
        return;
      }
      paramVPath.toPath(mPath);
      Object localObject1 = mPath;
      mRenderPath.reset();
      if (paramVPath.isClipPath())
      {
        paramColorFilter = mRenderPath;
        if (mFillColor == 0) {
          paramVGroup = Path.FillType.WINDING;
        } else {
          paramVGroup = Path.FillType.EVEN_ODD;
        }
        paramColorFilter.setFillType(paramVGroup);
        mRenderPath.addPath((Path)localObject1, mFinalPathMatrix);
        paramCanvas.clipPath(mRenderPath);
        return;
      }
      paramVPath = (VectorDrawableCompat.VFullPath)paramVPath;
      if ((mTrimPathStart == 0.0F) && (mTrimPathEnd == 1.0F)) {
        break label327;
      }
      float f6 = mTrimPathStart;
      float f4 = mTrimPathOffset;
      float f5 = mTrimPathEnd;
      if (mPathMeasure == null) {
        mPathMeasure = new PathMeasure();
      }
      mPathMeasure.setPath(mPath, false);
      f3 = mPathMeasure.getLength();
      f6 = (f6 + f4) % 1.0F * f3;
      f4 = (f5 + f4) % 1.0F * f3;
      ((Path)localObject1).reset();
      if (f6 > f4)
      {
        mPathMeasure.getSegment(f6, f3, (Path)localObject1, true);
        mPathMeasure.getSegment(0.0F, f4, (Path)localObject1, true);
      }
      else
      {
        mPathMeasure.getSegment(f6, f4, (Path)localObject1, true);
      }
      ((Path)localObject1).rLineTo(0.0F, 0.0F);
      label327:
      mRenderPath.addPath((Path)localObject1, mFinalPathMatrix);
      Object localObject2;
      if (a.b())
      {
        paramVGroup = a;
        if (mFillPaint == null)
        {
          localObject1 = new Paint(1);
          mFillPaint = ((Paint)localObject1);
          ((Paint)localObject1).setStyle(Paint.Style.FILL);
        }
        localObject1 = mFillPaint;
        if (paramVGroup.g())
        {
          paramVGroup = paramVGroup.l();
          paramVGroup.setLocalMatrix(mFinalPathMatrix);
          ((Paint)localObject1).setShader(paramVGroup);
          ((Paint)localObject1).setAlpha(Math.round(mFillAlpha * 255.0F));
        }
        else
        {
          ((Paint)localObject1).setShader(null);
          ((Paint)localObject1).setAlpha(255);
          ((Paint)localObject1).setColor(VectorDrawableCompat.access$getAlpha(paramVGroup.getColor(), mFillAlpha));
        }
        ((Paint)localObject1).setColorFilter(paramColorFilter);
        localObject2 = mRenderPath;
        if (mFillColor == 0) {
          paramVGroup = Path.FillType.WINDING;
        } else {
          paramVGroup = Path.FillType.EVEN_ODD;
        }
        ((Path)localObject2).setFillType(paramVGroup);
        paramCanvas.drawPath(mRenderPath, (Paint)localObject1);
      }
      if (mStrokeColor.b())
      {
        paramVGroup = mStrokeColor;
        if (mStrokePaint == null)
        {
          localObject1 = new Paint(1);
          mStrokePaint = ((Paint)localObject1);
          ((Paint)localObject1).setStyle(Paint.Style.STROKE);
        }
        localObject1 = mStrokePaint;
        localObject2 = mStrokeLineJoin;
        if (localObject2 != null) {
          ((Paint)localObject1).setStrokeJoin((Paint.Join)localObject2);
        }
        localObject2 = mStrokeLineCap;
        if (localObject2 != null) {
          ((Paint)localObject1).setStrokeCap((Paint.Cap)localObject2);
        }
        ((Paint)localObject1).setStrokeMiter(mStrokeMiterlimit);
        if (paramVGroup.g())
        {
          paramVGroup = paramVGroup.l();
          paramVGroup.setLocalMatrix(mFinalPathMatrix);
          ((Paint)localObject1).setShader(paramVGroup);
          ((Paint)localObject1).setAlpha(Math.round(mStrokeAlpha * 255.0F));
        }
        else
        {
          ((Paint)localObject1).setShader(null);
          ((Paint)localObject1).setAlpha(255);
          ((Paint)localObject1).setColor(VectorDrawableCompat.access$getAlpha(paramVGroup.getColor(), mStrokeAlpha));
        }
        ((Paint)localObject1).setColorFilter(paramColorFilter);
        ((Paint)localObject1).setStrokeWidth(mStrokeWidth * (f1 * f2));
        paramCanvas.drawPath(mRenderPath, (Paint)localObject1);
      }
    }
    
    public float getAlpha()
    {
      return getRootAlpha() / 255.0F;
    }
    
    public final float getMatrixScale(Matrix paramMatrix)
    {
      float[] arrayOfFloat = new float[4];
      arrayOfFloat[0] = 0.0F;
      arrayOfFloat[1] = 1.0F;
      arrayOfFloat[2] = 1.0F;
      arrayOfFloat[3] = 0.0F;
      paramMatrix.mapVectors(arrayOfFloat);
      float f2 = (float)Math.hypot(arrayOfFloat[0], arrayOfFloat[1]);
      float f3 = (float)Math.hypot(arrayOfFloat[2], arrayOfFloat[3]);
      float f1 = cross(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
      f2 = Math.max(f2, f3);
      if (f2 > 0.0F) {
        return Math.abs(f1) / f2;
      }
      return 0.0F;
    }
    
    public int getRootAlpha()
    {
      return mRootAlpha;
    }
    
    public void setAlpha(float paramFloat)
    {
      setRootAlpha((int)(255.0F * paramFloat));
    }
    
    public void setRootAlpha(int paramInt)
    {
      mRootAlpha = paramInt;
    }
  }
  
  public class VectorDrawableCompatState
    extends Drawable.ConstantState
  {
    public boolean mAutoMirrored;
    public boolean mCacheDirty;
    public boolean mCachedAutoMirrored;
    public Bitmap mCachedBitmap;
    public int mCachedRootAlpha;
    public ColorStateList mCachedTint;
    public PorterDuff.Mode mCachedTintMode;
    public int mChangingConfigurations;
    public Paint mTempPaint;
    public ColorStateList mTint = null;
    public PorterDuff.Mode mTintMode = VectorDrawableCompat.DEFAULT_TINT_MODE;
    public VectorDrawableCompat.VPathRenderer mVPathRenderer;
    
    public VectorDrawableCompatState()
    {
      mVPathRenderer = new VectorDrawableCompat.VPathRenderer();
    }
    
    public VectorDrawableCompatState()
    {
      if (this$1 != null)
      {
        mChangingConfigurations = mChangingConfigurations;
        VectorDrawableCompat.VPathRenderer localVPathRenderer = new VectorDrawableCompat.VPathRenderer(mVPathRenderer);
        mVPathRenderer = localVPathRenderer;
        if (mVPathRenderer.mFillPaint != null) {
          mFillPaint = new Paint(mVPathRenderer.mFillPaint);
        }
        if (mVPathRenderer.mStrokePaint != null) {
          mVPathRenderer.mStrokePaint = new Paint(mVPathRenderer.mStrokePaint);
        }
        mTint = mTint;
        mTintMode = mTintMode;
        mAutoMirrored = mAutoMirrored;
      }
    }
    
    public boolean canReuseBitmap(int paramInt1, int paramInt2)
    {
      return (paramInt1 == mCachedBitmap.getWidth()) && (paramInt2 == mCachedBitmap.getHeight());
    }
    
    public boolean canReuseCache()
    {
      return (!mCacheDirty) && (mCachedTint == mTint) && (mCachedTintMode == mTintMode) && (mCachedAutoMirrored == mAutoMirrored) && (mCachedRootAlpha == mVPathRenderer.getRootAlpha());
    }
    
    public void createCachedBitmapIfNeeded(int paramInt1, int paramInt2)
    {
      if ((mCachedBitmap == null) || (!canReuseBitmap(paramInt1, paramInt2)))
      {
        mCachedBitmap = Bitmap.createBitmap(paramInt1, paramInt2, Bitmap.Config.ARGB_8888);
        mCacheDirty = true;
      }
    }
    
    public boolean draw(int[] paramArrayOfInt)
    {
      boolean bool = mVPathRenderer.draw(paramArrayOfInt);
      mCacheDirty |= bool;
      return bool;
    }
    
    public void drawCachedBitmapWithRootAlpha(Canvas paramCanvas, ColorFilter paramColorFilter, Rect paramRect)
    {
      paramColorFilter = getPaint(paramColorFilter);
      paramCanvas.drawBitmap(mCachedBitmap, null, paramRect, paramColorFilter);
    }
    
    public int getChangingConfigurations()
    {
      return mChangingConfigurations;
    }
    
    public Paint getPaint(ColorFilter paramColorFilter)
    {
      if ((!hasTranslucentRoot()) && (paramColorFilter == null)) {
        return null;
      }
      if (mTempPaint == null)
      {
        Paint localPaint = new Paint();
        mTempPaint = localPaint;
        localPaint.setFilterBitmap(true);
      }
      mTempPaint.setAlpha(mVPathRenderer.getRootAlpha());
      mTempPaint.setColorFilter(paramColorFilter);
      return mTempPaint;
    }
    
    public boolean hasTranslucentRoot()
    {
      return mVPathRenderer.getRootAlpha() < 255;
    }
    
    public Drawable newDrawable()
    {
      return new VectorDrawableCompat(this);
    }
    
    public Drawable newDrawable(Resources paramResources)
    {
      return new VectorDrawableCompat(this);
    }
    
    public void updateCacheStates()
    {
      mCachedTint = mTint;
      mCachedTintMode = mTintMode;
      mCachedRootAlpha = mVPathRenderer.getRootAlpha();
      mCachedAutoMirrored = mAutoMirrored;
      mCacheDirty = false;
    }
    
    public void updateCachedBitmap(int paramInt1, int paramInt2)
    {
      mCachedBitmap.eraseColor(0);
      Canvas localCanvas = new Canvas(mCachedBitmap);
      mVPathRenderer.draw(localCanvas, paramInt1, paramInt2, null);
    }
    
    public boolean updateCachedBitmap()
    {
      return mVPathRenderer.draw();
    }
  }
}
