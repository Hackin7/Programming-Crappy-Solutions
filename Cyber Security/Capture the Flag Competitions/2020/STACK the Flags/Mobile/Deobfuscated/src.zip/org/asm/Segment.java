package org.asm;

import android.view.View;
import android.view.WindowId;

public class Segment
  implements aa
{
  public final WindowId from;
  
  public Segment(View paramView)
  {
    from = paramView.getWindowId();
  }
  
  public boolean equals(Object paramObject)
  {
    return ((paramObject instanceof Segment)) && (from.equals(from));
  }
  
  public int hashCode()
  {
    return from.hashCode();
  }
}
