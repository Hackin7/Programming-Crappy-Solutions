package org.asm;

public abstract interface aa {}
