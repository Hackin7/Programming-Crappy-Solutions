package org.asm;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import org.androidsoft.app.f;

public class a
  extends f
{
  public a() {}
  
  public static boolean a(l paramL)
  {
    return (!f.add(paramL.length())) || (!f.add(paramL.getValue())) || (!f.add(paramL.getTitle()));
  }
  
  public Object a(Object paramObject)
  {
    if (paramObject != null) {
      return ((l)paramObject).b();
    }
    return null;
  }
  
  public Object a(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    h localH = null;
    paramObject1 = (l)paramObject1;
    paramObject2 = (l)paramObject2;
    paramObject3 = (l)paramObject3;
    if ((paramObject1 != null) && (paramObject2 != null))
    {
      localH = new h();
      localH.a(paramObject1);
      localH.a(paramObject2);
      paramObject1 = localH.c(1);
    }
    else if (paramObject1 == null)
    {
      paramObject1 = localH;
      if (paramObject2 != null) {
        paramObject1 = paramObject2;
      }
    }
    if (paramObject3 != null)
    {
      paramObject2 = new h();
      if (paramObject1 != null) {
        paramObject2.a(paramObject1);
      }
      paramObject2.a(paramObject3);
      return paramObject2;
    }
    return paramObject1;
  }
  
  public void a(ViewGroup paramViewGroup, Object paramObject)
  {
    Handler.a(paramViewGroup, (l)paramObject);
  }
  
  public void a(Object paramObject, Rect paramRect)
  {
    if (paramObject != null) {
      ((l)paramObject).a(new FieldVisitor(this, paramRect));
    }
  }
  
  public void a(Object paramObject, View paramView)
  {
    if (paramObject != null) {
      ((l)paramObject).b(paramView);
    }
  }
  
  public void a(Object paramObject, View paramView, ArrayList paramArrayList)
  {
    paramObject = (h)paramObject;
    List localList = paramObject.get();
    localList.clear();
    int j = paramArrayList.size();
    int i = 0;
    while (i < j)
    {
      f.bfsAddViewChildren(localList, (View)paramArrayList.get(i));
      i += 1;
    }
    localList.add(paramView);
    paramArrayList.add(paramView);
    a(paramObject, paramArrayList);
  }
  
  public void a(Object paramObject, ArrayList paramArrayList)
  {
    paramObject = (l)paramObject;
    if (paramObject == null) {
      return;
    }
    int j;
    int i;
    if ((paramObject instanceof h))
    {
      paramObject = (h)paramObject;
      j = paramObject.k();
      i = 0;
      while (i < j)
      {
        a(paramObject.a(i), paramArrayList);
        i += 1;
      }
      return;
    }
    if ((!a(paramObject)) && (f.add(paramObject.get())))
    {
      j = paramArrayList.size();
      i = 0;
      while (i < j)
      {
        paramObject.get((View)paramArrayList.get(i));
        i += 1;
      }
    }
  }
  
  public void a(Object paramObject, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    paramObject = (l)paramObject;
    int j;
    int i;
    if ((paramObject instanceof h))
    {
      paramObject = (h)paramObject;
      j = paramObject.k();
      i = 0;
      while (i < j)
      {
        a(paramObject.a(i), paramArrayList1, paramArrayList2);
        i += 1;
      }
      return;
    }
    if (!a(paramObject))
    {
      List localList = paramObject.get();
      if ((localList.size() == paramArrayList1.size()) && (localList.containsAll(paramArrayList1)))
      {
        if (paramArrayList2 == null) {
          i = 0;
        } else {
          i = paramArrayList2.size();
        }
        j = 0;
        while (j < i)
        {
          paramObject.get((View)paramArrayList2.get(j));
          j += 1;
        }
        i = paramArrayList1.size() - 1;
        while (i >= 0)
        {
          paramObject.b((View)paramArrayList1.get(i));
          i -= 1;
        }
      }
    }
  }
  
  public Object b(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    h localH = new h();
    localH.a((l)paramObject);
    return localH;
  }
  
  public Object b(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    h localH = new h();
    if (paramObject1 != null) {
      localH.a((l)paramObject1);
    }
    if (paramObject2 != null) {
      localH.a((l)paramObject2);
    }
    if (paramObject3 != null) {
      localH.a((l)paramObject3);
    }
    return localH;
  }
  
  public void b(Object paramObject, View paramView)
  {
    if (paramObject != null) {
      ((l)paramObject).get(paramView);
    }
  }
  
  public void b(Object paramObject1, Object paramObject2, ArrayList paramArrayList1, Object paramObject3, ArrayList paramArrayList2, Object paramObject4, ArrayList paramArrayList3)
  {
    ((l)paramObject1).a(new d(this, paramObject2, paramArrayList1, paramObject3, paramArrayList2, paramObject4, paramArrayList3));
  }
  
  public void b(Object paramObject, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    paramObject = (h)paramObject;
    if (paramObject != null)
    {
      paramObject.get().clear();
      paramObject.get().addAll(paramArrayList2);
      a(paramObject, paramArrayList1, paramArrayList2);
    }
  }
  
  public void close(Object paramObject, View paramView)
  {
    if (paramView != null)
    {
      paramObject = (l)paramObject;
      Rect localRect = new Rect();
      add(paramView, localRect);
      paramObject.a(new Response(this, localRect));
    }
  }
  
  public void close(Object paramObject, View paramView, ArrayList paramArrayList)
  {
    ((l)paramObject).a(new MethodWriter(this, paramView, paramArrayList));
  }
  
  public boolean read(Object paramObject)
  {
    return paramObject instanceof l;
  }
}
