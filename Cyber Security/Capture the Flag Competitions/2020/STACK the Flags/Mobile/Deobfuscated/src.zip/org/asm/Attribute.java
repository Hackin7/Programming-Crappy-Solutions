package org.asm;

import android.graphics.Matrix;
import android.view.View;

public class Attribute
{
  public Attribute() {}
  
  public abstract void a(View paramView);
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.setLeft(paramInt1);
    paramView.setTop(paramInt2);
    paramView.setRight(paramInt3);
    paramView.setBottom(paramInt4);
  }
  
  public abstract void get(View paramView, Matrix paramMatrix);
  
  public abstract void set(View paramView, Matrix paramMatrix);
  
  public float setValue(View paramView)
  {
    Float localFloat = (Float)paramView.getTag(R.id.save_non_transition_alpha);
    if (localFloat != null) {
      return paramView.getAlpha() / localFloat.floatValue();
    }
    return paramView.getAlpha();
  }
  
  public abstract void setValue(View paramView, float paramFloat);
  
  public abstract void write(View paramView);
}
