package org.asm;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.util.Property;
import android.view.View;
import java.lang.reflect.Field;

public class Log
{
  public static final Attribute a;
  public static boolean dirty;
  public static Field field;
  public static final Property<View, Float> v;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 22) {
      a = new e();
    } else {
      a = new PopupWindowCompatGingerbread();
    }
    v = new MaterialRippleLayout.4(Float.class, "translationAlpha");
    new CircularProgressDrawable.2(Rect.class, "clipBounds");
  }
  
  public static aa a(View paramView)
  {
    return new Segment(paramView);
  }
  
  public static void d(View paramView)
  {
    a.a(paramView);
  }
  
  public static void d(View paramView, Matrix paramMatrix)
  {
    a.get(paramView, paramMatrix);
  }
  
  public static void draw(View paramView, Matrix paramMatrix)
  {
    a.set(paramView, paramMatrix);
  }
  
  public static void e(View paramView)
  {
    a.write(paramView);
  }
  
  public static void put(View paramView, float paramFloat)
  {
    a.setValue(paramView, paramFloat);
  }
  
  public static float set(View paramView)
  {
    return a.setValue(paramView);
  }
  
  public static void set()
  {
    if (!dirty)
    {
      try
      {
        Field localField = View.class.getDeclaredField("mViewFlags");
        field = localField;
        localField.setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
        android.util.Log.i("ViewUtils", "fetchViewFlagsField: ");
      }
      dirty = true;
    }
  }
  
  public static void set(View paramView, int paramInt)
  {
    set();
    Field localField = field;
    if (localField != null) {
      try
      {
        int i = localField.getInt(paramView);
        localField = field;
        localField.setInt(paramView, i & 0xFFFFFFF3 | paramInt);
        return;
      }
      catch (IllegalAccessException paramView) {}
    }
  }
  
  public static void set(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    a.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static Object setText(View paramView)
  {
    return new SwipeDismissListViewTouchListener.PendingDismissData(paramView);
  }
}
