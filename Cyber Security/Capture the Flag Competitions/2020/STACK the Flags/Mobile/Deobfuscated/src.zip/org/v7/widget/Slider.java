package org.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.StaticLayout.Builder;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.core.view.ViewCompat;
import org.v7.R.styleable;

public class Slider
{
  public static ConcurrentHashMap<String, Field> bf = new ConcurrentHashMap();
  public static ConcurrentHashMap<String, Method> h;
  public static final RectF mTempRect = new RectF();
  public boolean a = false;
  public boolean b = false;
  public int[] c = new int[0];
  public final Context context;
  public final a0.c data;
  public final TextView this$0;
  public int type = 0;
  public float value = -1.0F;
  public TextPaint w;
  public float x = -1.0F;
  public float y = -1.0F;
  
  static
  {
    h = new ConcurrentHashMap();
  }
  
  public Slider(TextView paramTextView)
  {
    this$0 = paramTextView;
    context = paramTextView.getContext();
    int i = Build.VERSION.SDK_INT;
    if (i >= 29)
    {
      data = new a0.b();
      return;
    }
    if (i >= 23)
    {
      data = new a0.a();
      return;
    }
    data = new a0.c();
  }
  
  public static Object create(Object paramObject1, String paramString, Object paramObject2)
  {
    int j = 0;
    int i = j;
    try
    {
      localObject = create(paramString);
      i = j;
      paramObject1 = ((Method)localObject).invoke(paramObject1, new Object[0]);
      if (paramObject1 == null) {
        return paramObject1;
      }
    }
    catch (Throwable paramObject1) {}catch (Exception paramObject1)
    {
      j = 1;
      i = j;
      Object localObject = new StringBuilder();
      i = j;
      ((StringBuilder)localObject).append("Failed to invoke TextView#");
      i = j;
      ((StringBuilder)localObject).append(paramString);
      i = j;
      ((StringBuilder)localObject).append("() method");
      i = j;
      Log.w("ACTVAutoSizeHelper", ((StringBuilder)localObject).toString(), paramObject1);
      return paramObject2;
    }
    return paramObject1;
    if (i != 0) {}
    throw paramObject1;
  }
  
  public static Method create(String paramString)
  {
    Object localObject1 = h;
    try
    {
      localObject1 = ((ConcurrentHashMap)localObject1).get(paramString);
      localObject2 = (Method)localObject1;
      localObject1 = localObject2;
      if (localObject2 == null)
      {
        localObject2 = TextView.class.getDeclaredMethod(paramString, new Class[0]);
        localObject1 = localObject2;
        if (localObject2 != null)
        {
          ((Method)localObject2).setAccessible(true);
          localObject1 = h;
          ((ConcurrentHashMap)localObject1).put(paramString, localObject2);
          return localObject2;
        }
      }
    }
    catch (Exception localException)
    {
      Object localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append("Failed to retrieve TextView#");
      ((StringBuilder)localObject2).append(paramString);
      ((StringBuilder)localObject2).append("() method");
      Log.w("ACTVAutoSizeHelper", ((StringBuilder)localObject2).toString(), localException);
      return null;
    }
    return localException;
  }
  
  public final boolean add()
  {
    if ((reset()) && (type == 1))
    {
      if ((!b) || (c.length == 0))
      {
        int j = (int)Math.floor((y - value) / x) + 1;
        int[] arrayOfInt = new int[j];
        int i = 0;
        while (i < j)
        {
          arrayOfInt[i] = Math.round(value + i * x);
          i += 1;
        }
        c = sort(arrayOfInt);
      }
      a = true;
    }
    else
    {
      a = false;
    }
    return a;
  }
  
  public int compareTo()
  {
    return Math.round(y);
  }
  
  public final StaticLayout create(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt)
  {
    float f1 = this$0.getLineSpacingMultiplier();
    float f2 = this$0.getLineSpacingExtra();
    boolean bool = this$0.getIncludeFontPadding();
    return new StaticLayout(paramCharSequence, w, paramInt, paramAlignment, f1, f2, bool);
  }
  
  public StaticLayout create(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2)
  {
    if (Build.VERSION.SDK_INT >= 23) {
      return init(paramCharSequence, paramAlignment, paramInt1, paramInt2);
    }
    return create(paramCharSequence, paramAlignment, paramInt1);
  }
  
  public boolean create()
  {
    return (reset()) && (type != 0);
  }
  
  public final int draw(RectF paramRectF)
  {
    int k = c.length;
    if (k != 0)
    {
      int j = 0;
      int i = 0 + 1;
      k -= 1;
      while (i <= k)
      {
        j = (i + k) / 2;
        if (render(c[j], paramRectF))
        {
          int m = j + 1;
          j = i;
          i = m;
        }
        else
        {
          k = j - 1;
          j = k;
        }
      }
      return c[j];
    }
    throw new IllegalStateException("No available text sizes to choose from.");
  }
  
  public void draw()
  {
    if (!create()) {
      return;
    }
    if (a) {
      if (this$0.getMeasuredHeight() > 0)
      {
        if (this$0.getMeasuredWidth() <= 0) {
          return;
        }
        int i;
        if (data.create(this$0)) {
          i = 1048576;
        } else {
          i = this$0.getMeasuredWidth() - this$0.getTotalPaddingLeft() - this$0.getTotalPaddingRight();
        }
        int j = this$0.getHeight() - this$0.getCompoundPaddingBottom() - this$0.getCompoundPaddingTop();
        if (i <= 0) {
          return;
        }
        if (j <= 0) {
          return;
        }
        RectF localRectF = mTempRect;
        try
        {
          mTempRect.setEmpty();
          mTempRectright = i;
          mTempRectbottom = j;
          float f = draw(mTempRect);
          if (f != this$0.getTextSize()) {
            init(0, f);
          }
        }
        catch (Throwable localThrowable)
        {
          throw localThrowable;
        }
      }
      else
      {
        return;
      }
    }
    a = true;
  }
  
  public void draw(int paramInt)
  {
    if (reset()) {
      if (paramInt != 0)
      {
        Object localObject;
        if (paramInt == 1)
        {
          localObject = context.getResources().getDisplayMetrics();
          set(TypedValue.applyDimension(2, 12.0F, (DisplayMetrics)localObject), TypedValue.applyDimension(2, 112.0F, (DisplayMetrics)localObject), 1.0F);
          if (add()) {
            draw();
          }
        }
        else
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("Unknown auto-size text type: ");
          ((StringBuilder)localObject).append(paramInt);
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
      }
      else
      {
        run();
      }
    }
  }
  
  public void draw(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (reset())
    {
      DisplayMetrics localDisplayMetrics = context.getResources().getDisplayMetrics();
      set(TypedValue.applyDimension(paramInt4, paramInt1, localDisplayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, localDisplayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, localDisplayMetrics));
      if (add()) {
        draw();
      }
    }
  }
  
  public int[] get()
  {
    return c;
  }
  
  public int getValue()
  {
    return Math.round(value);
  }
  
  public final StaticLayout init(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2)
  {
    paramCharSequence = StaticLayout.Builder.obtain(paramCharSequence, 0, paramCharSequence.length(), w, paramInt1);
    paramAlignment = paramCharSequence.setAlignment(paramAlignment).setLineSpacing(this$0.getLineSpacingExtra(), this$0.getLineSpacingMultiplier()).setIncludePad(this$0.getIncludeFontPadding()).setBreakStrategy(this$0.getBreakStrategy()).setHyphenationFrequency(this$0.getHyphenationFrequency());
    if (paramInt2 == -1) {
      paramInt2 = Integer.MAX_VALUE;
    }
    paramAlignment.setMaxLines(paramInt2);
    paramAlignment = data;
    TextView localTextView = this$0;
    try
    {
      paramAlignment.setOnClickListener(paramCharSequence, localTextView);
    }
    catch (ClassCastException paramAlignment)
    {
      Log.w("ACTVAutoSizeHelper", "Failed to obtain TextDirectionHeuristic, auto size may be incorrect");
    }
    return paramCharSequence.build();
  }
  
  public final void init(float paramFloat)
  {
    if (paramFloat != this$0.getPaint().getTextSize())
    {
      this$0.getPaint().setTextSize(paramFloat);
      boolean bool = this$0.isInLayout();
      if (this$0.getLayout() != null)
      {
        a = false;
        try
        {
          Method localMethod = create("nullLayouts");
          if (localMethod != null)
          {
            TextView localTextView = this$0;
            localMethod.invoke(localTextView, new Object[0]);
          }
        }
        catch (Exception localException)
        {
          Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", localException);
        }
        if (!bool) {
          this$0.requestLayout();
        } else {
          this$0.forceLayout();
        }
        this$0.invalidate();
      }
    }
  }
  
  public void init(int paramInt)
  {
    TextPaint localTextPaint = w;
    if (localTextPaint == null) {
      w = new TextPaint();
    } else {
      localTextPaint.reset();
    }
    w.set(this$0.getPaint());
    w.setTextSize(paramInt);
  }
  
  public void init(int paramInt, float paramFloat)
  {
    Object localObject = context;
    if (localObject == null) {
      localObject = Resources.getSystem();
    } else {
      localObject = ((Context)localObject).getResources();
    }
    init(TypedValue.applyDimension(paramInt, paramFloat, ((Resources)localObject).getDisplayMetrics()));
  }
  
  public final void init(TypedArray paramTypedArray)
  {
    int j = paramTypedArray.length();
    int[] arrayOfInt = new int[j];
    if (j > 0)
    {
      int i = 0;
      while (i < j)
      {
        arrayOfInt[i] = paramTypedArray.getDimensionPixelSize(i, -1);
        i += 1;
      }
      c = sort(arrayOfInt);
      init();
    }
  }
  
  public void init(AttributeSet paramAttributeSet, int paramInt)
  {
    float f2 = -1.0F;
    float f3 = -1.0F;
    float f1 = -1.0F;
    TypedArray localTypedArray = context.obtainStyledAttributes(paramAttributeSet, R.styleable.AppCompatTextView, paramInt, 0);
    TextView localTextView = this$0;
    ViewCompat.obtainStyledAttributes(localTextView, localTextView.getContext(), R.styleable.AppCompatTextView, paramAttributeSet, localTypedArray, paramInt, 0);
    if (localTypedArray.hasValue(R.styleable.AppCompatTextView_autoSizeTextType)) {
      type = localTypedArray.getInt(R.styleable.AppCompatTextView_autoSizeTextType, 0);
    }
    if (localTypedArray.hasValue(R.styleable.AppCompatTextView_autoSizeStepGranularity)) {
      f1 = localTypedArray.getDimension(R.styleable.AppCompatTextView_autoSizeStepGranularity, -1.0F);
    }
    if (localTypedArray.hasValue(R.styleable.AppCompatTextView_autoSizeMinTextSize)) {
      f2 = localTypedArray.getDimension(R.styleable.AppCompatTextView_autoSizeMinTextSize, -1.0F);
    }
    if (localTypedArray.hasValue(R.styleable.AppCompatTextView_autoSizeMaxTextSize)) {
      f3 = localTypedArray.getDimension(R.styleable.AppCompatTextView_autoSizeMaxTextSize, -1.0F);
    }
    if (localTypedArray.hasValue(R.styleable.AppCompatTextView_autoSizePresetSizes))
    {
      paramInt = localTypedArray.getResourceId(R.styleable.AppCompatTextView_autoSizePresetSizes, 0);
      if (paramInt > 0)
      {
        paramAttributeSet = localTypedArray.getResources().obtainTypedArray(paramInt);
        init(paramAttributeSet);
        paramAttributeSet.recycle();
      }
    }
    localTypedArray.recycle();
    if (reset())
    {
      if (type == 1)
      {
        if (!b)
        {
          paramAttributeSet = context.getResources().getDisplayMetrics();
          float f4 = f2;
          if (f2 == -1.0F) {
            f4 = TypedValue.applyDimension(2, 12.0F, paramAttributeSet);
          }
          f2 = f3;
          if (f3 == -1.0F) {
            f2 = TypedValue.applyDimension(2, 112.0F, paramAttributeSet);
          }
          f3 = f1;
          if (f1 == -1.0F) {
            f3 = 1.0F;
          }
          set(f4, f2, f3);
        }
        add();
      }
    }
    else {
      type = 0;
    }
  }
  
  public void init(int[] paramArrayOfInt, int paramInt)
  {
    if (reset())
    {
      int j = paramArrayOfInt.length;
      if (j > 0)
      {
        int[] arrayOfInt = new int[j];
        Object localObject;
        if (paramInt == 0)
        {
          localObject = Arrays.copyOf(paramArrayOfInt, j);
        }
        else
        {
          DisplayMetrics localDisplayMetrics = context.getResources().getDisplayMetrics();
          int i = 0;
          for (;;)
          {
            localObject = arrayOfInt;
            if (i >= j) {
              break;
            }
            arrayOfInt[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfInt[i], localDisplayMetrics));
            i += 1;
          }
        }
        c = sort((int[])localObject);
        if (!init())
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("None of the preset sizes is valid: ");
          ((StringBuilder)localObject).append(Arrays.toString(paramArrayOfInt));
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
      }
      else
      {
        b = false;
      }
      if (add()) {
        draw();
      }
    }
  }
  
  public final boolean init()
  {
    int i = c.length;
    boolean bool;
    if (i > 0) {
      bool = true;
    } else {
      bool = false;
    }
    b = bool;
    if (bool)
    {
      type = 1;
      int[] arrayOfInt = c;
      value = arrayOfInt[0];
      y = arrayOfInt[(i - 1)];
      x = -1.0F;
    }
    return b;
  }
  
  public final boolean render(int paramInt, RectF paramRectF)
  {
    CharSequence localCharSequence = this$0.getText();
    Object localObject2 = localCharSequence;
    TransformationMethod localTransformationMethod = this$0.getTransformationMethod();
    Object localObject1 = localObject2;
    if (localTransformationMethod != null)
    {
      localCharSequence = localTransformationMethod.getTransformation(localCharSequence, this$0);
      localObject1 = localObject2;
      if (localCharSequence != null) {
        localObject1 = localCharSequence;
      }
    }
    int i = this$0.getMaxLines();
    init(paramInt);
    localObject2 = create((CharSequence)localObject1, (Layout.Alignment)create(this$0, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(right), i);
    if (i != -1)
    {
      if (((StaticLayout)localObject2).getLineCount() > i) {
        break label160;
      }
      if (((Layout)localObject2).getLineEnd(((StaticLayout)localObject2).getLineCount() - 1) != ((CharSequence)localObject1).length()) {
        return false;
      }
    }
    return ((Layout)localObject2).getHeight() <= bottom;
    label160:
    return false;
  }
  
  public final boolean reset()
  {
    return this$0 instanceof AppCompatEditText ^ true;
  }
  
  public final void run()
  {
    type = 0;
    value = -1.0F;
    y = -1.0F;
    x = -1.0F;
    c = new int[0];
    a = false;
  }
  
  public final void set(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat1 > 0.0F)
    {
      if (paramFloat2 > paramFloat1)
      {
        if (paramFloat3 > 0.0F)
        {
          type = 1;
          value = paramFloat1;
          y = paramFloat2;
          x = paramFloat3;
          b = false;
          return;
        }
        localStringBuilder = new StringBuilder();
        localStringBuilder.append("The auto-size step granularity (");
        localStringBuilder.append(paramFloat3);
        localStringBuilder.append("px) is less or equal to (0px)");
        throw new IllegalArgumentException(localStringBuilder.toString());
      }
      localStringBuilder = new StringBuilder();
      localStringBuilder.append("Maximum auto-size text size (");
      localStringBuilder.append(paramFloat2);
      localStringBuilder.append("px) is less or equal to minimum auto-size text size (");
      localStringBuilder.append(paramFloat1);
      localStringBuilder.append("px)");
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Minimum auto-size text size (");
    localStringBuilder.append(paramFloat1);
    localStringBuilder.append("px) is less or equal to (0px)");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public int setValue()
  {
    return type;
  }
  
  public final int[] sort(int[] paramArrayOfInt)
  {
    int j = paramArrayOfInt.length;
    if (j == 0) {
      return paramArrayOfInt;
    }
    Arrays.sort(paramArrayOfInt);
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    while (i < j)
    {
      int k = paramArrayOfInt[i];
      if ((k > 0) && (Collections.binarySearch(localArrayList, Integer.valueOf(k)) < 0)) {
        localArrayList.add(Integer.valueOf(k));
      }
      i += 1;
    }
    if (j == localArrayList.size()) {
      return paramArrayOfInt;
    }
    j = localArrayList.size();
    paramArrayOfInt = new int[j];
    i = 0;
    while (i < j)
    {
      paramArrayOfInt[i] = ((Integer)localArrayList.get(i)).intValue();
      i += 1;
    }
    return paramArrayOfInt;
  }
  
  public int start()
  {
    return Math.round(x);
  }
}
