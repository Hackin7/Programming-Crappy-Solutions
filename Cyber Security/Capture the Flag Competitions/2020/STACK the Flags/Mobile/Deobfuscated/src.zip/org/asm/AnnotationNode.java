package org.asm;

import android.graphics.Path;

public final class AnnotationNode
  extends AnnotationVisitor
{
  public AnnotationNode() {}
  
  public Path getMarkPath(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    Path localPath = new Path();
    localPath.moveTo(paramFloat1, paramFloat2);
    localPath.lineTo(paramFloat3, paramFloat4);
    return localPath;
  }
}
