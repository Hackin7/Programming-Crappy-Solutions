package org.v7.app;

import android.content.res.Configuration;
import android.os.LocaleList;

public class Event
{
  public static void setLocale(Configuration paramConfiguration1, Configuration paramConfiguration2, Configuration paramConfiguration3)
  {
    paramConfiguration1 = paramConfiguration1.getLocales();
    LocaleList localLocaleList = paramConfiguration2.getLocales();
    if (!paramConfiguration1.equals(localLocaleList))
    {
      paramConfiguration3.setLocales(localLocaleList);
      locale = locale;
    }
  }
}
