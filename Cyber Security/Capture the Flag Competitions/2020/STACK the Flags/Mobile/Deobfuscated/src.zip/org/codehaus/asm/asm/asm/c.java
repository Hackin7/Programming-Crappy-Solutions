package org.codehaus.asm.asm.asm;

import java.util.Iterator;
import java.util.List;

public class c
  extends Label
{
  public int d;
  
  public c(h paramH)
  {
    super(paramH);
    if ((paramH instanceof f))
    {
      g = MathArrays.OrderDirection.DECREASING;
      return;
    }
    g = MathArrays.OrderDirection.a;
  }
  
  public void a(int paramInt)
  {
    if (c) {
      return;
    }
    c = true;
    d = paramInt;
    Iterator localIterator = f.iterator();
    while (localIterator.hasNext())
    {
      l localL = (l)localIterator.next();
      localL.a(localL);
    }
  }
}
