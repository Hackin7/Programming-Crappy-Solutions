package org.data;

import a.e.f;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public abstract class MapCollections<K, V>
{
  public f<K, V>.b mEntrySet;
  public f<K, V>.c mKeySet;
  public f<K, V>.e mValues;
  
  public MapCollections() {}
  
  public static boolean containsAllHelper(Map paramMap, Collection paramCollection)
  {
    paramCollection = paramCollection.iterator();
    while (paramCollection.hasNext()) {
      if (!paramMap.containsKey(paramCollection.next())) {
        return false;
      }
    }
    return true;
  }
  
  public static boolean equalsSetHelper(Set paramSet, Object paramObject)
  {
    if (paramSet == paramObject) {
      return true;
    }
    if ((paramObject instanceof Set))
    {
      paramObject = (Set)paramObject;
      try
      {
        int i = paramSet.size();
        int j = paramObject.size();
        if (i == j)
        {
          boolean bool = paramSet.containsAll(paramObject);
          if (bool) {
            return true;
          }
        }
        return false;
      }
      catch (ClassCastException paramSet)
      {
        return false;
      }
      catch (NullPointerException paramSet) {}
    }
    return false;
  }
  
  public static boolean removeAllHelper(Map paramMap, Collection paramCollection)
  {
    int i = paramMap.size();
    paramCollection = paramCollection.iterator();
    while (paramCollection.hasNext()) {
      paramMap.remove(paramCollection.next());
    }
    return i != paramMap.size();
  }
  
  public static boolean retainAllHelper(Map paramMap, Collection paramCollection)
  {
    int i = paramMap.size();
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext()) {
      if (!paramCollection.contains(localIterator.next())) {
        localIterator.remove();
      }
    }
    return i != paramMap.size();
  }
  
  public abstract void clear();
  
  public abstract int get(Object paramObject);
  
  public abstract Object get(int paramInt1, int paramInt2);
  
  public abstract Map get();
  
  public Set getEntrySet()
  {
    if (mEntrySet == null) {
      mEntrySet = new EntrySet();
    }
    return mEntrySet;
  }
  
  public Set getKeySet()
  {
    if (mKeySet == null) {
      mKeySet = new KeySet();
    }
    return mKeySet;
  }
  
  public Object[] getValue(int paramInt)
  {
    int j = size();
    Object[] arrayOfObject = new Object[j];
    int i = 0;
    while (i < j)
    {
      arrayOfObject[i] = get(i, paramInt);
      i += 1;
    }
    return arrayOfObject;
  }
  
  public Collection getValues()
  {
    if (mValues == null) {
      mValues = new ValuesCollection();
    }
    return mValues;
  }
  
  public abstract int indexOf(Object paramObject);
  
  public abstract Object put(int paramInt, Object paramObject);
  
  public abstract void put(Object paramObject1, Object paramObject2);
  
  public abstract void remove(int paramInt);
  
  public abstract int size();
  
  public Object[] toArray(Object[] paramArrayOfObject, int paramInt)
  {
    int j = size();
    Object[] arrayOfObject = paramArrayOfObject;
    if (paramArrayOfObject.length < j) {
      arrayOfObject = (Object[])Array.newInstance(paramArrayOfObject.getClass().getComponentType(), j);
    }
    int i = 0;
    while (i < j)
    {
      arrayOfObject[i] = get(i, paramInt);
      i += 1;
    }
    if (arrayOfObject.length > j) {
      arrayOfObject[j] = null;
    }
    return arrayOfObject;
  }
  
  public final class EntrySet
    implements Set<Map.Entry<K, V>>
  {
    public EntrySet() {}
    
    public boolean add()
    {
      throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection paramCollection)
    {
      int i = MapCollections.this.size();
      paramCollection = paramCollection.iterator();
      while (paramCollection.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)paramCollection.next();
        put(localEntry.getKey(), localEntry.getValue());
      }
      return i != MapCollections.this.size();
    }
    
    public void clear()
    {
      MapCollections.this.clear();
    }
    
    public boolean contains(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry)) {
        return false;
      }
      paramObject = (Map.Entry)paramObject;
      int i = indexOf(paramObject.getKey());
      if (i < 0) {
        return false;
      }
      return ContainerHelpers.equal(get(i, 1), paramObject.getValue());
    }
    
    public boolean containsAll(Collection paramCollection)
    {
      paramCollection = paramCollection.iterator();
      while (paramCollection.hasNext()) {
        if (!contains(paramCollection.next())) {
          return false;
        }
      }
      return true;
    }
    
    public boolean equals(Object paramObject)
    {
      return MapCollections.equalsSetHelper(this, paramObject);
    }
    
    public int hashCode()
    {
      int j = 0;
      int i = MapCollections.this.size() - 1;
      while (i >= 0)
      {
        Object localObject1 = MapCollections.this;
        int m = 0;
        localObject1 = ((MapCollections)localObject1).get(i, 0);
        Object localObject2 = get(i, 1);
        int k;
        if (localObject1 == null) {
          k = 0;
        } else {
          k = localObject1.hashCode();
        }
        if (localObject2 != null) {
          m = localObject2.hashCode();
        }
        j += (m ^ k);
        i -= 1;
      }
      return j;
    }
    
    public boolean isEmpty()
    {
      return MapCollections.this.size() == 0;
    }
    
    public Iterator iterator()
    {
      return new Attribute(MapCollections.this);
    }
    
    public boolean remove(Object paramObject)
    {
      throw new UnsupportedOperationException();
    }
    
    public boolean removeAll(Collection paramCollection)
    {
      throw new UnsupportedOperationException();
    }
    
    public boolean retainAll(Collection paramCollection)
    {
      throw new UnsupportedOperationException();
    }
    
    public int size()
    {
      return MapCollections.this.size();
    }
    
    public Object[] toArray()
    {
      throw new UnsupportedOperationException();
    }
    
    public Object[] toArray(Object[] paramArrayOfObject)
    {
      throw new UnsupportedOperationException();
    }
  }
  
  public final class KeySet
    implements Set<K>
  {
    public KeySet() {}
    
    public boolean add(Object paramObject)
    {
      throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection paramCollection)
    {
      throw new UnsupportedOperationException();
    }
    
    public void clear()
    {
      MapCollections.this.clear();
    }
    
    public boolean contains(Object paramObject)
    {
      return indexOf(paramObject) >= 0;
    }
    
    public boolean containsAll(Collection paramCollection)
    {
      return MapCollections.containsAllHelper(get(), paramCollection);
    }
    
    public boolean equals(Object paramObject)
    {
      return MapCollections.equalsSetHelper(this, paramObject);
    }
    
    public int hashCode()
    {
      int j = 0;
      int i = MapCollections.this.size() - 1;
      while (i >= 0)
      {
        Object localObject = MapCollections.this;
        int k = 0;
        localObject = ((MapCollections)localObject).get(i, 0);
        if (localObject != null) {
          k = localObject.hashCode();
        }
        j += k;
        i -= 1;
      }
      return j;
    }
    
    public boolean isEmpty()
    {
      return MapCollections.this.size() == 0;
    }
    
    public Iterator iterator()
    {
      return new UnboundedFifoByteBuffer.1(MapCollections.this, 0);
    }
    
    public boolean remove(Object paramObject)
    {
      int i = indexOf(paramObject);
      if (i >= 0)
      {
        remove(i);
        return true;
      }
      return false;
    }
    
    public boolean removeAll(Collection paramCollection)
    {
      return MapCollections.removeAllHelper(get(), paramCollection);
    }
    
    public boolean retainAll(Collection paramCollection)
    {
      return MapCollections.retainAllHelper(get(), paramCollection);
    }
    
    public int size()
    {
      return MapCollections.this.size();
    }
    
    public Object[] toArray()
    {
      return getValue(0);
    }
    
    public Object[] toArray(Object[] paramArrayOfObject)
    {
      return toArray(paramArrayOfObject, 0);
    }
  }
  
  public final class ValuesCollection
    implements Collection<V>
  {
    public ValuesCollection() {}
    
    public boolean add(Object paramObject)
    {
      throw new UnsupportedOperationException();
    }
    
    public boolean addAll(Collection paramCollection)
    {
      throw new UnsupportedOperationException();
    }
    
    public void clear()
    {
      MapCollections.this.clear();
    }
    
    public boolean contains(Object paramObject)
    {
      return get(paramObject) >= 0;
    }
    
    public boolean containsAll(Collection paramCollection)
    {
      paramCollection = paramCollection.iterator();
      while (paramCollection.hasNext()) {
        if (!contains(paramCollection.next())) {
          return false;
        }
      }
      return true;
    }
    
    public boolean isEmpty()
    {
      return MapCollections.this.size() == 0;
    }
    
    public Iterator iterator()
    {
      return new UnboundedFifoByteBuffer.1(MapCollections.this, 1);
    }
    
    public boolean remove(Object paramObject)
    {
      int i = get(paramObject);
      if (i >= 0)
      {
        remove(i);
        return true;
      }
      return false;
    }
    
    public boolean removeAll(Collection paramCollection)
    {
      int j = MapCollections.this.size();
      boolean bool = false;
      int i = 0;
      while (i < j)
      {
        int k = j;
        int m = i;
        if (paramCollection.contains(get(i, 1)))
        {
          remove(i);
          m = i - 1;
          k = j - 1;
          bool = true;
        }
        i = m + 1;
        j = k;
      }
      return bool;
    }
    
    public boolean retainAll(Collection paramCollection)
    {
      int j = MapCollections.this.size();
      boolean bool = false;
      int i = 0;
      while (i < j)
      {
        int k = j;
        int m = i;
        if (!paramCollection.contains(get(i, 1)))
        {
          remove(i);
          m = i - 1;
          k = j - 1;
          bool = true;
        }
        i = m + 1;
        j = k;
      }
      return bool;
    }
    
    public int size()
    {
      return MapCollections.this.size();
    }
    
    public Object[] toArray()
    {
      return getValue(1);
    }
    
    public Object[] toArray(Object[] paramArrayOfObject)
    {
      return toArray(paramArrayOfObject, 1);
    }
  }
}
