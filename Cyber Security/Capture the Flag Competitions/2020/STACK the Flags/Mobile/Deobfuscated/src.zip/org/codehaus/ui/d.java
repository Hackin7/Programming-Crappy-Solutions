package org.codehaus.ui;

import a.f.c.d.a;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class d
{
  public SparseArray<a.f.c.e> a = new SparseArray();
  public SparseArray<d.a> d = new SparseArray();
  
  public d(Context paramContext, ConstraintLayout paramConstraintLayout, int paramInt)
  {
    a(paramContext, paramInt);
  }
  
  public final void a(Context paramContext, int paramInt)
  {
    XmlResourceParser localXmlResourceParser = paramContext.getResources().getXml(paramInt);
    Object localObject1 = null;
    try
    {
      for (paramInt = localXmlResourceParser.getEventType(); paramInt != 1; paramInt = localXmlResourceParser.next()) {
        if (paramInt != 0)
        {
          if (paramInt != 2)
          {
            if (paramInt != 3) {}
          }
          else
          {
            Object localObject3 = localXmlResourceParser.getName();
            paramInt = -1;
            int i = ((String)localObject3).hashCode();
            switch (i)
            {
            default: 
              break;
            }
            for (;;)
            {
              break;
              boolean bool = ((String)localObject3).equals("Variant");
              if (bool)
              {
                paramInt = 3;
                break;
                bool = ((String)localObject3).equals("layoutDescription");
                if (bool)
                {
                  paramInt = 0;
                  break;
                  bool = ((String)localObject3).equals("StateSet");
                  if (bool)
                  {
                    paramInt = 1;
                    break;
                    bool = ((String)localObject3).equals("State");
                    if (bool)
                    {
                      paramInt = 2;
                      break;
                      bool = ((String)localObject3).equals("ConstraintSet");
                      if (bool) {
                        paramInt = 4;
                      }
                    }
                  }
                }
              }
            }
            Object localObject2 = localObject1;
            if (paramInt != 0) {
              if (paramInt != 1)
              {
                if (paramInt != 2)
                {
                  if (paramInt != 3)
                  {
                    if (paramInt != 4)
                    {
                      localObject2 = new StringBuilder();
                      ((StringBuilder)localObject2).append("unknown tag ");
                      ((StringBuilder)localObject2).append((String)localObject3);
                      Log.v("ConstraintLayoutStates", ((StringBuilder)localObject2).toString());
                      localObject2 = localObject1;
                    }
                    else
                    {
                      a(paramContext, localXmlResourceParser);
                      localObject2 = localObject1;
                    }
                  }
                  else
                  {
                    localObject3 = new e(paramContext, localXmlResourceParser);
                    localObject2 = localObject1;
                    if (localObject1 != null)
                    {
                      ((c)localObject1).a((e)localObject3);
                      localObject2 = localObject1;
                    }
                  }
                }
                else
                {
                  localObject1 = new c(paramContext, localXmlResourceParser);
                  localObject2 = localObject1;
                  localObject3 = d;
                  paramInt = i;
                  ((SparseArray)localObject3).put(paramInt, localObject1);
                }
              }
              else {
                localObject2 = localObject1;
              }
            }
            localObject1 = localObject2;
          }
        }
        else {
          localXmlResourceParser.getName();
        }
      }
      return;
    }
    catch (IOException paramContext)
    {
      paramContext.printStackTrace();
      return;
    }
    catch (XmlPullParserException paramContext)
    {
      paramContext.printStackTrace();
    }
  }
  
  public final void a(Context paramContext, XmlPullParser paramXmlPullParser)
  {
    Item localItem = new Item();
    int j = paramXmlPullParser.getAttributeCount();
    int i = 0;
    while (i < j)
    {
      if ("id".equals(paramXmlPullParser.getAttributeName(i)))
      {
        String str1 = paramXmlPullParser.getAttributeValue(i);
        i = -1;
        if (str1.contains("/"))
        {
          String str2 = str1.substring(str1.indexOf('/') + 1);
          i = paramContext.getResources().getIdentifier(str2, "id", paramContext.getPackageName());
        }
        j = i;
        if (i == -1) {
          if (str1.length() > 1)
          {
            j = Integer.parseInt(str1.substring(1));
          }
          else
          {
            Log.e("ConstraintLayoutStates", "error in parsing id");
            j = i;
          }
        }
        localItem.a(paramContext, paramXmlPullParser);
        a.put(j, localItem);
        return;
      }
      i += 1;
    }
  }
  
  public void c(Body paramBody) {}
}
