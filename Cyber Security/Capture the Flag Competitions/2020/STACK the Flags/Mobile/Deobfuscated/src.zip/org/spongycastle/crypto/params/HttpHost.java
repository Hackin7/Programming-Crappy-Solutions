package org.spongycastle.crypto.params;

import a.c.a.b.b.c;
import a.c.a.b.b.f;
import java.util.Iterator;
import java.util.Map.Entry;

public abstract class HttpHost<K, V>
  implements Iterator<Map.Entry<K, V>>, b.f<K, V>
{
  public b.c<K, V> host;
  public b.c<K, V> port;
  
  public HttpHost(Attribute paramAttribute1, Attribute paramAttribute2)
  {
    host = paramAttribute2;
    port = paramAttribute1;
  }
  
  public abstract Attribute a(Attribute paramAttribute);
  
  public abstract Attribute equals(Attribute paramAttribute);
  
  public final Attribute getPort()
  {
    Attribute localAttribute1 = port;
    Attribute localAttribute2 = host;
    if ((localAttribute1 != localAttribute2) && (localAttribute2 != null)) {
      return a(localAttribute1);
    }
    return null;
  }
  
  public boolean hasNext()
  {
    return port != null;
  }
  
  public Map.Entry init()
  {
    Attribute localAttribute = port;
    port = getPort();
    return localAttribute;
  }
  
  public void init(Attribute paramAttribute)
  {
    if ((host == paramAttribute) && (paramAttribute == port))
    {
      port = null;
      host = null;
    }
    Attribute localAttribute = host;
    if (localAttribute == paramAttribute) {
      host = equals(localAttribute);
    }
    if (port == paramAttribute) {
      port = getPort();
    }
  }
}
