package org.v7.internal.util;

import a.b.l.a.a.a;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import java.util.WeakHashMap;
import org.core.fonts.ContextCompat;
import org.core.fonts.data.Type;
import org.v7.widget.AppCompatDrawableManager;

@SuppressLint({"RestrictedAPI"})
public final class Resources
{
  public static final ThreadLocal<TypedValue> TL_TYPED_VALUE = new ThreadLocal();
  public static final WeakHashMap<Context, SparseArray<a.a>> c = new WeakHashMap(0);
  public static final Object d = new Object();
  
  public static ColorStateList a(Context paramContext, int paramInt)
  {
    Object localObject = d;
    try
    {
      SparseArray localSparseArray = (SparseArray)c.get(paramContext);
      if ((localSparseArray != null) && (localSparseArray.size() > 0))
      {
        e localE = (e)localSparseArray.get(paramInt);
        if (localE != null)
        {
          if (d.equals(paramContext.getResources().getConfiguration()))
          {
            paramContext = c;
            return paramContext;
          }
          localSparseArray.remove(paramInt);
        }
      }
      return null;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public static void add(Context paramContext, int paramInt, ColorStateList paramColorStateList)
  {
    Object localObject = d;
    try
    {
      SparseArray localSparseArray2 = (SparseArray)c.get(paramContext);
      SparseArray localSparseArray1 = localSparseArray2;
      if (localSparseArray2 == null)
      {
        localSparseArray2 = new SparseArray();
        localSparseArray1 = localSparseArray2;
        c.put(paramContext, localSparseArray2);
      }
      localSparseArray1.append(paramInt, new e(paramColorStateList, paramContext.getResources().getConfiguration()));
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public static boolean add(Context paramContext, int paramInt)
  {
    paramContext = paramContext.getResources();
    TypedValue localTypedValue = getTypedValue();
    paramContext.getValue(paramInt, localTypedValue, true);
    paramInt = type;
    return (paramInt >= 28) && (paramInt <= 31);
  }
  
  public static ColorStateList create(Context paramContext, int paramInt)
  {
    if (add(paramContext, paramInt)) {
      return null;
    }
    android.content.res.Resources localResources = paramContext.getResources();
    XmlResourceParser localXmlResourceParser = localResources.getXml(paramInt);
    try
    {
      paramContext = Type.create(localResources, localXmlResourceParser, paramContext.getTheme());
      return paramContext;
    }
    catch (Exception paramContext)
    {
      Log.e("AppCompatResources", "Failed to inflate ColorStateList, leaving it to the framework", paramContext);
    }
    return null;
  }
  
  public static Drawable getDrawable(Context paramContext, int paramInt)
  {
    return AppCompatDrawableManager.get().getDrawable(paramContext, paramInt);
  }
  
  public static TypedValue getTypedValue()
  {
    TypedValue localTypedValue2 = (TypedValue)TL_TYPED_VALUE.get();
    TypedValue localTypedValue1 = localTypedValue2;
    if (localTypedValue2 == null)
    {
      localTypedValue1 = new TypedValue();
      TL_TYPED_VALUE.set(localTypedValue1);
    }
    return localTypedValue1;
  }
  
  public static ColorStateList onCreateView(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23) {
      return paramContext.getColorStateList(paramInt);
    }
    ColorStateList localColorStateList = a(paramContext, paramInt);
    if (localColorStateList != null) {
      return localColorStateList;
    }
    localColorStateList = create(paramContext, paramInt);
    if (localColorStateList != null)
    {
      add(paramContext, paramInt, localColorStateList);
      return localColorStateList;
    }
    return ContextCompat.getColorStateList(paramContext, paramInt);
  }
}
