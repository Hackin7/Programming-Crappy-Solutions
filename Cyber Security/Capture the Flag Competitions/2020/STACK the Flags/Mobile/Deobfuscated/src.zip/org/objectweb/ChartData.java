package org.objectweb;

public final class ChartData
{
  public static final int compat_button_inset_horizontal_material = 2131099729;
  public static final int compat_button_inset_vertical_material = 2131099730;
  public static final int compat_button_padding_horizontal_material = 2131099731;
  public static final int compat_button_padding_vertical_material = 2131099732;
  public static final int compat_control_corner_material = 2131099733;
  public static final int compat_notification_large_icon_max_height = 2131099734;
  public static final int compat_notification_large_icon_max_width = 2131099735;
  public static final int fastscroll_default_thickness = 2131099782;
  public static final int fastscroll_margin = 2131099783;
  public static final int fastscroll_minimum_range = 2131099784;
  public static final int item_touch_helper_max_drag_scroll_per_frame = 2131099792;
  public static final int item_touch_helper_swipe_escape_max_velocity = 2131099793;
  public static final int item_touch_helper_swipe_escape_velocity = 2131099794;
  public static final int notification_action_icon_size = 2131099843;
  public static final int notification_action_text_size = 2131099844;
  public static final int notification_big_circle_margin = 2131099845;
  public static final int notification_content_margin_start = 2131099846;
  public static final int notification_large_icon_height = 2131099847;
  public static final int notification_large_icon_width = 2131099848;
  public static final int notification_main_column_padding_top = 2131099849;
  public static final int notification_media_narrow_margin = 2131099850;
  public static final int notification_right_icon_size = 2131099851;
  public static final int notification_right_side_padding_top = 2131099852;
  public static final int notification_small_icon_background_padding = 2131099853;
  public static final int notification_small_icon_size_as_large = 2131099854;
  public static final int notification_subtext_size = 2131099855;
  public static final int notification_top_pad = 2131099856;
  public static final int notification_top_pad_large_text = 2131099857;
}
