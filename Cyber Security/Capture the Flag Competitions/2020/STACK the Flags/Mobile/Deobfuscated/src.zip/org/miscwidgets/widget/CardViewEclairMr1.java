package org.miscwidgets.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import androidx.cardview.widget.CardView.a;

public class CardViewEclairMr1
  implements CardViewImpl
{
  public CardViewEclairMr1() {}
  
  public float getElevation(CardViewDelegate paramCardViewDelegate)
  {
    return ((CardView.a)paramCardViewDelegate).getViewGroup().getElevation();
  }
  
  public float getMaxElevation(CardViewDelegate paramCardViewDelegate)
  {
    return getShadowBackground(paramCardViewDelegate).getPadding();
  }
  
  public float getMinHeight(CardViewDelegate paramCardViewDelegate)
  {
    return getRadius(paramCardViewDelegate) * 2.0F;
  }
  
  public float getMinWidth(CardViewDelegate paramCardViewDelegate)
  {
    return getRadius(paramCardViewDelegate) * 2.0F;
  }
  
  public float getRadius(CardViewDelegate paramCardViewDelegate)
  {
    return getShadowBackground(paramCardViewDelegate).getRadius();
  }
  
  public final RoundRectDrawable getShadowBackground(CardViewDelegate paramCardViewDelegate)
  {
    return (RoundRectDrawable)((CardView.a)paramCardViewDelegate).getBackground();
  }
  
  public void initStatic() {}
  
  public void initialize(CardViewDelegate paramCardViewDelegate, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3)
  {
    paramContext = new RoundRectDrawable(paramColorStateList, paramFloat1);
    ((CardView.a)paramCardViewDelegate).setBackgroundDrawable(paramContext);
    paramContext = ((CardView.a)paramCardViewDelegate).getViewGroup();
    paramContext.setClipToOutline(true);
    paramContext.setElevation(paramFloat2);
    setMaxElevation(paramCardViewDelegate, paramFloat3);
  }
  
  public void onCompatPaddingChanged(CardViewDelegate paramCardViewDelegate)
  {
    setMaxElevation(paramCardViewDelegate, getMaxElevation(paramCardViewDelegate));
  }
  
  public void onPreventCornerOverlapChanged(CardViewDelegate paramCardViewDelegate)
  {
    setMaxElevation(paramCardViewDelegate, getMaxElevation(paramCardViewDelegate));
  }
  
  public ColorStateList setBackgroundColor(CardViewDelegate paramCardViewDelegate)
  {
    return getShadowBackground(paramCardViewDelegate).setColor();
  }
  
  public void setBackgroundColor(CardViewDelegate paramCardViewDelegate, ColorStateList paramColorStateList)
  {
    getShadowBackground(paramCardViewDelegate).setColor(paramColorStateList);
  }
  
  public void setElevation(CardViewDelegate paramCardViewDelegate, float paramFloat)
  {
    ((CardView.a)paramCardViewDelegate).getViewGroup().setElevation(paramFloat);
  }
  
  public void setMaxElevation(CardViewDelegate paramCardViewDelegate, float paramFloat)
  {
    getShadowBackground(paramCardViewDelegate).setPadding(paramFloat, ((CardView.a)paramCardViewDelegate).getUseCompatPadding(), ((CardView.a)paramCardViewDelegate).getPreventCornerOverlap());
    updatePadding(paramCardViewDelegate);
  }
  
  public void setRadius(CardViewDelegate paramCardViewDelegate, float paramFloat)
  {
    getShadowBackground(paramCardViewDelegate).setRadius(paramFloat);
  }
  
  public void updatePadding(CardViewDelegate paramCardViewDelegate)
  {
    if (!((CardView.a)paramCardViewDelegate).getUseCompatPadding())
    {
      ((CardView.a)paramCardViewDelegate).setShadowPadding(0, 0, 0, 0);
      return;
    }
    float f1 = getMaxElevation(paramCardViewDelegate);
    float f2 = getRadius(paramCardViewDelegate);
    int i = (int)Math.ceil(RoundRectDrawableWithShadow.calculateHorizontalPadding(f1, f2, ((CardView.a)paramCardViewDelegate).getPreventCornerOverlap()));
    int j = (int)Math.ceil(RoundRectDrawableWithShadow.calculateVerticalPadding(f1, f2, ((CardView.a)paramCardViewDelegate).getPreventCornerOverlap()));
    ((CardView.a)paramCardViewDelegate).setShadowPadding(i, j, i, j);
  }
}
