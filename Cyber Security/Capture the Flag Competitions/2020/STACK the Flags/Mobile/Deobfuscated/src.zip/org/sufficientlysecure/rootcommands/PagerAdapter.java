package org.sufficientlysecure.rootcommands;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.database.Observable;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

public abstract class PagerAdapter
{
  public static final int POSITION_NONE = -2;
  public static final int POSITION_UNCHANGED = -1;
  public final DataSetObservable mObservable = new DataSetObservable();
  public DataSetObserver mViewPagerObserver;
  
  public PagerAdapter() {}
  
  public void destroyItem(View paramView, int paramInt, Object paramObject)
  {
    throw new UnsupportedOperationException("Required method destroyItem was not overridden");
  }
  
  public abstract void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject);
  
  public void finishUpdate(View paramView) {}
  
  public abstract void finishUpdate(ViewGroup paramViewGroup);
  
  public abstract int getCount();
  
  public int getItemPosition(Object paramObject)
  {
    return -1;
  }
  
  public CharSequence getPageTitle(int paramInt)
  {
    return null;
  }
  
  public float getPageWidth(int paramInt)
  {
    return 1.0F;
  }
  
  public Object instantiateItem(View paramView, int paramInt)
  {
    throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
  }
  
  public abstract Object instantiateItem(ViewGroup paramViewGroup, int paramInt);
  
  public abstract boolean isViewFromObject(View paramView, Object paramObject);
  
  public void notifyDataSetChanged()
  {
    try
    {
      if (mViewPagerObserver != null) {
        mViewPagerObserver.onChanged();
      }
      mObservable.notifyChanged();
      return;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void registerDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    mObservable.registerObserver(paramDataSetObserver);
  }
  
  public abstract void restoreState(Parcelable paramParcelable, ClassLoader paramClassLoader);
  
  public abstract Parcelable saveState();
  
  public void setPrimaryItem(View paramView, int paramInt, Object paramObject) {}
  
  public abstract void setPrimaryItem(ViewGroup paramViewGroup, int paramInt, Object paramObject);
  
  public void setViewPagerObserver(DataSetObserver paramDataSetObserver)
  {
    try
    {
      mViewPagerObserver = paramDataSetObserver;
      return;
    }
    catch (Throwable paramDataSetObserver)
    {
      throw paramDataSetObserver;
    }
  }
  
  public void startUpdate(View paramView) {}
  
  public abstract void startUpdate(ViewGroup paramViewGroup);
  
  public void unregisterDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    mObservable.unregisterObserver(paramDataSetObserver);
  }
}
