package org.codehaus.asm;

public abstract interface d
{
  public abstract Label a(ClassWriter paramClassWriter, boolean[] paramArrayOfBoolean);
  
  public abstract void clear();
  
  public abstract void d(Label paramLabel);
  
  public abstract boolean isEmpty();
}
