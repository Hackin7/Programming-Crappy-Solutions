package org.util;

import a.m.d.a;

public enum Scope
{
  static
  {
    ON_RESUME = new Scope("ON_RESUME", 2);
    ON_PAUSE = new Scope("ON_PAUSE", 3);
    ON_STOP = new Scope("ON_STOP", 4);
    ON_DESTROY = new Scope("ON_DESTROY", 5);
    Scope localScope = new Scope("ON_ANY", 6);
    ON_ANY = localScope;
    $VALUES = new Scope[] { ON_CREATE, ON_START, ON_RESUME, ON_PAUSE, ON_STOP, ON_DESTROY, localScope };
  }
}
