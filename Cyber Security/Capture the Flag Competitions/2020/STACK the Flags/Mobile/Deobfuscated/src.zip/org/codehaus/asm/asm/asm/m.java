package org.codehaus.asm.asm.asm;

import a.f.b.i.m.p;
import java.util.ArrayList;
import java.util.Iterator;
import org.codehaus.asm.asm.MethodWriter;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.f;

public class m
  extends h
{
  public ArrayList<p> a = new ArrayList();
  public int d;
  
  public m(f paramF, int paramInt)
  {
    super(paramF);
    e = paramInt;
    b();
  }
  
  public void a()
  {
    Object localObject1 = a.iterator();
    while (((Iterator)localObject1).hasNext()) {
      ((h)((Iterator)localObject1).next()).a();
    }
    int i = a.size();
    if (i < 1) {
      return;
    }
    Object localObject2 = a.get(0)).b;
    localObject1 = a.get(i - 1)).b;
    Label localLabel;
    if (e == 0)
    {
      localObject2 = b;
      localObject1 = i;
      localLabel = a((org.codehaus.asm.asm.Label)localObject2, 0);
      i = ((org.codehaus.asm.asm.Label)localObject2).b();
      localObject2 = read();
      if (localObject2 != null) {
        i = b.b();
      }
      if (localLabel != null) {
        a(a, localLabel, i);
      }
      localObject2 = a((org.codehaus.asm.asm.Label)localObject1, 0);
      i = ((org.codehaus.asm.asm.Label)localObject1).b();
      localObject1 = write();
      if (localObject1 != null) {
        i = i.b();
      }
      if (localObject2 != null) {
        a(c, (Label)localObject2, -i);
      }
    }
    else
    {
      localObject2 = a;
      localObject1 = g;
      localLabel = a((org.codehaus.asm.asm.Label)localObject2, 1);
      i = ((org.codehaus.asm.asm.Label)localObject2).b();
      localObject2 = read();
      if (localObject2 != null) {
        i = a.b();
      }
      if (localLabel != null) {
        a(a, localLabel, i);
      }
      localObject2 = a((org.codehaus.asm.asm.Label)localObject1, 1);
      i = ((org.codehaus.asm.asm.Label)localObject1).b();
      localObject1 = write();
      if (localObject1 != null) {
        i = g.b();
      }
      if (localObject2 != null) {
        a(c, (Label)localObject2, -i);
      }
    }
    a.k = this;
    c.k = this;
  }
  
  public void a(l paramL)
  {
    if (a.c)
    {
      if (!c.c) {
        return;
      }
      paramL = b.l();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (paramL != null)
      {
        bool1 = bool2;
        if ((paramL instanceof MethodWriter)) {
          bool1 = ((MethodWriter)paramL).visitParameterAnnotation();
        }
      }
      int i10 = c.d - a.d;
      int i9 = a.size();
      int j = -1;
      int i = 0;
      for (;;)
      {
        i4 = j;
        if (i >= i9) {
          break label139;
        }
        if (a.get(i)).b.length() != 8) {
          break;
        }
        i += 1;
      }
      int i4 = i;
      label139:
      j = -1;
      i = i9 - 1;
      for (;;)
      {
        i5 = j;
        if (i < 0) {
          break label193;
        }
        if (a.get(i)).b.length() != 8) {
          break;
        }
        i -= 1;
      }
      int i5 = i;
      label193:
      int i1 = 0;
      int i6;
      int n;
      float f2;
      float f1;
      int m;
      int k;
      int i2;
      int i7;
      int i3;
      for (;;)
      {
        i6 = 0;
        n = 0;
        f2 = 0.0F;
        f1 = 0.0F;
        m = 0;
        i = 0;
        k = 0;
        j = 0;
        if (i1 >= 2) {
          break;
        }
        i2 = 0;
        while (i2 < i9)
        {
          paramL = (h)a.get(i2);
          if (b.length() == 8)
          {
            f2 = f1;
          }
          else
          {
            i6 = n + 1;
            k = j;
            if (i2 > 0)
            {
              k = j;
              if (i2 >= i4) {
                k = j + a.j;
              }
            }
            i7 = d.d;
            if (p != XLayoutStyle.a) {
              n = 1;
            } else {
              n = 0;
            }
            if (n != 0)
            {
              if ((e == 0) && (!b.f.d.c)) {
                return;
              }
              j = n;
              m = i;
              i3 = i7;
              if (e == 1)
              {
                j = n;
                m = i;
                i3 = i7;
                if (b.e.d.c) {}
              }
            }
            else if ((g == 1) && (i1 == 0))
            {
              j = 1;
              i3 = d.d;
              m = i + 1;
            }
            else
            {
              j = n;
              m = i;
              i3 = i7;
              if (d.c)
              {
                j = 1;
                m = i;
                i3 = i7;
              }
            }
            if (j == 0)
            {
              m += 1;
              float f3 = b.A[e];
              f2 = f1;
              if (f3 >= 0.0F) {
                f2 = f1 + f3;
              }
              f1 = f2;
            }
            else
            {
              k += i3;
            }
            j = k;
            i = m;
            f2 = f1;
            n = i6;
            if (i2 < i9 - 1)
            {
              j = k;
              i = m;
              f2 = f1;
              n = i6;
              if (i2 < i5)
              {
                j = k + -c.j;
                n = i6;
                f2 = f1;
                i = m;
              }
            }
          }
          i2 += 1;
          f1 = f2;
        }
        k = j;
        m = i;
        f2 = f1;
        i6 = n;
        if (j < i10) {
          break;
        }
        if (i == 0)
        {
          k = j;
          m = i;
          f2 = f1;
          i6 = n;
          break;
        }
        i1 += 1;
      }
      i = a.d;
      if (bool1) {
        i = c.d;
      }
      j = i;
      if (k > i10) {
        if (bool1) {
          j = i + (int)((k - i10) / 2.0F + 0.5F);
        } else {
          j = i - (int)((k - i10) / 2.0F + 0.5F);
        }
      }
      Object localObject;
      if (m > 0)
      {
        int i8 = (int)((i10 - k) / m + 0.5F);
        n = 0;
        i7 = 0;
        while (i7 < i9)
        {
          paramL = (h)a.get(i7);
          if (b.length() == 8)
          {
            i1 = n;
          }
          else
          {
            i1 = n;
            if (p == XLayoutStyle.a)
            {
              i1 = n;
              if (!d.c)
              {
                i = i8;
                if (f2 > 0.0F)
                {
                  f1 = b.A[e];
                  i = (int)((i10 - k) * f1 / f2 + 0.5F);
                }
                if (e == 0)
                {
                  localObject = b;
                  i3 = o;
                  i2 = l;
                  if (g == 1) {
                    i1 = Math.min(i, d.d);
                  } else {
                    i1 = i;
                  }
                  i2 = Math.max(i2, i1);
                  i1 = i2;
                  if (i3 > 0) {
                    i1 = Math.min(i3, i2);
                  }
                  i3 = n;
                  i2 = i;
                  if (i1 != i)
                  {
                    i3 = n + 1;
                    i2 = i1;
                  }
                  i1 = i3;
                  i3 = i2;
                }
                else
                {
                  localObject = b;
                  i3 = p;
                  i2 = m;
                  i1 = i;
                  if (g == 1) {
                    i1 = Math.min(i, d.d);
                  }
                  i1 = Math.max(i2, i1);
                  i2 = i1;
                  if (i3 > 0) {
                    i2 = Math.min(i3, i1);
                  }
                  i1 = n;
                  i3 = i;
                  if (i2 != i)
                  {
                    i1 = n + 1;
                    i3 = i2;
                  }
                }
                d.a(i3);
              }
            }
          }
          i7 += 1;
          n = i1;
        }
        i = k;
        k = m;
        if (n > 0)
        {
          i1 = m - n;
          i = 0;
          k = 0;
          while (k < i9)
          {
            paramL = (h)a.get(k);
            if (b.length() != 8)
            {
              m = i;
              if (k > 0)
              {
                m = i;
                if (k >= i4) {
                  m = i + a.j;
                }
              }
              m += d.d;
              i = m;
              if (k < i9 - 1)
              {
                i = m;
                if (k < i5) {
                  i = m + -c.j;
                }
              }
            }
            k += 1;
          }
          k = i1;
        }
        if ((d == 2) && (n == 0)) {
          d = 0;
        }
        m = i;
        n = k;
      }
      else
      {
        n = m;
        m = k;
      }
      if (m > i10) {
        d = 2;
      }
      if ((i6 > 0) && (n == 0) && (i4 == i5)) {
        d = 2;
      }
      i = d;
      if (i == 1)
      {
        i = 0;
        if (i6 > 1) {
          i = (i10 - m) / (i6 - 1);
        } else if (i6 == 1) {
          i = (i10 - m) / 2;
        }
        if (n > 0) {
          i = 0;
        }
        n = 0;
        m = i;
        k = j;
        j = n;
        while (j < i9)
        {
          i = j;
          if (bool1) {
            i = i9 - (j + 1);
          }
          paramL = (h)a.get(i);
          if (b.length() == 8)
          {
            a.a(k);
            c.a(k);
            i = k;
          }
          else
          {
            i = k;
            if (j > 0) {
              if (bool1) {
                i = k - m;
              } else {
                i = k + m;
              }
            }
            k = i;
            if (j > 0)
            {
              k = i;
              if (j >= i4) {
                if (bool1) {
                  k = i - a.j;
                } else {
                  k = i + a.j;
                }
              }
            }
            if (bool1) {
              c.a(k);
            } else {
              a.a(k);
            }
            localObject = d;
            n = d;
            i = n;
            if (p == XLayoutStyle.a)
            {
              i = n;
              if (g == 1) {
                i = d;
              }
            }
            if (bool1) {
              k -= i;
            } else {
              k += i;
            }
            if (bool1) {
              a.a(k);
            } else {
              c.a(k);
            }
            f = true;
            i = k;
            if (j < i9 - 1)
            {
              i = k;
              if (j < i5) {
                if (bool1) {
                  i = k - -c.j;
                } else {
                  i = k + -c.j;
                }
              }
            }
          }
          j += 1;
          k = i;
        }
        return;
      }
      if (i == 0)
      {
        m = (i10 - m) / (i6 + 1);
        if (n > 0) {
          m = 0;
        }
        k = 0;
        i = j;
        j = k;
        while (j < i9)
        {
          k = j;
          if (bool1) {
            k = i9 - (j + 1);
          }
          paramL = (h)a.get(k);
          if (b.length() == 8)
          {
            a.a(i);
            c.a(i);
          }
          else
          {
            if (bool1) {
              k = i - m;
            } else {
              k = i + m;
            }
            i = k;
            if (j > 0)
            {
              i = k;
              if (j >= i4) {
                if (bool1) {
                  i = k - a.j;
                } else {
                  i = k + a.j;
                }
              }
            }
            if (bool1) {
              c.a(i);
            } else {
              a.a(i);
            }
            localObject = d;
            n = d;
            k = n;
            if (p == XLayoutStyle.a)
            {
              k = n;
              if (g == 1) {
                k = Math.min(n, d);
              }
            }
            if (bool1) {
              k = i - k;
            } else {
              k = i + k;
            }
            if (bool1) {
              a.a(k);
            } else {
              c.a(k);
            }
            i = k;
            if (j < i9 - 1)
            {
              i = k;
              if (j < i5) {
                if (bool1) {
                  i = k - -c.j;
                } else {
                  i = k + -c.j;
                }
              }
            }
          }
          j += 1;
        }
        return;
      }
      if (i == 2)
      {
        if (e == 0) {
          f1 = b.width();
        } else {
          f1 = b.height();
        }
        f2 = f1;
        if (bool1) {
          f2 = 1.0F - f1;
        }
        i = (int)((i10 - m) * f2 + 0.5F);
        if ((i < 0) || (n > 0)) {
          i = 0;
        }
        if (bool1) {
          i = j - i;
        } else {
          i = j + i;
        }
        j = 0;
        while (j < i9)
        {
          k = j;
          if (bool1) {
            k = i9 - (j + 1);
          }
          paramL = (h)a.get(k);
          if (b.length() == 8)
          {
            a.a(i);
            c.a(i);
          }
          else
          {
            k = i;
            if (j > 0)
            {
              k = i;
              if (j >= i4) {
                if (bool1) {
                  k = i - a.j;
                } else {
                  k = i + a.j;
                }
              }
            }
            if (bool1) {
              c.a(k);
            } else {
              a.a(k);
            }
            localObject = d;
            m = d;
            i = m;
            if (p == XLayoutStyle.a)
            {
              i = m;
              if (g == 1) {
                i = d;
              }
            }
            if (bool1) {
              k -= i;
            } else {
              k += i;
            }
            if (bool1) {
              a.a(k);
            } else {
              c.a(k);
            }
            i = k;
            if (j < i9 - 1)
            {
              i = k;
              if (j < i5) {
                if (bool1) {
                  i = k - -c.j;
                } else {
                  i = k + -c.j;
                }
              }
            }
          }
          j += 1;
        }
      }
    }
  }
  
  public final void b()
  {
    Object localObject2 = b;
    for (Object localObject1 = ((f)localObject2).e(e); localObject1 != null; localObject1 = ((f)localObject1).e(e)) {
      localObject2 = localObject1;
    }
    b = ((f)localObject2);
    a.add(((f)localObject2).getItem(e));
    for (localObject1 = ((f)localObject2).f(e); localObject1 != null; localObject1 = ((f)localObject1).f(e)) {
      a.add(((f)localObject1).getItem(e));
    }
    localObject1 = a.iterator();
    int i;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (h)((Iterator)localObject1).next();
      i = e;
      if (i == 0) {
        b.length = this;
      } else if (i == 1) {
        b.next = this;
      }
    }
    if ((e == 0) && (((MethodWriter)b.l()).visitParameterAnnotation())) {
      i = 1;
    } else {
      i = 0;
    }
    if ((i != 0) && (a.size() > 1))
    {
      localObject1 = a;
      b = getsize1b;
    }
    if (e == 0) {
      i = b.indexOf();
    } else {
      i = b.show();
    }
    d = i;
  }
  
  public long c()
  {
    int j = a.size();
    long l = 0L;
    int i = 0;
    while (i < j)
    {
      h localH = (h)a.get(i);
      l = l + a.j + localH.c() + c.j;
      i += 1;
    }
    return l;
  }
  
  public void d()
  {
    int i = 0;
    while (i < a.size())
    {
      ((h)a.get(i)).d();
      i += 1;
    }
  }
  
  public void e()
  {
    q = null;
    Iterator localIterator = a.iterator();
    while (localIterator.hasNext()) {
      ((h)localIterator.next()).e();
    }
  }
  
  public boolean k()
  {
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      if (!((h)a.get(i)).k()) {
        return false;
      }
      i += 1;
    }
    return true;
  }
  
  public final f read()
  {
    int i = 0;
    while (i < a.size())
    {
      h localH = (h)a.get(i);
      if (b.length() != 8) {
        return b;
      }
      i += 1;
    }
    return null;
  }
  
  public String toString()
  {
    Object localObject1 = new StringBuilder();
    ((StringBuilder)localObject1).append("ChainRun ");
    if (e == 0) {
      str = "horizontal : ";
    } else {
      str = "vertical : ";
    }
    ((StringBuilder)localObject1).append(str);
    String str = ((StringBuilder)localObject1).toString();
    localObject1 = a.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      Object localObject2 = (h)((Iterator)localObject1).next();
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(str);
      localStringBuilder.append("<");
      str = localStringBuilder.toString();
      localStringBuilder = new StringBuilder();
      localStringBuilder.append(str);
      localStringBuilder.append(localObject2);
      str = localStringBuilder.toString();
      localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append(str);
      ((StringBuilder)localObject2).append("> ");
      str = ((StringBuilder)localObject2).toString();
    }
    return str;
  }
  
  public final f write()
  {
    int i = a.size() - 1;
    while (i >= 0)
    {
      h localH = (h)a.get(i);
      if (b.length() != 8) {
        return b;
      }
      i -= 1;
    }
    return null;
  }
}
