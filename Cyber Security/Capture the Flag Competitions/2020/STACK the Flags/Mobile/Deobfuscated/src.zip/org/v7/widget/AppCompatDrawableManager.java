package org.v7.widget;

import a.e.d;
import a.e.g;
import a.e.h;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.core.asm.signature.DrawableCompat;
import org.core.fonts.ContextCompat;
import org.data.Item;
import org.data.SparseArray;
import org.greendroid.graphics.drawable.VectorDrawableCompat;
import org.v7.util.Count;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class AppCompatDrawableManager
{
  public static final m0.c COLOR_FILTER_CACHE = new m0.c(6);
  public static final PorterDuff.Mode DEFAULT_MODE = PorterDuff.Mode.SRC_IN;
  public static AppCompatDrawableManager INSTANCE;
  public g<String, a.b.p.m0.d> mDelegates;
  public final WeakHashMap<android.content.Context, d<WeakReference<Drawable.ConstantState>>> mDrawableCaches = new WeakHashMap(0);
  public h<String> mKnownDrawableIdTags;
  public WeakHashMap<android.content.Context, h<ColorStateList>> mTintLists;
  public TypedValue mTypedValue;
  public boolean multiline;
  public m0.e string;
  
  public AppCompatDrawableManager() {}
  
  public static long createCacheKey(TypedValue paramTypedValue)
  {
    return assetCookie << 32 | data;
  }
  
  public static PorterDuffColorFilter createTintFilter(ColorStateList paramColorStateList, PorterDuff.Mode paramMode, int[] paramArrayOfInt)
  {
    if ((paramColorStateList != null) && (paramMode != null)) {
      return getPorterDuffColorFilter(paramColorStateList.getColorForState(paramArrayOfInt, 0), paramMode);
    }
    return null;
  }
  
  public static AppCompatDrawableManager get()
  {
    try
    {
      if (INSTANCE == null)
      {
        localAppCompatDrawableManager = new AppCompatDrawableManager();
        INSTANCE = localAppCompatDrawableManager;
        installDefaultInflateDelegates(localAppCompatDrawableManager);
      }
      AppCompatDrawableManager localAppCompatDrawableManager = INSTANCE;
      return localAppCompatDrawableManager;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public static PorterDuffColorFilter getPorterDuffColorFilter(int paramInt, PorterDuff.Mode paramMode)
  {
    try
    {
      PorterDuffColorFilter localPorterDuffColorFilter2 = COLOR_FILTER_CACHE.get(paramInt, paramMode);
      PorterDuffColorFilter localPorterDuffColorFilter1 = localPorterDuffColorFilter2;
      if (localPorterDuffColorFilter2 == null)
      {
        localPorterDuffColorFilter2 = new PorterDuffColorFilter(paramInt, paramMode);
        localPorterDuffColorFilter1 = localPorterDuffColorFilter2;
        COLOR_FILTER_CACHE.put(paramInt, paramMode, localPorterDuffColorFilter2);
      }
      return localPorterDuffColorFilter1;
    }
    catch (Throwable paramMode)
    {
      throw paramMode;
    }
  }
  
  public static void installDefaultInflateDelegates(AppCompatDrawableManager paramAppCompatDrawableManager)
  {
    if (Build.VERSION.SDK_INT < 24)
    {
      paramAppCompatDrawableManager.addDelegate("vector", new m0.f());
      paramAppCompatDrawableManager.addDelegate("animated-vector", new m0.b());
      paramAppCompatDrawableManager.addDelegate("animated-selector", new m0.a());
    }
  }
  
  public static boolean isVectorDrawable(Drawable paramDrawable)
  {
    return ((paramDrawable instanceof VectorDrawableCompat)) || ("android.graphics.drawable.VectorDrawable".equals(paramDrawable.getClass().getName()));
  }
  
  public static void tintDrawable(Drawable paramDrawable, TintInfo paramTintInfo, int[] paramArrayOfInt)
  {
    if ((DrawableUtils.canSafelyMutateDrawable(paramDrawable)) && (paramDrawable.mutate() != paramDrawable))
    {
      Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
      return;
    }
    if ((!mHasTintList) && (!mHasTintMode))
    {
      paramDrawable.clearColorFilter();
    }
    else
    {
      ColorStateList localColorStateList;
      if (mHasTintList) {
        localColorStateList = mTintList;
      } else {
        localColorStateList = null;
      }
      if (mHasTintMode) {
        paramTintInfo = mTintMode;
      } else {
        paramTintInfo = DEFAULT_MODE;
      }
      paramDrawable.setColorFilter(createTintFilter(localColorStateList, paramTintInfo, paramArrayOfInt));
    }
    if (Build.VERSION.SDK_INT <= 23) {
      paramDrawable.invalidateSelf();
    }
  }
  
  public void add(android.content.Context paramContext)
  {
    try
    {
      paramContext = (Item)mDrawableCaches.get(paramContext);
      if (paramContext != null) {
        paramContext.a();
      }
      return;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public final void addDelegate(String paramString, m0.d paramD)
  {
    if (mDelegates == null) {
      mDelegates = new org.data.Context();
    }
    mDelegates.put(paramString, paramD);
  }
  
  public final boolean addDrawableToCache(android.content.Context paramContext, long paramLong, Drawable paramDrawable)
  {
    try
    {
      Drawable.ConstantState localConstantState = paramDrawable.getConstantState();
      if (localConstantState != null)
      {
        Item localItem = (Item)mDrawableCaches.get(paramContext);
        paramDrawable = localItem;
        if (localItem == null)
        {
          localItem = new Item();
          paramDrawable = localItem;
          mDrawableCaches.put(paramContext, localItem);
        }
        paramDrawable.a(paramLong, new WeakReference(localConstantState));
        return true;
      }
      return false;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public final void addTintListToCache(android.content.Context paramContext, int paramInt, ColorStateList paramColorStateList)
  {
    if (mTintLists == null) {
      mTintLists = new WeakHashMap();
    }
    SparseArray localSparseArray2 = (SparseArray)mTintLists.get(paramContext);
    SparseArray localSparseArray1 = localSparseArray2;
    if (localSparseArray2 == null)
    {
      localSparseArray2 = new SparseArray();
      localSparseArray1 = localSparseArray2;
      mTintLists.put(paramContext, localSparseArray2);
    }
    localSparseArray1.append(paramInt, paramColorStateList);
  }
  
  public void clear(m0.e paramE)
  {
    try
    {
      string = paramE;
      return;
    }
    catch (Throwable paramE)
    {
      throw paramE;
    }
  }
  
  public final Drawable createDrawableIfNeeded(android.content.Context paramContext, int paramInt)
  {
    if (mTypedValue == null) {
      mTypedValue = new TypedValue();
    }
    TypedValue localTypedValue = mTypedValue;
    paramContext.getResources().getValue(paramInt, localTypedValue, true);
    long l = createCacheKey(localTypedValue);
    Object localObject = getCachedDrawable(paramContext, l);
    if (localObject != null) {
      return localObject;
    }
    localObject = string;
    if (localObject == null) {
      localObject = null;
    } else {
      localObject = ((TintManager)localObject).getDrawable(this, paramContext, paramInt);
    }
    if (localObject != null)
    {
      ((Drawable)localObject).setChangingConfigurations(changingConfigurations);
      addDrawableToCache(paramContext, l, (Drawable)localObject);
    }
    return localObject;
  }
  
  public ColorStateList get(android.content.Context paramContext, int paramInt)
  {
    try
    {
      Object localObject1 = getTintListFromCache(paramContext, paramInt);
      Object localObject2 = localObject1;
      if (localObject1 == null)
      {
        if (string == null)
        {
          localObject1 = null;
        }
        else
        {
          localObject1 = string;
          localObject1 = (TintManager)localObject1;
          localObject1 = ((TintManager)localObject1).getTintList(paramContext, paramInt);
        }
        Object localObject3 = localObject1;
        localObject2 = localObject3;
        if (localObject1 != null)
        {
          addTintListToCache(paramContext, paramInt, (ColorStateList)localObject1);
          localObject2 = localObject3;
        }
      }
      return localObject2;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public PorterDuff.Mode get(int paramInt)
  {
    m0.e localE = string;
    if (localE == null) {
      return null;
    }
    return ((TintManager)localE).getTintMode(paramInt);
  }
  
  public final void get(android.content.Context paramContext)
  {
    if (multiline) {
      return;
    }
    multiline = true;
    paramContext = getDrawable(paramContext, Count.abc_vector_test);
    if ((paramContext != null) && (isVectorDrawable(paramContext))) {
      return;
    }
    multiline = false;
    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
  }
  
  public boolean get(android.content.Context paramContext, int paramInt, Drawable paramDrawable)
  {
    m0.e localE = string;
    return (localE != null) && (((TintManager)localE).tintDrawableUsingColorFilter(paramContext, paramInt, paramDrawable));
  }
  
  public final Drawable getCachedDrawable(android.content.Context paramContext, long paramLong)
  {
    try
    {
      Item localItem = (Item)mDrawableCaches.get(paramContext);
      if (localItem == null) {
        return null;
      }
      Object localObject = (WeakReference)localItem.get(paramLong);
      if (localObject != null)
      {
        localObject = (Drawable.ConstantState)((WeakReference)localObject).get();
        if (localObject != null)
        {
          paramContext = ((Drawable.ConstantState)localObject).newDrawable(paramContext.getResources());
          return paramContext;
        }
        localItem.a(paramLong);
      }
      return null;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public Drawable getDrawable(android.content.Context paramContext, int paramInt)
  {
    try
    {
      paramContext = getDrawable(paramContext, paramInt, false);
      return paramContext;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public Drawable getDrawable(android.content.Context paramContext, int paramInt, boolean paramBoolean)
  {
    try
    {
      get(paramContext);
      Object localObject2 = loadDrawableFromDelegates(paramContext, paramInt);
      Object localObject1 = localObject2;
      if (localObject2 == null) {
        localObject1 = createDrawableIfNeeded(paramContext, paramInt);
      }
      localObject2 = localObject1;
      if (localObject1 == null) {
        localObject2 = ContextCompat.getDrawable(paramContext, paramInt);
      }
      localObject1 = localObject2;
      if (localObject2 != null) {
        localObject1 = tintDrawable(paramContext, paramInt, paramBoolean, (Drawable)localObject2);
      }
      if (localObject1 != null) {
        DrawableUtils.fixDrawable((Drawable)localObject1);
      }
      return localObject1;
    }
    catch (Throwable paramContext)
    {
      throw paramContext;
    }
  }
  
  public final ColorStateList getTintListFromCache(android.content.Context paramContext, int paramInt)
  {
    WeakHashMap localWeakHashMap = mTintLists;
    if (localWeakHashMap != null)
    {
      paramContext = (SparseArray)localWeakHashMap.get(paramContext);
      if (paramContext != null) {
        return (ColorStateList)paramContext.get(paramInt);
      }
    }
    return null;
  }
  
  public final Drawable loadDrawableFromDelegates(android.content.Context paramContext, int paramInt)
  {
    Object localObject1 = mDelegates;
    Object localObject2;
    if ((localObject1 != null) && (!((org.data.Context)localObject1).isEmpty()))
    {
      localObject1 = mKnownDrawableIdTags;
      if (localObject1 != null)
      {
        localObject1 = (String)((SparseArray)localObject1).get(paramInt);
        if (!"appcompat_skip_skip".equals(localObject1))
        {
          if ((localObject1 != null) && (mDelegates.get(localObject1) == null)) {
            return null;
          }
        }
        else {
          return null;
        }
      }
      else
      {
        mKnownDrawableIdTags = new SparseArray();
      }
      if (mTypedValue == null) {
        mTypedValue = new TypedValue();
      }
      TypedValue localTypedValue = mTypedValue;
      Object localObject4 = paramContext.getResources();
      ((Resources)localObject4).getValue(paramInt, localTypedValue, true);
      long l = createCacheKey(localTypedValue);
      localObject2 = getCachedDrawable(paramContext, l);
      localObject1 = localObject2;
      if (localObject2 != null) {
        return localObject2;
      }
      Object localObject3 = string;
      localObject2 = localObject1;
      if (localObject3 != null)
      {
        localObject2 = localObject1;
        if (((CharSequence)localObject3).toString().endsWith(".xml"))
        {
          localObject3 = localObject1;
          try
          {
            localObject4 = ((Resources)localObject4).getXml(paramInt);
            localObject3 = localObject1;
            AttributeSet localAttributeSet = Xml.asAttributeSet((XmlPullParser)localObject4);
            int i;
            do
            {
              localObject3 = localObject1;
              i = ((XmlPullParser)localObject4).next();
            } while ((i != 2) && (i != 1));
            if (i == 2)
            {
              localObject3 = localObject1;
              localObject2 = ((XmlPullParser)localObject4).getName();
              Object localObject5 = mKnownDrawableIdTags;
              localObject3 = localObject1;
              ((SparseArray)localObject5).append(paramInt, localObject2);
              localObject5 = mDelegates;
              localObject3 = localObject1;
              localObject2 = ((org.data.Context)localObject5).get(localObject2);
              localObject5 = (m0.d)localObject2;
              localObject2 = localObject1;
              if (localObject5 != null)
              {
                localObject3 = localObject1;
                localObject2 = ((m0.d)localObject5).createFromXmlInner(paramContext, (XmlPullParser)localObject4, localAttributeSet, paramContext.getTheme());
              }
              if (localObject2 != null)
              {
                i = changingConfigurations;
                localObject3 = localObject2;
                ((Drawable)localObject2).setChangingConfigurations(i);
                localObject3 = localObject2;
                addDrawableToCache(paramContext, l, (Drawable)localObject2);
              }
            }
            else
            {
              localObject3 = localObject1;
              paramContext = new XmlPullParserException("No start tag found");
              throw paramContext;
            }
          }
          catch (Exception paramContext)
          {
            Log.e("ResourceManagerInternal", "Exception while inflating drawable", paramContext);
            localObject2 = localObject3;
          }
        }
      }
      if (localObject2 == null)
      {
        mKnownDrawableIdTags.append(paramInt, "appcompat_skip_skip");
        return localObject2;
      }
    }
    else
    {
      return null;
    }
    return localObject2;
  }
  
  public final Drawable tintDrawable(android.content.Context paramContext, int paramInt, boolean paramBoolean, Drawable paramDrawable)
  {
    Object localObject = get(paramContext, paramInt);
    if (localObject != null)
    {
      paramContext = paramDrawable;
      if (DrawableUtils.canSafelyMutateDrawable(paramDrawable)) {
        paramContext = paramDrawable.mutate();
      }
      paramContext = DrawableCompat.wrap(paramContext);
      DrawableCompat.setTintList(paramContext, (ColorStateList)localObject);
      paramDrawable = get(paramInt);
      if (paramDrawable != null) {
        DrawableCompat.setTintMode(paramContext, paramDrawable);
      }
      return paramContext;
    }
    localObject = string;
    if ((localObject != null) && (((TintManager)localObject).tintDrawable(paramContext, paramInt, paramDrawable))) {
      return paramDrawable;
    }
    if ((!get(paramContext, paramInt, paramDrawable)) && (paramBoolean)) {
      return null;
    }
    return paramDrawable;
  }
}
