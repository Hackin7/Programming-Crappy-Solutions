package org.misc;

import android.os.Bundle;
import androidx.savedstate.Recreator;
import androidx.savedstate.SavedStateRegistry;
import org.util.Log;
import org.util.c;
import org.util.d;

public final class b
{
  public final Paint l;
  public final SavedStateRegistry m;
  
  public b(Paint paramPaint)
  {
    l = paramPaint;
    m = new SavedStateRegistry();
  }
  
  public static b a(Paint paramPaint)
  {
    return new b(paramPaint);
  }
  
  public void a(Bundle paramBundle)
  {
    Log localLog = l.getLifecycle();
    if (localLog.p() == c.b)
    {
      localLog.a(new Recreator(l));
      m.a(localLog, paramBundle);
      return;
    }
    throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
  }
  
  public SavedStateRegistry d()
  {
    return m;
  }
  
  public void e(Bundle paramBundle)
  {
    m.onSaveInstanceState(paramBundle);
  }
}
