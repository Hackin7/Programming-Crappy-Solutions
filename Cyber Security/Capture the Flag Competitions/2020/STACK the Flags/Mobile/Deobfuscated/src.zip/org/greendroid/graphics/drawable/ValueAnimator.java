package org.greendroid.graphics.drawable;

import android.content.Context;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

public class ValueAnimator
{
  public static Interpolator setInterpolator(Context paramContext, int paramInt)
  {
    return AnimationUtils.loadInterpolator(paramContext, paramInt);
  }
}
