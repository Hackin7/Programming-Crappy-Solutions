package org.codehaus.asm.asm;

import a.f.b.i.d.a;

public enum c
{
  static
  {
    a = new c("TOP", 2);
    i = new c("RIGHT", 3);
    b = new c("BOTTOM", 4);
    g = new c("BASELINE", 5);
    l = new c("CENTER", 6);
    c = new c("CENTER_X", 7);
    c localC = new c("CENTER_Y", 8);
    f = localC;
    e = new c[] { V, d, a, i, b, g, l, c, localC };
  }
}
