package org.util;

public class m
{
  public c a;
  public MenuItem b;
  
  public m(MethodVisitor paramMethodVisitor, c paramC)
  {
    b = Frame.a(paramMethodVisitor);
    a = paramC;
  }
  
  public void a(d paramD, Scope paramScope)
  {
    c localC = f.a(paramScope);
    a = f.a(a, localC);
    b.b(paramD, paramScope);
    a = localC;
  }
}
