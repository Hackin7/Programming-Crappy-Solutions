package org.protocol.async;

import java.io.Closeable;

public abstract interface Connection
  extends Closeable
{}
