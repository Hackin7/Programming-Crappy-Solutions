package org.v7.view.menu;

import a.e.g;
import a.h.g.a.b;
import a.h.g.a.c;
import android.view.SubMenu;
import org.core.base.utils.SupportSubMenu;

public abstract class BaseMenuWrapper
{
  public g<b, android.view.MenuItem> a;
  public final android.content.Context mContext;
  public g<c, SubMenu> mSubMenus;
  
  public BaseMenuWrapper(android.content.Context paramContext)
  {
    mContext = paramContext;
  }
  
  public final void a(int paramInt)
  {
    if (a == null) {
      return;
    }
    int j;
    for (int i = 0; i < a.size(); i = j + 1)
    {
      j = i;
      if (((org.core.base.utils.MenuItem)a.getValue(i)).getGroupId() == paramInt)
      {
        a.write(i);
        j = i - 1;
      }
    }
  }
  
  public final void b(int paramInt)
  {
    if (a == null) {
      return;
    }
    int i = 0;
    while (i < a.size())
    {
      if (((org.core.base.utils.MenuItem)a.getValue(i)).getItemId() == paramInt)
      {
        a.write(i);
        return;
      }
      i += 1;
    }
  }
  
  public final android.view.MenuItem getMenuItemWrapper(android.view.MenuItem paramMenuItem)
  {
    android.view.MenuItem localMenuItem = paramMenuItem;
    if ((paramMenuItem instanceof org.core.base.utils.MenuItem))
    {
      org.core.base.utils.MenuItem localMenuItem1 = (org.core.base.utils.MenuItem)paramMenuItem;
      if (a == null) {
        a = new org.data.Context();
      }
      paramMenuItem = (android.view.MenuItem)a.get(paramMenuItem);
      localMenuItem = paramMenuItem;
      if (paramMenuItem == null)
      {
        paramMenuItem = new MenuItemWrapper(mContext, localMenuItem1);
        a.put(localMenuItem1, paramMenuItem);
        return paramMenuItem;
      }
    }
    return localMenuItem;
  }
  
  public final SubMenu getSubMenuWrapper(SubMenu paramSubMenu)
  {
    SubMenu localSubMenu = paramSubMenu;
    if ((paramSubMenu instanceof SupportSubMenu))
    {
      SupportSubMenu localSupportSubMenu = (SupportSubMenu)paramSubMenu;
      if (mSubMenus == null) {
        mSubMenus = new org.data.Context();
      }
      paramSubMenu = (SubMenu)mSubMenus.get(localSupportSubMenu);
      localSubMenu = paramSubMenu;
      if (paramSubMenu == null)
      {
        paramSubMenu = new SubMenuWrapper(mContext, localSupportSubMenu);
        mSubMenus.put(localSupportSubMenu, paramSubMenu);
        return paramSubMenu;
      }
    }
    return localSubMenu;
  }
  
  public final void internalClear()
  {
    org.data.Context localContext = a;
    if (localContext != null) {
      localContext.clear();
    }
    localContext = mSubMenus;
    if (localContext != null) {
      localContext.clear();
    }
  }
}
