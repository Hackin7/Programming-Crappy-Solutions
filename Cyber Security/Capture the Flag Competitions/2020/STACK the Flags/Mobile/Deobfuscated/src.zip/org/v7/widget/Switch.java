package org.v7.widget;

import a.h.k.a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.ActionMode.Callback;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.core.asm.Item;
import org.core.tree.Segment;
import org.core.widget.Account;
import org.core.widget.MonthAdapter.CalendarDay;

public class Switch
  extends TextView
  implements Account, MonthAdapter.CalendarDay
{
  public Future<a> f;
  public final AppCompatBackgroundHelper mBackgroundTintHelper;
  public final TimePicker mTimePicker;
  public final ClassReader r;
  
  public Switch(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public Switch(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public Switch(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    ThemeUtils.init(this, getContext());
    paramContext = new AppCompatBackgroundHelper(this);
    mBackgroundTintHelper = paramContext;
    paramContext.loadFromAttributes(paramAttributeSet, paramInt);
    paramContext = new TimePicker(this);
    mTimePicker = paramContext;
    paramContext.init(paramAttributeSet, paramInt);
    mTimePicker.applyCompoundDrawablesTints();
    r = new ClassReader(this);
  }
  
  public final void a()
  {
    Object localObject = f;
    if (localObject != null)
    {
      f = null;
      try
      {
        localObject = ((Future)localObject).get();
        localObject = (Segment)localObject;
        org.core.widget.Label.a(this, (Segment)localObject);
        return;
      }
      catch (ExecutionException localExecutionException) {}catch (InterruptedException localInterruptedException) {}
    }
  }
  
  public void drawableStateChanged()
  {
    super.drawableStateChanged();
    Object localObject = mBackgroundTintHelper;
    if (localObject != null) {
      ((AppCompatBackgroundHelper)localObject).applySupportBackgroundTint();
    }
    localObject = mTimePicker;
    if (localObject != null) {
      ((TimePicker)localObject).applyCompoundDrawablesTints();
    }
  }
  
  public int getAutoSizeMaxTextSize()
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled) {
      return super.getAutoSizeMaxTextSize();
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      return localTimePicker.getCurrentHour();
    }
    return -1;
  }
  
  public int getAutoSizeMinTextSize()
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled) {
      return super.getAutoSizeMinTextSize();
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      return localTimePicker.getHours();
    }
    return -1;
  }
  
  public int getAutoSizeStepGranularity()
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled) {
      return super.getAutoSizeStepGranularity();
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      return localTimePicker.applyStyle();
    }
    return -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes()
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled) {
      return super.getAutoSizeTextAvailableSizes();
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      return localTimePicker.getHour();
    }
    return new int[0];
  }
  
  public int getAutoSizeTextType()
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled)
    {
      if (super.getAutoSizeTextType() == 1) {
        return 1;
      }
      return 0;
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      return localTimePicker.onSaveInstanceState();
    }
    return 0;
  }
  
  public int getFirstBaselineToTopHeight()
  {
    return org.core.widget.Label.setText(this);
  }
  
  public int getLastBaselineToBottomHeight()
  {
    return org.core.widget.Label.b(this);
  }
  
  public ColorStateList getSupportBackgroundTintList()
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      return localAppCompatBackgroundHelper.getSupportBackgroundTintList();
    }
    return null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      return localAppCompatBackgroundHelper.getSupportBackgroundTintMode();
    }
    return null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList()
  {
    return mTimePicker.getTypeface();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode()
  {
    return mTimePicker.getSupportBackgroundTintMode();
  }
  
  public CharSequence getText()
  {
    a();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier()
  {
    if (Build.VERSION.SDK_INT < 28)
    {
      ClassReader localClassReader = r;
      if (localClassReader != null) {
        return localClassReader.a();
      }
    }
    return super.getTextClassifier();
  }
  
  public org.core.tree.Label getTextMetricsParamsCompat()
  {
    return org.core.widget.Label.a(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo)
  {
    InputConnection localInputConnection = super.onCreateInputConnection(paramEditorInfo);
    Resources.validate(localInputConnection, paramEditorInfo, this);
    return localInputConnection;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      localTimePicker.setTime();
    }
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    a();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    paramCharSequence = mTimePicker;
    if ((paramCharSequence != null) && (!MonthAdapter.CalendarDay.$assertionsDisabled) && (paramCharSequence.update())) {
      mTimePicker.setEnabled();
    }
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled)
    {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      localTimePicker.onSaveInstanceState(paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfInt, int paramInt)
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled)
    {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfInt, paramInt);
      return;
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      localTimePicker.setEnabled(paramArrayOfInt, paramInt);
    }
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt)
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled)
    {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      localTimePicker.setCurrentHour(paramInt);
    }
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    super.setBackgroundDrawable(paramDrawable);
    paramDrawable = mBackgroundTintHelper;
    if (paramDrawable != null) {
      paramDrawable.setSupportBackgroundTintList();
    }
  }
  
  public void setBackgroundResource(int paramInt)
  {
    super.setBackgroundResource(paramInt);
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.loadFromAttributes(paramInt);
    }
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4)
  {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    paramDrawable1 = mTimePicker;
    if (paramDrawable1 != null) {
      paramDrawable1.setCompoundDrawablesWithIntrinsicBounds();
    }
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4)
  {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    paramDrawable1 = mTimePicker;
    if (paramDrawable1 != null) {
      paramDrawable1.setCompoundDrawablesWithIntrinsicBounds();
    }
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Context localContext = getContext();
    Drawable localDrawable3 = null;
    if (paramInt1 != 0) {
      localObject = org.v7.internal.util.Resources.getDrawable(localContext, paramInt1);
    } else {
      localObject = null;
    }
    Drawable localDrawable1;
    if (paramInt2 != 0) {
      localDrawable1 = org.v7.internal.util.Resources.getDrawable(localContext, paramInt2);
    } else {
      localDrawable1 = null;
    }
    Drawable localDrawable2;
    if (paramInt3 != 0) {
      localDrawable2 = org.v7.internal.util.Resources.getDrawable(localContext, paramInt3);
    } else {
      localDrawable2 = null;
    }
    if (paramInt4 != 0) {
      localDrawable3 = org.v7.internal.util.Resources.getDrawable(localContext, paramInt4);
    }
    setCompoundDrawablesRelativeWithIntrinsicBounds((Drawable)localObject, localDrawable1, localDrawable2, localDrawable3);
    Object localObject = mTimePicker;
    if (localObject != null) {
      ((TimePicker)localObject).setCompoundDrawablesWithIntrinsicBounds();
    }
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4)
  {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    paramDrawable1 = mTimePicker;
    if (paramDrawable1 != null) {
      paramDrawable1.setCompoundDrawablesWithIntrinsicBounds();
    }
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Context localContext = getContext();
    Drawable localDrawable3 = null;
    if (paramInt1 != 0) {
      localObject = org.v7.internal.util.Resources.getDrawable(localContext, paramInt1);
    } else {
      localObject = null;
    }
    Drawable localDrawable1;
    if (paramInt2 != 0) {
      localDrawable1 = org.v7.internal.util.Resources.getDrawable(localContext, paramInt2);
    } else {
      localDrawable1 = null;
    }
    Drawable localDrawable2;
    if (paramInt3 != 0) {
      localDrawable2 = org.v7.internal.util.Resources.getDrawable(localContext, paramInt3);
    } else {
      localDrawable2 = null;
    }
    if (paramInt4 != 0) {
      localDrawable3 = org.v7.internal.util.Resources.getDrawable(localContext, paramInt4);
    }
    setCompoundDrawablesWithIntrinsicBounds((Drawable)localObject, localDrawable1, localDrawable2, localDrawable3);
    Object localObject = mTimePicker;
    if (localObject != null) {
      ((TimePicker)localObject).setCompoundDrawablesWithIntrinsicBounds();
    }
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4)
  {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    paramDrawable1 = mTimePicker;
    if (paramDrawable1 != null) {
      paramDrawable1.setCompoundDrawablesWithIntrinsicBounds();
    }
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback)
  {
    super.setCustomSelectionActionModeCallback(org.core.widget.Label.a(this, paramCallback));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 28)
    {
      super.setFirstBaselineToTopHeight(paramInt);
      return;
    }
    org.core.widget.Label.a(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 28)
    {
      super.setLastBaselineToBottomHeight(paramInt);
      return;
    }
    org.core.widget.Label.setText(this, paramInt);
  }
  
  public void setLineHeight(int paramInt)
  {
    org.core.widget.Label.setup(this, paramInt);
  }
  
  public void setPrecomputedText(Segment paramSegment)
  {
    org.core.widget.Label.a(this, paramSegment);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList)
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.setSupportBackgroundTintList(paramColorStateList);
    }
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    AppCompatBackgroundHelper localAppCompatBackgroundHelper = mBackgroundTintHelper;
    if (localAppCompatBackgroundHelper != null) {
      localAppCompatBackgroundHelper.setSupportBackgroundTintMode(paramMode);
    }
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList)
  {
    mTimePicker.setMinute(paramColorStateList);
    mTimePicker.applyCompoundDrawablesTints();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode)
  {
    mTimePicker.setMinute(paramMode);
    mTimePicker.applyCompoundDrawablesTints();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt)
  {
    super.setTextAppearance(paramContext, paramInt);
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      localTimePicker.applyStyle(paramContext, paramInt);
    }
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier)
  {
    if (Build.VERSION.SDK_INT < 28)
    {
      ClassReader localClassReader = r;
      if (localClassReader != null)
      {
        localClassReader.b(paramTextClassifier);
        return;
      }
    }
    super.setTextClassifier(paramTextClassifier);
  }
  
  public void setTextFuture(Future paramFuture)
  {
    f = paramFuture;
    if (paramFuture != null) {
      requestLayout();
    }
  }
  
  public void setTextMetricsParamsCompat(org.core.tree.Label paramLabel)
  {
    org.core.widget.Label.a(this, paramLabel);
  }
  
  public void setTextSize(int paramInt, float paramFloat)
  {
    if (MonthAdapter.CalendarDay.$assertionsDisabled)
    {
      super.setTextSize(paramInt, paramFloat);
      return;
    }
    TimePicker localTimePicker = mTimePicker;
    if (localTimePicker != null) {
      localTimePicker.setTime(paramInt, paramFloat);
    }
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt)
  {
    Object localObject2 = null;
    Object localObject1 = localObject2;
    if (paramTypeface != null)
    {
      localObject1 = localObject2;
      if (paramInt > 0) {
        localObject1 = Item.load(getContext(), paramTypeface, paramInt);
      }
    }
    if (localObject1 != null) {
      paramTypeface = (Typeface)localObject1;
    }
    super.setTypeface(paramTypeface, paramInt);
  }
}
