package org.spongycastle.crypto.params;

import a.c.a.b.b.e;

public class l<K, V>
  extends b.e<K, V>
{
  public l(Attribute paramAttribute1, Attribute paramAttribute2)
  {
    super(paramAttribute1, paramAttribute2);
  }
  
  public Attribute a(Attribute paramAttribute)
  {
    return b;
  }
  
  public Attribute equals(Attribute paramAttribute)
  {
    return a;
  }
}
