package org.asm;

import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Property;

public final class OverlayList
  extends Property<Drawable, PointF>
{
  public Rect mRect = new Rect();
  
  public OverlayList(Class paramClass, String paramString)
  {
    super(paramClass, paramString);
  }
  
  public PointF draw(Drawable paramDrawable)
  {
    paramDrawable.copyBounds(mRect);
    paramDrawable = mRect;
    return new PointF(left, top);
  }
  
  public void draw(Drawable paramDrawable, PointF paramPointF)
  {
    paramDrawable.copyBounds(mRect);
    mRect.offsetTo(Math.round(x), Math.round(y));
    paramDrawable.setBounds(mRect);
  }
}
