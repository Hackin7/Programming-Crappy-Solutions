package org.asm;

import android.view.ViewGroup;

public class b
  extends p
{
  public boolean b = false;
  
  public b(f paramF, ViewGroup paramViewGroup) {}
  
  public void a(l paramL)
  {
    if (!b) {
      Type.a(a, false);
    }
    paramL.b(this);
  }
  
  public void b(l paramL)
  {
    Type.a(a, false);
  }
  
  public void d(l paramL)
  {
    Type.a(a, true);
  }
}
