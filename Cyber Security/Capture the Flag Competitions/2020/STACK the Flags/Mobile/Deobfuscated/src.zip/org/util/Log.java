package org.util;

import java.util.concurrent.atomic.AtomicReference;

public abstract class Log
{
  public Log()
  {
    new AtomicReference();
  }
  
  public abstract void a(MethodVisitor paramMethodVisitor);
  
  public abstract void e(MethodVisitor paramMethodVisitor);
  
  public abstract c p();
}
