package org.asm;

import android.animation.PropertyValuesHolder;
import android.graphics.Path;
import android.util.Property;

public class k
{
  public static PropertyValuesHolder ofObject(Property paramProperty, Path paramPath)
  {
    return PropertyValuesHolder.ofObject(paramProperty, null, paramPath);
  }
}
