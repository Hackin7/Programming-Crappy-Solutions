package org.util;

public abstract interface Control
{
  public abstract Label getViewModelStore();
}
