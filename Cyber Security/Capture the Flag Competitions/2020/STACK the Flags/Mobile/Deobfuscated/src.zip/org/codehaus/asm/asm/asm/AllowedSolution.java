package org.codehaus.asm.asm.asm;

import a.f.b.i.m.p.a;

public enum AllowedSolution
{
  static
  {
    AllowedSolution localAllowedSolution = new AllowedSolution("CENTER", 3);
    H = localAllowedSolution;
    $VALUES = new AllowedSolution[] { ANY_SIDE, LEFT_SIDE, RIGHT_SIDE, localAllowedSolution };
  }
}
