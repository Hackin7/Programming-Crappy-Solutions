package org.v7.graphics.drawable;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.drawable.AnimationDrawable;

public class CircularProgressDrawable
  extends Animator
{
  public final ObjectAnimator mAnimator;
  public final boolean mPaint;
  
  public CircularProgressDrawable(AnimationDrawable paramAnimationDrawable, boolean paramBoolean1, boolean paramBoolean2)
  {
    super(null);
    int j = paramAnimationDrawable.getNumberOfFrames();
    int i;
    if (paramBoolean1) {
      i = j - 1;
    } else {
      i = 0;
    }
    if (paramBoolean1) {
      j = 0;
    } else {
      j -= 1;
    }
    ClassWriter localClassWriter = new ClassWriter(paramAnimationDrawable, paramBoolean1);
    paramAnimationDrawable = ObjectAnimator.ofInt(paramAnimationDrawable, "currentIndex", new int[] { i, j });
    paramAnimationDrawable.setAutoCancel(true);
    paramAnimationDrawable.setDuration(localClassWriter.get());
    paramAnimationDrawable.setInterpolator(localClassWriter);
    mPaint = paramBoolean2;
    mAnimator = paramAnimationDrawable;
  }
  
  public boolean draw()
  {
    return mPaint;
  }
  
  public void setDuration()
  {
    mAnimator.reverse();
  }
  
  public void start()
  {
    mAnimator.start();
  }
  
  public void stop()
  {
    mAnimator.cancel();
  }
}
