package org.objectweb.asm;

import android.view.View;

public abstract interface g
{
  public abstract int a();
  
  public abstract int b();
  
  public abstract int b(View paramView);
  
  public abstract int c(View paramView);
  
  public abstract View c(int paramInt);
}
