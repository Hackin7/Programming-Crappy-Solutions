package org.util;

public abstract interface k
{
  public abstract i a(Class paramClass);
}
