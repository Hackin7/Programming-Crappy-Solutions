package org.asm;

import android.view.View;

public abstract interface Item
  extends Object
{
  public abstract void a(View paramView);
}
