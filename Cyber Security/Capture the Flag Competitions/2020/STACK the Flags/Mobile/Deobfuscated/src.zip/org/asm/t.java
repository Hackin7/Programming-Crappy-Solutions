package org.asm;

import android.view.View;

public class t
  extends p
{
  public t(q paramQ, View paramView) {}
  
  public void a(l paramL)
  {
    Log.put(a, 1.0F);
    Log.d(a);
    paramL.b(this);
  }
}
