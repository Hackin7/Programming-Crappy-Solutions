package org.asm;

import android.animation.TypeEvaluator;
import android.graphics.Rect;

public class IntEvaluator
  implements TypeEvaluator<Rect>
{
  public IntEvaluator() {}
  
  public Rect evaluate(float paramFloat, Rect paramRect1, Rect paramRect2)
  {
    int i = left;
    int j = (int)((left - i) * paramFloat);
    int k = top;
    int m = (int)((top - k) * paramFloat);
    int n = right;
    int i1 = (int)((right - n) * paramFloat);
    int i2 = bottom;
    return new Rect(i + j, k + m, n + i1, i2 + (int)((bottom - i2) * paramFloat));
  }
}
