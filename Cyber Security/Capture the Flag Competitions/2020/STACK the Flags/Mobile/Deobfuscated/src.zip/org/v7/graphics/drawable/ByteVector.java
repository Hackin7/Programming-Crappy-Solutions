package org.v7.graphics.drawable;

import a.e.d;
import a.e.h;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.StateSet;
import org.data.Item;
import org.data.SparseArray;

public class ByteVector
  extends Document
{
  public d<Long> a;
  public h<Integer> b;
  
  public ByteVector(ByteVector paramByteVector, AnimatedVectorDrawableCompat paramAnimatedVectorDrawableCompat, Resources paramResources)
  {
    super(paramByteVector, paramAnimatedVectorDrawableCompat, paramResources);
    if (paramByteVector != null)
    {
      a = a;
      b = b;
      return;
    }
    a = new Item();
    b = new SparseArray();
  }
  
  public static long add(int paramInt1, int paramInt2)
  {
    return paramInt1 << 32 | paramInt2;
  }
  
  public boolean a(int paramInt1, int paramInt2)
  {
    long l = add(paramInt1, paramInt2);
    return (((Long)a.get(l, Long.valueOf(-1L))).longValue() & 0x200000000) != 0L;
  }
  
  public int add(int paramInt)
  {
    if (paramInt < 0) {
      return 0;
    }
    return ((Integer)b.get(paramInt, Integer.valueOf(0))).intValue();
  }
  
  public int add(int paramInt1, int paramInt2, Drawable paramDrawable, boolean paramBoolean)
  {
    int i = super.add(paramDrawable);
    long l2 = add(paramInt1, paramInt2);
    long l1 = 0L;
    if (paramBoolean) {
      l1 = 8589934592L;
    }
    a.set(l2, Long.valueOf(i | l1));
    if (paramBoolean)
    {
      l2 = add(paramInt2, paramInt1);
      a.set(l2, Long.valueOf(i | 0x100000000 | l1));
    }
    return i;
  }
  
  public int add(int[] paramArrayOfInt)
  {
    int i = super.a(paramArrayOfInt);
    if (i >= 0) {
      return i;
    }
    return super.a(StateSet.WILD_CARD);
  }
  
  public int add(int[] paramArrayOfInt, Drawable paramDrawable, int paramInt)
  {
    int i = super.add(paramArrayOfInt, paramDrawable);
    b.put(i, Integer.valueOf(paramInt));
    return i;
  }
  
  public boolean get(int paramInt1, int paramInt2)
  {
    long l = add(paramInt1, paramInt2);
    return (((Long)a.get(l, Long.valueOf(-1L))).longValue() & 0x100000000) != 0L;
  }
  
  public void init()
  {
    a = a.set();
    b = b.get();
  }
  
  public Drawable newDrawable()
  {
    return new AnimatedVectorDrawableCompat(this, null);
  }
  
  public Drawable newDrawable(Resources paramResources)
  {
    return new AnimatedVectorDrawableCompat(this, paramResources);
  }
  
  public int write(int paramInt1, int paramInt2)
  {
    long l = add(paramInt1, paramInt2);
    return (int)((Long)a.get(l, Long.valueOf(-1L))).longValue();
  }
}
