package org.v7.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import org.core.asm.signature.DrawableCompat;

public class DrawableContainer
  extends Drawable
  implements Drawable.Callback
{
  public int mAlpha = 255;
  public Runnable mAnimationRunnable;
  public Drawable mCurrDrawable;
  public Drawable mDrawable;
  public boolean mMutated;
  public Rect mRect;
  public DrawableContainerState mState;
  public boolean r;
  public int state = -1;
  public MaterialProgressDrawable.3 this$0;
  public long x;
  public long y;
  
  public DrawableContainer() {}
  
  public static int init(Resources paramResources, int paramInt)
  {
    if (paramResources != null) {
      paramInt = getDisplayMetricsdensityDpi;
    }
    if (paramInt == 0) {
      return 160;
    }
    return paramInt;
  }
  
  public void animate(boolean paramBoolean)
  {
    r = true;
    long l1 = SystemClock.uptimeMillis();
    int j = 0;
    Drawable localDrawable = mDrawable;
    long l2;
    int i;
    if (localDrawable != null)
    {
      l2 = x;
      i = j;
      if (l2 != 0L) {
        if (l2 <= l1)
        {
          localDrawable.setAlpha(mAlpha);
          x = 0L;
          i = j;
        }
        else
        {
          localDrawable.setAlpha((255 - (int)((l2 - l1) * 255L) / mState.mMode) * mAlpha / 255);
          i = 1;
        }
      }
    }
    else
    {
      x = 0L;
      i = j;
    }
    localDrawable = mCurrDrawable;
    if (localDrawable != null)
    {
      l2 = y;
      j = i;
      if (l2 != 0L) {
        if (l2 <= l1)
        {
          localDrawable.setVisible(false, false);
          mCurrDrawable = null;
          y = 0L;
          j = i;
        }
        else
        {
          i = (int)((l2 - l1) * 255L) / mState.mAlpha;
          localDrawable.setAlpha(mAlpha * i / 255);
          j = 1;
        }
      }
    }
    else
    {
      y = 0L;
      j = i;
    }
    if ((paramBoolean) && (j != 0)) {
      scheduleSelf(mAnimationRunnable, 16L + l1);
    }
  }
  
  public void applyTheme(Resources.Theme paramTheme)
  {
    mState.init(paramTheme);
  }
  
  public boolean canApplyTheme()
  {
    return mState.canApplyTheme();
  }
  
  public abstract DrawableContainerState create();
  
  public void draw(Canvas paramCanvas)
  {
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      localDrawable.draw(paramCanvas);
    }
    localDrawable = mCurrDrawable;
    if (localDrawable != null) {
      localDrawable.draw(paramCanvas);
    }
  }
  
  public final void draw(Drawable paramDrawable)
  {
    if (this$0 == null) {
      this$0 = new MaterialProgressDrawable.3();
    }
    Object localObject = this$0;
    ((MaterialProgressDrawable.3)localObject).put(paramDrawable.getCallback());
    paramDrawable.setCallback((Drawable.Callback)localObject);
    try
    {
      int i = mState.mMode;
      if (i <= 0)
      {
        bool = r;
        if (bool) {
          paramDrawable.setAlpha(mAlpha);
        }
      }
      boolean bool = mState.mDrawableState;
      if (bool)
      {
        paramDrawable.setColorFilter(mState.mState);
      }
      else
      {
        bool = mState.height;
        if (bool) {
          DrawableCompat.setTintList(paramDrawable, mState.mTint);
        }
        bool = mState.top;
        if (bool) {
          DrawableCompat.setTintMode(paramDrawable, mState.mTintMode);
        }
      }
      paramDrawable.setVisible(isVisible(), true);
      paramDrawable.setDither(mState.mDither);
      paramDrawable.setState(getState());
      paramDrawable.setLevel(getLevel());
      paramDrawable.setBounds(getBounds());
      i = Build.VERSION.SDK_INT;
      if (i >= 23) {
        paramDrawable.setLayoutDirection(getLayoutDirection());
      }
      paramDrawable.setAutoMirrored(mState.mDrawable);
      localObject = mRect;
      if (localObject != null) {
        paramDrawable.setHotspotBounds(left, top, right, bottom);
      }
      paramDrawable.setCallback(this$0.apply());
      return;
    }
    catch (Throwable localThrowable)
    {
      paramDrawable.setCallback(this$0.apply());
      throw localThrowable;
    }
  }
  
  public boolean draw(int paramInt)
  {
    if (paramInt == state) {
      return false;
    }
    long l = SystemClock.uptimeMillis();
    Object localObject;
    if (mState.mAlpha > 0)
    {
      localObject = mCurrDrawable;
      if (localObject != null) {
        ((Drawable)localObject).setVisible(false, false);
      }
      localObject = mDrawable;
      if (localObject != null)
      {
        mCurrDrawable = ((Drawable)localObject);
        y = (mState.mAlpha + l);
      }
      else
      {
        mCurrDrawable = null;
        y = 0L;
      }
    }
    else
    {
      localObject = mDrawable;
      if (localObject != null) {
        ((Drawable)localObject).setVisible(false, false);
      }
    }
    if (paramInt >= 0)
    {
      localObject = mState;
      if (paramInt < size)
      {
        localObject = ((DrawableContainerState)localObject).get(paramInt);
        mDrawable = ((Drawable)localObject);
        state = paramInt;
        if (localObject != null)
        {
          paramInt = mState.mMode;
          if (paramInt > 0) {
            x = (paramInt + l);
          }
          draw((Drawable)localObject);
        }
        break label191;
      }
    }
    mDrawable = null;
    state = -1;
    label191:
    if ((x != 0L) || (y != 0L))
    {
      localObject = mAnimationRunnable;
      if (localObject == null) {
        mAnimationRunnable = new MonthByWeekFragment.2(this);
      } else {
        unscheduleSelf((Runnable)localObject);
      }
      animate(true);
    }
    invalidateSelf();
    return true;
  }
  
  public int get()
  {
    return state;
  }
  
  public int getAlpha()
  {
    return mAlpha;
  }
  
  public int getChangingConfigurations()
  {
    return super.getChangingConfigurations() | mState.getChangingConfigurations();
  }
  
  public final Drawable.ConstantState getConstantState()
  {
    if (mState.canConstantState())
    {
      mState.flags = getChangingConfigurations();
      return mState;
    }
    return null;
  }
  
  public Drawable getCurrent()
  {
    return mDrawable;
  }
  
  public void getHotspotBounds(Rect paramRect)
  {
    Rect localRect = mRect;
    if (localRect != null)
    {
      paramRect.set(localRect);
      return;
    }
    super.getHotspotBounds(paramRect);
  }
  
  public int getIntrinsicHeight()
  {
    if (mState.get()) {
      return mState.a();
    }
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      return localDrawable.getIntrinsicHeight();
    }
    return -1;
  }
  
  public int getIntrinsicWidth()
  {
    if (mState.get()) {
      return mState.getWidth();
    }
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      return localDrawable.getIntrinsicWidth();
    }
    return -1;
  }
  
  public int getMinimumHeight()
  {
    if (mState.get()) {
      return mState.getMinimumHeight();
    }
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      return localDrawable.getMinimumHeight();
    }
    return 0;
  }
  
  public int getMinimumWidth()
  {
    if (mState.get()) {
      return mState.getMinimumWidth();
    }
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      return localDrawable.getMinimumWidth();
    }
    return 0;
  }
  
  public int getOpacity()
  {
    Drawable localDrawable = mDrawable;
    if ((localDrawable != null) && (localDrawable.isVisible())) {
      return mState.getOpacity();
    }
    return -2;
  }
  
  public void getOutline(Outline paramOutline)
  {
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      localDrawable.getOutline(paramOutline);
    }
  }
  
  public boolean getPadding(Rect paramRect)
  {
    Object localObject = mState.add();
    boolean bool;
    if (localObject != null)
    {
      paramRect.set((Rect)localObject);
      if ((left | top | bottom | right) != 0) {
        bool = true;
      } else {
        bool = false;
      }
    }
    else
    {
      localObject = mDrawable;
      if (localObject != null) {
        bool = ((Drawable)localObject).getPadding(paramRect);
      } else {
        bool = super.getPadding(paramRect);
      }
    }
    if (needMirroring())
    {
      int i = left;
      left = right;
      right = i;
    }
    return bool;
  }
  
  public final void inflate(Resources paramResources)
  {
    mState.addChild(paramResources);
  }
  
  public void invalidateDrawable(Drawable paramDrawable)
  {
    DrawableContainerState localDrawableContainerState = mState;
    if (localDrawableContainerState != null) {
      localDrawableContainerState.addChild();
    }
    if ((paramDrawable == mDrawable) && (getCallback() != null)) {
      getCallback().invalidateDrawable(this);
    }
  }
  
  public boolean isAutoMirrored()
  {
    return mState.mDrawable;
  }
  
  public void jumpToCurrentState()
  {
    int i = 0;
    Drawable localDrawable = mCurrDrawable;
    if (localDrawable != null)
    {
      localDrawable.jumpToCurrentState();
      mCurrDrawable = null;
      i = 1;
    }
    localDrawable = mDrawable;
    if (localDrawable != null)
    {
      localDrawable.jumpToCurrentState();
      if (r) {
        mDrawable.setAlpha(mAlpha);
      }
    }
    if (y != 0L)
    {
      y = 0L;
      i = 1;
    }
    if (x != 0L)
    {
      x = 0L;
      i = 1;
    }
    if (i != 0) {
      invalidateSelf();
    }
  }
  
  public Drawable mutate()
  {
    if ((!mMutated) && (super.mutate() == this))
    {
      DrawableContainerState localDrawableContainerState = create();
      localDrawableContainerState.init();
      mutate(localDrawableContainerState);
      mMutated = true;
    }
    return this;
  }
  
  public void mutate(DrawableContainerState paramDrawableContainerState)
  {
    mState = paramDrawableContainerState;
    int i = state;
    if (i >= 0)
    {
      paramDrawableContainerState = paramDrawableContainerState.get(i);
      mDrawable = paramDrawableContainerState;
      if (paramDrawableContainerState != null) {
        draw(paramDrawableContainerState);
      }
    }
    mCurrDrawable = null;
  }
  
  public final boolean needMirroring()
  {
    return (isAutoMirrored()) && (DrawableCompat.getLayoutDirection(this) == 1);
  }
  
  public void onBoundsChange(Rect paramRect)
  {
    Drawable localDrawable = mCurrDrawable;
    if (localDrawable != null) {
      localDrawable.setBounds(paramRect);
    }
    localDrawable = mDrawable;
    if (localDrawable != null) {
      localDrawable.setBounds(paramRect);
    }
  }
  
  public boolean onLayoutDirectionChanged(int paramInt)
  {
    return mState.update(paramInt, get());
  }
  
  public boolean onLevelChange(int paramInt)
  {
    Drawable localDrawable = mCurrDrawable;
    if (localDrawable != null) {
      return localDrawable.setLevel(paramInt);
    }
    localDrawable = mDrawable;
    if (localDrawable != null) {
      return localDrawable.setLevel(paramInt);
    }
    return false;
  }
  
  public boolean onStateChange(int[] paramArrayOfInt)
  {
    Drawable localDrawable = mCurrDrawable;
    if (localDrawable != null) {
      return localDrawable.setState(paramArrayOfInt);
    }
    localDrawable = mDrawable;
    if (localDrawable != null) {
      return localDrawable.setState(paramArrayOfInt);
    }
    return false;
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong)
  {
    if ((paramDrawable == mDrawable) && (getCallback() != null)) {
      getCallback().scheduleDrawable(this, paramRunnable, paramLong);
    }
  }
  
  public void setAlpha(int paramInt)
  {
    if ((!r) || (mAlpha != paramInt))
    {
      r = true;
      mAlpha = paramInt;
      Drawable localDrawable = mDrawable;
      if (localDrawable != null)
      {
        if (x == 0L)
        {
          localDrawable.setAlpha(paramInt);
          return;
        }
        animate(false);
      }
    }
  }
  
  public void setAutoMirrored(boolean paramBoolean)
  {
    Object localObject = mState;
    if (mDrawable != paramBoolean)
    {
      mDrawable = paramBoolean;
      localObject = mDrawable;
      if (localObject != null) {
        DrawableCompat.setAutoMirrored((Drawable)localObject, paramBoolean);
      }
    }
  }
  
  public void setColorFilter(ColorFilter paramColorFilter)
  {
    Object localObject = mState;
    mDrawableState = true;
    if (mState != paramColorFilter)
    {
      mState = paramColorFilter;
      localObject = mDrawable;
      if (localObject != null) {
        ((Drawable)localObject).setColorFilter(paramColorFilter);
      }
    }
  }
  
  public void setDither(boolean paramBoolean)
  {
    Object localObject = mState;
    if (mDither != paramBoolean)
    {
      mDither = paramBoolean;
      localObject = mDrawable;
      if (localObject != null) {
        ((Drawable)localObject).setDither(paramBoolean);
      }
    }
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2)
  {
    Drawable localDrawable = mDrawable;
    if (localDrawable != null) {
      DrawableCompat.setHotspot(localDrawable, paramFloat1, paramFloat2);
    }
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Object localObject = mRect;
    if (localObject == null) {
      mRect = new Rect(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      ((Rect)localObject).set(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    localObject = mDrawable;
    if (localObject != null) {
      DrawableCompat.setHotspotBounds((Drawable)localObject, paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }
  
  public void setTintList(ColorStateList paramColorStateList)
  {
    DrawableContainerState localDrawableContainerState = mState;
    height = true;
    if (mTint != paramColorStateList)
    {
      mTint = paramColorStateList;
      DrawableCompat.setTintList(mDrawable, paramColorStateList);
    }
  }
  
  public void setTintMode(PorterDuff.Mode paramMode)
  {
    DrawableContainerState localDrawableContainerState = mState;
    top = true;
    if (mTintMode != paramMode)
    {
      mTintMode = paramMode;
      DrawableCompat.setTintMode(mDrawable, paramMode);
    }
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    Drawable localDrawable = mCurrDrawable;
    if (localDrawable != null) {
      localDrawable.setVisible(paramBoolean1, paramBoolean2);
    }
    localDrawable = mDrawable;
    if (localDrawable != null) {
      localDrawable.setVisible(paramBoolean1, paramBoolean2);
    }
    return bool;
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable)
  {
    if ((paramDrawable == mDrawable) && (getCallback() != null)) {
      getCallback().unscheduleDrawable(this, paramRunnable);
    }
  }
  
  public abstract class DrawableContainerState
    extends Drawable.ConstantState
  {
    public boolean a = false;
    public boolean b = false;
    public Resources children;
    public SparseArray<Drawable.ConstantState> data;
    public boolean debugEnabled;
    public int flags;
    public boolean height;
    public boolean index;
    public Drawable[] key;
    public int mAlpha = 0;
    public boolean mCanConstantState;
    public boolean mCheckedConstantState;
    public boolean mDither = true;
    public boolean mDrawable;
    public boolean mDrawableState;
    public int mFilter;
    public boolean mHaveOpacity;
    public boolean mHaveStateful;
    public int mHeight;
    public int mMode = 0;
    public int mOpacity;
    public ColorFilter mState;
    public boolean mStateful;
    public ColorStateList mTint;
    public PorterDuff.Mode mTintMode;
    public int mWidth;
    public int parent = 160;
    public int size;
    public final DrawableContainer this$0;
    public boolean top;
    public int type;
    public Rect value;
    public int width;
    public boolean x;
    public int y;
    
    public DrawableContainerState(DrawableContainer paramDrawableContainer, Resources paramResources)
    {
      this$0 = paramDrawableContainer;
      if (paramResources != null) {
        paramDrawableContainer = paramResources;
      } else if (this$1 != null) {
        paramDrawableContainer = children;
      } else {
        paramDrawableContainer = null;
      }
      children = paramDrawableContainer;
      if (this$1 != null) {
        i = parent;
      } else {
        i = 0;
      }
      int i = DrawableContainer.init(paramResources, i);
      parent = i;
      if (this$1 != null)
      {
        flags = flags;
        type = type;
        mCheckedConstantState = true;
        mCanConstantState = true;
        b = b;
        a = a;
        mDither = mDither;
        debugEnabled = debugEnabled;
        mFilter = mFilter;
        mMode = mMode;
        mAlpha = mAlpha;
        mDrawable = mDrawable;
        mState = mState;
        mDrawableState = mDrawableState;
        mTint = mTint;
        mTintMode = mTintMode;
        height = height;
        top = top;
        if (parent == i)
        {
          if (index)
          {
            value = new Rect(value);
            index = true;
          }
          if (x)
          {
            width = width;
            y = y;
            mWidth = mWidth;
            mHeight = mHeight;
            x = true;
          }
        }
        if (mHaveOpacity)
        {
          mOpacity = mOpacity;
          mHaveOpacity = true;
        }
        if (mHaveStateful)
        {
          mStateful = mStateful;
          mHaveStateful = true;
        }
        paramDrawableContainer = key;
        key = new Drawable[paramDrawableContainer.length];
        size = size;
        this$1 = data;
        if (this$1 != null) {
          data = this$1.clone();
        } else {
          data = new SparseArray(size);
        }
        int j = size;
        i = 0;
        while (i < j)
        {
          if (paramDrawableContainer[i] != null)
          {
            this$1 = paramDrawableContainer[i].getConstantState();
            if (this$1 != null) {
              data.put(i, this$1);
            } else {
              key[i] = paramDrawableContainer[i];
            }
          }
          i += 1;
        }
        return;
      }
      key = new Drawable[10];
      size = 0;
    }
    
    public final int a()
    {
      if (!x) {
        draw();
      }
      return y;
    }
    
    public final int add(Drawable paramDrawable)
    {
      int i = size;
      if (i >= key.length) {
        addChild(i, i + 10);
      }
      paramDrawable.mutate();
      paramDrawable.setVisible(false, true);
      paramDrawable.setCallback(this$0);
      key[i] = paramDrawable;
      size += 1;
      type |= paramDrawable.getChangingConfigurations();
      addChild();
      value = null;
      index = false;
      x = false;
      mCheckedConstantState = false;
      return i;
    }
    
    public final Rect add()
    {
      if (b) {
        return null;
      }
      if ((value == null) && (!index))
      {
        remove();
        Object localObject1 = null;
        Rect localRect = new Rect();
        int j = size;
        Drawable[] arrayOfDrawable = key;
        int i = 0;
        while (i < j)
        {
          Object localObject3 = localObject1;
          if (arrayOfDrawable[i].getPadding(localRect))
          {
            Object localObject2 = localObject1;
            if (localObject1 == null) {
              localObject2 = new Rect(0, 0, 0, 0);
            }
            int k = left;
            if (k > left) {
              left = k;
            }
            k = top;
            if (k > top) {
              top = k;
            }
            k = right;
            if (k > right) {
              right = k;
            }
            k = bottom;
            localObject3 = localObject2;
            if (k > bottom)
            {
              bottom = k;
              localObject3 = localObject2;
            }
          }
          i += 1;
          localObject1 = localObject3;
        }
        index = true;
        value = localObject1;
        return localObject1;
      }
      return value;
    }
    
    public void addChild()
    {
      mHaveOpacity = false;
      mHaveStateful = false;
    }
    
    public void addChild(int paramInt1, int paramInt2)
    {
      Drawable[] arrayOfDrawable = new Drawable[paramInt2];
      System.arraycopy(key, 0, arrayOfDrawable, 0, paramInt1);
      key = arrayOfDrawable;
    }
    
    public final void addChild(Resources paramResources)
    {
      if (paramResources != null)
      {
        children = paramResources;
        int i = DrawableContainer.init(paramResources, parent);
        int j = parent;
        parent = i;
        if (j != i)
        {
          x = false;
          index = false;
        }
      }
    }
    
    public final Drawable apply(Drawable paramDrawable)
    {
      if (Build.VERSION.SDK_INT >= 23) {
        paramDrawable.setLayoutDirection(mFilter);
      }
      paramDrawable = paramDrawable.mutate();
      paramDrawable.setCallback(this$0);
      return paramDrawable;
    }
    
    public boolean canApplyTheme()
    {
      int j = size;
      Drawable[] arrayOfDrawable = key;
      int i = 0;
      while (i < j)
      {
        Object localObject = arrayOfDrawable[i];
        if (localObject != null)
        {
          if (((Drawable)localObject).canApplyTheme()) {
            return true;
          }
        }
        else
        {
          localObject = (Drawable.ConstantState)data.get(i);
          if ((localObject != null) && (((Drawable.ConstantState)localObject).canApplyTheme())) {
            return true;
          }
        }
        i += 1;
      }
      return false;
    }
    
    public boolean canConstantState()
    {
      try
      {
        if (mCheckedConstantState)
        {
          boolean bool = mCanConstantState;
          return bool;
        }
        remove();
        mCheckedConstantState = true;
        int j = size;
        Drawable[] arrayOfDrawable = key;
        int i = 0;
        while (i < j)
        {
          if (arrayOfDrawable[i].getConstantState() == null)
          {
            mCanConstantState = false;
            return false;
          }
          i += 1;
        }
        mCanConstantState = true;
        return true;
      }
      catch (Throwable localThrowable)
      {
        throw localThrowable;
      }
    }
    
    public void draw()
    {
      x = true;
      remove();
      int j = size;
      Drawable[] arrayOfDrawable = key;
      y = -1;
      width = -1;
      mHeight = 0;
      mWidth = 0;
      int i = 0;
      while (i < j)
      {
        Drawable localDrawable = arrayOfDrawable[i];
        int k = localDrawable.getIntrinsicWidth();
        if (k > width) {
          width = k;
        }
        k = localDrawable.getIntrinsicHeight();
        if (k > y) {
          y = k;
        }
        k = localDrawable.getMinimumWidth();
        if (k > mWidth) {
          mWidth = k;
        }
        k = localDrawable.getMinimumHeight();
        if (k > mHeight) {
          mHeight = k;
        }
        i += 1;
      }
    }
    
    public final Drawable get(int paramInt)
    {
      Object localObject = key[paramInt];
      if (localObject != null) {
        return localObject;
      }
      localObject = data;
      if (localObject != null)
      {
        int i = ((SparseArray)localObject).indexOfKey(paramInt);
        if (i >= 0)
        {
          localObject = apply(((Drawable.ConstantState)data.valueAt(i)).newDrawable(children));
          key[paramInt] = localObject;
          data.removeAt(i);
          if (data.size() != 0) {
            return localObject;
          }
          data = null;
          return localObject;
        }
      }
      return null;
      return localObject;
    }
    
    public final boolean get()
    {
      return a;
    }
    
    public int getChangingConfigurations()
    {
      return flags | type;
    }
    
    public final int getChildCount()
    {
      return size;
    }
    
    public final int getChildren()
    {
      return key.length;
    }
    
    public final int getMinimumHeight()
    {
      if (!x) {
        draw();
      }
      return mHeight;
    }
    
    public final int getMinimumWidth()
    {
      if (!x) {
        draw();
      }
      return mWidth;
    }
    
    public final int getOpacity()
    {
      if (mHaveOpacity) {
        return mOpacity;
      }
      remove();
      int k = size;
      Drawable[] arrayOfDrawable = key;
      int i;
      if (k > 0) {
        i = arrayOfDrawable[0].getOpacity();
      } else {
        i = -2;
      }
      int j = 1;
      while (j < k)
      {
        i = Drawable.resolveOpacity(i, arrayOfDrawable[j].getOpacity());
        j += 1;
      }
      mOpacity = i;
      mHaveOpacity = true;
      return i;
    }
    
    public final int getWidth()
    {
      if (!x) {
        draw();
      }
      return width;
    }
    
    public abstract void init();
    
    public final void init(Resources.Theme paramTheme)
    {
      if (paramTheme != null)
      {
        remove();
        int j = size;
        Drawable[] arrayOfDrawable = key;
        int i = 0;
        while (i < j)
        {
          if ((arrayOfDrawable[i] != null) && (arrayOfDrawable[i].canApplyTheme()))
          {
            arrayOfDrawable[i].applyTheme(paramTheme);
            type |= arrayOfDrawable[i].getChangingConfigurations();
          }
          i += 1;
        }
        addChild(paramTheme.getResources());
      }
    }
    
    public final void remove()
    {
      Object localObject = data;
      if (localObject != null)
      {
        int j = ((SparseArray)localObject).size();
        int i = 0;
        while (i < j)
        {
          int k = data.keyAt(i);
          localObject = (Drawable.ConstantState)data.valueAt(i);
          key[k] = apply(((Drawable.ConstantState)localObject).newDrawable(children));
          i += 1;
        }
        data = null;
      }
    }
    
    public final void set(boolean paramBoolean)
    {
      b = paramBoolean;
    }
    
    public final void setEnterFadeDuration(int paramInt)
    {
      mMode = paramInt;
    }
    
    public final void setExitFadeDuration(int paramInt)
    {
      mAlpha = paramInt;
    }
    
    public final boolean update(int paramInt1, int paramInt2)
    {
      boolean bool2 = false;
      int j = size;
      Drawable[] arrayOfDrawable = key;
      int i = 0;
      while (i < j)
      {
        boolean bool3 = bool2;
        if (arrayOfDrawable[i] != null)
        {
          boolean bool1 = false;
          if (Build.VERSION.SDK_INT >= 23) {
            bool1 = arrayOfDrawable[i].setLayoutDirection(paramInt1);
          }
          bool3 = bool2;
          if (i == paramInt2) {
            bool3 = bool1;
          }
        }
        i += 1;
        bool2 = bool3;
      }
      mFilter = paramInt1;
      return bool2;
    }
    
    public final void write(boolean paramBoolean)
    {
      a = paramBoolean;
    }
  }
}
