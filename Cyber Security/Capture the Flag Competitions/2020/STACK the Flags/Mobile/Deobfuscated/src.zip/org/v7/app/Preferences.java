package org.v7.app;

import android.view.MenuItem;
import android.view.Window.Callback;
import androidx.appcompat.widget.Toolbar.f;

public class Preferences
  implements Toolbar.f
{
  public Preferences(ToolbarActionBar paramToolbarActionBar) {}
  
  public boolean onMenuItemSelected(MenuItem paramMenuItem)
  {
    return this$0.mWindowCallback.onMenuItemSelected(0, paramMenuItem);
  }
}
