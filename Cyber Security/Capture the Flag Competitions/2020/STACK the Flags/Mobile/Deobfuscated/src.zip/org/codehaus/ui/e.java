package org.codehaus.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;

public class e
{
  public float a = NaN.0F;
  public float b = NaN.0F;
  public float c = NaN.0F;
  public float f = NaN.0F;
  public int h = -1;
  public Item k;
  
  public e(Context paramContext, XmlPullParser paramXmlPullParser)
  {
    paramXmlPullParser = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), IpAddress.Variant);
    int j = paramXmlPullParser.getIndexCount();
    int i = 0;
    while (i < j)
    {
      int m = paramXmlPullParser.getIndex(i);
      if (m == IpAddress.Variant_constraints)
      {
        h = paramXmlPullParser.getResourceId(m, h);
        Object localObject = paramContext.getResources().getResourceTypeName(h);
        paramContext.getResources().getResourceName(h);
        if ("layout".equals(localObject))
        {
          localObject = new Item();
          k = ((Item)localObject);
          ((Item)localObject).b(paramContext, h);
        }
      }
      else if (m == IpAddress.Variant_region_heightLessThan)
      {
        a = paramXmlPullParser.getDimension(m, a);
      }
      else if (m == IpAddress.Variant_region_heightMoreThan)
      {
        f = paramXmlPullParser.getDimension(m, f);
      }
      else if (m == IpAddress.Variant_region_widthLessThan)
      {
        c = paramXmlPullParser.getDimension(m, c);
      }
      else if (m == IpAddress.Variant_region_widthMoreThan)
      {
        b = paramXmlPullParser.getDimension(m, b);
      }
      else
      {
        Log.v("ConstraintLayoutStates", "Unknown tag");
      }
      i += 1;
    }
    paramXmlPullParser.recycle();
  }
}
