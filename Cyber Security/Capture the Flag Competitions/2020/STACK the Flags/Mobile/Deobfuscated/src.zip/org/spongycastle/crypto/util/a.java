package org.spongycastle.crypto.util;

public class a
  extends f
{
  public static volatile a j;
  public f c;
  public f d;
  
  static
  {
    new Threading.2();
    new AsyncTask.SerialExecutor();
  }
  
  public a()
  {
    DiskLruCache localDiskLruCache = new DiskLruCache();
    d = localDiskLruCache;
    c = localDiskLruCache;
  }
  
  public static a a()
  {
    if (j != null) {
      return j;
    }
    try
    {
      if (j == null) {
        j = new a();
      }
      return j;
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
  
  public void close(Runnable paramRunnable)
  {
    c.close(paramRunnable);
  }
  
  public boolean close()
  {
    return c.close();
  }
  
  public void remove(Runnable paramRunnable)
  {
    c.remove(paramRunnable);
  }
}
