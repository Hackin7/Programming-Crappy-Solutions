package org.codehaus.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.util.TypedValue;

public class Switch
{
  public static SparseIntArray mTextColors;
  public int a = 0;
  public String c = null;
  public float h = NaN.0F;
  public boolean i = false;
  public int type = -1;
  public float w = NaN.0F;
  public int y = -1;
  
  static
  {
    SparseIntArray localSparseIntArray = new SparseIntArray();
    mTextColors = localSparseIntArray;
    localSparseIntArray.append(IpAddress.Motion_motionPathRotate, 1);
    mTextColors.append(IpAddress.Motion_pathMotionArc, 2);
    mTextColors.append(IpAddress.Motion_transitionEasing, 3);
    mTextColors.append(IpAddress.Motion_drawPath, 4);
    mTextColors.append(IpAddress.Motion_animate_relativeTo, 5);
    mTextColors.append(IpAddress.Motion_motionStagger, 6);
  }
  
  public Switch() {}
  
  public void a(Switch paramSwitch)
  {
    i = i;
    type = type;
    c = c;
    y = y;
    a = a;
    w = w;
    h = h;
  }
  
  public void applyStyle(Context paramContext, AttributeSet paramAttributeSet)
  {
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.Motion);
    i = true;
    int k = paramContext.getIndexCount();
    int j = 0;
    while (j < k)
    {
      int m = paramContext.getIndex(j);
      switch (mTextColors.get(m))
      {
      default: 
        break;
      case 6: 
        h = paramContext.getFloat(m, h);
        break;
      case 5: 
        type = Item.getString(paramContext, m, type);
        break;
      case 4: 
        a = paramContext.getInt(m, 0);
        break;
      case 3: 
        if (peekValuetype == 3) {
          c = paramContext.getString(m);
        } else {
          c = org.codehaus.converters.special.Unit.type[paramContext.getInteger(m, 0)];
        }
        break;
      case 2: 
        y = paramContext.getInt(m, y);
        break;
      case 1: 
        w = paramContext.getFloat(m, w);
      }
      j += 1;
    }
    paramContext.recycle();
  }
}
