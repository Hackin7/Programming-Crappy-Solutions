package org.jdom;

import android.os.Parcelable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.data.Context;
import org.data.Label;

public abstract class Attribute
{
  public final a.e.a<String, Class> a;
  public final a.e.a<String, Method> b;
  public final a.e.a<String, Method> c;
  
  public Attribute(Label paramLabel1, Label paramLabel2, Label paramLabel3)
  {
    c = paramLabel1;
    b = paramLabel2;
    a = paramLabel3;
  }
  
  public int a(int paramInt1, int paramInt2)
  {
    if (!a(paramInt2)) {
      return paramInt1;
    }
    return read();
  }
  
  public abstract void a();
  
  public abstract void a(java.lang.CharSequence paramCharSequence);
  
  public void a(java.lang.CharSequence paramCharSequence, int paramInt)
  {
    write(paramInt);
    a(paramCharSequence);
  }
  
  public void a(String paramString, int paramInt)
  {
    write(paramInt);
    write(paramString);
  }
  
  public void a(CharSequence paramCharSequence, int paramInt)
  {
    write(paramInt);
    d(paramCharSequence);
  }
  
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean a(int paramInt);
  
  public abstract Parcelable add();
  
  public Parcelable add(Parcelable paramParcelable, int paramInt)
  {
    if (!a(paramInt)) {
      return paramParcelable;
    }
    return add();
  }
  
  public java.lang.CharSequence add(java.lang.CharSequence paramCharSequence, int paramInt)
  {
    if (!a(paramInt)) {
      return paramCharSequence;
    }
    return getQueueTitle();
  }
  
  public abstract Attribute b();
  
  public void d(CharSequence paramCharSequence)
  {
    if (paramCharSequence == null)
    {
      write(null);
      return;
    }
    write(paramCharSequence);
    Attribute localAttribute = b();
    set(paramCharSequence, localAttribute);
    localAttribute.a();
  }
  
  public final Class get(Class paramClass)
  {
    Class localClass2 = (Class)a.get(paramClass.getName());
    Class localClass1 = localClass2;
    if (localClass2 == null)
    {
      localClass1 = Class.forName(String.format("%s.%sParcelizer", new Object[] { paramClass.getPackage().getName(), paramClass.getSimpleName() }), false, paramClass.getClassLoader());
      a.put(paramClass.getName(), localClass1);
    }
    return localClass1;
  }
  
  public final Method get(String paramString)
  {
    Method localMethod2 = (Method)c.get(paramString);
    Method localMethod1 = localMethod2;
    if (localMethod2 == null)
    {
      System.currentTimeMillis();
      localMethod1 = Class.forName(paramString, true, a.t.a.class.getClassLoader()).getDeclaredMethod("read", new Class[] { a.t.a.class });
      c.put(paramString, localMethod1);
    }
    return localMethod1;
  }
  
  public CharSequence get(CharSequence paramCharSequence, int paramInt)
  {
    if (!a(paramInt)) {
      return paramCharSequence;
    }
    return getName();
  }
  
  public abstract void get(int paramInt);
  
  public abstract byte[] get();
  
  public void getBytes(byte[] paramArrayOfByte, int paramInt)
  {
    write(paramInt);
    write(paramArrayOfByte);
  }
  
  public CharSequence getName()
  {
    String str = getValue();
    if (str == null) {
      return null;
    }
    return toString(str, b());
  }
  
  public abstract java.lang.CharSequence getQueueTitle();
  
  public abstract String getValue();
  
  public void name() {}
  
  public void put(Parcelable paramParcelable, int paramInt)
  {
    write(paramInt);
    write(paramParcelable);
  }
  
  public abstract int read();
  
  public byte[] read(byte[] paramArrayOfByte, int paramInt)
  {
    if (!a(paramInt)) {
      return paramArrayOfByte;
    }
    return get();
  }
  
  public String set(String paramString, int paramInt)
  {
    if (!a(paramInt)) {
      return paramString;
    }
    return getValue();
  }
  
  public void set(CharSequence paramCharSequence, Attribute paramAttribute)
  {
    try
    {
      Method localMethod = write(paramCharSequence.getClass());
      localMethod.invoke(null, new Object[] { paramCharSequence, paramAttribute });
      return;
    }
    catch (ClassNotFoundException paramCharSequence)
    {
      throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", paramCharSequence);
    }
    catch (NoSuchMethodException paramCharSequence)
    {
      throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", paramCharSequence);
    }
    catch (InvocationTargetException paramCharSequence)
    {
      if ((paramCharSequence.getCause() instanceof RuntimeException)) {
        throw ((RuntimeException)paramCharSequence.getCause());
      }
      throw new RuntimeException("VersionedParcel encountered InvocationTargetException", paramCharSequence);
    }
    catch (IllegalAccessException paramCharSequence)
    {
      throw new RuntimeException("VersionedParcel encountered IllegalAccessException", paramCharSequence);
    }
  }
  
  public boolean set(boolean paramBoolean, int paramInt)
  {
    if (!a(paramInt)) {
      return paramBoolean;
    }
    return write();
  }
  
  public CharSequence toString(String paramString, Attribute paramAttribute)
  {
    try
    {
      paramString = get(paramString);
      paramString = paramString.invoke(null, new Object[] { paramAttribute });
      return (CharSequence)paramString;
    }
    catch (ClassNotFoundException paramString)
    {
      throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", paramString);
    }
    catch (NoSuchMethodException paramString)
    {
      throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", paramString);
    }
    catch (InvocationTargetException paramString)
    {
      if ((paramString.getCause() instanceof RuntimeException)) {
        throw ((RuntimeException)paramString.getCause());
      }
      throw new RuntimeException("VersionedParcel encountered InvocationTargetException", paramString);
    }
    catch (IllegalAccessException paramString)
    {
      throw new RuntimeException("VersionedParcel encountered IllegalAccessException", paramString);
    }
  }
  
  public final Method write(Class paramClass)
  {
    Method localMethod = (Method)b.get(paramClass.getName());
    Object localObject = localMethod;
    if (localMethod == null)
    {
      localObject = get(paramClass);
      System.currentTimeMillis();
      localObject = ((Class)localObject).getDeclaredMethod("write", new Class[] { paramClass, a.t.a.class });
      b.put(paramClass.getName(), localObject);
    }
    return localObject;
  }
  
  public abstract void write(int paramInt);
  
  public void write(int paramInt1, int paramInt2)
  {
    write(paramInt2);
    get(paramInt1);
  }
  
  public abstract void write(Parcelable paramParcelable);
  
  public abstract void write(String paramString);
  
  public final void write(CharSequence paramCharSequence)
  {
    try
    {
      Class localClass = get(paramCharSequence.getClass());
      write(localClass.getName());
      return;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramCharSequence.getClass().getSimpleName());
      localStringBuilder.append(" does not have a Parcelizer");
      throw new RuntimeException(localStringBuilder.toString(), localClassNotFoundException);
    }
  }
  
  public void write(boolean paramBoolean, int paramInt)
  {
    write(paramInt);
    a(paramBoolean);
  }
  
  public abstract void write(byte[] paramArrayOfByte);
  
  public abstract boolean write();
  
  public boolean writeObject()
  {
    return false;
  }
}
