package org.asm;

import android.animation.TimeInterpolator;
import android.util.AndroidRuntimeException;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;

public class h
  extends l
{
  public ArrayList<a.r.l> a = new ArrayList();
  public boolean c = true;
  public int h = 0;
  public int n;
  public boolean s = false;
  
  public h() {}
  
  public String a(String paramString)
  {
    Object localObject = super.a(paramString);
    int i = 0;
    while (i < a.size())
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      localStringBuilder1.append((String)localObject);
      localStringBuilder1.append("\n");
      localObject = (l)a.get(i);
      StringBuilder localStringBuilder2 = new StringBuilder();
      localStringBuilder2.append(paramString);
      localStringBuilder2.append("  ");
      localStringBuilder1.append(((l)localObject).a(localStringBuilder2.toString()));
      localObject = localStringBuilder1.toString();
      i += 1;
    }
    return localObject;
  }
  
  public h a(long paramLong)
  {
    super.b(paramLong);
    if (e >= 0L)
    {
      int j = a.size();
      int i = 0;
      while (i < j)
      {
        ((l)a.get(i)).b(paramLong);
        i += 1;
      }
    }
    return this;
  }
  
  public h a(TimeInterpolator paramTimeInterpolator)
  {
    h |= 0x1;
    ArrayList localArrayList = a;
    if (localArrayList != null)
    {
      int j = localArrayList.size();
      int i = 0;
      while (i < j)
      {
        ((l)a.get(i)).b(paramTimeInterpolator);
        i += 1;
      }
    }
    super.b(paramTimeInterpolator);
    return (h)this;
  }
  
  public h a(l paramL)
  {
    a.add(paramL);
    g = this;
    long l = e;
    if (l >= 0L) {
      paramL.b(l);
    }
    if ((h & 0x1) != 0) {
      paramL.b(onCloseMenu());
    }
    if ((h & 0x2) != 0)
    {
      setCallback();
      paramL.a(null);
    }
    if ((h & 0x4) != 0) {
      paramL.a(visitAnnotation());
    }
    if ((h & 0x8) != 0) {
      paramL.a(f());
    }
    return this;
  }
  
  public l a(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < a.size())) {
      return (l)a.get(paramInt);
    }
    return null;
  }
  
  public void a(ViewGroup paramViewGroup, x paramX1, x paramX2, ArrayList paramArrayList1, ArrayList paramArrayList2)
  {
    long l1 = next();
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      l localL = (l)a.get(i);
      if ((l1 > 0L) && ((c) || (i == 0)))
      {
        long l2 = localL.next();
        if (l2 > 0L) {
          localL.f(l1 + l2);
        } else {
          localL.f(l1);
        }
      }
      localL.a(paramViewGroup, paramX1, paramX2, paramArrayList1, paramArrayList2);
      i += 1;
    }
  }
  
  public void a(AnnotationVisitor paramAnnotationVisitor)
  {
    super.a(paramAnnotationVisitor);
    h |= 0x4;
    int i = 0;
    while (i < a.size())
    {
      ((l)a.get(i)).a(paramAnnotationVisitor);
      i += 1;
    }
  }
  
  public void a(ClassVisitor paramClassVisitor)
  {
    super.a(paramClassVisitor);
    h |= 0x2;
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((l)a.get(i)).a(paramClassVisitor);
      i += 1;
    }
  }
  
  public void a(Label paramLabel)
  {
    if (a(a))
    {
      Iterator localIterator = a.iterator();
      while (localIterator.hasNext())
      {
        l localL = (l)localIterator.next();
        if (localL.a(a))
        {
          localL.a(paramLabel);
          b.add(localL);
        }
      }
    }
  }
  
  public void a(Message paramMessage)
  {
    super.a(paramMessage);
    h |= 0x8;
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((l)a.get(i)).a(paramMessage);
      i += 1;
    }
  }
  
  public void accept(View paramView)
  {
    super.accept(paramView);
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((l)a.get(i)).accept(paramView);
      i += 1;
    }
  }
  
  public l b()
  {
    h localH = (h)super.b();
    a = new ArrayList();
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      localH.a(((l)a.get(i)).b());
      i += 1;
    }
    return localH;
  }
  
  public void b(Label paramLabel)
  {
    if (a(a))
    {
      Iterator localIterator = a.iterator();
      while (localIterator.hasNext())
      {
        l localL = (l)localIterator.next();
        if (localL.a(a))
        {
          localL.b(paramLabel);
          b.add(localL);
        }
      }
    }
  }
  
  public h c(int paramInt)
  {
    if (paramInt != 0)
    {
      if (paramInt == 1)
      {
        c = false;
        return this;
      }
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("Invalid parameter for TransitionSet ordering: ");
      localStringBuilder.append(paramInt);
      throw new AndroidRuntimeException(localStringBuilder.toString());
    }
    c = true;
    return this;
  }
  
  public h c(long paramLong)
  {
    super.f(paramLong);
    return (h)this;
  }
  
  public h c(View paramView)
  {
    int i = 0;
    while (i < a.size())
    {
      ((l)a.get(i)).b(paramView);
      i += 1;
    }
    super.b(paramView);
    return (h)this;
  }
  
  public h c(m paramM)
  {
    super.a(paramM);
    return (h)this;
  }
  
  public void c(Label paramLabel)
  {
    super.c(paramLabel);
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((l)a.get(i)).c(paramLabel);
      i += 1;
    }
  }
  
  public h d(View paramView)
  {
    int i = 0;
    while (i < a.size())
    {
      ((l)a.get(i)).get(paramView);
      i += 1;
    }
    super.get(paramView);
    return (h)this;
  }
  
  public final void d()
  {
    Frame localFrame = new Frame(this);
    Iterator localIterator = a.iterator();
    while (localIterator.hasNext()) {
      ((l)localIterator.next()).a(localFrame);
    }
    n = a.size();
  }
  
  public void draw()
  {
    if (a.isEmpty())
    {
      e();
      a();
      return;
    }
    d();
    if (!c)
    {
      int i = 1;
      while (i < a.size())
      {
        ((l)a.get(i - 1)).a(new AnnotationWriter(this, (l)a.get(i)));
        i += 1;
      }
      localObject = (l)a.get(0);
      if (localObject != null) {
        ((l)localObject).draw();
      }
      return;
    }
    Object localObject = a.iterator();
    while (((Iterator)localObject).hasNext()) {
      ((l)((Iterator)localObject).next()).draw();
    }
  }
  
  public void draw(View paramView)
  {
    super.draw(paramView);
    int j = a.size();
    int i = 0;
    while (i < j)
    {
      ((l)a.get(i)).draw(paramView);
      i += 1;
    }
  }
  
  public int k()
  {
    return a.size();
  }
  
  public h k(m paramM)
  {
    super.b(paramM);
    return (h)this;
  }
}
