package org.codehaus.asm.asm.asm;

public abstract interface l
{
  public abstract void a(l paramL);
}
