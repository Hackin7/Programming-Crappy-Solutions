package org.v7.widget;

import android.graphics.Typeface;
import android.os.Build.VERSION;
import java.lang.ref.WeakReference;
import org.core.fonts.data.Label;

public class ClassWriter
  extends Label
{
  public ClassWriter(TimePicker paramTimePicker, int paramInt1, int paramInt2, WeakReference paramWeakReference) {}
  
  public void a(int paramInt) {}
  
  public void a(Typeface paramTypeface)
  {
    Typeface localTypeface = paramTypeface;
    if (Build.VERSION.SDK_INT >= 28)
    {
      int i = c;
      localTypeface = paramTypeface;
      if (i != -1)
      {
        boolean bool;
        if ((b & 0x2) != 0) {
          bool = true;
        } else {
          bool = false;
        }
        localTypeface = Typeface.create(paramTypeface, i, bool);
      }
    }
    v.init(a, localTypeface);
  }
}
