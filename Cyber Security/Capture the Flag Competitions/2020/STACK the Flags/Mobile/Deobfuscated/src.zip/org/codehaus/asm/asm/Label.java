package org.codehaus.asm.asm;

import a.f.b.i.d;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.codehaus.asm.asm.asm.ClassReader;

public class Label
{
  public Label a;
  public final f b;
  public HashSet<d> c = null;
  public final c d;
  public int h = -1;
  public org.codehaus.asm.Label i;
  public int j = 0;
  public boolean k;
  public int m;
  
  public Label(f paramF, c paramC)
  {
    b = paramF;
    d = paramC;
  }
  
  public void a()
  {
    Object localObject = a;
    if (localObject != null)
    {
      localObject = c;
      if (localObject != null)
      {
        ((HashSet)localObject).remove(this);
        if (a.c.size() == 0) {
          a.c = null;
        }
      }
    }
    c = null;
    a = null;
    j = 0;
    h = -1;
    k = false;
    m = 0;
  }
  
  public void a(int paramInt)
  {
    m = paramInt;
    k = true;
  }
  
  public void a(int paramInt, ArrayList paramArrayList, org.codehaus.asm.asm.asm.i paramI)
  {
    Object localObject = c;
    if (localObject != null)
    {
      localObject = ((HashSet)localObject).iterator();
      while (((Iterator)localObject).hasNext()) {
        ClassReader.a(nextb, paramInt, paramArrayList, paramI);
      }
    }
  }
  
  public boolean a(Label paramLabel)
  {
    boolean bool4 = false;
    boolean bool3 = false;
    if (paramLabel == null) {
      return false;
    }
    c localC1 = paramLabel.e();
    c localC2 = d;
    boolean bool2;
    if (localC1 == localC2)
    {
      if (localC2 == c.g)
      {
        if (paramLabel.getName().j())
        {
          if (getName().j()) {
            break label314;
          }
          return false;
        }
      }
      else {
        return true;
      }
    }
    else
    {
      boolean bool1;
      switch (localC2.ordinal())
      {
      default: 
        throw new AssertionError(d.name());
      case 0: 
      case 5: 
      case 7: 
      case 8: 
        return false;
      case 2: 
      case 4: 
        if ((localC1 != c.a) && (localC1 != c.b)) {
          bool1 = false;
        } else {
          bool1 = true;
        }
        bool2 = bool1;
        if (!(paramLabel.getName() instanceof i)) {
          break;
        }
        if (!bool1)
        {
          bool1 = bool3;
          if (localC1 != c.f) {}
        }
        else
        {
          bool1 = true;
        }
        return bool1;
      case 1: 
      case 3: 
        if ((localC1 != c.d) && (localC1 != c.i)) {
          bool1 = false;
        } else {
          bool1 = true;
        }
        bool2 = bool1;
        if (!(paramLabel.getName() instanceof i)) {
          break;
        }
        if (!bool1)
        {
          bool1 = bool4;
          if (localC1 != c.c) {}
        }
        else
        {
          bool1 = true;
        }
        return bool1;
      case 6: 
        if ((localC1 == c.g) || (localC1 == c.c) || (localC1 == c.f)) {
          break label318;
        }
        return true;
      }
    }
    return false;
    label314:
    return true;
    return bool2;
    label318:
    return false;
  }
  
  public boolean a(Label paramLabel, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramLabel == null)
    {
      a();
      return true;
    }
    if ((!paramBoolean) && (!a(paramLabel))) {
      return false;
    }
    a = paramLabel;
    if (c == null) {
      c = new HashSet();
    }
    paramLabel = a.c;
    if (paramLabel != null) {
      paramLabel.add(this);
    }
    if (paramInt1 > 0) {
      j = paramInt1;
    } else {
      j = 0;
    }
    h = paramInt2;
    return true;
  }
  
  public boolean add()
  {
    HashSet localHashSet = c;
    if (localHashSet == null) {
      return false;
    }
    return localHashSet.size() > 0;
  }
  
  public int b()
  {
    if (b.length() == 8) {
      return 0;
    }
    if (h > -1)
    {
      Label localLabel = a;
      if ((localLabel != null) && (b.length() == 8)) {
        return h;
      }
    }
    return j;
  }
  
  public org.codehaus.asm.Label c()
  {
    return i;
  }
  
  public int d()
  {
    if (!k) {
      return 0;
    }
    return m;
  }
  
  public boolean draw()
  {
    Object localObject = c;
    if (localObject == null) {
      return false;
    }
    localObject = ((HashSet)localObject).iterator();
    while (((Iterator)localObject).hasNext()) {
      if (((Label)((Iterator)localObject).next()).getValue().put()) {
        return true;
      }
    }
    return false;
  }
  
  public c e()
  {
    return d;
  }
  
  public boolean equals()
  {
    return k;
  }
  
  public HashSet get()
  {
    return c;
  }
  
  public f getName()
  {
    return b;
  }
  
  public Label getText()
  {
    return a;
  }
  
  public final Label getValue()
  {
    switch (d.ordinal())
    {
    default: 
      throw new AssertionError(d.name());
    case 4: 
      return b.a;
    case 2: 
      return b.g;
    case 3: 
      return b.b;
    case 1: 
      return b.i;
    }
    return null;
  }
  
  public boolean put()
  {
    return a != null;
  }
  
  public void setIcon()
  {
    k = false;
    m = 0;
  }
  
  public void setText()
  {
    org.codehaus.asm.Label localLabel = i;
    if (localLabel == null)
    {
      i = new org.codehaus.asm.Label(org.codehaus.asm.c.a);
      return;
    }
    localLabel.a();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(b.getString());
    localStringBuilder.append(":");
    localStringBuilder.append(d.toString());
    return localStringBuilder.toString();
  }
}
