package org.miscwidgets.widget;

public abstract interface CardViewDelegate {}
