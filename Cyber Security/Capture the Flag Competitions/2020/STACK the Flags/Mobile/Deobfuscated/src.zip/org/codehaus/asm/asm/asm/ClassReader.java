package org.codehaus.asm.asm.asm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.codehaus.asm.asm.Label;
import org.codehaus.asm.asm.MethodWriter;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.b;
import org.codehaus.asm.asm.c;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.h;
import org.codehaus.asm.asm.m;

public class ClassReader
{
  public static i a(ArrayList paramArrayList, int paramInt)
  {
    int j = paramArrayList.size();
    int i = 0;
    while (i < j)
    {
      i localI = (i)paramArrayList.get(i);
      if (paramInt == b) {
        return localI;
      }
      i += 1;
    }
    return null;
  }
  
  public static i a(f paramF, int paramInt, ArrayList paramArrayList, i paramI)
  {
    int i;
    if (paramInt == 0) {
      i = B;
    } else {
      i = Q;
    }
    int j;
    Object localObject;
    if ((i != -1) && ((paramI == null) || (i != b)))
    {
      j = 0;
      for (;;)
      {
        localObject = paramI;
        if (j >= paramArrayList.size()) {
          break;
        }
        localObject = (i)paramArrayList.get(j);
        if (((i)localObject).a() == i)
        {
          if (paramI != null)
          {
            paramI.a(paramInt, (i)localObject);
            paramArrayList.remove(paramI);
          }
          break;
        }
        j += 1;
      }
    }
    else
    {
      localObject = paramI;
      if (i != -1) {
        return paramI;
      }
    }
    paramI = (i)localObject;
    if (localObject == null)
    {
      paramI = (i)localObject;
      if ((paramF instanceof m))
      {
        j = ((m)paramF).a(paramInt);
        paramI = (i)localObject;
        if (j != -1)
        {
          i = 0;
          for (;;)
          {
            paramI = (i)localObject;
            if (i >= paramArrayList.size()) {
              break;
            }
            paramI = (i)paramArrayList.get(i);
            if (paramI.a() == j) {
              break;
            }
            i += 1;
          }
        }
      }
      localObject = paramI;
      if (paramI == null) {
        localObject = new i(paramInt);
      }
      paramArrayList.add(localObject);
      paramI = (i)localObject;
    }
    if (paramI.a(paramF))
    {
      if ((paramF instanceof org.codehaus.asm.asm.i))
      {
        localObject = (org.codehaus.asm.asm.i)paramF;
        Label localLabel = ((org.codehaus.asm.asm.i)localObject).a();
        if (((org.codehaus.asm.asm.i)localObject).k() == 0) {
          i = 1;
        } else {
          i = 0;
        }
        localLabel.a(i, paramArrayList, paramI);
      }
      if (paramInt == 0)
      {
        B = paramI.a();
        b.a(paramInt, paramArrayList, paramI);
        paramF.i.a(paramInt, paramArrayList, paramI);
      }
      else
      {
        Q = paramI.a();
        a.a(paramInt, paramArrayList, paramI);
        u.a(paramInt, paramArrayList, paramI);
        g.a(paramInt, paramArrayList, paramI);
      }
      N.a(paramInt, paramArrayList, paramI);
    }
    return paramI;
  }
  
  public static boolean a(MethodWriter paramMethodWriter, Item paramItem)
  {
    ArrayList localArrayList = paramMethodWriter.m();
    int j = localArrayList.size();
    Object localObject6 = null;
    Object localObject3 = null;
    Object localObject2 = null;
    Object localObject1 = null;
    Object localObject5 = null;
    Object localObject4 = null;
    int i = 0;
    while (i < j)
    {
      localObject7 = (f)localArrayList.get(i);
      if (!a(paramMethodWriter.doubleValue(), paramMethodWriter.get(), ((f)localObject7).doubleValue(), ((f)localObject7).get())) {
        return false;
      }
      i += 1;
    }
    i = 0;
    while (i < j)
    {
      f localF = (f)localArrayList.get(i);
      if (!a(paramMethodWriter.doubleValue(), paramMethodWriter.get(), localF.doubleValue(), localF.get())) {
        MethodWriter.a(localF, paramItem, paramMethodWriter.j, false);
      }
      Object localObject10 = localObject6;
      Object localObject9 = localObject3;
      if ((localF instanceof org.codehaus.asm.asm.i))
      {
        localObject8 = (org.codehaus.asm.asm.i)localF;
        localObject7 = localObject3;
        if (((org.codehaus.asm.asm.i)localObject8).k() == 0)
        {
          localObject7 = localObject3;
          if (localObject3 == null) {
            localObject7 = new ArrayList();
          }
          ((ArrayList)localObject7).add(localObject8);
        }
        localObject10 = localObject6;
        localObject9 = localObject7;
        if (((org.codehaus.asm.asm.i)localObject8).k() == 1)
        {
          localObject3 = localObject6;
          if (localObject6 == null) {
            localObject3 = new ArrayList();
          }
          ((ArrayList)localObject3).add(localObject8);
          localObject9 = localObject7;
          localObject10 = localObject3;
        }
      }
      localObject7 = localObject2;
      Object localObject8 = localObject1;
      if ((localF instanceof m)) {
        if ((localF instanceof h))
        {
          localObject3 = (h)localF;
          localObject7 = localObject2;
          if (((h)localObject3).getItemId() == 0)
          {
            localObject7 = localObject2;
            if (localObject2 == null) {
              localObject7 = new ArrayList();
            }
            ((ArrayList)localObject7).add(localObject3);
          }
          localObject8 = localObject1;
          if (((h)localObject3).getItemId() == 1)
          {
            localObject8 = localObject1;
            if (localObject1 == null) {
              localObject8 = new ArrayList();
            }
            ((ArrayList)localObject8).add(localObject3);
          }
        }
        else
        {
          localObject3 = (m)localF;
          localObject7 = localObject2;
          if (localObject2 == null) {
            localObject7 = new ArrayList();
          }
          ((ArrayList)localObject7).add(localObject3);
          localObject8 = localObject1;
          if (localObject1 == null) {
            localObject8 = new ArrayList();
          }
          ((ArrayList)localObject8).add(localObject3);
        }
      }
      Object localObject11 = localObject5;
      if (b.a == null)
      {
        localObject11 = localObject5;
        if (i.a == null)
        {
          localObject11 = localObject5;
          if (!(localF instanceof org.codehaus.asm.asm.i))
          {
            localObject11 = localObject5;
            if (!(localF instanceof h))
            {
              localObject1 = localObject5;
              if (localObject5 == null) {
                localObject1 = new ArrayList();
              }
              ((ArrayList)localObject1).add(localF);
              localObject11 = localObject1;
            }
          }
        }
      }
      Object localObject12 = localObject4;
      if (a.a == null)
      {
        localObject12 = localObject4;
        if (g.a == null)
        {
          localObject12 = localObject4;
          if (u.a == null)
          {
            localObject12 = localObject4;
            if (!(localF instanceof org.codehaus.asm.asm.i))
            {
              localObject12 = localObject4;
              if (!(localF instanceof h))
              {
                localObject1 = localObject4;
                if (localObject4 == null) {
                  localObject1 = new ArrayList();
                }
                ((ArrayList)localObject1).add(localF);
                localObject12 = localObject1;
              }
            }
          }
        }
      }
      i += 1;
      localObject6 = localObject10;
      localObject3 = localObject9;
      localObject2 = localObject7;
      localObject1 = localObject8;
      localObject5 = localObject11;
      localObject4 = localObject12;
    }
    Object localObject7 = new ArrayList();
    if (localObject6 != null)
    {
      paramItem = ((ArrayList)localObject6).iterator();
      while (paramItem.hasNext()) {
        a((org.codehaus.asm.asm.i)paramItem.next(), 0, (ArrayList)localObject7, null);
      }
    }
    if (localObject2 != null)
    {
      paramItem = ((ArrayList)localObject2).iterator();
      while (paramItem.hasNext())
      {
        localObject2 = (m)paramItem.next();
        localObject6 = a((f)localObject2, 0, (ArrayList)localObject7, null);
        ((m)localObject2).a((ArrayList)localObject7, 0, (i)localObject6);
        ((i)localObject6).a((ArrayList)localObject7);
      }
    }
    paramItem = paramMethodWriter.a(c.d);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 0, (ArrayList)localObject7, null);
      }
    }
    paramItem = paramMethodWriter.a(c.i);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 0, (ArrayList)localObject7, null);
      }
    }
    paramItem = paramMethodWriter.a(c.l);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 0, (ArrayList)localObject7, null);
      }
    }
    if (localObject5 != null)
    {
      paramItem = localObject5.iterator();
      while (paramItem.hasNext()) {
        a((f)paramItem.next(), 0, (ArrayList)localObject7, null);
      }
    }
    if (localObject3 != null)
    {
      paramItem = ((ArrayList)localObject3).iterator();
      while (paramItem.hasNext()) {
        a((org.codehaus.asm.asm.i)paramItem.next(), 1, (ArrayList)localObject7, null);
      }
    }
    if (localObject1 != null)
    {
      paramItem = ((ArrayList)localObject1).iterator();
      while (paramItem.hasNext())
      {
        localObject1 = (m)paramItem.next();
        localObject2 = a((f)localObject1, 1, (ArrayList)localObject7, null);
        ((m)localObject1).a((ArrayList)localObject7, 1, (i)localObject2);
        ((i)localObject2).a((ArrayList)localObject7);
      }
    }
    paramItem = paramMethodWriter.a(c.a);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 1, (ArrayList)localObject7, null);
      }
    }
    paramItem = paramMethodWriter.a(c.g);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 1, (ArrayList)localObject7, null);
      }
    }
    paramItem = paramMethodWriter.a(c.b);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 1, (ArrayList)localObject7, null);
      }
    }
    paramItem = paramMethodWriter.a(c.l);
    if (paramItem.get() != null)
    {
      paramItem = paramItem.get().iterator();
      while (paramItem.hasNext()) {
        a(nextb, 1, (ArrayList)localObject7, null);
      }
    }
    if (localObject4 != null)
    {
      paramItem = ((ArrayList)localObject4).iterator();
      while (paramItem.hasNext()) {
        a((f)paramItem.next(), 1, (ArrayList)localObject7, null);
      }
    }
    i = 0;
    while (i < j)
    {
      localObject1 = (f)localArrayList.get(i);
      if (((f)localObject1).o())
      {
        paramItem = a((ArrayList)localObject7, B);
        localObject1 = a((ArrayList)localObject7, Q);
        if ((paramItem != null) && (localObject1 != null))
        {
          paramItem.a(0, (i)localObject1);
          ((i)localObject1).a(2);
          ((ArrayList)localObject7).remove(paramItem);
        }
      }
      i += 1;
    }
    if (((ArrayList)localObject7).size() <= 1) {
      return false;
    }
    localObject3 = null;
    localObject2 = null;
    localObject1 = localObject3;
    if (paramMethodWriter.doubleValue() == XLayoutStyle.c)
    {
      i = 0;
      paramItem = null;
      localObject4 = ((ArrayList)localObject7).iterator();
      while (((Iterator)localObject4).hasNext())
      {
        localObject1 = (i)((Iterator)localObject4).next();
        if (((i)localObject1).i() != 1)
        {
          ((i)localObject1).a(false);
          int k = ((i)localObject1).a(paramMethodWriter.visitLocalVariableAnnotation(), 0);
          j = i;
          if (k > i)
          {
            j = k;
            paramItem = (Item)localObject1;
          }
          i = j;
        }
      }
      localObject1 = localObject3;
      if (paramItem != null)
      {
        paramMethodWriter.add(XLayoutStyle.b);
        paramMethodWriter.append(i);
        paramItem.a(true);
        localObject1 = paramItem;
      }
    }
    paramItem = (Item)localObject2;
    if (paramMethodWriter.get() == XLayoutStyle.c)
    {
      i = 0;
      paramItem = null;
      localObject4 = ((ArrayList)localObject7).iterator();
      while (((Iterator)localObject4).hasNext())
      {
        localObject3 = (i)((Iterator)localObject4).next();
        if (((i)localObject3).i() != 0)
        {
          ((i)localObject3).a(false);
          j = ((i)localObject3).a(paramMethodWriter.visitLocalVariableAnnotation(), 1);
          if (j > i)
          {
            paramItem = (Item)localObject3;
            i = j;
          }
        }
      }
      if (paramItem != null)
      {
        paramMethodWriter.a(XLayoutStyle.b);
        paramMethodWriter.add(i);
        paramItem.a(true);
      }
      else
      {
        paramItem = (Item)localObject2;
      }
    }
    return (localObject1 != null) || (paramItem != null);
  }
  
  public static boolean a(XLayoutStyle paramXLayoutStyle1, XLayoutStyle paramXLayoutStyle2, XLayoutStyle paramXLayoutStyle3, XLayoutStyle paramXLayoutStyle4)
  {
    int i;
    if ((paramXLayoutStyle3 != XLayoutStyle.b) && (paramXLayoutStyle3 != XLayoutStyle.c) && ((paramXLayoutStyle3 != XLayoutStyle.r) || (paramXLayoutStyle1 == XLayoutStyle.c))) {
      i = 0;
    } else {
      i = 1;
    }
    int j;
    if ((paramXLayoutStyle4 != XLayoutStyle.b) && (paramXLayoutStyle4 != XLayoutStyle.c) && ((paramXLayoutStyle4 != XLayoutStyle.r) || (paramXLayoutStyle2 == XLayoutStyle.c))) {
      j = 0;
    } else {
      j = 1;
    }
    if (i == 0) {
      return j != 0;
    }
    return true;
  }
}
