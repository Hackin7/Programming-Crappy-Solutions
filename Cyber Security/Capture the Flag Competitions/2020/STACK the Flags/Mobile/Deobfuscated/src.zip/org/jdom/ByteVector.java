package org.jdom;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.SparseIntArray;
import org.data.Label;

public class ByteVector
  extends Attribute
{
  public final Parcel a;
  public final int b;
  public final SparseIntArray buffer = new SparseIntArray();
  public final int c;
  public int data = -1;
  public int k = 0;
  public int n = -1;
  public final String s;
  
  public ByteVector(Parcel paramParcel)
  {
    this(paramParcel, paramParcel.dataPosition(), paramParcel.dataSize(), "", new Label(), new Label(), new Label());
  }
  
  public ByteVector(Parcel paramParcel, int paramInt1, int paramInt2, String paramString, Label paramLabel1, Label paramLabel2, Label paramLabel3)
  {
    super(paramLabel1, paramLabel2, paramLabel3);
    a = paramParcel;
    c = paramInt1;
    b = paramInt2;
    k = paramInt1;
    s = paramString;
  }
  
  public void a()
  {
    int i = data;
    if (i >= 0)
    {
      i = buffer.get(i);
      int j = a.dataPosition();
      a.setDataPosition(i);
      a.writeInt(j - i);
      a.setDataPosition(j);
    }
  }
  
  public void a(CharSequence paramCharSequence)
  {
    TextUtils.writeToParcel(paramCharSequence, a, 0);
  }
  
  public void a(boolean paramBoolean)
  {
    throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
  }
  
  public boolean a(int paramInt)
  {
    while (k < b)
    {
      int i = n;
      if (i == paramInt) {
        return true;
      }
      if (String.valueOf(i).compareTo(String.valueOf(paramInt)) > 0) {
        return false;
      }
      a.setDataPosition(k);
      i = a.readInt();
      n = a.readInt();
      k += i;
    }
    return n == paramInt;
  }
  
  public Parcelable add()
  {
    return a.readParcelable(getClass().getClassLoader());
  }
  
  public Attribute b()
  {
    Parcel localParcel = a;
    int m = localParcel.dataPosition();
    int j = k;
    int i = j;
    if (j == c) {
      i = b;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(s);
    localStringBuilder.append("  ");
    return new ByteVector(localParcel, m, i, localStringBuilder.toString(), c, b, a);
  }
  
  public void get(int paramInt)
  {
    a.writeInt(paramInt);
  }
  
  public byte[] get()
  {
    int i = a.readInt();
    if (i < 0) {
      return null;
    }
    byte[] arrayOfByte = new byte[i];
    a.readByteArray(arrayOfByte);
    return arrayOfByte;
  }
  
  public CharSequence getQueueTitle()
  {
    return (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(a);
  }
  
  public String getValue()
  {
    return a.readString();
  }
  
  public int read()
  {
    return a.readInt();
  }
  
  public void write(int paramInt)
  {
    a();
    data = paramInt;
    buffer.put(paramInt, a.dataPosition());
    get(0);
    get(paramInt);
  }
  
  public void write(Parcelable paramParcelable)
  {
    a.writeParcelable(paramParcelable, 0);
  }
  
  public void write(String paramString)
  {
    a.writeString(paramString);
  }
  
  public void write(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte != null)
    {
      a.writeInt(paramArrayOfByte.length);
      a.writeByteArray(paramArrayOfByte);
      return;
    }
    a.writeInt(-1);
  }
  
  public boolean write()
  {
    return a.readInt() != 0;
  }
}
