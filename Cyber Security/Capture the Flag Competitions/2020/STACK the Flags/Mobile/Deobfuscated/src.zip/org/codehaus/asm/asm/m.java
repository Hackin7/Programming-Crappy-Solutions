package org.codehaus.asm.asm;

import java.util.ArrayList;
import java.util.Arrays;
import org.codehaus.asm.asm.asm.ClassReader;
import org.codehaus.asm.asm.asm.i;

public class m
  extends f
  implements AnnotationWriter
{
  public f[] b = new f[4];
  public int c = 0;
  
  public m() {}
  
  public int a(int paramInt)
  {
    int i = 0;
    while (i < c)
    {
      f localF = b[i];
      int j;
      if (paramInt == 0)
      {
        j = B;
        if (j != -1) {
          return j;
        }
      }
      if (paramInt == 1)
      {
        j = Q;
        if (j != -1) {
          return j;
        }
      }
      i += 1;
    }
    return -1;
  }
  
  public void a(ArrayList paramArrayList, int paramInt, i paramI)
  {
    int i = 0;
    while (i < c)
    {
      paramI.a(b[i]);
      i += 1;
    }
    i = 0;
    while (i < c)
    {
      ClassReader.a(b[i], paramInt, paramArrayList, paramI);
      i += 1;
    }
  }
  
  public void a(MethodWriter paramMethodWriter) {}
  
  public void a(f paramF)
  {
    if (paramF != this)
    {
      if (paramF == null) {
        return;
      }
      int i = c;
      f[] arrayOfF = b;
      if (i + 1 > arrayOfF.length) {
        b = ((f[])Arrays.copyOf(arrayOfF, arrayOfF.length * 2));
      }
      arrayOfF = b;
      i = c;
      arrayOfF[i] = paramF;
      c = (i + 1);
    }
  }
  
  public void setIcon()
  {
    c = 0;
    Arrays.fill(b, null);
  }
}
