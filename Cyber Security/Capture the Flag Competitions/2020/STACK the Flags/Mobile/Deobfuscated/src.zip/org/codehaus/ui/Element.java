package org.codehaus.ui;

import a.f.c.b.a;

public enum Element
{
  static
  {
    offset = new Element("FLOAT_TYPE", 1);
    depth = new Element("COLOR_TYPE", 2);
    name = new Element("COLOR_DRAWABLE_TYPE", 3);
    text = new Element("STRING_TYPE", 4);
    off = new Element("BOOLEAN_TYPE", 5);
    Element localElement = new Element("DIMENSION_TYPE", 6);
    read = localElement;
    $VALUES = new Element[] { root, offset, depth, name, text, off, localElement };
  }
}
