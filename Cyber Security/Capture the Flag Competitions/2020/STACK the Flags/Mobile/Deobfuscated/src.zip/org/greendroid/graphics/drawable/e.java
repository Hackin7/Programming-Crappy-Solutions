package org.greendroid.graphics.drawable;

import a.h.f.c.b;
import android.animation.TypeEvaluator;
import org.core.asm.PathParser;
import org.core.asm.PathParser.PathDataNode;

public class e
  implements TypeEvaluator<c.b[]>
{
  public PathParser.PathDataNode[] k;
  
  public e() {}
  
  public PathParser.PathDataNode[] a(float paramFloat, PathParser.PathDataNode[] paramArrayOfPathDataNode1, PathParser.PathDataNode[] paramArrayOfPathDataNode2)
  {
    if (PathParser.canMorph(paramArrayOfPathDataNode1, paramArrayOfPathDataNode2))
    {
      if (!PathParser.canMorph(k, paramArrayOfPathDataNode1)) {
        k = PathParser.deepCopyNodes(paramArrayOfPathDataNode1);
      }
      int i = 0;
      while (i < paramArrayOfPathDataNode1.length)
      {
        k[i].interpolatePathDataNode(paramArrayOfPathDataNode1[i], paramArrayOfPathDataNode2[i], paramFloat);
        i += 1;
      }
      return k;
    }
    throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
  }
}
