package org.v7.widget;

import android.os.Build.VERSION;
import android.view.View;

public class MenuItemImpl
{
  public static void setText(View paramView, CharSequence paramCharSequence)
  {
    if (Build.VERSION.SDK_INT >= 26)
    {
      paramView.setTooltipText(paramCharSequence);
      return;
    }
    NumberPicker.init(paramView, paramCharSequence);
  }
}
