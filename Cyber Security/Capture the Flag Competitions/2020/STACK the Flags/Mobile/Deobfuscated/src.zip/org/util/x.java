package org.util;

public abstract class x
  implements k
{
  public x() {}
  
  public i a(Class paramClass)
  {
    throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
  }
  
  public abstract i a(String paramString, Class paramClass);
}
