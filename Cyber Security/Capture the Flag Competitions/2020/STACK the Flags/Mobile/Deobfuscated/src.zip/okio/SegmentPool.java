package okio;

import javax.annotation.Nullable;

public final class SegmentPool
{
  public static long byteCount;
  @Nullable
  public static Segment next;
  
  public SegmentPool() {}
  
  public static void recycle(Segment paramSegment)
  {
    if ((next == null) && (head == null))
    {
      if (count) {
        return;
      }
      try
      {
        if (byteCount + 8192L > 65536L) {
          return;
        }
        byteCount += 8192L;
        next = next;
        size = 0;
        pos = 0;
        next = paramSegment;
        return;
      }
      catch (Throwable paramSegment)
      {
        throw paramSegment;
      }
    }
    throw new IllegalArgumentException();
  }
  
  public static Segment take()
  {
    try
    {
      if (next != null)
      {
        Segment localSegment = next;
        next = next;
        next = null;
        byteCount -= 8192L;
        return localSegment;
      }
      return new Segment();
    }
    catch (Throwable localThrowable)
    {
      throw localThrowable;
    }
  }
}
