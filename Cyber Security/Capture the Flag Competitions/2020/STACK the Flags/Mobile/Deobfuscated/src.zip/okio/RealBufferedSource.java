package okio;

import java.nio.ByteBuffer;

public final class RealBufferedSource
  implements BufferedSource
{
  public final Buffer buffer = new Buffer();
  public boolean closed;
  public final Source source;
  
  public RealBufferedSource(Source paramSource)
  {
    if (paramSource != null)
    {
      source = paramSource;
      return;
    }
    throw new NullPointerException("source == null");
  }
  
  public Buffer buffer()
  {
    return buffer;
  }
  
  public void close()
  {
    if (closed) {
      return;
    }
    closed = true;
    source.close();
    buffer.clear();
  }
  
  public long indexOf(ByteString paramByteString)
  {
    return indexOf(paramByteString, 0L);
  }
  
  public long indexOf(ByteString paramByteString, long paramLong)
  {
    if (!closed) {
      for (;;)
      {
        long l = buffer.indexOf(paramByteString, paramLong);
        if (l != -1L) {
          return l;
        }
        Buffer localBuffer = buffer;
        l = size;
        if (source.read(localBuffer, 8192L) == -1L) {
          return -1L;
        }
        paramLong = Math.max(paramLong, l);
      }
    }
    throw new IllegalStateException("closed");
  }
  
  public boolean isOpen()
  {
    return closed ^ true;
  }
  
  public int read(ByteBuffer paramByteBuffer)
  {
    Buffer localBuffer = buffer;
    if ((size == 0L) && (source.read(localBuffer, 8192L) == -1L)) {
      return -1;
    }
    return buffer.read(paramByteBuffer);
  }
  
  public int read(Session paramSession)
  {
    if (!closed)
    {
      int i;
      do
      {
        i = buffer.read(paramSession, true);
        if (i == -1) {
          return -1;
        }
        if (i != -2) {
          break;
        }
      } while (source.read(buffer, 8192L) != -1L);
      return -1;
      int j = data[i].length();
      buffer.write(j);
      return i;
    }
    throw new IllegalStateException("closed");
  }
  
  public long read(Buffer paramBuffer, long paramLong)
  {
    if (paramBuffer != null)
    {
      if (paramLong >= 0L)
      {
        if (!closed)
        {
          Buffer localBuffer = buffer;
          if ((size == 0L) && (source.read(localBuffer, 8192L) == -1L)) {
            return -1L;
          }
          paramLong = Math.min(paramLong, buffer.size);
          return buffer.read(paramBuffer, paramLong);
        }
        throw new IllegalStateException("closed");
      }
      paramBuffer = new StringBuilder();
      paramBuffer.append("byteCount < 0: ");
      paramBuffer.append(paramLong);
      throw new IllegalArgumentException(paramBuffer.toString());
    }
    throw new IllegalArgumentException("sink == null");
  }
  
  public boolean read(long paramLong)
  {
    if (paramLong >= 0L)
    {
      if (!closed)
      {
        do
        {
          localObject = buffer;
          if (size >= paramLong) {
            break;
          }
        } while (source.read((Buffer)localObject, 8192L) != -1L);
        return false;
        return true;
      }
      throw new IllegalStateException("closed");
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("byteCount < 0: ");
    ((StringBuilder)localObject).append(paramLong);
    throw new IllegalArgumentException(((StringBuilder)localObject).toString());
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("buffer(");
    localStringBuilder.append(source);
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
}
