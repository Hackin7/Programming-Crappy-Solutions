package okio;

public final class Segment
{
  public boolean count;
  public final byte[] data;
  public Segment head;
  public Segment next;
  public int pos;
  public int size;
  public boolean value;
  
  public Segment()
  {
    data = new byte['?'];
    value = true;
    count = false;
  }
  
  public Segment(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    data = paramArrayOfByte;
    pos = paramInt1;
    size = paramInt2;
    count = paramBoolean1;
    value = paramBoolean2;
  }
  
  public final Segment next()
  {
    count = true;
    return new Segment(data, pos, size, true, false);
  }
  
  public final Segment pop()
  {
    Segment localSegment1 = next;
    if (localSegment1 == this) {
      localSegment1 = null;
    }
    Segment localSegment2 = head;
    next = next;
    next.head = localSegment2;
    next = null;
    head = null;
    return localSegment1;
  }
  
  public final Segment push(Segment paramSegment)
  {
    head = this;
    next = next;
    next.head = paramSegment;
    next = paramSegment;
    return paramSegment;
  }
  
  public final Segment write(int paramInt)
  {
    if ((paramInt > 0) && (paramInt <= size - pos))
    {
      Object localObject;
      if (paramInt >= 1024)
      {
        localObject = next();
      }
      else
      {
        Segment localSegment = SegmentPool.take();
        localObject = localSegment;
        System.arraycopy(data, pos, data, 0, paramInt);
      }
      size = (pos + paramInt);
      pos += paramInt;
      head.push((Segment)localObject);
      return localObject;
    }
    throw new IllegalArgumentException();
  }
  
  public final void write()
  {
    Segment localSegment = head;
    if (localSegment != this)
    {
      if (!value) {
        return;
      }
      int j = size - pos;
      int k = size;
      int i;
      if (count) {
        i = 0;
      } else {
        i = pos;
      }
      if (j > 8192 - k + i) {
        return;
      }
      write(head, j);
      pop();
      SegmentPool.recycle(this);
      return;
    }
    throw new IllegalStateException();
  }
  
  public final void write(Segment paramSegment, int paramInt)
  {
    if (value)
    {
      int i = size;
      if (i + paramInt > 8192) {
        if (!count)
        {
          int j = pos;
          if (i + paramInt - j <= 8192)
          {
            byte[] arrayOfByte = data;
            System.arraycopy(arrayOfByte, j, arrayOfByte, 0, i - j);
            size -= pos;
            pos = 0;
          }
          else
          {
            throw new IllegalArgumentException();
          }
        }
        else
        {
          throw new IllegalArgumentException();
        }
      }
      System.arraycopy(data, pos, data, size, paramInt);
      size += paramInt;
      pos += paramInt;
      return;
    }
    throw new IllegalArgumentException();
  }
}
