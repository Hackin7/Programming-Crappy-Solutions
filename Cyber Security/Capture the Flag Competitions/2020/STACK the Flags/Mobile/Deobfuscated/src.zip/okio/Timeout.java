package okio;

import java.io.InterruptedIOException;

public class Timeout
{
  static
  {
    new AsyncTimeout();
  }
  
  public Timeout() {}
  
  public void enter()
  {
    if (!Thread.interrupted()) {
      return;
    }
    Thread.currentThread().interrupt();
    throw new InterruptedIOException("interrupted");
  }
}
