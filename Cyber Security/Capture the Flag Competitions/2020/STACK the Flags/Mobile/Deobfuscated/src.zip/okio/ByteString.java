package okio;

import e.d;
import java.io.Serializable;
import java.util.Arrays;

public class ByteString
  implements Serializable, Comparable<d>
{
  public static final ByteString EMPTY = of(new byte[0]);
  public static final char[] HEX_DIGITS = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  public transient String count;
  public final byte[] data;
  public transient int hashCode;
  
  public ByteString(byte[] paramArrayOfByte)
  {
    data = paramArrayOfByte;
  }
  
  public static ByteString encodeUtf8(String paramString)
  {
    if (paramString != null)
    {
      ByteString localByteString = new ByteString(paramString.getBytes(Util.UTF_8));
      count = paramString;
      return localByteString;
    }
    throw new IllegalArgumentException("s == null");
  }
  
  public static int escape(String paramString, int paramInt)
  {
    int i = 0;
    int j = 0;
    int k = paramString.length();
    while (i < k)
    {
      if (j == paramInt) {
        return i;
      }
      int m = paramString.codePointAt(i);
      if (((Character.isISOControl(m)) && (m != 10) && (m != 13)) || (m == 65533)) {
        return -1;
      }
      j += 1;
      i += Character.charCount(m);
    }
    return paramString.length();
  }
  
  public static ByteString of(byte... paramVarArgs)
  {
    if (paramVarArgs != null) {
      return new ByteString((byte[])paramVarArgs.clone());
    }
    throw new IllegalArgumentException("data == null");
  }
  
  public int compareTo(ByteString paramByteString)
  {
    int j = length();
    int k = paramByteString.length();
    int i = 0;
    int m = Math.min(j, k);
    while (i < m)
    {
      int n = read(i) & 0xFF;
      int i1 = paramByteString.read(i) & 0xFF;
      if (n == i1)
      {
        i += 1;
      }
      else
      {
        if (n < i1) {
          return -1;
        }
        return 1;
      }
    }
    if (j == k) {
      return 0;
    }
    if (j < k) {
      return -1;
    }
    return 1;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if ((paramObject instanceof ByteString))
    {
      int i = ((ByteString)paramObject).length();
      byte[] arrayOfByte = data;
      if ((i == arrayOfByte.length) && (((ByteString)paramObject).write(0, arrayOfByte, 0, arrayOfByte.length))) {
        return true;
      }
    }
    return false;
  }
  
  public int hashCode()
  {
    int i = hashCode;
    if (i != 0) {
      return i;
    }
    i = Arrays.hashCode(data);
    hashCode = i;
    return i;
  }
  
  public String hex()
  {
    byte[] arrayOfByte = data;
    char[] arrayOfChar1 = new char[arrayOfByte.length * 2];
    int j = 0;
    int k = arrayOfByte.length;
    int i = 0;
    while (i < k)
    {
      int m = arrayOfByte[i];
      int n = j + 1;
      char[] arrayOfChar2 = HEX_DIGITS;
      arrayOfChar1[j] = arrayOfChar2[(m >> 4 & 0xF)];
      j = n + 1;
      arrayOfChar1[n] = arrayOfChar2[(m & 0xF)];
      i += 1;
    }
    return new String(arrayOfChar1);
  }
  
  public int length()
  {
    return data.length;
  }
  
  public byte read(int paramInt)
  {
    return data[paramInt];
  }
  
  public byte[] read()
  {
    return data;
  }
  
  public String toString()
  {
    if (data.length == 0) {
      return "[size=0]";
    }
    Object localObject2 = write();
    int i = escape((String)localObject2, 64);
    if (i == -1)
    {
      if (data.length <= 64)
      {
        localObject1 = new StringBuilder();
        ((StringBuilder)localObject1).append("[hex=");
        ((StringBuilder)localObject1).append(hex());
        ((StringBuilder)localObject1).append("]");
        return ((StringBuilder)localObject1).toString();
      }
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append("[size=");
      ((StringBuilder)localObject1).append(data.length);
      ((StringBuilder)localObject1).append(" hex=");
      ((StringBuilder)localObject1).append(write(0, 64).hex());
      ((StringBuilder)localObject1).append("?]");
      return ((StringBuilder)localObject1).toString();
    }
    Object localObject1 = ((String)localObject2).substring(0, i).replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r");
    if (i < ((String)localObject2).length())
    {
      localObject2 = new StringBuilder();
      ((StringBuilder)localObject2).append("[size=");
      ((StringBuilder)localObject2).append(data.length);
      ((StringBuilder)localObject2).append(" text=");
      ((StringBuilder)localObject2).append((String)localObject1);
      ((StringBuilder)localObject2).append("?]");
      return ((StringBuilder)localObject2).toString();
    }
    localObject2 = new StringBuilder();
    ((StringBuilder)localObject2).append("[text=");
    ((StringBuilder)localObject2).append((String)localObject1);
    ((StringBuilder)localObject2).append("]");
    return ((StringBuilder)localObject2).toString();
  }
  
  public String write()
  {
    String str = count;
    if (str != null) {
      return str;
    }
    str = new String(data, Util.UTF_8);
    count = str;
    return str;
  }
  
  public ByteString write(int paramInt1, int paramInt2)
  {
    if (paramInt1 >= 0)
    {
      Object localObject = data;
      if (paramInt2 <= localObject.length)
      {
        int i = paramInt2 - paramInt1;
        if (i >= 0)
        {
          if ((paramInt1 == 0) && (paramInt2 == localObject.length)) {
            return this;
          }
          localObject = new byte[i];
          System.arraycopy(data, paramInt1, localObject, 0, i);
          return new ByteString((byte[])localObject);
        }
        throw new IllegalArgumentException("endIndex < beginIndex");
      }
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("endIndex > length(");
      ((StringBuilder)localObject).append(data.length);
      ((StringBuilder)localObject).append(")");
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    throw new IllegalArgumentException("beginIndex < 0");
  }
  
  public boolean write(int paramInt1, ByteString paramByteString, int paramInt2, int paramInt3)
  {
    return paramByteString.write(paramInt2, data, paramInt1, paramInt3);
  }
  
  public boolean write(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    if (paramInt1 >= 0)
    {
      byte[] arrayOfByte = data;
      if ((paramInt1 <= arrayOfByte.length - paramInt3) && (paramInt2 >= 0) && (paramInt2 <= paramArrayOfByte.length - paramInt3) && (Util.compareArray(arrayOfByte, paramInt1, paramArrayOfByte, paramInt2, paramInt3))) {
        return true;
      }
    }
    return false;
  }
  
  public final boolean write(ByteString paramByteString)
  {
    return write(0, paramByteString, 0, paramByteString.length());
  }
}
