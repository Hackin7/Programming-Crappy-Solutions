package okio;

import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;
import java.util.AbstractList;
import javax.annotation.Nullable;

public final class Buffer
  implements BufferedSource, BufferedSink, Cloneable, ByteChannel
{
  @Nullable
  public Segment head;
  public long size;
  
  public Buffer() {}
  
  public Buffer buffer()
  {
    return this;
  }
  
  public final void clear()
  {
    long l = size;
    try
    {
      write(l);
      return;
    }
    catch (EOFException localEOFException)
    {
      throw new AssertionError(localEOFException);
    }
  }
  
  public void close() {}
  
  public Buffer copyTo()
  {
    Buffer localBuffer = new Buffer();
    if (size == 0L) {
      return localBuffer;
    }
    Segment localSegment = head.next();
    head = localSegment;
    head = localSegment;
    next = localSegment;
    for (localSegment = head.next; localSegment != head; localSegment = next) {
      head.head.push(localSegment.next());
    }
    size = size;
    return localBuffer;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof Buffer)) {
      return false;
    }
    paramObject = (Buffer)paramObject;
    long l1 = size;
    if (l1 != size) {
      return false;
    }
    if (l1 == 0L) {
      return true;
    }
    Object localObject2 = head;
    paramObject = head;
    int j = pos;
    int i = pos;
    l1 = 0L;
    while (l1 < size)
    {
      long l2 = Math.min(size - j, size - i);
      int k = 0;
      while (k < l2)
      {
        if (data[j] != data[i]) {
          return false;
        }
        k += 1;
        j += 1;
        i += 1;
      }
      Object localObject1 = localObject2;
      k = j;
      if (j == size)
      {
        localObject1 = next;
        k = pos;
      }
      Object localObject3 = paramObject;
      int m = i;
      if (i == size)
      {
        localObject3 = next;
        m = pos;
      }
      l1 += l2;
      localObject2 = localObject1;
      paramObject = localObject3;
      j = k;
      i = m;
    }
    return true;
  }
  
  public boolean exhausted()
  {
    return size == 0L;
  }
  
  public void flush() {}
  
  public ByteString get()
  {
    return new ByteString(readByteArray());
  }
  
  public int hashCode()
  {
    Object localObject = head;
    if (localObject == null) {
      return 0;
    }
    int i = 1;
    int j;
    Segment localSegment;
    do
    {
      int k = pos;
      int m = size;
      j = i;
      while (k < m)
      {
        j = j * 31 + data[k];
        k += 1;
      }
      localSegment = next;
      localObject = localSegment;
      i = j;
    } while (localSegment != head);
    return j;
  }
  
  public final byte indexOf(long paramLong)
  {
    Util.checkOffsetAndCount(size, paramLong, 1L);
    long l = size;
    int j;
    int i;
    if (l - paramLong > paramLong) {
      for (localSegment = head;; localSegment = next)
      {
        j = size;
        i = pos;
        j -= i;
        if (paramLong < j) {
          return data[(i + (int)paramLong)];
        }
        paramLong -= j;
      }
    }
    paramLong -= l;
    for (Segment localSegment = head.head;; localSegment = head)
    {
      i = size;
      j = pos;
      paramLong += i - j;
      if (paramLong >= 0L) {
        return data[(j + (int)paramLong)];
      }
    }
  }
  
  public long indexOf(ByteString paramByteString)
  {
    return indexOf(paramByteString, 0L);
  }
  
  public long indexOf(ByteString paramByteString, long paramLong)
  {
    if (paramLong >= 0L)
    {
      Object localObject2 = head;
      if (localObject2 == null) {
        return -1L;
      }
      long l2;
      Object localObject1;
      if (size - paramLong < paramLong) {
        for (l2 = size;; l2 -= size - pos)
        {
          localObject1 = localObject2;
          l1 = l2;
          if (l2 <= paramLong) {
            break;
          }
          localObject2 = head;
        }
      }
      for (long l1 = 0L;; l1 = l2)
      {
        l2 = size - pos + l1;
        localObject1 = localObject2;
        if (l2 >= paramLong) {
          break;
        }
        localObject2 = next;
      }
      int j;
      int k;
      int i;
      int m;
      int n;
      if (paramByteString.length() == 2)
      {
        j = paramByteString.read(0);
        k = paramByteString.read(1);
        while (l1 < size)
        {
          paramByteString = data;
          i = (int)(pos + paramLong - l1);
          m = size;
          while (i < m)
          {
            n = paramByteString[i];
            if ((n != j) && (n != k)) {
              i += 1;
            } else {
              return i - pos + l1;
            }
          }
          l1 += size - pos;
          paramLong = l1;
          localObject1 = next;
        }
      }
      else
      {
        paramByteString = paramByteString.read();
        while (l1 < size)
        {
          localObject2 = data;
          i = (int)(pos + paramLong - l1);
          k = size;
          for (;;)
          {
            j = 0;
            if (i >= k) {
              break;
            }
            m = localObject2[i];
            n = paramByteString.length;
            while (j < n)
            {
              if (m == paramByteString[j]) {
                return i - pos + l1;
              }
              j += 1;
            }
            i += 1;
          }
          l1 += size - pos;
          paramLong = l1;
          localObject1 = next;
        }
      }
      return -1L;
    }
    throw new IllegalArgumentException("fromIndex < 0");
  }
  
  public boolean isOpen()
  {
    return true;
  }
  
  public byte read()
  {
    long l = size;
    if (l != 0L)
    {
      Segment localSegment = head;
      int i = pos;
      int j = size;
      byte[] arrayOfByte = data;
      int k = i + 1;
      byte b = arrayOfByte[i];
      size = (l - 1L);
      if (k == j)
      {
        head = localSegment.pop();
        SegmentPool.recycle(localSegment);
        return b;
      }
      pos = k;
      return b;
    }
    throw new IllegalStateException("size == 0");
  }
  
  public int read(ByteBuffer paramByteBuffer)
  {
    Segment localSegment = head;
    if (localSegment == null) {
      return -1;
    }
    int i = Math.min(paramByteBuffer.remaining(), size - pos);
    paramByteBuffer.put(data, pos, i);
    int j = pos + i;
    pos = j;
    size -= i;
    if (j == size)
    {
      head = localSegment.pop();
      SegmentPool.recycle(localSegment);
    }
    return i;
  }
  
  public int read(Session paramSession)
  {
    int i = read(paramSession, false);
    if (i == -1) {
      return -1;
    }
    long l = data[i].length();
    try
    {
      write(l);
      return i;
    }
    catch (EOFException paramSession)
    {
      throw new AssertionError();
    }
  }
  
  public int read(Session paramSession, boolean paramBoolean)
  {
    Segment localSegment = head;
    if (localSegment == null)
    {
      if (paramBoolean) {
        return -2;
      }
      return paramSession.indexOf(ByteString.EMPTY);
    }
    Object localObject = localSegment;
    byte[] arrayOfByte = data;
    int i = pos;
    int j = size;
    int[] arrayOfInt = buf;
    int k = 0;
    int m = -1;
    paramSession = (Session)localObject;
    int i1 = k + 1;
    int i4 = arrayOfInt[k];
    int n = i1 + 1;
    k = arrayOfInt[i1];
    if (k != -1) {
      m = k;
    }
    if (paramSession != null)
    {
      if (i4 < 0)
      {
        k = n;
        localObject = paramSession;
        i1 = j;
      }
    }
    else {
      for (;;)
      {
        int i3 = i + 1;
        i = arrayOfByte[i];
        int i2 = k + 1;
        if ((i & 0xFF) != arrayOfInt[k]) {
          return m;
        }
        if (i2 == n + i4 * -1) {
          k = 1;
        } else {
          k = 0;
        }
        j = i1;
        paramSession = (Session)localObject;
        i = i3;
        if (i3 == i1)
        {
          paramSession = next;
          i = pos;
          arrayOfByte = data;
          j = size;
          if (paramSession == localSegment)
          {
            if (k == 0)
            {
              if (paramBoolean) {
                return -2;
              }
              return m;
            }
            paramSession = null;
          }
          else {}
        }
        if (k != 0)
        {
          k = arrayOfInt[i2];
          break;
        }
        k = i2;
        i1 = j;
        localObject = paramSession;
      }
    }
    k = i + 1;
    i1 = arrayOfByte[i];
    i = n;
    for (;;)
    {
      if (i == n + i4) {
        return m;
      }
      if ((i1 & 0xFF) == arrayOfInt[i])
      {
        n = arrayOfInt[(i + i4)];
        if (k == j)
        {
          paramSession = next;
          i = pos;
          arrayOfByte = data;
          j = size;
          if (paramSession == localSegment)
          {
            paramSession = null;
            k = n;
          }
          else
          {
            k = n;
          }
        }
        else
        {
          i = k;
          k = n;
        }
        if (k >= 0) {
          return k;
        }
        k = -k;
        break;
      }
      i += 1;
    }
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    Util.checkOffsetAndCount(paramArrayOfByte.length, paramInt1, paramInt2);
    Segment localSegment = head;
    if (localSegment == null) {
      return -1;
    }
    paramInt2 = Math.min(paramInt2, size - pos);
    System.arraycopy(data, pos, paramArrayOfByte, paramInt1, paramInt2);
    paramInt1 = pos + paramInt2;
    pos = paramInt1;
    size -= paramInt2;
    if (paramInt1 == size)
    {
      head = localSegment.pop();
      SegmentPool.recycle(localSegment);
    }
    return paramInt2;
  }
  
  public long read(Buffer paramBuffer, long paramLong)
  {
    if (paramBuffer != null)
    {
      if (paramLong >= 0L)
      {
        long l2 = size;
        if (l2 == 0L) {
          return -1L;
        }
        long l1 = paramLong;
        if (paramLong > l2) {
          l1 = size;
        }
        paramBuffer.write(this, l1);
        return l1;
      }
      paramBuffer = new StringBuilder();
      paramBuffer.append("byteCount < 0: ");
      paramBuffer.append(paramLong);
      throw new IllegalArgumentException(paramBuffer.toString());
    }
    throw new IllegalArgumentException("sink == null");
  }
  
  public boolean read(long paramLong)
  {
    return size >= paramLong;
  }
  
  public byte[] readByteArray()
  {
    long l = size;
    try
    {
      byte[] arrayOfByte = readByteArray(l);
      return arrayOfByte;
    }
    catch (EOFException localEOFException)
    {
      throw new AssertionError(localEOFException);
    }
  }
  
  public byte[] readByteArray(long paramLong)
  {
    Util.checkOffsetAndCount(size, 0L, paramLong);
    if (paramLong <= 2147483647L)
    {
      localObject = new byte[(int)paramLong];
      readFully((byte[])localObject);
      return localObject;
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("byteCount > Integer.MAX_VALUE: ");
    ((StringBuilder)localObject).append(paramLong);
    throw new IllegalArgumentException(((StringBuilder)localObject).toString());
  }
  
  public void readFully(byte[] paramArrayOfByte)
  {
    int i = 0;
    while (i < paramArrayOfByte.length)
    {
      int j = read(paramArrayOfByte, i, paramArrayOfByte.length - i);
      if (j != -1) {
        i += j;
      } else {
        throw new EOFException();
      }
    }
  }
  
  public int readInt()
  {
    long l = size;
    if (l >= 4L)
    {
      localObject = head;
      int j = pos;
      int i = size;
      if (i - j < 4) {
        return (read() & 0xFF) << 24 | (read() & 0xFF) << 16 | (read() & 0xFF) << 8 | read() & 0xFF;
      }
      byte[] arrayOfByte = data;
      int k = j + 1;
      j = arrayOfByte[j];
      int n = k + 1;
      k = arrayOfByte[k];
      int m = n + 1;
      int i1 = arrayOfByte[n];
      n = m + 1;
      j = (j & 0xFF) << 24 | (k & 0xFF) << 16 | (i1 & 0xFF) << 8 | arrayOfByte[m] & 0xFF;
      size = (l - 4L);
      if (n == i)
      {
        head = ((Segment)localObject).pop();
        SegmentPool.recycle((Segment)localObject);
        return j;
      }
      pos = n;
      return j;
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("size < 4: ");
    ((StringBuilder)localObject).append(size);
    throw new IllegalStateException(((StringBuilder)localObject).toString());
  }
  
  public String readString(long paramLong)
  {
    return readString(paramLong, Util.UTF_8);
  }
  
  public String readString(long paramLong, Charset paramCharset)
  {
    Util.checkOffsetAndCount(size, 0L, paramLong);
    if (paramCharset != null)
    {
      if (paramLong <= 2147483647L)
      {
        if (paramLong == 0L) {
          return "";
        }
        Segment localSegment = head;
        if (pos + paramLong > size) {
          return new String(readByteArray(paramLong), paramCharset);
        }
        paramCharset = new String(data, pos, (int)paramLong, paramCharset);
        int i = (int)(pos + paramLong);
        pos = i;
        size -= paramLong;
        if (i == size)
        {
          head = localSegment.pop();
          SegmentPool.recycle(localSegment);
          return paramCharset;
        }
      }
      else
      {
        paramCharset = new StringBuilder();
        paramCharset.append("byteCount > Integer.MAX_VALUE: ");
        paramCharset.append(paramLong);
        throw new IllegalArgumentException(paramCharset.toString());
      }
    }
    else {
      throw new IllegalArgumentException("charset == null");
    }
    return paramCharset;
  }
  
  public String readUtf8()
  {
    long l = size;
    Object localObject = Util.UTF_8;
    try
    {
      localObject = readString(l, (Charset)localObject);
      return localObject;
    }
    catch (EOFException localEOFException)
    {
      throw new AssertionError(localEOFException);
    }
  }
  
  public final long size()
  {
    return size;
  }
  
  public final ByteString snapshot()
  {
    long l = size;
    if (l <= 2147483647L) {
      return snapshot((int)l);
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("size > Integer.MAX_VALUE: ");
    localStringBuilder.append(size);
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public final ByteString snapshot(int paramInt)
  {
    if (paramInt == 0) {
      return ByteString.EMPTY;
    }
    return new ByteVector(this, paramInt);
  }
  
  public String toString()
  {
    return snapshot().toString();
  }
  
  public Segment writableSegment(int paramInt)
  {
    Segment localSegment;
    if ((paramInt >= 1) && (paramInt <= 8192))
    {
      localSegment = head;
      if (localSegment == null)
      {
        localSegment = SegmentPool.take();
        head = localSegment;
        head = localSegment;
        next = localSegment;
        return localSegment;
      }
      localSegment = head;
      if ((size + paramInt > 8192) || (!value)) {
        return localSegment.push(SegmentPool.take());
      }
    }
    else
    {
      throw new IllegalArgumentException();
    }
    return localSegment;
  }
  
  public int write(ByteBuffer paramByteBuffer)
  {
    if (paramByteBuffer != null)
    {
      int j = paramByteBuffer.remaining();
      int i = j;
      while (i > 0)
      {
        Segment localSegment = writableSegment(1);
        int k = Math.min(i, 8192 - size);
        paramByteBuffer.get(data, size, k);
        i -= k;
        size += k;
      }
      size += j;
      return j;
    }
    throw new IllegalArgumentException("source == null");
  }
  
  public void write(long paramLong)
  {
    while (paramLong > 0L)
    {
      Segment localSegment = head;
      if (localSegment != null)
      {
        int i = (int)Math.min(paramLong, size - pos);
        size -= i;
        long l = paramLong - i;
        localSegment = head;
        i = pos + i;
        pos = i;
        paramLong = l;
        if (i == size)
        {
          localSegment = head;
          head = localSegment.pop();
          SegmentPool.recycle(localSegment);
          paramLong = l;
        }
      }
      else
      {
        throw new EOFException();
      }
    }
  }
  
  public void write(Buffer paramBuffer, long paramLong)
  {
    if (paramBuffer != null)
    {
      if (paramBuffer != this)
      {
        Util.checkOffsetAndCount(size, 0L, paramLong);
        while (paramLong > 0L)
        {
          Segment localSegment1 = head;
          if (paramLong < size - pos)
          {
            localSegment1 = head;
            if (localSegment1 != null) {
              localSegment1 = head;
            } else {
              localSegment1 = null;
            }
            if ((localSegment1 != null) && (value))
            {
              l = size;
              int i;
              if (count) {
                i = 0;
              } else {
                i = pos;
              }
              if (l + paramLong - i <= 8192L)
              {
                head.write(localSegment1, (int)paramLong);
                size -= paramLong;
                size += paramLong;
                return;
              }
            }
            head = head.write((int)paramLong);
          }
          localSegment1 = head;
          long l = size - pos;
          head = localSegment1.pop();
          Segment localSegment2 = head;
          if (localSegment2 == null)
          {
            head = localSegment1;
            head = localSegment1;
            next = localSegment1;
          }
          else
          {
            head.push(localSegment1).write();
          }
          size -= l;
          size += l;
          paramLong -= l;
        }
        return;
      }
      throw new IllegalArgumentException("source == this");
    }
    throw new IllegalArgumentException("source == null");
  }
  
  public Buffer writeByte(int paramInt)
  {
    Segment localSegment = writableSegment(1);
    byte[] arrayOfByte = data;
    int i = size;
    size = (i + 1);
    arrayOfByte[i] = ((byte)paramInt);
    size += 1L;
    return this;
  }
  
  public Buffer writeInt(int paramInt)
  {
    Segment localSegment = writableSegment(4);
    byte[] arrayOfByte = data;
    int j = size;
    int i = j + 1;
    arrayOfByte[j] = ((byte)(paramInt >>> 24 & 0xFF));
    j = i + 1;
    arrayOfByte[i] = ((byte)(paramInt >>> 16 & 0xFF));
    i = j + 1;
    arrayOfByte[j] = ((byte)(paramInt >>> 8 & 0xFF));
    arrayOfByte[i] = ((byte)(paramInt & 0xFF));
    size = (i + 1);
    size += 4L;
    return this;
  }
  
  public Buffer writeUtf8(String paramString)
  {
    writeUtf8(paramString, 0, paramString.length());
    return this;
  }
  
  public Buffer writeUtf8(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString != null)
    {
      if (paramInt1 >= 0)
      {
        if (paramInt2 >= paramInt1)
        {
          if (paramInt2 <= paramString.length())
          {
            while (paramInt1 < paramInt2)
            {
              int k = paramString.charAt(paramInt1);
              int i;
              if (k < 128)
              {
                localObject = writableSegment(1);
                byte[] arrayOfByte = data;
                int j = size - paramInt1;
                int m = Math.min(paramInt2, 8192 - j);
                i = paramInt1 + 1;
                arrayOfByte[(paramInt1 + j)] = ((byte)k);
                paramInt1 = i;
                while (paramInt1 < m)
                {
                  i = paramString.charAt(paramInt1);
                  if (i >= 128) {
                    break;
                  }
                  arrayOfByte[(paramInt1 + j)] = ((byte)i);
                  paramInt1 += 1;
                }
                i = size;
                j = paramInt1 + j - i;
                size = (i + j);
                size += j;
              }
              else if (k < 2048)
              {
                writeByte(k >> 6 | 0xC0);
                writeByte(0x80 | k & 0x3F);
                paramInt1 += 1;
              }
              else if ((k >= 55296) && (k <= 57343))
              {
                if (paramInt1 + 1 < paramInt2) {
                  i = paramString.charAt(paramInt1 + 1);
                } else {
                  i = 0;
                }
                if ((k <= 56319) && (i >= 56320) && (i <= 57343))
                {
                  i = ((0xFFFF27FF & k) << 10 | 0xFFFF23FF & i) + 65536;
                  writeByte(i >> 18 | 0xF0);
                  writeByte(i >> 12 & 0x3F | 0x80);
                  writeByte(i >> 6 & 0x3F | 0x80);
                  writeByte(0x80 | i & 0x3F);
                  paramInt1 += 2;
                }
                else
                {
                  writeByte(63);
                  paramInt1 += 1;
                }
              }
              else
              {
                writeByte(k >> 12 | 0xE0);
                writeByte(k >> 6 & 0x3F | 0x80);
                writeByte(0x80 | k & 0x3F);
                paramInt1 += 1;
              }
            }
            return this;
          }
          Object localObject = new StringBuilder();
          ((StringBuilder)localObject).append("endIndex > string.length: ");
          ((StringBuilder)localObject).append(paramInt2);
          ((StringBuilder)localObject).append(" > ");
          ((StringBuilder)localObject).append(paramString.length());
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
        paramString = new StringBuilder();
        paramString.append("endIndex < beginIndex: ");
        paramString.append(paramInt2);
        paramString.append(" < ");
        paramString.append(paramInt1);
        throw new IllegalArgumentException(paramString.toString());
      }
      paramString = new StringBuilder();
      paramString.append("beginIndex < 0: ");
      paramString.append(paramInt1);
      throw new IllegalArgumentException(paramString.toString());
    }
    throw new IllegalArgumentException("string == null");
  }
}
