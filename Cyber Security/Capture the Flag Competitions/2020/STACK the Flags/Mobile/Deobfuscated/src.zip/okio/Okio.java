package okio;

import e.e;
import java.io.InputStream;
import java.util.logging.Logger;

public final class Okio
{
  static
  {
    Logger.getLogger(e.class.getName());
  }
  
  public Okio() {}
  
  public static boolean isAndroidGetsocknameError(AssertionError paramAssertionError)
  {
    return (paramAssertionError.getCause() != null) && (paramAssertionError.getMessage() != null) && (paramAssertionError.getMessage().contains("getsockname failed"));
  }
  
  public static BufferedSource readLong(Source paramSource)
  {
    return new RealBufferedSource(paramSource);
  }
  
  public static Source source(InputStream paramInputStream)
  {
    return source(paramInputStream, new Timeout());
  }
  
  public static Source source(InputStream paramInputStream, Timeout paramTimeout)
  {
    if (paramInputStream != null)
    {
      if (paramTimeout != null) {
        return new AsyncTimeout.2(paramTimeout, paramInputStream);
      }
      throw new IllegalArgumentException("timeout == null");
    }
    throw new IllegalArgumentException("in == null");
  }
}
