package okio;

public final class AsyncTimeout
  extends Timeout
{
  public AsyncTimeout() {}
  
  public void enter() {}
}
