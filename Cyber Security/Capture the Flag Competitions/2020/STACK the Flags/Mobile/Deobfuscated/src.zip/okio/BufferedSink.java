package okio;

import java.io.Closeable;
import java.io.Flushable;
import java.nio.channels.WritableByteChannel;

public abstract interface BufferedSink
  extends Closeable, Flushable, WritableByteChannel
{}
