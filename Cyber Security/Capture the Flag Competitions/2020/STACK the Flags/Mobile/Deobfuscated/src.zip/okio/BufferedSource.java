package okio;

import java.nio.channels.ReadableByteChannel;

public abstract interface BufferedSource
  extends Source, ReadableByteChannel
{
  public abstract Buffer buffer();
  
  public abstract long indexOf(ByteString paramByteString);
  
  public abstract int read(Session paramSession);
  
  public abstract boolean read(long paramLong);
}
