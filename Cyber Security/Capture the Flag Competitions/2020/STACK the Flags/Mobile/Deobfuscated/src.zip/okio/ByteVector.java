package okio;

import java.util.Arrays;

public final class ByteVector
  extends ByteString
{
  public final transient byte[][] data;
  public final transient int[] size;
  
  public ByteVector(Buffer paramBuffer, int paramInt)
  {
    super(null);
    Util.checkOffsetAndCount(size, 0L, paramInt);
    int j = 0;
    int i = 0;
    Object localObject = head;
    int k;
    while (j < paramInt)
    {
      k = size;
      int m = pos;
      if (k != m)
      {
        j += k - m;
        i += 1;
        localObject = next;
      }
      else
      {
        throw new AssertionError("s.limit == s.pos");
      }
    }
    data = new byte[i][];
    size = new int[i * 2];
    i = 0;
    j = 0;
    for (paramBuffer = head; i < paramInt; paramBuffer = next)
    {
      data[j] = data;
      k = i + (size - pos);
      i = k;
      if (k > paramInt) {
        i = paramInt;
      }
      localObject = size;
      localObject[j] = i;
      localObject[(data.length + j)] = pos;
      count = true;
      j += 1;
    }
  }
  
  public final int add(int paramInt)
  {
    paramInt = Arrays.binarySearch(size, 0, data.length, paramInt + 1);
    if (paramInt >= 0) {
      return paramInt;
    }
    return paramInt;
  }
  
  public final ByteString add()
  {
    return new ByteString(get());
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    return ((paramObject instanceof ByteString)) && (((ByteString)paramObject).length() == length()) && (write(0, (ByteString)paramObject, 0, length()));
  }
  
  public byte[] get()
  {
    Object localObject2 = size;
    Object localObject1 = data;
    localObject2 = new byte[localObject2[(localObject1.length - 1)]];
    int j = 0;
    int i = 0;
    int m = localObject1.length;
    while (i < m)
    {
      localObject1 = size;
      int n = localObject1[(m + i)];
      int k = localObject1[i];
      System.arraycopy(data[i], n, localObject2, j, k - j);
      j = k;
      i += 1;
    }
    return localObject2;
  }
  
  public int hashCode()
  {
    int i = hashCode;
    if (i != 0) {
      return i;
    }
    int k = 1;
    i = 0;
    int j = 0;
    int i2 = data.length;
    while (j < i2)
    {
      byte[] arrayOfByte = data[j];
      int[] arrayOfInt = size;
      int n = arrayOfInt[(i2 + j)];
      int i1 = arrayOfInt[j];
      int m = n;
      while (m < n + (i1 - i))
      {
        k = k * 31 + arrayOfByte[m];
        m += 1;
      }
      i = i1;
      j += 1;
    }
    hashCode = k;
    return k;
  }
  
  public String hex()
  {
    return add().hex();
  }
  
  public int length()
  {
    return size[(data.length - 1)];
  }
  
  public byte read(int paramInt)
  {
    Util.checkOffsetAndCount(size[(data.length - 1)], paramInt, 1L);
    int j = add(paramInt);
    int i;
    if (j == 0) {
      i = 0;
    } else {
      i = size[(j - 1)];
    }
    int[] arrayOfInt = size;
    byte[][] arrayOfByte = data;
    int k = arrayOfInt[(arrayOfByte.length + j)];
    return arrayOfByte[j][(paramInt - i + k)];
  }
  
  public byte[] read()
  {
    return get();
  }
  
  public String toString()
  {
    return add().toString();
  }
  
  public String write()
  {
    return add().write();
  }
  
  public ByteString write(int paramInt1, int paramInt2)
  {
    return add().write(paramInt1, paramInt2);
  }
  
  public boolean write(int paramInt1, ByteString paramByteString, int paramInt2, int paramInt3)
  {
    if (paramInt1 >= 0)
    {
      if (paramInt1 > length() - paramInt3) {
        return false;
      }
      int j = add(paramInt1);
      int i = paramInt1;
      paramInt1 = j;
      while (paramInt3 > 0)
      {
        if (paramInt1 == 0) {
          j = 0;
        } else {
          j = size[(paramInt1 - 1)];
        }
        int k = Math.min(paramInt3, j + (size[paramInt1] - j) - i);
        int[] arrayOfInt = size;
        byte[][] arrayOfByte = data;
        int m = arrayOfInt[(arrayOfByte.length + paramInt1)];
        if (!paramByteString.write(paramInt2, arrayOfByte[paramInt1], i - j + m, k)) {
          return false;
        }
        i += k;
        paramInt2 += k;
        paramInt3 -= k;
        paramInt1 += 1;
      }
      return true;
    }
    return false;
  }
  
  public boolean write(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    if ((paramInt1 >= 0) && (paramInt1 <= length() - paramInt3) && (paramInt2 >= 0))
    {
      if (paramInt2 > paramArrayOfByte.length - paramInt3) {
        return false;
      }
      int j = add(paramInt1);
      int i = paramInt1;
      paramInt1 = j;
      while (paramInt3 > 0)
      {
        if (paramInt1 == 0) {
          j = 0;
        } else {
          j = size[(paramInt1 - 1)];
        }
        int k = Math.min(paramInt3, j + (size[paramInt1] - j) - i);
        int[] arrayOfInt = size;
        byte[][] arrayOfByte = data;
        int m = arrayOfInt[(arrayOfByte.length + paramInt1)];
        if (!Util.compareArray(arrayOfByte[paramInt1], i - j + m, paramArrayOfByte, paramInt2, k)) {
          return false;
        }
        i += k;
        paramInt2 += k;
        paramInt3 -= k;
        paramInt1 += 1;
      }
      return true;
    }
    return false;
  }
}
