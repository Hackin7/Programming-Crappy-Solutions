package protect.simbio.encryption;

import commons.httpclient.cookie.params.Base64;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class Encryption
{
  public final c mBuilder;
  
  public Encryption(c paramC)
  {
    mBuilder = paramC;
  }
  
  public static Encryption getDefault(String paramString1, String paramString2, byte[] paramArrayOfByte)
  {
    try
    {
      paramString1 = c.init(paramString1, paramString2, paramArrayOfByte).init();
      return paramString1;
    }
    catch (NoSuchAlgorithmException paramString1)
    {
      paramString1.printStackTrace();
    }
    return null;
  }
  
  private SecretKey getSecretKey(char[] paramArrayOfChar)
  {
    return new SecretKeySpec(SecretKeyFactory.getInstance(c.build(mBuilder)).generateSecret(new PBEKeySpec(paramArrayOfChar, c.b(mBuilder).getBytes(c.generateKey(mBuilder)), c.isFavoriteBoard(mBuilder), c.unescape(mBuilder))).getEncoded(), c.c(mBuilder));
  }
  
  private char[] hashTheKey(String paramString)
  {
    MessageDigest localMessageDigest = MessageDigest.getInstance(c.getEngine(mBuilder));
    localMessageDigest.update(paramString.getBytes(c.generateKey(mBuilder)));
    return Base64.encode(localMessageDigest.digest(), 1).toCharArray();
  }
  
  public String decrypt(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    paramString = Base64.decode(paramString, c.length(mBuilder));
    SecretKey localSecretKey = getSecretKey(hashTheKey(c.getEncryptionKey(mBuilder)));
    Cipher localCipher = Cipher.getInstance(c.decode(mBuilder));
    localCipher.init(2, localSecretKey, c.getKey(mBuilder), c.genKey(mBuilder));
    return new String(localCipher.doFinal(paramString));
  }
  
  public void decryptAsync(String paramString, d paramD)
  {
    if (paramD == null) {
      return;
    }
    new Thread(new Encryption.b(this, paramString, paramD)).start();
  }
  
  public String decryptOrNull(String paramString)
  {
    try
    {
      paramString = decrypt(paramString);
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  public String encrypt(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    SecretKey localSecretKey = getSecretKey(hashTheKey(c.getEncryptionKey(mBuilder)));
    paramString = paramString.getBytes(c.generateKey(mBuilder));
    Cipher localCipher = Cipher.getInstance(c.decode(mBuilder));
    localCipher.init(1, localSecretKey, c.getKey(mBuilder), c.genKey(mBuilder));
    return Base64.encode(localCipher.doFinal(paramString), c.length(mBuilder));
  }
  
  public void encryptAsync(String paramString, d paramD)
  {
    if (paramD == null) {
      return;
    }
    new Thread(new Encryption.a(this, paramString, paramD)).start();
  }
  
  public String encryptOrNull(String paramString)
  {
    try
    {
      paramString = encrypt(paramString);
      return paramString;
    }
    catch (Exception paramString)
    {
      paramString.printStackTrace();
    }
    return null;
  }
  
  public class c
  {
    public int _value;
    public String a;
    public int arraySize;
    public byte[] colorProfile;
    public String d;
    public String e;
    public String engine;
    public String formatted;
    public IvParameterSpec keySize;
    public String l;
    public String length;
    public int mCellHeight;
    public String mPermissions;
    public SecureRandom secureRandom;
    
    public c() {}
    
    public static c init(String paramString1, String paramString2, byte[] paramArrayOfByte)
    {
      c localC = new c();
      localC.sweep(paramArrayOfByte);
      localC.setAttributes(paramString1);
      localC.e(paramString2);
      localC.setInfo(128);
      localC.setAlgorithm("AES");
      localC.format("UTF8");
      localC.put(1);
      localC.setProperty("SHA1");
      localC.append(0);
      localC.multiply("AES/CBC/PKCS5Padding");
      localC.getView("SHA1PRNG");
      localC.setLocationDescription("PBKDF2WithHmacSHA1");
      return localC;
    }
    
    public c append(int paramInt)
    {
      arraySize = paramInt;
      return this;
    }
    
    public final String b()
    {
      return d;
    }
    
    public final int booleanValue()
    {
      return _value;
    }
    
    public final String build()
    {
      return mPermissions;
    }
    
    public final String c()
    {
      return a;
    }
    
    public c configure(SecureRandom paramSecureRandom)
    {
      secureRandom = paramSecureRandom;
      return this;
    }
    
    public final String decode()
    {
      return length;
    }
    
    public final String e()
    {
      return e;
    }
    
    public c e(String paramString)
    {
      d = paramString;
      return this;
    }
    
    public final String format()
    {
      return formatted;
    }
    
    public c format(String paramString)
    {
      formatted = paramString;
      return this;
    }
    
    public final int getCellHeight()
    {
      return mCellHeight;
    }
    
    public final byte[] getColorProfile()
    {
      return colorProfile;
    }
    
    public final String getEngine()
    {
      return engine;
    }
    
    public final IvParameterSpec getKeySize()
    {
      return keySize;
    }
    
    public final SecureRandom getSecureRandom()
    {
      return secureRandom;
    }
    
    public final String getValue()
    {
      return l;
    }
    
    public c getView(String paramString)
    {
      l = paramString;
      return this;
    }
    
    public c init(IvParameterSpec paramIvParameterSpec)
    {
      keySize = paramIvParameterSpec;
      return this;
    }
    
    public Encryption init()
    {
      configure(SecureRandom.getInstance(getValue()));
      init(new IvParameterSpec(getColorProfile()));
      return new Encryption(this, null);
    }
    
    public final int length()
    {
      return arraySize;
    }
    
    public c multiply(String paramString)
    {
      e = paramString;
      return this;
    }
    
    public c put(int paramInt)
    {
      _value = paramInt;
      return this;
    }
    
    public c setAlgorithm(String paramString)
    {
      a = paramString;
      return this;
    }
    
    public c setAttributes(String paramString)
    {
      length = paramString;
      return this;
    }
    
    public c setInfo(int paramInt)
    {
      mCellHeight = paramInt;
      return this;
    }
    
    public c setLocationDescription(String paramString)
    {
      mPermissions = paramString;
      return this;
    }
    
    public c setProperty(String paramString)
    {
      engine = paramString;
      return this;
    }
    
    public c sweep(byte[] paramArrayOfByte)
    {
      colorProfile = paramArrayOfByte;
      return this;
    }
  }
  
  public abstract interface d
  {
    public abstract void put(String paramString);
    
    public abstract void show(Exception paramException);
  }
}
