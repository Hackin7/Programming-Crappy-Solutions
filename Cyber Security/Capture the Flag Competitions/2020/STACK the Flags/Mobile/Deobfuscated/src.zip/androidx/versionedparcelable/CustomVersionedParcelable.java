package androidx.versionedparcelable;

import org.jdom.CharSequence;

public abstract class CustomVersionedParcelable
  implements CharSequence
{
  public CustomVersionedParcelable() {}
}
