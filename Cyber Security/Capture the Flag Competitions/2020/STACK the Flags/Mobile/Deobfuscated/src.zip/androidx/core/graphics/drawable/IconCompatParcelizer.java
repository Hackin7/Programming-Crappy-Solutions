package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import org.jdom.Attribute;

public class IconCompatParcelizer
{
  public IconCompatParcelizer() {}
  
  public static IconCompat read(Attribute paramAttribute)
  {
    IconCompat localIconCompat = new IconCompat();
    b = paramAttribute.a(b, 1);
    data = paramAttribute.read(data, 2);
    value = paramAttribute.add(value, 3);
    n = paramAttribute.a(n, 4);
    s = paramAttribute.a(s, 5);
    c = ((ColorStateList)paramAttribute.add(c, 6));
    i = paramAttribute.set(i, 7);
    localIconCompat.init();
    return localIconCompat;
  }
  
  public static void write(IconCompat paramIconCompat, Attribute paramAttribute)
  {
    paramAttribute.name();
    paramAttribute.writeObject();
    paramIconCompat.put(false);
    int i = b;
    if (-1 != i) {
      paramAttribute.write(i, 1);
    }
    Object localObject = data;
    if (localObject != null) {
      paramAttribute.getBytes((byte[])localObject, 2);
    }
    localObject = value;
    if (localObject != null) {
      paramAttribute.put((Parcelable)localObject, 3);
    }
    i = n;
    if (i != 0) {
      paramAttribute.write(i, 4);
    }
    i = s;
    if (i != 0) {
      paramAttribute.write(i, 5);
    }
    localObject = c;
    if (localObject != null) {
      paramAttribute.put((Parcelable)localObject, 6);
    }
    paramIconCompat = paramIconCompat.i;
    if (paramIconCompat != null) {
      paramAttribute.a(paramIconCompat, 7);
    }
  }
}
