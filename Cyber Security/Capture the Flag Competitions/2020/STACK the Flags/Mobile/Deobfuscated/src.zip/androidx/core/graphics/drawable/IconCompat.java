package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Icon;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;

public class IconCompat
  extends CustomVersionedParcelable
{
  public static final PorterDuff.Mode packageName = PorterDuff.Mode.SRC_IN;
  public int b = -1;
  public ColorStateList c = null;
  public byte[] data = null;
  public String i = null;
  public int n = 0;
  public PorterDuff.Mode name = packageName;
  public int s = 0;
  public Parcelable value = null;
  public Object x;
  
  public IconCompat() {}
  
  public static int a(Icon paramIcon)
  {
    if (Build.VERSION.SDK_INT >= 28) {
      return paramIcon.getResId();
    }
    try
    {
      Object localObject = paramIcon.getClass();
      localObject = ((Class)localObject).getMethod("getResId", new Class[0]);
      paramIcon = ((Method)localObject).invoke(paramIcon, new Object[0]);
      paramIcon = (Integer)paramIcon;
      int j = paramIcon.intValue();
      return j;
    }
    catch (NoSuchMethodException paramIcon)
    {
      Log.e("IconCompat", "Unable to get icon resource", paramIcon);
      return 0;
    }
    catch (InvocationTargetException paramIcon)
    {
      Log.e("IconCompat", "Unable to get icon resource", paramIcon);
      return 0;
    }
    catch (IllegalAccessException paramIcon)
    {
      Log.e("IconCompat", "Unable to get icon resource", paramIcon);
    }
    return 0;
  }
  
  public static String getNetworkTypeName(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return "UNKNOWN";
    case 6: 
      return "URI_MASKABLE";
    case 5: 
      return "BITMAP_MASKABLE";
    case 4: 
      return "URI";
    case 3: 
      return "DATA";
    case 2: 
      return "RESOURCE";
    }
    return "BITMAP";
  }
  
  public static String init(Icon paramIcon)
  {
    if (Build.VERSION.SDK_INT >= 28) {
      return paramIcon.getResPackage();
    }
    try
    {
      Object localObject = paramIcon.getClass();
      localObject = ((Class)localObject).getMethod("getResPackage", new Class[0]);
      paramIcon = ((Method)localObject).invoke(paramIcon, new Object[0]);
      return (String)paramIcon;
    }
    catch (NoSuchMethodException paramIcon)
    {
      Log.e("IconCompat", "Unable to get icon package", paramIcon);
      return null;
    }
    catch (InvocationTargetException paramIcon)
    {
      Log.e("IconCompat", "Unable to get icon package", paramIcon);
      return null;
    }
    catch (IllegalAccessException paramIcon)
    {
      Log.e("IconCompat", "Unable to get icon package", paramIcon);
    }
    return null;
  }
  
  public int a()
  {
    if ((b == -1) && (Build.VERSION.SDK_INT >= 23)) {
      return a((Icon)x);
    }
    if (b == 2) {
      return n;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("called getResId() on ");
    localStringBuilder.append(this);
    throw new IllegalStateException(localStringBuilder.toString());
  }
  
  public String get()
  {
    if ((b == -1) && (Build.VERSION.SDK_INT >= 23)) {
      return init((Icon)x);
    }
    if (b == 2) {
      return ((String)x).split(":", -1)[0];
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("called getResPackage() on ");
    localStringBuilder.append(this);
    throw new IllegalStateException(localStringBuilder.toString());
  }
  
  public void init()
  {
    name = PorterDuff.Mode.valueOf(i);
    switch (b)
    {
    default: 
      return;
    case 0: 
      return;
    case 3: 
      x = data;
      return;
    case 2: 
    case 4: 
    case 6: 
      x = new String(data, Charset.forName("UTF-16"));
      return;
    case 1: 
    case 5: 
      localObject = value;
      if (localObject != null)
      {
        x = localObject;
        return;
      }
      localObject = data;
      x = localObject;
      b = 3;
      n = 0;
      s = localObject.length;
      return;
    }
    Object localObject = value;
    if (localObject != null)
    {
      x = localObject;
      return;
    }
    throw new IllegalArgumentException("Invalid icon");
  }
  
  public void put(boolean paramBoolean)
  {
    i = name.name();
    switch (b)
    {
    default: 
      return;
    case 0: 
      return;
    case 4: 
    case 6: 
      data = x.toString().getBytes(Charset.forName("UTF-16"));
      return;
    case 3: 
      data = ((byte[])x);
      return;
    case 2: 
      data = ((String)x).getBytes(Charset.forName("UTF-16"));
      return;
    case 1: 
    case 5: 
      if (paramBoolean)
      {
        Bitmap localBitmap = (Bitmap)x;
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        localBitmap.compress(Bitmap.CompressFormat.PNG, 90, localByteArrayOutputStream);
        data = localByteArrayOutputStream.toByteArray();
        return;
      }
      value = ((Parcelable)x);
      return;
    }
    if (!paramBoolean)
    {
      value = ((Parcelable)x);
      return;
    }
    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
  }
  
  public String toString()
  {
    if (b == -1) {
      return String.valueOf(x);
    }
    StringBuilder localStringBuilder = new StringBuilder("Icon(typ=").append(getNetworkTypeName(b));
    switch (b)
    {
    default: 
      break;
    case 4: 
    case 6: 
      localStringBuilder.append(" uri=");
      localStringBuilder.append(x);
      break;
    case 3: 
      localStringBuilder.append(" len=");
      localStringBuilder.append(n);
      if (s != 0)
      {
        localStringBuilder.append(" off=");
        localStringBuilder.append(s);
      }
      break;
    case 2: 
      localStringBuilder.append(" pkg=");
      localStringBuilder.append(get());
      localStringBuilder.append(" id=");
      localStringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(a()) }));
      break;
    case 1: 
    case 5: 
      localStringBuilder.append(" size=");
      localStringBuilder.append(((Bitmap)x).getWidth());
      localStringBuilder.append("x");
      localStringBuilder.append(((Bitmap)x).getHeight());
    }
    if (c != null)
    {
      localStringBuilder.append(" tint=");
      localStringBuilder.append(c);
    }
    if (name != packageName)
    {
      localStringBuilder.append(" mode=");
      localStringBuilder.append(name);
    }
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
}
