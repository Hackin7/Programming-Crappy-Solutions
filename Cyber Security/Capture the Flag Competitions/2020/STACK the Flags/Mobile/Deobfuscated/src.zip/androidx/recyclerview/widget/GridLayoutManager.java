package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.Arrays;
import org.core.view.tree.AccessibilityNodeInfoCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat.CollectionItemInfoCompat;
import org.objectweb.asm.OrientationHelper;
import org.objectweb.asm.i;

public class GridLayoutManager
  extends LinearLayoutManager
{
  public int[] mCachedBorders;
  public boolean mPendingSpanCountChange = false;
  public final SparseIntArray mPreLayoutSpanIndexCache = new SparseIntArray();
  public final SparseIntArray mPreLayoutSpanSizeCache = new SparseIntArray();
  public View[] mSet;
  public final Rect mSizePerSpan = new Rect();
  public int mSpanCount = -1;
  public c mSpanSizeLookup = new a();
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    setSpanCount(getPropertiesspanCount);
  }
  
  public static int[] calculateItemBorders(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int[] arrayOfInt;
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length == paramInt1 + 1))
    {
      arrayOfInt = paramArrayOfInt;
      if (paramArrayOfInt[(paramArrayOfInt.length - 1)] == paramInt2) {}
    }
    else
    {
      arrayOfInt = new int[paramInt1 + 1];
    }
    arrayOfInt[0] = 0;
    int n = paramInt2 / paramInt1;
    int i2 = paramInt2 % paramInt1;
    int j = 0;
    paramInt2 = 0;
    int i = 1;
    while (i <= paramInt1)
    {
      int k = n;
      int i1 = paramInt2 + i2;
      paramInt2 = i1;
      int m = k;
      if (i1 > 0)
      {
        paramInt2 = i1;
        m = k;
        if (paramInt1 - i1 < i2)
        {
          m = n + 1;
          paramInt2 = i1 - paramInt1;
        }
      }
      j += m;
      arrayOfInt[i] = j;
      i += 1;
    }
    return arrayOfInt;
  }
  
  public int assignSpans(int paramInt1, int paramInt2)
  {
    if ((mOrientation == 1) && (isLayoutRTL()))
    {
      arrayOfInt = mCachedBorders;
      int i = mSpanCount;
      return arrayOfInt[(i - paramInt1)] - arrayOfInt[(i - paramInt1 - paramInt2)];
    }
    int[] arrayOfInt = mCachedBorders;
    return arrayOfInt[(paramInt1 + paramInt2)] - arrayOfInt[paramInt1];
  }
  
  public final void assignSpans(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt, boolean paramBoolean)
  {
    int i;
    int j;
    if (paramBoolean)
    {
      i = 0;
      j = 1;
    }
    else
    {
      i = paramInt - 1;
      paramInt = -1;
      j = -1;
    }
    int k = 0;
    while (i != paramInt)
    {
      View localView = mSet[i];
      b localB = (b)localView.getLayoutParams();
      int m = getSpanSize(paramU, paramY, getPosition(localView));
      mOrientation = m;
      mSpanCount = k;
      k += m;
      i += j;
    }
  }
  
  public final void cachePreLayoutSpanMapping()
  {
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      b localB = (b)getChildAt(i).getLayoutParams();
      int k = localB.getViewLayoutPosition();
      mPreLayoutSpanSizeCache.put(k, localB.getSpanSize());
      mPreLayoutSpanIndexCache.put(k, localB.getSpanIndex());
      i += 1;
    }
  }
  
  public final void calculateItemBorders(int paramInt)
  {
    mCachedBorders = calculateItemBorders(mCachedBorders, mSpanCount, paramInt);
  }
  
  public boolean checkLayoutParams(RecyclerView.p paramP)
  {
    return paramP instanceof b;
  }
  
  public final void clearPreLayoutSpanMappingCache()
  {
    mPreLayoutSpanSizeCache.clear();
    mPreLayoutSpanIndexCache.clear();
  }
  
  public final void ensureAnchorIsInCorrectSpan(RecyclerView.u paramU, RecyclerView.y paramY, LinearLayoutManager.a paramA, int paramInt)
  {
    if (paramInt == 1) {
      i = 1;
    } else {
      i = 0;
    }
    paramInt = getSpanIndex(paramU, paramY, mPosition);
    int j = paramInt;
    if (i != 0) {
      while (j > 0)
      {
        paramInt = mPosition;
        if (paramInt <= 0) {
          break;
        }
        paramInt -= 1;
        mPosition = paramInt;
        j = getSpanIndex(paramU, paramY, paramInt);
      }
    }
    int k = paramY.getItemCount();
    int i = mPosition;
    while (i < k - 1)
    {
      j = getSpanIndex(paramU, paramY, i + 1);
      if (j <= paramInt) {
        break;
      }
      i += 1;
      paramInt = j;
    }
    mPosition = i;
  }
  
  public final void ensureViewSet()
  {
    View[] arrayOfView = mSet;
    if ((arrayOfView == null) || (arrayOfView.length != mSpanCount)) {
      mSet = new View[mSpanCount];
    }
  }
  
  public void fill(RecyclerView.y paramY, LinearLayoutManager.c paramC, RecyclerView.o.c paramC1)
  {
    int j = mSpanCount;
    int i = 0;
    while ((i < mSpanCount) && (paramC.hasMore(paramY)) && (j > 0))
    {
      int k = mCurrentPosition;
      int m = Math.max(0, mScrollingOffset);
      ((i)paramC1).add(k, m);
      mSpanSizeLookup.getSpanSize(k);
      j -= 1;
      mCurrentPosition += mItemDirection;
      i += 1;
    }
  }
  
  public View findReferenceChild(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt1, int paramInt2, int paramInt3)
  {
    ensureLayoutState();
    Object localObject1 = null;
    Object localObject2 = null;
    int j = mOrientationHelper.get();
    int k = mOrientationHelper.a();
    int i;
    if (paramInt2 > paramInt1) {
      i = 1;
    } else {
      i = -1;
    }
    while (paramInt1 != paramInt2)
    {
      View localView = getChildAt(paramInt1);
      int m = getPosition(localView);
      Object localObject3 = localObject1;
      Object localObject4 = localObject2;
      if (m >= 0)
      {
        localObject3 = localObject1;
        localObject4 = localObject2;
        if (m < paramInt3) {
          if (getSpanIndex(paramU, paramY, m) != 0)
          {
            localObject3 = localObject1;
            localObject4 = localObject2;
          }
          else if (((RecyclerView.p)localView.getLayoutParams()).isItemRemoved())
          {
            localObject3 = localObject1;
            localObject4 = localObject2;
            if (localObject1 == null)
            {
              localObject3 = localView;
              localObject4 = localObject2;
            }
          }
          else
          {
            if ((mOrientationHelper.getDecoratedStart(localView) < k) && (mOrientationHelper.getDecoratedEnd(localView) >= j)) {
              return localView;
            }
            localObject3 = localObject1;
            localObject4 = localObject2;
            if (localObject2 == null)
            {
              localObject4 = localView;
              localObject3 = localObject1;
            }
          }
        }
      }
      paramInt1 += i;
      localObject1 = localObject3;
      localObject2 = localObject4;
    }
    if (localObject2 != null) {
      return localObject2;
    }
    return localObject1;
  }
  
  public RecyclerView.p generateDefaultLayoutParams()
  {
    if (mOrientation == 0) {
      return new b(-2, -1);
    }
    return new b(-1, -2);
  }
  
  public RecyclerView.p generateLayoutParams(Context paramContext, AttributeSet paramAttributeSet)
  {
    return new b(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new b((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new b(paramLayoutParams);
  }
  
  public int getColumnCountForAccessibility(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mOrientation == 1) {
      return mSpanCount;
    }
    if (paramY.getItemCount() < 1) {
      return 0;
    }
    return getSpanGroupIndex(paramU, paramY, paramY.getItemCount() - 1) + 1;
  }
  
  public int getRowCountForAccessibility(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mOrientation == 0) {
      return mSpanCount;
    }
    if (paramY.getItemCount() < 1) {
      return 0;
    }
    return getSpanGroupIndex(paramU, paramY, paramY.getItemCount() - 1) + 1;
  }
  
  public final int getSpanGroupIndex(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt)
  {
    if (!paramY.isPreLayout()) {
      return mSpanSizeLookup.getSpanGroupIndex(paramInt, mSpanCount);
    }
    int i = paramU.convertPreLayoutPositionToPostLayout(paramInt);
    if (i == -1)
    {
      paramU = new StringBuilder();
      paramU.append("Cannot find span size for pre layout position. ");
      paramU.append(paramInt);
      Log.w("GridLayoutManager", paramU.toString());
      return 0;
    }
    return mSpanSizeLookup.getSpanGroupIndex(i, mSpanCount);
  }
  
  public final int getSpanIndex(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt)
  {
    if (!paramY.isPreLayout()) {
      return mSpanSizeLookup.getCachedSpanIndex(paramInt, mSpanCount);
    }
    int i = mPreLayoutSpanIndexCache.get(paramInt, -1);
    if (i != -1) {
      return i;
    }
    i = paramU.convertPreLayoutPositionToPostLayout(paramInt);
    if (i == -1)
    {
      paramU = new StringBuilder();
      paramU.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      paramU.append(paramInt);
      Log.w("GridLayoutManager", paramU.toString());
      return 0;
    }
    return mSpanSizeLookup.getCachedSpanIndex(i, mSpanCount);
  }
  
  public final int getSpanSize(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt)
  {
    if (!paramY.isPreLayout())
    {
      mSpanSizeLookup.getSpanSize(paramInt);
      return 1;
    }
    int i = mPreLayoutSpanSizeCache.get(paramInt, -1);
    if (i != -1) {
      return i;
    }
    i = paramU.convertPreLayoutPositionToPostLayout(paramInt);
    if (i == -1)
    {
      paramU = new StringBuilder();
      paramU.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      paramU.append(paramInt);
      Log.w("GridLayoutManager", paramU.toString());
      return 1;
    }
    mSpanSizeLookup.getSpanSize(i);
    return 1;
  }
  
  public final void guessMeasurement(float paramFloat, int paramInt)
  {
    calculateItemBorders(Math.max(Math.round(mSpanCount * paramFloat), paramInt));
  }
  
  public void layoutChunk(RecyclerView.u paramU, RecyclerView.y paramY, LinearLayoutManager.c paramC, LinearLayoutManager.b paramB)
  {
    int i3 = mOrientationHelper.getModeInOther();
    if (i3 != 1073741824) {
      j = 1;
    } else {
      j = 0;
    }
    if (getChildCount() > 0) {
      k = mCachedBorders[mSpanCount];
    } else {
      k = 0;
    }
    if (j != 0) {
      updateMeasurements();
    }
    boolean bool;
    if (mItemDirection == 1) {
      bool = true;
    } else {
      bool = false;
    }
    int i = mSpanCount;
    int n;
    if (!bool)
    {
      i = getSpanIndex(paramU, paramY, mCurrentPosition) + getSpanSize(paramU, paramY, mCurrentPosition);
      n = 0;
    }
    else
    {
      n = 0;
    }
    Object localObject;
    while ((n < mSpanCount) && (paramC.hasMore(paramY)) && (i > 0))
    {
      m = mCurrentPosition;
      i1 = getSpanSize(paramU, paramY, m);
      if (i1 <= mSpanCount)
      {
        i -= i1;
        if (i >= 0)
        {
          localObject = paramC.next(paramU);
          if (localObject != null)
          {
            mSet[n] = localObject;
            n += 1;
          }
        }
      }
      else
      {
        paramU = new StringBuilder();
        paramU.append("Item at position ");
        paramU.append(m);
        paramU.append(" requires ");
        paramU.append(i1);
        paramU.append(" spans but GridLayoutManager has only ");
        paramU.append(mSpanCount);
        paramU.append(" spans.");
        throw new IllegalArgumentException(paramU.toString());
      }
    }
    if (n == 0)
    {
      mFinished = true;
      return;
    }
    i = 0;
    assignSpans(paramU, paramY, n, bool);
    int m = 0;
    float f2;
    for (float f1 = 0.0F; m < n; f1 = f2)
    {
      paramU = mSet[m];
      if (mScrapList == null)
      {
        if (bool) {
          addView(paramU);
        } else {
          addView(paramU, 0);
        }
      }
      else if (bool) {
        addDisappearingView(paramU);
      } else {
        addDisappearingView(paramU, 0);
      }
      calculateItemDecorationsForChild(paramU, mSizePerSpan);
      measureChildWithDecorationsAndMargin(paramU, i3, false);
      i2 = mOrientationHelper.getDecoratedMeasurement(paramU);
      i1 = i;
      if (i2 > i) {
        i1 = i2;
      }
      paramY = (b)paramU.getLayoutParams();
      float f3 = mOrientationHelper.getDecoratedMeasurementInOther(paramU) * 1.0F / mOrientation;
      f2 = f1;
      if (f3 > f1) {
        f2 = f3;
      }
      m += 1;
      i = i1;
    }
    if (j != 0)
    {
      guessMeasurement(f1, k);
      i = 0;
      j = 0;
      while (j < n)
      {
        paramU = mSet[j];
        measureChildWithDecorationsAndMargin(paramU, 1073741824, true);
        m = mOrientationHelper.getDecoratedMeasurement(paramU);
        k = i;
        if (m > i) {
          k = m;
        }
        j += 1;
        i = k;
      }
    }
    int j = 0;
    while (j < n)
    {
      paramU = mSet[j];
      if (mOrientationHelper.getDecoratedMeasurement(paramU) != i)
      {
        paramY = (b)paramU.getLayoutParams();
        localObject = mDecorInsets;
        k = top + bottom + topMargin + bottomMargin;
        m = left + right + leftMargin + rightMargin;
        i1 = assignSpans(mSpanCount, mOrientation);
        if (mOrientation == 1)
        {
          m = RecyclerView.o.getChildMeasureSpec(i1, 1073741824, m, width, false);
          k = View.MeasureSpec.makeMeasureSpec(i - k, 1073741824);
        }
        else
        {
          m = View.MeasureSpec.makeMeasureSpec(i - m, 1073741824);
          k = RecyclerView.o.getChildMeasureSpec(i1, 1073741824, k, height, false);
        }
        measureChildWithDecorationsAndMargin(paramU, m, k, true);
      }
      j += 1;
    }
    mConsumed = i;
    int k = 0;
    m = 0;
    int i1 = 0;
    j = 0;
    if (mOrientation == 1)
    {
      if (mLayoutDirection == -1)
      {
        j = mOffset;
        i = j - i;
      }
      else
      {
        j = mOffset;
        i1 = j + i;
        i = j;
        j = i1;
      }
    }
    else if (mLayoutDirection == -1)
    {
      m = mOffset;
      k = m - i;
      i = i1;
    }
    else
    {
      k = mOffset;
      m = k + i;
      i = i1;
    }
    int i4 = 0;
    i3 = m;
    int i2 = k;
    m = j;
    i1 = i;
    k = i4;
    while (k < n)
    {
      paramU = mSet[k];
      paramY = (b)paramU.getLayoutParams();
      if (mOrientation == 1)
      {
        if (isLayoutRTL())
        {
          j = getPaddingLeft() + mCachedBorders[(mSpanCount - mSpanCount)];
          i = j - mOrientationHelper.getDecoratedMeasurementInOther(paramU);
        }
        else
        {
          i = getPaddingLeft() + mCachedBorders[mSpanCount];
          j = mOrientationHelper.getDecoratedMeasurementInOther(paramU) + i;
        }
      }
      else
      {
        i1 = getPaddingTop() + mCachedBorders[mSpanCount];
        m = mOrientationHelper.getDecoratedMeasurementInOther(paramU) + i1;
        j = i3;
        i = i2;
      }
      measureChildWithDecorationsAndMargin(paramU, i, i1, j, m);
      if ((!paramY.isItemRemoved()) && (!paramY.next())) {
        break label1093;
      }
      mIgnoreConsumed = true;
      label1093:
      mFocusable |= paramU.hasFocusable();
      k += 1;
      i2 = i;
      i3 = j;
    }
    Arrays.fill(mSet, null);
  }
  
  public final void measureChildWithDecorationsAndMargin(View paramView, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = shouldReMeasureChild(paramView, paramInt1, paramInt2, localP);
    } else {
      paramBoolean = shouldMeasureChild(paramView, paramInt1, paramInt2, localP);
    }
    if (paramBoolean) {
      paramView.measure(paramInt1, paramInt2);
    }
  }
  
  public final void measureChildWithDecorationsAndMargin(View paramView, int paramInt, boolean paramBoolean)
  {
    b localB = (b)paramView.getLayoutParams();
    Rect localRect = mDecorInsets;
    int j = top + bottom + topMargin + bottomMargin;
    int i = left + right + leftMargin + rightMargin;
    int k = assignSpans(mSpanCount, mOrientation);
    if (mOrientation == 1)
    {
      i = RecyclerView.o.getChildMeasureSpec(k, paramInt, i, width, false);
      paramInt = RecyclerView.o.getChildMeasureSpec(mOrientationHelper.getTotalSpace(), getHeightMode(), j, height, true);
    }
    else
    {
      paramInt = RecyclerView.o.getChildMeasureSpec(k, paramInt, j, height, false);
      i = RecyclerView.o.getChildMeasureSpec(mOrientationHelper.getTotalSpace(), getWidthMode(), i, width, true);
    }
    measureChildWithDecorationsAndMargin(paramView, i, paramInt, paramBoolean);
  }
  
  public void onAnchorReady(RecyclerView.u paramU, RecyclerView.y paramY, LinearLayoutManager.a paramA, int paramInt)
  {
    super.onAnchorReady(paramU, paramY, paramA, paramInt);
    updateMeasurements();
    if ((paramY.getItemCount() > 0) && (!paramY.isPreLayout())) {
      ensureAnchorIsInCorrectSpan(paramU, paramY, paramA, paramInt);
    }
    ensureViewSet();
  }
  
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    View localView2 = findContainingItemView(paramView);
    if (localView2 == null) {
      return null;
    }
    Object localObject = (b)localView2.getLayoutParams();
    int i4 = mSpanCount;
    int i5 = mSpanCount + mOrientation;
    if (super.onFocusSearchFailed(paramView, paramInt, paramU, paramY) == null) {
      return null;
    }
    int i10;
    if (fill(paramInt) == 1) {
      i10 = 1;
    } else {
      i10 = 0;
    }
    if (i10 != mShouldReverseLayout) {
      paramInt = 1;
    } else {
      paramInt = 0;
    }
    int j;
    int k;
    if (paramInt != 0)
    {
      paramInt = getChildCount() - 1;
      j = -1;
      k = -1;
    }
    else
    {
      paramInt = 0;
      j = 1;
      k = getChildCount();
    }
    int m;
    if ((mOrientation == 1) && (isLayoutRTL())) {
      m = 1;
    } else {
      m = 0;
    }
    paramView = null;
    localObject = null;
    int i6 = getSpanGroupIndex(paramU, paramY, paramInt);
    int i = -1;
    int i1 = 0;
    int i3 = -1;
    int i2 = 0;
    int n = paramInt;
    for (;;)
    {
      GridLayoutManager localGridLayoutManager = this;
      if (n == k) {
        break;
      }
      paramInt = localGridLayoutManager.getSpanGroupIndex(paramU, paramY, n);
      View localView1 = localGridLayoutManager.getChildAt(n);
      if (localView1 == localView2) {
        break;
      }
      if ((localView1.hasFocusable()) && (paramInt != i6))
      {
        if (paramView != null) {
          break;
        }
      }
      else
      {
        b localB = (b)localView1.getLayoutParams();
        int i7 = mSpanCount;
        int i8 = mSpanCount + mOrientation;
        if ((localView1.hasFocusable()) && (i7 == i4) && (i8 == i5)) {
          return localView1;
        }
        if (((localView1.hasFocusable()) && (paramView == null)) || ((!localView1.hasFocusable()) && (localObject == null)))
        {
          paramInt = 1;
        }
        else
        {
          paramInt = Math.max(i7, i4);
          int i9 = Math.min(i8, i5) - paramInt;
          if (localView1.hasFocusable())
          {
            if (i9 > i1)
            {
              paramInt = 1;
              break label458;
            }
            if (i9 == i1)
            {
              if (i7 > i) {
                paramInt = 1;
              } else {
                paramInt = 0;
              }
              if (m != paramInt) {
                break label456;
              }
              paramInt = 1;
              break label458;
            }
          }
          else if (paramView == null)
          {
            paramInt = 0;
            if (localGridLayoutManager.a(localView1, false))
            {
              if (i9 > i2)
              {
                paramInt = 1;
                break label458;
              }
              if (i9 == i2)
              {
                if (i7 > i3) {
                  paramInt = 1;
                }
                if (m == paramInt)
                {
                  paramInt = 1;
                  break label458;
                }
              }
            }
          }
          label456:
          paramInt = 0;
        }
        label458:
        if (paramInt != 0) {
          if (localView1.hasFocusable())
          {
            i = mSpanCount;
            i1 = Math.min(i8, i5) - Math.max(i7, i4);
            paramView = localView1;
          }
          else
          {
            i3 = mSpanCount;
            paramInt = Math.min(i8, i5);
            i2 = Math.max(i7, i4);
            localObject = localView1;
            i2 = paramInt - i2;
          }
        }
      }
      n += j;
    }
    if (paramView != null) {
      return paramView;
    }
    return localObject;
  }
  
  public void onInitializeAccessibilityNodeInfoForItem(RecyclerView.u paramU, RecyclerView.y paramY, View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
    ViewGroup.LayoutParams localLayoutParams = paramView.getLayoutParams();
    if (!(localLayoutParams instanceof b))
    {
      super.onInitializeAccessibilityNodeInfoForItem(paramView, paramAccessibilityNodeInfoCompat);
      return;
    }
    paramView = (b)localLayoutParams;
    int i = getSpanGroupIndex(paramU, paramY, paramView.getViewLayoutPosition());
    boolean bool;
    if (mOrientation == 0)
    {
      j = paramView.getSpanIndex();
      k = paramView.getSpanSize();
      if ((mSpanCount > 1) && (paramView.getSpanSize() == mSpanCount)) {
        bool = true;
      } else {
        bool = false;
      }
      paramAccessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(j, k, i, 1, bool, false));
      return;
    }
    int j = paramView.getSpanIndex();
    int k = paramView.getSpanSize();
    if ((mSpanCount > 1) && (paramView.getSpanSize() == mSpanCount)) {
      bool = true;
    } else {
      bool = false;
    }
    paramAccessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(i, 1, j, k, bool, false));
  }
  
  public void onItemsAdded(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    mSpanSizeLookup.invalidateSpanIndexCache();
  }
  
  public void onItemsChanged(RecyclerView paramRecyclerView)
  {
    mSpanSizeLookup.invalidateSpanIndexCache();
  }
  
  public void onItemsMoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3)
  {
    mSpanSizeLookup.invalidateSpanIndexCache();
  }
  
  public void onItemsRemoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    mSpanSizeLookup.invalidateSpanIndexCache();
  }
  
  public void onItemsUpdated(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject)
  {
    mSpanSizeLookup.invalidateSpanIndexCache();
  }
  
  public void onLayoutChildren(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (paramY.isPreLayout()) {
      cachePreLayoutSpanMapping();
    }
    super.onLayoutChildren(paramU, paramY);
    clearPreLayoutSpanMappingCache();
  }
  
  public void onLayoutChildren(RecyclerView.y paramY)
  {
    super.onLayoutChildren(paramY);
    mPendingSpanCountChange = false;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    updateMeasurements();
    ensureViewSet();
    return super.scrollHorizontallyBy(paramInt, paramU, paramY);
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    updateMeasurements();
    ensureViewSet();
    return super.scrollVerticallyBy(paramInt, paramU, paramY);
  }
  
  public void setMeasuredDimension(Rect paramRect, int paramInt1, int paramInt2)
  {
    if (mCachedBorders == null) {
      super.setMeasuredDimension(paramRect, paramInt1, paramInt2);
    }
    int i = getPaddingLeft() + getPaddingRight();
    int j = getPaddingTop() + getPaddingBottom();
    if (mOrientation == 1)
    {
      paramInt2 = RecyclerView.o.chooseSize(paramInt2, paramRect.height() + j, getMinimumHeight());
      paramRect = mCachedBorders;
      paramInt1 = RecyclerView.o.chooseSize(paramInt1, paramRect[(paramRect.length - 1)] + i, getMinimumWidth());
    }
    else
    {
      paramInt1 = RecyclerView.o.chooseSize(paramInt1, paramRect.width() + i, getMinimumWidth());
      paramRect = mCachedBorders;
      paramInt2 = RecyclerView.o.chooseSize(paramInt2, paramRect[(paramRect.length - 1)] + j, getMinimumHeight());
    }
    setMeasuredDimension(paramInt1, paramInt2);
  }
  
  public void setSpanCount(int paramInt)
  {
    if (paramInt == mSpanCount) {
      return;
    }
    mPendingSpanCountChange = true;
    if (paramInt >= 1)
    {
      mSpanCount = paramInt;
      mSpanSizeLookup.invalidateSpanIndexCache();
      requestLayout();
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Span count should be at least 1. Provided ");
    localStringBuilder.append(paramInt);
    throw new IllegalArgumentException(localStringBuilder.toString());
  }
  
  public void setStackFromEnd(boolean paramBoolean)
  {
    if (!paramBoolean)
    {
      super.setStackFromEnd(false);
      return;
    }
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public boolean supportsPredictiveItemAnimations()
  {
    return (mPendingSavedState == null) && (!mPendingSpanCountChange);
  }
  
  public final void updateMeasurements()
  {
    int i;
    if (getOrientation() == 1) {
      i = getWidth() - getPaddingRight() - getPaddingLeft();
    } else {
      i = getHeight() - getPaddingBottom() - getPaddingTop();
    }
    calculateItemBorders(i);
  }
  
  public static final class a
    extends GridLayoutManager.c
  {
    public a() {}
    
    public int getSpanIndex(int paramInt1, int paramInt2)
    {
      return paramInt1 % paramInt2;
    }
    
    public int getSpanSize(int paramInt)
    {
      return 1;
    }
  }
  
  public static class b
    extends RecyclerView.p
  {
    public int mOrientation = 0;
    public int mSpanCount = -1;
    
    public b(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public b(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    public b(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
    
    public int getSpanIndex()
    {
      return mSpanCount;
    }
    
    public int getSpanSize()
    {
      return mOrientation;
    }
  }
  
  public static abstract class c
  {
    public boolean mCacheSpanIndices = false;
    public final SparseIntArray mSpanIndexCache = new SparseIntArray();
    
    public c() {}
    
    public int getCachedSpanIndex(int paramInt1, int paramInt2)
    {
      if (!mCacheSpanIndices) {
        return getSpanIndex(paramInt1, paramInt2);
      }
      int i = mSpanIndexCache.get(paramInt1, -1);
      if (i != -1) {
        return i;
      }
      paramInt2 = getSpanIndex(paramInt1, paramInt2);
      mSpanIndexCache.put(paramInt1, paramInt2);
      return paramInt2;
    }
    
    public int getSpanGroupIndex(int paramInt1, int paramInt2)
    {
      int i = 0;
      int m = 0;
      getSpanSize(paramInt1);
      int k = 0;
      while (k < paramInt1)
      {
        getSpanSize(k);
        int n = i + 1;
        int j;
        if (n == paramInt2)
        {
          i = 0;
          j = m + 1;
        }
        else
        {
          i = n;
          j = m;
          if (n > paramInt2)
          {
            i = 1;
            j = m + 1;
          }
        }
        k += 1;
        m = j;
      }
      if (i + 1 > paramInt2) {
        return m + 1;
      }
      return m;
    }
    
    public abstract int getSpanIndex(int paramInt1, int paramInt2);
    
    public abstract int getSpanSize(int paramInt);
    
    public void invalidateSpanIndexCache()
    {
      mSpanIndexCache.clear();
    }
  }
}
