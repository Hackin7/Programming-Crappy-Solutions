package androidx.activity;

import android.app.Activity;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.savedstate.SavedStateRegistry;
import org.core.helpers.AbstractGalleryActivity;
import org.misc.Paint;
import org.misc.b;
import org.util.BaseFragment;
import org.util.Control;
import org.util.Label;
import org.util.Log;
import org.util.MenuItem;
import org.util.Scope;
import org.util.d;
import org.util.f;

public class ComponentActivity
  extends AbstractGalleryActivity
  implements d, Control, Paint, org.curve.c
{
  public int mContentLayoutId;
  public final f mLifecycleRegistry = new f(this);
  public final OnBackPressedDispatcher mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a());
  public final b mSavedStateRegistryController = b.a(this);
  public Label mViewModelStore;
  
  public ComponentActivity()
  {
    if (getLifecycle() != null)
    {
      getLifecycle().a(new MenuItem()
      {
        public void b(d paramAnonymousD, Scope paramAnonymousScope)
        {
          if (paramAnonymousScope == Scope.ON_STOP)
          {
            paramAnonymousD = getWindow();
            if (paramAnonymousD != null) {
              paramAnonymousD = paramAnonymousD.peekDecorView();
            } else {
              paramAnonymousD = null;
            }
            if (paramAnonymousD != null) {
              paramAnonymousD.cancelPendingInputEvents();
            }
          }
        }
      });
      getLifecycle().a(new MenuItem()
      {
        public void b(d paramAnonymousD, Scope paramAnonymousScope)
        {
          if ((paramAnonymousScope == Scope.ON_DESTROY) && (!isChangingConfigurations())) {
            getViewModelStore().a();
          }
        }
      });
      if (Build.VERSION.SDK_INT <= 23) {
        getLifecycle().a(new ImmLeaksCleaner(this));
      }
    }
    else
    {
      throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }
  }
  
  public ComponentActivity(int paramInt)
  {
    this();
    mContentLayoutId = paramInt;
  }
  
  public Object getLastCustomNonConfigurationInstance()
  {
    b localB = (b)getLastNonConfigurationInstance();
    if (localB != null) {
      return custom;
    }
    return null;
  }
  
  public Log getLifecycle()
  {
    return mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher()
  {
    return mOnBackPressedDispatcher;
  }
  
  public final SavedStateRegistry getSavedStateRegistry()
  {
    return mSavedStateRegistryController.d();
  }
  
  public Label getViewModelStore()
  {
    if (getApplication() != null)
    {
      if (mViewModelStore == null)
      {
        b localB = (b)getLastNonConfigurationInstance();
        if (localB != null) {
          mViewModelStore = loginTask;
        }
        if (mViewModelStore == null) {
          mViewModelStore = new Label();
        }
      }
      return mViewModelStore;
    }
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void onBackPressed()
  {
    mOnBackPressedDispatcher.a();
  }
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    mSavedStateRegistryController.a(paramBundle);
    BaseFragment.showDialog(this);
    int i = mContentLayoutId;
    if (i != 0) {
      setContentView(i);
    }
  }
  
  public Object onRetainCustomNonConfigurationInstance()
  {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance()
  {
    Object localObject3 = onRetainCustomNonConfigurationInstance();
    Object localObject2 = mViewModelStore;
    Object localObject1 = localObject2;
    if (localObject2 == null)
    {
      b localB = (b)getLastNonConfigurationInstance();
      localObject1 = localObject2;
      if (localB != null) {
        localObject1 = loginTask;
      }
    }
    if ((localObject1 == null) && (localObject3 == null)) {
      return null;
    }
    localObject2 = new b();
    custom = localObject3;
    loginTask = ((Label)localObject1);
    return localObject2;
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    Log localLog = getLifecycle();
    if ((localLog instanceof f)) {
      ((f)localLog).c(org.util.c.d);
    }
    super.onSaveInstanceState(paramBundle);
    mSavedStateRegistryController.e(paramBundle);
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    public void run()
    {
      ComponentActivity.access$001(ComponentActivity.this);
    }
  }
  
  public static final class b
  {
    public Object custom;
    public Label loginTask;
    
    public b() {}
  }
}
