package androidx.savedstate;

import a.c.a.b.b;
import android.annotation.SuppressLint;
import android.os.BaseBundle;
import android.os.Bundle;
import java.util.Map.Entry;
import org.misc.Paint;
import org.spongycastle.crypto.params.f;
import org.util.Log;
import org.util.MenuItem;
import org.util.Scope;

@SuppressLint({"RestrictedApi"})
public final class SavedStateRegistry
{
  public boolean J;
  public Bundle a;
  public b<String, b> c = new f();
  public boolean d;
  
  public SavedStateRegistry() {}
  
  public Bundle a(String paramString)
  {
    Bundle localBundle;
    if (J)
    {
      localBundle = a;
      if (localBundle != null)
      {
        localBundle = localBundle.getBundle(paramString);
        a.remove(paramString);
        if (a.isEmpty())
        {
          a = null;
          return localBundle;
        }
      }
      else
      {
        return null;
      }
    }
    else
    {
      throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
    }
    return localBundle;
  }
  
  public void a(Log paramLog, Bundle paramBundle)
  {
    if (!J)
    {
      if (paramBundle != null) {
        a = paramBundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
      }
      paramLog.a(new MenuItem()
      {
        public void b(org.util.d paramAnonymousD, Scope paramAnonymousScope)
        {
          if (paramAnonymousScope == Scope.ON_START)
          {
            d = true;
            return;
          }
          if (paramAnonymousScope == Scope.ON_STOP) {
            d = false;
          }
        }
      });
      J = true;
      return;
    }
    throw new IllegalStateException("SavedStateRegistry was already restored.");
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    Bundle localBundle = new Bundle();
    Object localObject = a;
    if (localObject != null) {
      localBundle.putAll((Bundle)localObject);
    }
    localObject = c.a();
    while (((org.spongycastle.crypto.params.d)localObject).hasNext())
    {
      Map.Entry localEntry = (Map.Entry)((org.spongycastle.crypto.params.d)localObject).next();
      localBundle.putBundle((String)localEntry.getKey(), ((b)localEntry.getValue()).saveInstanceState());
    }
    paramBundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", localBundle);
  }
  
  public static abstract interface a
  {
    public abstract void removeView(Paint paramPaint);
  }
  
  public static abstract interface b
  {
    public abstract Bundle saveInstanceState();
  }
}
