package androidx.lifecycle;

import org.util.Attribute;
import org.util.MenuItem;
import org.util.Scope;
import org.util.d;

public class SingleGeneratedAdapterObserver
  implements MenuItem
{
  public final Attribute j;
  
  public SingleGeneratedAdapterObserver(Attribute paramAttribute)
  {
    j = paramAttribute;
  }
  
  public void b(d paramD, Scope paramScope)
  {
    j.a(paramD, paramScope, false, null);
    j.a(paramD, paramScope, true, null);
  }
}
