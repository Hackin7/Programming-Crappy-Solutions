package androidx.appcompat.wiki;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;
import org.core.view.ViewCompat;
import org.v7.R.attr;
import org.v7.R.id;
import org.v7.R.styleable;
import org.v7.app.AppCompatDialog;
import org.v7.widget.i0.a;

public class AlertController
{
  public CharSequence content;
  public Drawable icon;
  public ListAdapter mAdapter;
  public int mAlertDialogLayout;
  public final View.OnClickListener mButtonHandler = new a();
  public Button mButtonNegative;
  public Message mButtonNegativeMessage;
  public CharSequence mButtonNegativeText;
  public Button mButtonNeutral;
  public Message mButtonNeutralMessage;
  public CharSequence mButtonNeutralText;
  public int mButtonPanelLayoutHint = 0;
  public int mButtonPanelSideLayout;
  public Button mButtonPositive;
  public Message mButtonPositiveMessage;
  public Drawable mButtonPositiveText;
  public int mCheckedItem = -1;
  public final Context mContext;
  public View mCustomTitleView;
  public final AppCompatDialog mDialog;
  public Handler mHandler;
  public Drawable mIcon;
  public int mIconId = 0;
  public ImageView mIconView;
  public int mListItemLayout;
  public int mListLayout;
  public ListView mListView;
  public CharSequence mMessage;
  public TextView mMessageView;
  public int mMultiChoiceItemLayout;
  public NestedScrollView mScrollView;
  public boolean mSelected;
  public int mSingleChoiceItemLayout;
  public Drawable mState;
  public CharSequence mTitle;
  public TextView mTitleView;
  public View mView;
  public int mViewLayoutResId;
  public int mViewSpacingBottom;
  public int mViewSpacingLeft;
  public int mViewSpacingRight;
  public boolean mViewSpacingSpecified = false;
  public int mViewSpacingTop;
  public final Window mWindow;
  public final int width;
  
  public AlertController(Context paramContext, AppCompatDialog paramAppCompatDialog, Window paramWindow)
  {
    mContext = paramContext;
    mDialog = paramAppCompatDialog;
    mWindow = paramWindow;
    mHandler = new g(paramAppCompatDialog);
    paramContext = paramContext.obtainStyledAttributes(null, R.styleable.AlertDialog, R.attr.alertDialogStyle, 0);
    mAlertDialogLayout = paramContext.getResourceId(R.styleable.AlertDialog_android_layout, 0);
    mButtonPanelSideLayout = paramContext.getResourceId(R.styleable.AlertDialog_buttonPanelSideLayout, 0);
    mListLayout = paramContext.getResourceId(R.styleable.AlertDialog_listLayout, 0);
    mMultiChoiceItemLayout = paramContext.getResourceId(R.styleable.AlertDialog_multiChoiceItemLayout, 0);
    mSingleChoiceItemLayout = paramContext.getResourceId(R.styleable.AlertDialog_singleChoiceItemLayout, 0);
    mListItemLayout = paramContext.getResourceId(R.styleable.AlertDialog_listItemLayout, 0);
    mSelected = paramContext.getBoolean(R.styleable.AlertDialog_showTitle, true);
    width = paramContext.getDimensionPixelSize(R.styleable.AlertDialog_buttonIconDimen, 0);
    paramContext.recycle();
    paramAppCompatDialog.supportRequestWindowFeature(1);
  }
  
  public static void access$800(View paramView1, View paramView2, View paramView3)
  {
    int j = 0;
    int i;
    if (paramView2 != null)
    {
      if (paramView1.canScrollVertically(-1)) {
        i = 0;
      } else {
        i = 4;
      }
      paramView2.setVisibility(i);
    }
    if (paramView3 != null)
    {
      if (paramView1.canScrollVertically(1)) {
        i = j;
      } else {
        i = 4;
      }
      paramView3.setVisibility(i);
    }
  }
  
  public static boolean canTextInput(View paramView)
  {
    if (paramView.onCheckIsTextEditor()) {
      return true;
    }
    if (!(paramView instanceof ViewGroup)) {
      return false;
    }
    paramView = (ViewGroup)paramView;
    int i = paramView.getChildCount();
    while (i > 0)
    {
      int j = i - 1;
      i = j;
      if (canTextInput(paramView.getChildAt(j))) {
        return true;
      }
    }
    return false;
  }
  
  public static boolean shouldCenterSingleButton(Context paramContext)
  {
    TypedValue localTypedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, localTypedValue, true);
    return data != 0;
  }
  
  public final void centerButton(Button paramButton)
  {
    LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    gravity = 1;
    weight = 0.5F;
    paramButton.setLayoutParams(localLayoutParams);
  }
  
  public int getIconAttributeResId(int paramInt)
  {
    TypedValue localTypedValue = new TypedValue();
    mContext.getTheme().resolveAttribute(paramInt, localTypedValue, true);
    return resourceId;
  }
  
  public ListView getListView()
  {
    return mListView;
  }
  
  public void installContent()
  {
    int i = selectContentView();
    mDialog.setContentView(i);
    setupView();
  }
  
  public boolean onKeyDown(KeyEvent paramKeyEvent)
  {
    NestedScrollView localNestedScrollView = mScrollView;
    return (localNestedScrollView != null) && (localNestedScrollView.executeKeyEvent(paramKeyEvent));
  }
  
  public boolean onKeyUp(KeyEvent paramKeyEvent)
  {
    NestedScrollView localNestedScrollView = mScrollView;
    return (localNestedScrollView != null) && (localNestedScrollView.executeKeyEvent(paramKeyEvent));
  }
  
  public final ViewGroup resolvePanel(View paramView1, View paramView2)
  {
    if (paramView1 == null)
    {
      paramView1 = paramView2;
      if ((paramView2 instanceof ViewStub)) {
        paramView1 = ((ViewStub)paramView2).inflate();
      }
      return (ViewGroup)paramView1;
    }
    if (paramView2 != null)
    {
      ViewParent localViewParent = paramView2.getParent();
      if ((localViewParent instanceof ViewGroup)) {
        ((ViewGroup)localViewParent).removeView(paramView2);
      }
    }
    paramView2 = paramView1;
    if ((paramView1 instanceof ViewStub)) {
      paramView2 = ((ViewStub)paramView1).inflate();
    }
    return (ViewGroup)paramView2;
  }
  
  public final int selectContentView()
  {
    int i = mButtonPanelSideLayout;
    if (i == 0) {
      return mAlertDialogLayout;
    }
    if (mButtonPanelLayoutHint == 1) {
      return i;
    }
    return mAlertDialogLayout;
  }
  
  public void setButton(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable)
  {
    Message localMessage = paramMessage;
    if (paramMessage == null)
    {
      localMessage = paramMessage;
      if (paramOnClickListener != null) {
        localMessage = mHandler.obtainMessage(paramInt, paramOnClickListener);
      }
    }
    if (paramInt != -3)
    {
      if (paramInt != -2)
      {
        if (paramInt == -1)
        {
          mButtonNeutralText = paramCharSequence;
          mButtonNeutralMessage = localMessage;
          mButtonPositiveText = paramDrawable;
          return;
        }
        throw new IllegalArgumentException("Button does not exist");
      }
      mButtonNegativeText = paramCharSequence;
      mButtonNegativeMessage = localMessage;
      icon = paramDrawable;
      return;
    }
    content = paramCharSequence;
    mButtonPositiveMessage = localMessage;
    mState = paramDrawable;
  }
  
  public void setCustomTitle(View paramView)
  {
    mCustomTitleView = paramView;
  }
  
  public void setIcon(int paramInt)
  {
    mIcon = null;
    mIconId = paramInt;
    ImageView localImageView = mIconView;
    if (localImageView != null)
    {
      if (paramInt != 0)
      {
        localImageView.setVisibility(0);
        mIconView.setImageResource(mIconId);
        return;
      }
      localImageView.setVisibility(8);
    }
  }
  
  public void setIcon(Drawable paramDrawable)
  {
    mIcon = paramDrawable;
    mIconId = 0;
    ImageView localImageView = mIconView;
    if (localImageView != null)
    {
      if (paramDrawable != null)
      {
        localImageView.setVisibility(0);
        mIconView.setImageDrawable(paramDrawable);
        return;
      }
      localImageView.setVisibility(8);
    }
  }
  
  public final void setScrollIndicators(ViewGroup paramViewGroup, View paramView, int paramInt1, int paramInt2)
  {
    View localView2 = mWindow.findViewById(R.id.scrollIndicatorUp);
    Object localObject2 = localView2;
    View localView1 = mWindow.findViewById(R.id.scrollIndicatorDown);
    Object localObject1 = localView1;
    if (Build.VERSION.SDK_INT >= 23)
    {
      ViewCompat.setScrollIndicators(paramView, paramInt1, paramInt2);
      if (localView2 != null) {
        paramViewGroup.removeView(localView2);
      }
      if (localView1 != null) {
        paramViewGroup.removeView(localView1);
      }
    }
    else
    {
      paramView = (View)localObject2;
      if (localView2 != null)
      {
        paramView = (View)localObject2;
        if ((paramInt1 & 0x1) == 0)
        {
          paramViewGroup.removeView(localView2);
          paramView = null;
        }
      }
      localObject2 = localObject1;
      if (localView1 != null)
      {
        localObject2 = localObject1;
        if ((paramInt1 & 0x2) == 0)
        {
          paramViewGroup.removeView(localView1);
          localObject2 = null;
        }
      }
      if ((paramView != null) || (localObject2 != null))
      {
        if (mMessage != null)
        {
          mScrollView.setOnScrollChangeListener(new AlertController.b(this, paramView, (View)localObject2));
          mScrollView.post(new AlertController.c(this, paramView, (View)localObject2));
          return;
        }
        localObject1 = mListView;
        if (localObject1 != null)
        {
          ((AbsListView)localObject1).setOnScrollListener(new AlertController.d(this, paramView, (View)localObject2));
          mListView.post(new AlertController.e(this, paramView, (View)localObject2));
          return;
        }
        if (paramView != null) {
          paramViewGroup.removeView(paramView);
        }
        if (localObject2 != null) {
          paramViewGroup.removeView((View)localObject2);
        }
      }
    }
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    mTitle = paramCharSequence;
    TextView localTextView = mTitleView;
    if (localTextView != null) {
      localTextView.setText(paramCharSequence);
    }
  }
  
  public void setView(int paramInt)
  {
    mView = null;
    mViewLayoutResId = paramInt;
    mViewSpacingSpecified = false;
  }
  
  public void setView(View paramView)
  {
    mView = paramView;
    mViewLayoutResId = 0;
    mViewSpacingSpecified = false;
  }
  
  public void setView(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    mView = paramView;
    mViewLayoutResId = 0;
    mViewSpacingSpecified = true;
    mViewSpacingLeft = paramInt1;
    mViewSpacingTop = paramInt2;
    mViewSpacingRight = paramInt3;
    mViewSpacingBottom = paramInt4;
  }
  
  public final void setupButtons(ViewGroup paramViewGroup)
  {
    int i = 0;
    Object localObject = (Button)paramViewGroup.findViewById(16908313);
    mButtonPositive = ((Button)localObject);
    ((View)localObject).setOnClickListener(mButtonHandler);
    boolean bool = TextUtils.isEmpty(mButtonNeutralText);
    int j = 0;
    if ((bool) && (mButtonPositiveText == null))
    {
      mButtonPositive.setVisibility(8);
    }
    else
    {
      mButtonPositive.setText(mButtonNeutralText);
      localObject = mButtonPositiveText;
      if (localObject != null)
      {
        i = width;
        ((Drawable)localObject).setBounds(0, 0, i, i);
        mButtonPositive.setCompoundDrawables(mButtonPositiveText, null, null, null);
      }
      mButtonPositive.setVisibility(0);
      i = 0x0 | 0x1;
    }
    localObject = (Button)paramViewGroup.findViewById(16908314);
    mButtonNegative = ((Button)localObject);
    ((View)localObject).setOnClickListener(mButtonHandler);
    int k;
    if ((TextUtils.isEmpty(mButtonNegativeText)) && (icon == null))
    {
      mButtonNegative.setVisibility(8);
    }
    else
    {
      mButtonNegative.setText(mButtonNegativeText);
      localObject = icon;
      if (localObject != null)
      {
        k = width;
        ((Drawable)localObject).setBounds(0, 0, k, k);
        mButtonNegative.setCompoundDrawables(icon, null, null, null);
      }
      mButtonNegative.setVisibility(0);
      i |= 0x2;
    }
    localObject = (Button)paramViewGroup.findViewById(16908315);
    mButtonNeutral = ((Button)localObject);
    ((View)localObject).setOnClickListener(mButtonHandler);
    if ((TextUtils.isEmpty(content)) && (mState == null))
    {
      mButtonNeutral.setVisibility(8);
    }
    else
    {
      mButtonNeutral.setText(content);
      localObject = mState;
      if (localObject != null)
      {
        k = width;
        ((Drawable)localObject).setBounds(0, 0, k, k);
        mButtonNeutral.setCompoundDrawables(mState, null, null, null);
      }
      mButtonNeutral.setVisibility(0);
      i |= 0x4;
    }
    if (shouldCenterSingleButton(mContext)) {
      if (i == 1) {
        centerButton(mButtonPositive);
      } else if (i == 2) {
        centerButton(mButtonNegative);
      } else if (i == 4) {
        centerButton(mButtonNeutral);
      }
    }
    if (i != 0) {
      j = 1;
    }
    if (j == 0) {
      paramViewGroup.setVisibility(8);
    }
  }
  
  public final void setupContent(ViewGroup paramViewGroup)
  {
    Object localObject = (NestedScrollView)mWindow.findViewById(R.id.scrollView);
    mScrollView = ((NestedScrollView)localObject);
    ((View)localObject).setFocusable(false);
    mScrollView.setNestedScrollingEnabled(false);
    localObject = (TextView)paramViewGroup.findViewById(16908299);
    mMessageView = ((TextView)localObject);
    if (localObject == null) {
      return;
    }
    CharSequence localCharSequence = mMessage;
    if (localCharSequence != null)
    {
      ((TextView)localObject).setText(localCharSequence);
      return;
    }
    ((View)localObject).setVisibility(8);
    mScrollView.removeView(mMessageView);
    if (mListView != null)
    {
      paramViewGroup = (ViewGroup)mScrollView.getParent();
      int i = paramViewGroup.indexOfChild(mScrollView);
      paramViewGroup.removeViewAt(i);
      paramViewGroup.addView(mListView, i, new ViewGroup.LayoutParams(-1, -1));
      return;
    }
    paramViewGroup.setVisibility(8);
  }
  
  public final void setupCustomContent(ViewGroup paramViewGroup)
  {
    View localView = mView;
    int i = 0;
    if (localView != null) {
      localView = mView;
    } else if (mViewLayoutResId != 0) {
      localView = LayoutInflater.from(mContext).inflate(mViewLayoutResId, paramViewGroup, false);
    } else {
      localView = null;
    }
    if (localView != null) {
      i = 1;
    }
    if ((i == 0) || (!canTextInput(localView))) {
      mWindow.setFlags(131072, 131072);
    }
    if (i != 0)
    {
      FrameLayout localFrameLayout = (FrameLayout)mWindow.findViewById(R.id.custom);
      localFrameLayout.addView(localView, new ViewGroup.LayoutParams(-1, -1));
      if (mViewSpacingSpecified) {
        localFrameLayout.setPadding(mViewSpacingLeft, mViewSpacingTop, mViewSpacingRight, mViewSpacingBottom);
      }
      if (mListView != null) {
        getLayoutParamsweight = 0.0F;
      }
      return;
    }
    paramViewGroup.setVisibility(8);
  }
  
  public final void setupTitle(ViewGroup paramViewGroup)
  {
    if (mCustomTitleView != null)
    {
      ViewGroup.LayoutParams localLayoutParams = new ViewGroup.LayoutParams(-1, -2);
      paramViewGroup.addView(mCustomTitleView, 0, localLayoutParams);
      mWindow.findViewById(R.id.title_template).setVisibility(8);
      return;
    }
    mIconView = ((ImageView)mWindow.findViewById(16908294));
    if (((TextUtils.isEmpty(mTitle) ^ true)) && (mSelected))
    {
      paramViewGroup = (TextView)mWindow.findViewById(R.id.alertTitle);
      mTitleView = paramViewGroup;
      paramViewGroup.setText(mTitle);
      int i = mIconId;
      if (i != 0)
      {
        mIconView.setImageResource(i);
        return;
      }
      paramViewGroup = mIcon;
      if (paramViewGroup != null)
      {
        mIconView.setImageDrawable(paramViewGroup);
        return;
      }
      mTitleView.setPadding(mIconView.getPaddingLeft(), mIconView.getPaddingTop(), mIconView.getPaddingRight(), mIconView.getPaddingBottom());
      mIconView.setVisibility(8);
      return;
    }
    mWindow.findViewById(R.id.title_template).setVisibility(8);
    mIconView.setVisibility(8);
    paramViewGroup.setVisibility(8);
  }
  
  public final void setupView()
  {
    Object localObject4 = mWindow.findViewById(R.id.parentPanel);
    Object localObject3 = ((View)localObject4).findViewById(R.id.topPanel);
    Object localObject2 = ((View)localObject4).findViewById(R.id.contentPanel);
    Object localObject1 = ((View)localObject4).findViewById(R.id.buttonPanel);
    localObject4 = (ViewGroup)((View)localObject4).findViewById(R.id.customPanel);
    setupCustomContent((ViewGroup)localObject4);
    View localView3 = ((View)localObject4).findViewById(R.id.topPanel);
    View localView2 = ((View)localObject4).findViewById(R.id.contentPanel);
    View localView1 = ((View)localObject4).findViewById(R.id.buttonPanel);
    localObject3 = resolvePanel(localView3, (View)localObject3);
    localObject2 = resolvePanel(localView2, (View)localObject2);
    localObject1 = resolvePanel(localView1, (View)localObject1);
    setupContent((ViewGroup)localObject2);
    setupButtons((ViewGroup)localObject1);
    setupTitle((ViewGroup)localObject3);
    int i;
    if (((View)localObject4).getVisibility() != 8) {
      i = 1;
    } else {
      i = 0;
    }
    boolean bool1;
    if ((localObject3 != null) && (((View)localObject3).getVisibility() != 8)) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    boolean bool2;
    if (((View)localObject1).getVisibility() != 8) {
      bool2 = true;
    } else {
      bool2 = false;
    }
    if (!bool2)
    {
      localObject1 = ((View)localObject2).findViewById(R.id.textSpacerNoButtons);
      if (localObject1 != null) {
        ((View)localObject1).setVisibility(0);
      } else {}
    }
    if (bool1)
    {
      localObject1 = mScrollView;
      if (localObject1 != null) {
        ((ViewGroup)localObject1).setClipToPadding(true);
      }
      localObject1 = null;
      if ((mMessage != null) || (mListView != null)) {
        localObject1 = ((View)localObject3).findViewById(R.id.titleDividerNoCustom);
      }
      if (localObject1 != null) {
        ((View)localObject1).setVisibility(0);
      }
    }
    else
    {
      localObject1 = ((View)localObject2).findViewById(R.id.textSpacerNoTitle);
      if (localObject1 != null) {
        ((View)localObject1).setVisibility(0);
      }
    }
    localObject1 = mListView;
    if ((localObject1 instanceof RecycleListView)) {
      ((RecycleListView)localObject1).a(bool1, bool2);
    }
    if (i == 0)
    {
      localObject1 = mListView;
      if (localObject1 == null) {
        localObject1 = mScrollView;
      }
      if (localObject1 != null)
      {
        if (bool1) {
          i = 1;
        } else {
          i = 0;
        }
        int j;
        if (bool2) {
          j = 2;
        } else {
          j = 0;
        }
        setScrollIndicators((ViewGroup)localObject2, (View)localObject1, i | j, 3);
      }
      else {}
    }
    localObject1 = mListView;
    if (localObject1 != null)
    {
      localObject2 = mAdapter;
      if (localObject2 != null)
      {
        ((ListView)localObject1).setAdapter((ListAdapter)localObject2);
        i = mCheckedItem;
        if (i > -1)
        {
          ((AbsListView)localObject1).setItemChecked(i, true);
          ((ListView)localObject1).setSelection(i);
        }
      }
    }
  }
  
  public class RecycleListView
    extends ListView
  {
    public final int j;
    public final int k;
    
    public RecycleListView(AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      this$1 = this$1.obtainStyledAttributes(paramAttributeSet, R.styleable.RecycleListView);
      j = this$1.getDimensionPixelOffset(R.styleable.RecycleListView_paddingBottomNoButtons, -1);
      k = this$1.getDimensionPixelOffset(R.styleable.RecycleListView_paddingTopNoTitle, -1);
    }
    
    public void a(boolean paramBoolean1, boolean paramBoolean2)
    {
      if ((!paramBoolean2) || (!paramBoolean1))
      {
        int n = getPaddingLeft();
        int i;
        if (paramBoolean1) {
          i = getPaddingTop();
        } else {
          i = k;
        }
        int i1 = getPaddingRight();
        int m;
        if (paramBoolean2) {
          m = getPaddingBottom();
        } else {
          m = j;
        }
        setPadding(n, i, i1, m);
      }
    }
  }
  
  public class a
    implements View.OnClickListener
  {
    public a() {}
    
    public void onClick(View paramView)
    {
      Object localObject = AlertController.this;
      if (paramView == mButtonPositive)
      {
        localObject = mButtonNeutralMessage;
        if (localObject != null)
        {
          paramView = Message.obtain((Message)localObject);
          break label92;
        }
      }
      localObject = AlertController.this;
      if (paramView == mButtonNegative)
      {
        localObject = mButtonNegativeMessage;
        if (localObject != null)
        {
          paramView = Message.obtain((Message)localObject);
          break label92;
        }
      }
      localObject = AlertController.this;
      if (paramView == mButtonNeutral)
      {
        paramView = mButtonPositiveMessage;
        if (paramView != null)
        {
          paramView = Message.obtain(paramView);
          break label92;
        }
      }
      paramView = null;
      label92:
      if (paramView != null) {
        paramView.sendToTarget();
      }
      paramView = AlertController.this;
      mHandler.obtainMessage(1, mDialog).sendToTarget();
    }
  }
  
  public class f
  {
    public ListAdapter mAdapter;
    public boolean mCancelable = true;
    public int mCheckedItem = -1;
    public View mCustomTitleView;
    public Drawable mIcon;
    public int mIconAttrId = 0;
    public int mIconId = 0;
    public final LayoutInflater mInflater = (LayoutInflater)getSystemService("layout_inflater");
    public boolean mIsSingleChoice;
    public DialogInterface.OnClickListener mNeutralButtonListener;
    public CharSequence mNeutralButtonText;
    public DialogInterface.OnCancelListener mOnCancelListener;
    public DialogInterface.OnClickListener mOnClickListener;
    public DialogInterface.OnDismissListener mOnDismissListener;
    public DialogInterface.OnKeyListener mOnKeyListener;
    public DialogInterface.OnClickListener mPositiveButtonListener;
    public CharSequence mPositiveButtonText;
    public CharSequence mTitle;
    public View mView;
    public int mViewLayoutResId;
    public boolean mViewSpacingSpecified = false;
    
    public f() {}
    
    public void apply(AlertController paramAlertController)
    {
      Object localObject = mCustomTitleView;
      if (localObject != null)
      {
        paramAlertController.setCustomTitle((View)localObject);
      }
      else
      {
        localObject = mTitle;
        if (localObject != null) {
          paramAlertController.setTitle((CharSequence)localObject);
        }
        localObject = mIcon;
        if (localObject != null) {
          paramAlertController.setIcon((Drawable)localObject);
        }
        i = mIconId;
        if (i != 0) {
          paramAlertController.setIcon(i);
        }
        i = mIconAttrId;
        if (i != 0) {
          paramAlertController.setIcon(paramAlertController.getIconAttributeResId(i));
        }
      }
      localObject = mNeutralButtonText;
      if (localObject != null) {
        paramAlertController.setButton(-1, (CharSequence)localObject, mNeutralButtonListener, null, null);
      }
      localObject = mPositiveButtonText;
      if (localObject != null) {
        paramAlertController.setButton(-2, (CharSequence)localObject, mPositiveButtonListener, null, null);
      }
      if (mAdapter != null) {
        createListView(paramAlertController);
      }
      localObject = mView;
      if (localObject != null)
      {
        if (mViewSpacingSpecified)
        {
          paramAlertController.setView((View)localObject, 0, 0, 0, 0);
          return;
        }
        paramAlertController.setView((View)localObject);
        return;
      }
      int i = mViewLayoutResId;
      if (i != 0) {
        paramAlertController.setView(i);
      }
    }
    
    public final void createListView(AlertController paramAlertController)
    {
      AlertController.RecycleListView localRecycleListView = (AlertController.RecycleListView)mInflater.inflate(mListLayout, null);
      int i;
      if (mIsSingleChoice) {
        i = mSingleChoiceItemLayout;
      } else {
        i = mListItemLayout;
      }
      Object localObject;
      if (mAdapter != null) {
        localObject = mAdapter;
      } else {
        localObject = new AlertController.h(AlertController.this, i, 16908308, null);
      }
      mAdapter = ((ListAdapter)localObject);
      mCheckedItem = mCheckedItem;
      if (mOnClickListener != null) {
        localRecycleListView.setOnItemClickListener(new AlertController.f.a(this, paramAlertController));
      }
      if (mIsSingleChoice) {
        localRecycleListView.setChoiceMode(1);
      }
      mListView = localRecycleListView;
    }
  }
  
  public final class g
    extends Handler
  {
    public WeakReference<DialogInterface> mDialog;
    
    public g()
    {
      mDialog = new WeakReference(this$1);
    }
    
    public void handleMessage(Message paramMessage)
    {
      int i = what;
      if ((i != -3) && (i != -2) && (i != -1))
      {
        if (i != 1) {
          return;
        }
        ((DialogInterface)obj).dismiss();
        return;
      }
      ((DialogInterface.OnClickListener)obj).onClick((DialogInterface)mDialog.get(), what);
    }
  }
  
  public class h
    extends ArrayAdapter<CharSequence>
  {
    public h(int paramInt1, int paramInt2, CharSequence[] paramArrayOfCharSequence)
    {
      super(paramInt1, paramInt2, paramArrayOfCharSequence);
    }
    
    public long getItemId(int paramInt)
    {
      return paramInt;
    }
    
    public boolean hasStableIds()
    {
      return true;
    }
  }
}
