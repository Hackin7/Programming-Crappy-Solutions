package androidx.recyclerview.widget;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import java.util.List;
import org.objectweb.asm.AnnotationWriter;
import org.objectweb.asm.OrientationHelper;
import org.objectweb.asm.ScrollbarHelper;
import org.objectweb.asm.i;

public class LinearLayoutManager
  extends RecyclerView.o
{
  public final b T = new b();
  public final a mAnchorInfo = new a();
  public boolean mLastStackFromEnd;
  public c mLayoutState;
  public int mOrientation = 1;
  public OrientationHelper mOrientationHelper;
  public d mPendingSavedState = null;
  public int mPendingScrollPosition = -1;
  public int mPendingScrollPositionOffset = Integer.MIN_VALUE;
  public boolean mReverseLayout = false;
  public boolean mShouldReverseLayout = false;
  public boolean mSmoothScrollbarEnabled = true;
  public boolean mStackFromEnd = false;
  public int t = 2;
  
  public LinearLayoutManager(int paramInt, boolean paramBoolean)
  {
    setOrientation(paramInt);
    setReverseLayout(paramBoolean);
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    paramContext = RecyclerView.o.getProperties(paramContext, paramAttributeSet, paramInt1, paramInt2);
    setOrientation(orientation);
    setReverseLayout(reverseLayout);
    setStackFromEnd(stackFromEnd);
  }
  
  public void a(int paramInt1, int paramInt2, RecyclerView.y paramY, RecyclerView.o.c paramC)
  {
    if (mOrientation != 0) {
      paramInt1 = paramInt2;
    }
    if (getChildCount() != 0)
    {
      if (paramInt1 == 0) {
        return;
      }
      ensureLayoutState();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      }
      updateLayoutState(paramInt2, Math.abs(paramInt1), true, paramY);
      fill(paramY, mLayoutState, paramC);
    }
  }
  
  public void a(int paramInt, RecyclerView.o.c paramC)
  {
    d localD = mPendingSavedState;
    int j = -1;
    boolean bool;
    int i;
    if ((localD != null) && (localD.hasValidAnchor()))
    {
      localD = mPendingSavedState;
      bool = b;
      i = c;
    }
    else
    {
      resolveShouldLayoutReverse();
      bool = mShouldReverseLayout;
      if (mPendingScrollPosition == -1)
      {
        if (bool) {
          i = paramInt - 1;
        } else {
          i = 0;
        }
      }
      else {
        i = mPendingScrollPosition;
      }
    }
    if (!bool) {
      j = 1;
    }
    int k = 0;
    while ((k < t) && (i >= 0) && (i < paramInt))
    {
      ((i)paramC).add(i, 0);
      i += j;
      k += 1;
    }
  }
  
  public void a(RecyclerView paramRecyclerView, RecyclerView.u paramU)
  {
    super.a(paramRecyclerView, paramU);
  }
  
  public void assertNotInLayoutOrScroll(String paramString)
  {
    if (mPendingSavedState == null) {
      super.assertNotInLayoutOrScroll(paramString);
    }
  }
  
  public boolean canScrollHorizontally()
  {
    return mOrientation == 0;
  }
  
  public boolean canScrollVertically()
  {
    return mOrientation == 1;
  }
  
  public int computeHorizontalScrollExtent(RecyclerView.y paramY)
  {
    return computeScrollExtent(paramY);
  }
  
  public int computeHorizontalScrollOffset(RecyclerView.y paramY)
  {
    return computeScrollOffset(paramY);
  }
  
  public int computeHorizontalScrollRange(RecyclerView.y paramY)
  {
    return computeScrollRange(paramY);
  }
  
  public final int computeScrollExtent(RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return 0;
    }
    ensureLayoutState();
    return ScrollbarHelper.computeScrollExtent(paramY, mOrientationHelper, findFirstVisibleChildClosestToEnd(mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToStart(mSmoothScrollbarEnabled ^ true, true), this, mSmoothScrollbarEnabled);
  }
  
  public final int computeScrollOffset(RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return 0;
    }
    ensureLayoutState();
    return ScrollbarHelper.computeScrollOffset(paramY, mOrientationHelper, findFirstVisibleChildClosestToEnd(mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToStart(mSmoothScrollbarEnabled ^ true, true), this, mSmoothScrollbarEnabled, mShouldReverseLayout);
  }
  
  public final int computeScrollRange(RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return 0;
    }
    ensureLayoutState();
    return ScrollbarHelper.computeScrollRange(paramY, mOrientationHelper, findFirstVisibleChildClosestToEnd(mSmoothScrollbarEnabled ^ true, true), findFirstVisibleChildClosestToStart(mSmoothScrollbarEnabled ^ true, true), this, mSmoothScrollbarEnabled);
  }
  
  public int computeVerticalScrollExtent(RecyclerView.y paramY)
  {
    return computeScrollExtent(paramY);
  }
  
  public int computeVerticalScrollOffset(RecyclerView.y paramY)
  {
    return computeScrollOffset(paramY);
  }
  
  public int computeVerticalScrollRange(RecyclerView.y paramY)
  {
    return computeScrollRange(paramY);
  }
  
  public c createLayoutState()
  {
    return new c();
  }
  
  public Parcelable d()
  {
    if (mPendingSavedState != null) {
      return new d(mPendingSavedState);
    }
    d localD = new d();
    if (getChildCount() > 0)
    {
      ensureLayoutState();
      boolean bool = mLastStackFromEnd ^ mShouldReverseLayout;
      b = bool;
      if (bool)
      {
        localView = getChildClosestToEnd();
        a = (mOrientationHelper.a() - mOrientationHelper.getDecoratedEnd(localView));
        c = getPosition(localView);
        return localD;
      }
      View localView = getChildClosestToStart();
      c = getPosition(localView);
      a = (mOrientationHelper.getDecoratedStart(localView) - mOrientationHelper.get());
      return localD;
    }
    localD.b();
    return localD;
  }
  
  public void ensureLayoutState()
  {
    if (mLayoutState == null) {
      mLayoutState = createLayoutState();
    }
  }
  
  public int fill(int paramInt)
  {
    if (paramInt != 1)
    {
      if (paramInt != 2)
      {
        if (paramInt != 17)
        {
          if (paramInt != 33)
          {
            if (paramInt != 66)
            {
              if (paramInt != 130) {
                return Integer.MIN_VALUE;
              }
              if (mOrientation == 1) {
                return 1;
              }
              return Integer.MIN_VALUE;
            }
            if (mOrientation == 0) {
              return 1;
            }
            return Integer.MIN_VALUE;
          }
          if (mOrientation == 1) {
            return -1;
          }
          return Integer.MIN_VALUE;
        }
        if (mOrientation == 0) {
          return -1;
        }
        return Integer.MIN_VALUE;
      }
      if (mOrientation == 1) {
        return 1;
      }
      if (isLayoutRTL()) {
        return -1;
      }
      return 1;
    }
    if (mOrientation == 1) {
      return -1;
    }
    if (isLayoutRTL()) {
      return 1;
    }
    return -1;
  }
  
  public int fill(RecyclerView.u paramU, c paramC, RecyclerView.y paramY, boolean paramBoolean)
  {
    int k = mAvailable;
    int i = mScrollingOffset;
    if (i != Integer.MIN_VALUE)
    {
      j = mAvailable;
      if (j < 0) {
        mScrollingOffset = (i + j);
      }
      recycleByLayoutState(paramU, paramC);
    }
    int j = mAvailable + mExtra;
    b localB = T;
    do
    {
      do
      {
        if (((!mInfinite) && (j <= 0)) || (!paramC.hasMore(paramY))) {
          break;
        }
        localB.resetInternal();
        layoutChunk(paramU, paramY, paramC, localB);
        if (mFinished) {
          break;
        }
        mOffset += mConsumed * mLayoutDirection;
        int m;
        if ((mIgnoreConsumed) && (mLayoutState.mScrapList == null))
        {
          i = j;
          if (paramY.isPreLayout()) {}
        }
        else
        {
          i = mAvailable;
          m = mConsumed;
          mAvailable = (i - m);
          i = j - m;
        }
        j = mScrollingOffset;
        if (j != Integer.MIN_VALUE)
        {
          j += mConsumed;
          mScrollingOffset = j;
          m = mAvailable;
          if (m < 0) {
            mScrollingOffset = (j + m);
          }
          recycleByLayoutState(paramU, paramC);
        }
        j = i;
      } while (!paramBoolean);
      j = i;
    } while (!mFocusable);
    return k - mAvailable;
  }
  
  public void fill(RecyclerView.y paramY, c paramC, RecyclerView.o.c paramC1)
  {
    int i = mCurrentPosition;
    if ((i >= 0) && (i < paramY.getItemCount()))
    {
      int j = Math.max(0, mScrollingOffset);
      ((i)paramC1).add(i, j);
    }
  }
  
  public final View findFirstReferenceChild()
  {
    return findReferenceChild(0, getChildCount());
  }
  
  public final View findFirstReferenceChild(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    return findReferenceChild(paramU, paramY, 0, getChildCount(), paramY.getItemCount());
  }
  
  public final View findFirstVisibleChildClosestToEnd(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (mShouldReverseLayout) {
      return findOneVisibleChild(getChildCount() - 1, -1, paramBoolean1, paramBoolean2);
    }
    return findOneVisibleChild(0, getChildCount(), paramBoolean1, paramBoolean2);
  }
  
  public final View findFirstVisibleChildClosestToStart(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (mShouldReverseLayout) {
      return findOneVisibleChild(0, getChildCount(), paramBoolean1, paramBoolean2);
    }
    return findOneVisibleChild(getChildCount() - 1, -1, paramBoolean1, paramBoolean2);
  }
  
  public int findFirstVisibleItemPosition()
  {
    View localView = findOneVisibleChild(0, getChildCount(), false, true);
    if (localView == null) {
      return -1;
    }
    return getPosition(localView);
  }
  
  public final View findLastReferenceChild()
  {
    return findReferenceChild(getChildCount() - 1, -1);
  }
  
  public final View findLastReferenceChild(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    return findReferenceChild(paramU, paramY, getChildCount() - 1, -1, paramY.getItemCount());
  }
  
  public int findLastVisibleItemPosition()
  {
    View localView = findOneVisibleChild(getChildCount() - 1, -1, false, true);
    if (localView == null) {
      return -1;
    }
    return getPosition(localView);
  }
  
  public View findOneVisibleChild(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    ensureLayoutState();
    int j = 0;
    int i;
    if (paramBoolean1) {
      i = 24579;
    } else {
      i = 320;
    }
    if (paramBoolean2) {
      j = 320;
    }
    if (mOrientation == 0) {
      return g.a(paramInt1, paramInt2, i, j);
    }
    return u.a(paramInt1, paramInt2, i, j);
  }
  
  public View findReferenceChild(int paramInt1, int paramInt2)
  {
    ensureLayoutState();
    int i;
    if (paramInt2 > paramInt1) {
      i = 1;
    } else if (paramInt2 < paramInt1) {
      i = -1;
    } else {
      i = 0;
    }
    if (i == 0) {
      return getChildAt(paramInt1);
    }
    int j;
    if (mOrientationHelper.getDecoratedStart(getChildAt(paramInt1)) < mOrientationHelper.get())
    {
      i = 16644;
      j = 16388;
    }
    else
    {
      i = 4161;
      j = 4097;
    }
    if (mOrientation == 0) {
      return g.a(paramInt1, paramInt2, i, j);
    }
    return u.a(paramInt1, paramInt2, i, j);
  }
  
  public View findReferenceChild(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt1, int paramInt2, int paramInt3)
  {
    ensureLayoutState();
    paramU = null;
    paramY = null;
    int j = mOrientationHelper.get();
    int k = mOrientationHelper.a();
    int i;
    if (paramInt2 > paramInt1) {
      i = 1;
    } else {
      i = -1;
    }
    while (paramInt1 != paramInt2)
    {
      View localView = getChildAt(paramInt1);
      int m = getPosition(localView);
      Object localObject1 = paramU;
      Object localObject2 = paramY;
      if (m >= 0)
      {
        localObject1 = paramU;
        localObject2 = paramY;
        if (m < paramInt3) {
          if (((RecyclerView.p)localView.getLayoutParams()).isItemRemoved())
          {
            localObject1 = paramU;
            localObject2 = paramY;
            if (paramU == null)
            {
              localObject1 = localView;
              localObject2 = paramY;
            }
          }
          else
          {
            if ((mOrientationHelper.getDecoratedStart(localView) < k) && (mOrientationHelper.getDecoratedEnd(localView) >= j)) {
              return localView;
            }
            localObject1 = paramU;
            localObject2 = paramY;
            if (paramY == null)
            {
              localObject2 = localView;
              localObject1 = paramU;
            }
          }
        }
      }
      paramInt1 += i;
      paramU = (RecyclerView.u)localObject1;
      paramY = (RecyclerView.y)localObject2;
    }
    if (paramY != null) {
      return paramY;
    }
    return paramU;
  }
  
  public final View findReferenceChildClosestToEnd(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mShouldReverseLayout) {
      return findFirstReferenceChild();
    }
    return findLastReferenceChild();
  }
  
  public final View findReferenceChildClosestToStart(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mShouldReverseLayout) {
      return findLastReferenceChild();
    }
    return findFirstReferenceChild();
  }
  
  public View findViewByPosition(int paramInt)
  {
    int i = getChildCount();
    if (i == 0) {
      return null;
    }
    int j = paramInt - getPosition(getChildAt(0));
    if ((j >= 0) && (j < i))
    {
      View localView = getChildAt(j);
      if (getPosition(localView) == paramInt) {
        return localView;
      }
    }
    return super.findViewByPosition(paramInt);
  }
  
  public final int fixLayoutEndGap(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY, boolean paramBoolean)
  {
    int i = mOrientationHelper.a() - paramInt;
    if (i > 0)
    {
      i = -scrollBy(-i, paramU, paramY);
      if (paramBoolean)
      {
        paramInt = mOrientationHelper.a() - (paramInt + i);
        if (paramInt > 0)
        {
          mOrientationHelper.offsetChildren(paramInt);
          return paramInt + i;
        }
      }
      else
      {
        return i;
      }
    }
    else
    {
      return 0;
    }
    return i;
  }
  
  public final int fixLayoutStartGap(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY, boolean paramBoolean)
  {
    int i = paramInt - mOrientationHelper.get();
    if (i > 0)
    {
      i = -scrollBy(i, paramU, paramY);
      if (paramBoolean)
      {
        paramInt = paramInt + i - mOrientationHelper.get();
        if (paramInt > 0)
        {
          mOrientationHelper.offsetChildren(-paramInt);
          return i - paramInt;
        }
      }
      else
      {
        return i;
      }
    }
    else
    {
      return 0;
    }
    return i;
  }
  
  public RecyclerView.p generateDefaultLayoutParams()
  {
    return new RecyclerView.p(-2, -2);
  }
  
  public final View getChildAt(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mShouldReverseLayout) {
      return findLastReferenceChild(paramU, paramY);
    }
    return findFirstReferenceChild(paramU, paramY);
  }
  
  public final View getChildClosestToEnd()
  {
    int i;
    if (mShouldReverseLayout) {
      i = 0;
    } else {
      i = getChildCount() - 1;
    }
    return getChildAt(i);
  }
  
  public final View getChildClosestToStart()
  {
    int i;
    if (mShouldReverseLayout) {
      i = getChildCount() - 1;
    } else {
      i = 0;
    }
    return getChildAt(i);
  }
  
  public int getExtraLayoutSpace(RecyclerView.y paramY)
  {
    if (paramY.b()) {
      return mOrientationHelper.getTotalSpace();
    }
    return 0;
  }
  
  public int getOrientation()
  {
    return mOrientation;
  }
  
  public boolean isLayoutRTL()
  {
    return getLayoutDirection() == 1;
  }
  
  public void layoutChunk(RecyclerView.u paramU, RecyclerView.y paramY, c paramC, b paramB)
  {
    paramU = paramC.next(paramU);
    if (paramU == null)
    {
      mFinished = true;
      return;
    }
    paramY = (RecyclerView.p)paramU.getLayoutParams();
    boolean bool2;
    boolean bool1;
    if (mScrapList == null)
    {
      bool2 = mShouldReverseLayout;
      if (mLayoutDirection == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      if (bool2 == bool1) {
        addView(paramU);
      } else {
        addView(paramU, 0);
      }
    }
    else
    {
      bool2 = mShouldReverseLayout;
      if (mLayoutDirection == -1) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      if (bool2 == bool1) {
        addDisappearingView(paramU);
      } else {
        addDisappearingView(paramU, 0);
      }
    }
    measureChildWithMargins(paramU, 0, 0);
    mConsumed = mOrientationHelper.getDecoratedMeasurement(paramU);
    int j;
    int i;
    int k;
    int m;
    if (mOrientation == 1)
    {
      if (isLayoutRTL())
      {
        j = getWidth() - getPaddingRight();
        i = j - mOrientationHelper.getDecoratedMeasurementInOther(paramU);
      }
      else
      {
        j = getPaddingLeft();
        i = j;
        j = mOrientationHelper.getDecoratedMeasurementInOther(paramU) + j;
      }
      int i1;
      int n;
      if (mLayoutDirection == -1)
      {
        k = mOffset;
        m = mConsumed;
        i1 = mOffset;
        n = i;
        k -= m;
        m = j;
        i = i1;
        j = n;
      }
      else
      {
        i1 = mOffset + mConsumed;
        n = i;
        k = mOffset;
        m = j;
        i = i1;
        j = n;
      }
    }
    else
    {
      k = getPaddingTop();
      i = mOrientationHelper.getDecoratedMeasurementInOther(paramU) + k;
      if (mLayoutDirection == -1)
      {
        j = mOffset - mConsumed;
        m = mOffset;
      }
      else
      {
        j = mOffset;
        m = mConsumed;
        m = j + m;
        j = mOffset;
      }
    }
    measureChildWithDecorationsAndMargin(paramU, j, k, m, i);
    if ((paramY.isItemRemoved()) || (paramY.next())) {
      mIgnoreConsumed = true;
    }
    mFocusable = paramU.hasFocusable();
  }
  
  public final void layoutForPredictiveAnimations(RecyclerView.u paramU, RecyclerView.y paramY, int paramInt1, int paramInt2)
  {
    if ((paramY.willRunPredictiveAnimations()) && (getChildCount() != 0) && (!paramY.isPreLayout()))
    {
      if (!supportsPredictiveItemAnimations()) {
        return;
      }
      int j = 0;
      int k = 0;
      Object localObject = paramU.getScrapList();
      int n = ((List)localObject).size();
      int i1 = getPosition(getChildAt(0));
      int i = 0;
      while (i < n)
      {
        RecyclerView.b0 localB0 = (RecyclerView.b0)((List)localObject).get(i);
        if (!localB0.isRemoved())
        {
          int i2 = localB0.getLayoutPosition();
          int m = 1;
          int i3;
          if (i2 < i1) {
            i3 = 1;
          } else {
            i3 = 0;
          }
          if (i3 != mShouldReverseLayout) {
            m = -1;
          }
          if (m == -1) {
            j += mOrientationHelper.getDecoratedMeasurement(itemView);
          } else {
            k += mOrientationHelper.getDecoratedMeasurement(itemView);
          }
        }
        i += 1;
      }
      mLayoutState.mScrapList = ((List)localObject);
      if (j > 0)
      {
        updateLayoutStateToFillEnd(getPosition(getChildClosestToStart()), paramInt1);
        localObject = mLayoutState;
        mExtra = j;
        mAvailable = 0;
        ((c)localObject).assignPositionFromScrapList();
        fill(paramU, mLayoutState, paramY, false);
      }
      if (k > 0)
      {
        updateLayoutStateToFillStart(getPosition(getChildClosestToEnd()), paramInt2);
        localObject = mLayoutState;
        mExtra = k;
        mAvailable = 0;
        ((c)localObject).assignPositionFromScrapList();
        fill(paramU, mLayoutState, paramY, false);
      }
      mLayoutState.mScrapList = null;
    }
  }
  
  public void onAnchorReady(RecyclerView.u paramU, RecyclerView.y paramY, a paramA, int paramInt) {}
  
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    resolveShouldLayoutReverse();
    if (getChildCount() == 0) {
      return null;
    }
    paramInt = fill(paramInt);
    if (paramInt == Integer.MIN_VALUE) {
      return null;
    }
    ensureLayoutState();
    ensureLayoutState();
    updateLayoutState(paramInt, (int)(mOrientationHelper.getTotalSpace() * 0.33333334F), false, paramY);
    paramView = mLayoutState;
    mScrollingOffset = Integer.MIN_VALUE;
    mRecycle = false;
    fill(paramU, paramView, paramY, true);
    if (paramInt == -1) {
      paramView = findReferenceChildClosestToStart(paramU, paramY);
    } else {
      paramView = findReferenceChildClosestToEnd(paramU, paramY);
    }
    if (paramInt == -1) {
      paramU = getChildClosestToStart();
    } else {
      paramU = getChildClosestToEnd();
    }
    if (paramU.hasFocusable())
    {
      if (paramView == null) {
        return null;
      }
      return paramU;
    }
    return paramView;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    if (getChildCount() > 0)
    {
      paramAccessibilityEvent.setFromIndex(findFirstVisibleItemPosition());
      paramAccessibilityEvent.setToIndex(findLastVisibleItemPosition());
    }
  }
  
  public void onLayoutChildren(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    Object localObject = mPendingSavedState;
    int k = -1;
    if (((localObject != null) || (mPendingScrollPosition != -1)) && (paramY.getItemCount() == 0))
    {
      removeAndRecycleAllViews(paramU);
      return;
    }
    localObject = mPendingSavedState;
    if ((localObject != null) && (((d)localObject).hasValidAnchor())) {
      mPendingScrollPosition = mPendingSavedState.c;
    }
    ensureLayoutState();
    mLayoutState.mRecycle = false;
    resolveShouldLayoutReverse();
    localObject = getFocusedChild();
    if ((mAnchorInfo.mLayoutFromEnd) && (mPendingScrollPosition == -1) && (mPendingSavedState == null))
    {
      if ((localObject != null) && ((mOrientationHelper.getDecoratedStart((View)localObject) >= mOrientationHelper.a()) || (mOrientationHelper.getDecoratedEnd((View)localObject) <= mOrientationHelper.get()))) {
        mAnchorInfo.set((View)localObject, getPosition((View)localObject));
      }
    }
    else
    {
      mAnchorInfo.reset();
      localObject = mAnchorInfo;
      c = (mShouldReverseLayout ^ mStackFromEnd);
      updateAnchorInfoForLayout(paramU, paramY, (a)localObject);
      mAnchorInfo.mLayoutFromEnd = true;
    }
    int i = getExtraLayoutSpace(paramY);
    if (mLayoutState.mLastScrollDelta >= 0)
    {
      j = 0;
    }
    else
    {
      m = 0;
      j = i;
      i = m;
    }
    int m = j + mOrientationHelper.get();
    int n = i + mOrientationHelper.getEndPadding();
    i = n;
    int j = m;
    if (paramY.isPreLayout())
    {
      int i1 = mPendingScrollPosition;
      i = n;
      j = m;
      if (i1 != -1)
      {
        i = n;
        j = m;
        if (mPendingScrollPositionOffset != Integer.MIN_VALUE)
        {
          localObject = findViewByPosition(i1);
          i = n;
          j = m;
          if (localObject != null)
          {
            if (mShouldReverseLayout)
            {
              i = mOrientationHelper.a() - mOrientationHelper.getDecoratedEnd((View)localObject) - mPendingScrollPositionOffset;
            }
            else
            {
              i = mOrientationHelper.getDecoratedStart((View)localObject);
              j = mOrientationHelper.get();
              i = mPendingScrollPositionOffset - (i - j);
            }
            if (i > 0)
            {
              j = m + i;
              i = n;
            }
            else
            {
              i = n - i;
              j = m;
            }
          }
        }
      }
    }
    if (mAnchorInfo.c)
    {
      if (mShouldReverseLayout) {
        k = 1;
      }
    }
    else if (!mShouldReverseLayout) {
      k = 1;
    }
    onAnchorReady(paramU, paramY, mAnchorInfo, k);
    detachAndScrapAttachedViews(paramU);
    mLayoutState.mInfinite = resolveIsInfinite();
    mLayoutState.mIsPreLayout = paramY.isPreLayout();
    localObject = mAnchorInfo;
    if (c)
    {
      updateLayoutStateToFillEnd((a)localObject);
      localObject = mLayoutState;
      mExtra = j;
      fill(paramU, (c)localObject, paramY, false);
      localObject = mLayoutState;
      k = mOffset;
      m = mCurrentPosition;
      n = mAvailable;
      j = i;
      if (n > 0) {
        j = i + n;
      }
      updateLayoutStateToFillStart(mAnchorInfo);
      localObject = mLayoutState;
      mExtra = j;
      mCurrentPosition += mItemDirection;
      fill(paramU, (c)localObject, paramY, false);
      localObject = mLayoutState;
      i = mOffset;
      j = k;
      if (mAvailable > 0)
      {
        j = mAvailable;
        updateLayoutStateToFillEnd(m, k);
        localObject = mLayoutState;
        mExtra = j;
        fill(paramU, (c)localObject, paramY, false);
        j = mLayoutState.mOffset;
      }
    }
    else
    {
      updateLayoutStateToFillStart((a)localObject);
      localObject = mLayoutState;
      mExtra = i;
      fill(paramU, (c)localObject, paramY, false);
      localObject = mLayoutState;
      k = mOffset;
      n = mCurrentPosition;
      m = mAvailable;
      i = j;
      if (m > 0) {
        i = j + m;
      }
      updateLayoutStateToFillEnd(mAnchorInfo);
      localObject = mLayoutState;
      mExtra = i;
      mCurrentPosition += mItemDirection;
      fill(paramU, (c)localObject, paramY, false);
      localObject = mLayoutState;
      m = mOffset;
      i = k;
      j = m;
      if (mAvailable > 0)
      {
        i = mAvailable;
        updateLayoutStateToFillStart(n, k);
        localObject = mLayoutState;
        mExtra = i;
        fill(paramU, (c)localObject, paramY, false);
        i = mLayoutState.mOffset;
        j = m;
      }
    }
    k = i;
    m = j;
    if (getChildCount() > 0) {
      if ((mShouldReverseLayout ^ mStackFromEnd))
      {
        k = fixLayoutEndGap(i, paramU, paramY, true);
        m = j + k;
        j = fixLayoutStartGap(m, paramU, paramY, false);
        m += j;
        k = i + k + j;
      }
      else
      {
        k = fixLayoutStartGap(j, paramU, paramY, true);
        i += k;
        n = fixLayoutEndGap(i, paramU, paramY, false);
        m = j + k + n;
        k = i + n;
      }
    }
    layoutForPredictiveAnimations(paramU, paramY, m, k);
    if (!paramY.isPreLayout()) {
      mOrientationHelper.onLayoutComplete();
    } else {
      mAnchorInfo.reset();
    }
    mLastStackFromEnd = mStackFromEnd;
  }
  
  public void onLayoutChildren(RecyclerView.y paramY)
  {
    super.onLayoutChildren(paramY);
    mPendingSavedState = null;
    mPendingScrollPosition = -1;
    mPendingScrollPositionOffset = Integer.MIN_VALUE;
    mAnchorInfo.reset();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if ((paramParcelable instanceof d))
    {
      mPendingSavedState = ((d)paramParcelable);
      requestLayout();
    }
  }
  
  public final View onSaveInstanceState(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mShouldReverseLayout) {
      return findFirstReferenceChild(paramU, paramY);
    }
    return findLastReferenceChild(paramU, paramY);
  }
  
  public final boolean onSaveInstanceState(RecyclerView.u paramU, RecyclerView.y paramY, a paramA)
  {
    int j = getChildCount();
    int i = 0;
    if (j == 0) {
      return false;
    }
    View localView = getFocusedChild();
    if ((localView != null) && (paramA.isViewValidAsAnchor(localView, paramY)))
    {
      paramA.set(localView, getPosition(localView));
      return true;
    }
    if (mLastStackFromEnd != mStackFromEnd) {
      return false;
    }
    if (c) {
      paramU = onSaveInstanceState(paramU, paramY);
    } else {
      paramU = getChildAt(paramU, paramY);
    }
    if (paramU != null)
    {
      paramA.onSaveInstanceState(paramU, getPosition(paramU));
      if ((!paramY.isPreLayout()) && (supportsPredictiveItemAnimations()))
      {
        if ((mOrientationHelper.getDecoratedStart(paramU) >= mOrientationHelper.a()) || (mOrientationHelper.getDecoratedEnd(paramU) < mOrientationHelper.get())) {
          i = 1;
        }
        if (i != 0)
        {
          if (c) {
            i = mOrientationHelper.a();
          } else {
            i = mOrientationHelper.get();
          }
          x = i;
          return true;
        }
      }
    }
    else
    {
      return false;
    }
    return true;
  }
  
  public final void recycleByLayoutState(RecyclerView.u paramU, c paramC)
  {
    if (mRecycle)
    {
      if (mInfinite) {
        return;
      }
      if (mLayoutDirection == -1)
      {
        recycleViewsFromEnd(paramU, mScrollingOffset);
        return;
      }
      recycleViewsFromStart(paramU, mScrollingOffset);
    }
  }
  
  public final void recycleChildren(RecyclerView.u paramU, int paramInt1, int paramInt2)
  {
    if (paramInt1 == paramInt2) {
      return;
    }
    int i = paramInt1;
    if (paramInt2 > paramInt1)
    {
      paramInt2 -= 1;
      while (paramInt2 >= paramInt1)
      {
        removeAndRecycleViewAt(paramInt2, paramU);
        paramInt2 -= 1;
      }
      return;
    }
    while (i > paramInt2)
    {
      removeAndRecycleViewAt(i, paramU);
      i -= 1;
    }
  }
  
  public final void recycleViewsFromEnd(RecyclerView.u paramU, int paramInt)
  {
    int i = getChildCount();
    if (paramInt < 0) {
      return;
    }
    int j = mOrientationHelper.getEnd() - paramInt;
    View localView;
    if (mShouldReverseLayout)
    {
      paramInt = 0;
      while (paramInt < i)
      {
        localView = getChildAt(paramInt);
        if ((mOrientationHelper.getDecoratedStart(localView) >= j) && (mOrientationHelper.getEnd(localView) >= j)) {
          paramInt += 1;
        } else {
          recycleChildren(paramU, 0, paramInt);
        }
      }
      return;
    }
    paramInt = i - 1;
    while (paramInt >= 0)
    {
      localView = getChildAt(paramInt);
      if ((mOrientationHelper.getDecoratedStart(localView) >= j) && (mOrientationHelper.getEnd(localView) >= j)) {
        paramInt -= 1;
      } else {
        recycleChildren(paramU, i - 1, paramInt);
      }
    }
  }
  
  public final void recycleViewsFromStart(RecyclerView.u paramU, int paramInt)
  {
    if (paramInt < 0) {
      return;
    }
    int j = getChildCount();
    View localView;
    if (mShouldReverseLayout)
    {
      i = j - 1;
      while (i >= 0)
      {
        localView = getChildAt(i);
        if ((mOrientationHelper.getDecoratedEnd(localView) <= paramInt) && (mOrientationHelper.a(localView) <= paramInt)) {
          i -= 1;
        } else {
          recycleChildren(paramU, j - 1, i);
        }
      }
      return;
    }
    int i = 0;
    while (i < j)
    {
      localView = getChildAt(i);
      if ((mOrientationHelper.getDecoratedEnd(localView) <= paramInt) && (mOrientationHelper.a(localView) <= paramInt)) {
        i += 1;
      } else {
        recycleChildren(paramU, 0, i);
      }
    }
  }
  
  public boolean resolveIsInfinite()
  {
    return (mOrientationHelper.getMode() == 0) && (mOrientationHelper.getEnd() == 0);
  }
  
  public final void resolveShouldLayoutReverse()
  {
    if ((mOrientation != 1) && (isLayoutRTL()))
    {
      mShouldReverseLayout = (mReverseLayout ^ true);
      return;
    }
    mShouldReverseLayout = mReverseLayout;
  }
  
  public int scrollBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (getChildCount() != 0)
    {
      if (paramInt == 0) {
        return 0;
      }
      mLayoutState.mRecycle = true;
      ensureLayoutState();
      int i;
      if (paramInt > 0) {
        i = 1;
      } else {
        i = -1;
      }
      int j = Math.abs(paramInt);
      updateLayoutState(i, j, true, paramY);
      c localC = mLayoutState;
      int k = mScrollingOffset + fill(paramU, localC, paramY, false);
      if (k < 0) {
        return 0;
      }
      if (j > k) {
        paramInt = i * k;
      }
      mOrientationHelper.offsetChildren(-paramInt);
      mLayoutState.mLastScrollDelta = paramInt;
      return paramInt;
    }
    return 0;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mOrientation == 1) {
      return 0;
    }
    return scrollBy(paramInt, paramU, paramY);
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mOrientation == 0) {
      return 0;
    }
    return scrollBy(paramInt, paramU, paramY);
  }
  
  public void setOrientation(int paramInt)
  {
    Object localObject;
    if ((paramInt != 0) && (paramInt != 1))
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("invalid orientation:");
      ((StringBuilder)localObject).append(paramInt);
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    assertNotInLayoutOrScroll(null);
    if ((paramInt != mOrientation) || (mOrientationHelper == null))
    {
      localObject = OrientationHelper.toString(this, paramInt);
      mOrientationHelper = ((OrientationHelper)localObject);
      mAnchorInfo.a = ((OrientationHelper)localObject);
      mOrientation = paramInt;
      requestLayout();
    }
  }
  
  public boolean setOrientation()
  {
    return true;
  }
  
  public void setReverseLayout(boolean paramBoolean)
  {
    assertNotInLayoutOrScroll(null);
    if (paramBoolean == mReverseLayout) {
      return;
    }
    mReverseLayout = paramBoolean;
    requestLayout();
  }
  
  public void setStackFromEnd(boolean paramBoolean)
  {
    assertNotInLayoutOrScroll(null);
    if (mStackFromEnd == paramBoolean) {
      return;
    }
    mStackFromEnd = paramBoolean;
    requestLayout();
  }
  
  public boolean shouldMeasureTwice()
  {
    return (getHeightMode() != 1073741824) && (getWidthMode() != 1073741824) && (hasFlexibleChildInBothOrientations());
  }
  
  public boolean supportsPredictiveItemAnimations()
  {
    return (mPendingSavedState == null) && (mLastStackFromEnd == mStackFromEnd);
  }
  
  public final boolean updateAnchorFromPendingData(RecyclerView.y paramY, a paramA)
  {
    boolean bool1 = paramY.isPreLayout();
    boolean bool2 = false;
    if (!bool1)
    {
      int i = mPendingScrollPosition;
      if (i == -1) {
        return false;
      }
      if ((i >= 0) && (i < paramY.getItemCount()))
      {
        mPosition = mPendingScrollPosition;
        paramY = mPendingSavedState;
        if ((paramY != null) && (paramY.hasValidAnchor()))
        {
          bool1 = mPendingSavedState.b;
          c = bool1;
          if (bool1)
          {
            x = (mOrientationHelper.a() - mPendingSavedState.a);
            return true;
          }
          x = (mOrientationHelper.get() + mPendingSavedState.a);
          return true;
        }
        if (mPendingScrollPositionOffset == Integer.MIN_VALUE)
        {
          paramY = findViewByPosition(mPendingScrollPosition);
          if (paramY != null)
          {
            if (mOrientationHelper.getDecoratedMeasurement(paramY) > mOrientationHelper.getTotalSpace())
            {
              paramA.b();
              return true;
            }
            if (mOrientationHelper.getDecoratedStart(paramY) - mOrientationHelper.get() < 0)
            {
              x = mOrientationHelper.get();
              c = false;
              return true;
            }
            if (mOrientationHelper.a() - mOrientationHelper.getDecoratedEnd(paramY) < 0)
            {
              x = mOrientationHelper.a();
              c = true;
              return true;
            }
            if (c) {
              i = mOrientationHelper.getDecoratedEnd(paramY) + mOrientationHelper.getTotalSpaceChange();
            } else {
              i = mOrientationHelper.getDecoratedStart(paramY);
            }
            x = i;
            return true;
          }
          if (getChildCount() > 0)
          {
            i = getPosition(getChildAt(0));
            if (mPendingScrollPosition < i) {
              bool1 = true;
            } else {
              bool1 = false;
            }
            if (bool1 == mShouldReverseLayout) {
              bool2 = true;
            }
            c = bool2;
          }
          paramA.b();
          return true;
        }
        bool1 = mShouldReverseLayout;
        c = bool1;
        if (bool1)
        {
          x = (mOrientationHelper.a() - mPendingScrollPositionOffset);
          return true;
        }
        x = (mOrientationHelper.get() + mPendingScrollPositionOffset);
        return true;
      }
      mPendingScrollPosition = -1;
      mPendingScrollPositionOffset = Integer.MIN_VALUE;
    }
    return false;
  }
  
  public final void updateAnchorInfoForLayout(RecyclerView.u paramU, RecyclerView.y paramY, a paramA)
  {
    if (updateAnchorFromPendingData(paramY, paramA)) {
      return;
    }
    if (onSaveInstanceState(paramU, paramY, paramA)) {
      return;
    }
    paramA.b();
    int i;
    if (mStackFromEnd) {
      i = paramY.getItemCount() - 1;
    } else {
      i = 0;
    }
    mPosition = i;
  }
  
  public final void updateLayoutState(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.y paramY)
  {
    mLayoutState.mInfinite = resolveIsInfinite();
    mLayoutState.mExtra = getExtraLayoutSpace(paramY);
    paramY = mLayoutState;
    mLayoutDirection = paramInt1;
    int i = -1;
    c localC1;
    c localC2;
    if (paramInt1 == 1)
    {
      mExtra += mOrientationHelper.getEndPadding();
      paramY = getChildClosestToEnd();
      localC1 = mLayoutState;
      if (!mShouldReverseLayout) {
        i = 1;
      }
      mItemDirection = i;
      localC1 = mLayoutState;
      paramInt1 = getPosition(paramY);
      localC2 = mLayoutState;
      mCurrentPosition = (paramInt1 + mItemDirection);
      mOffset = mOrientationHelper.getDecoratedEnd(paramY);
      paramInt1 = mOrientationHelper.getDecoratedEnd(paramY) - mOrientationHelper.a();
    }
    else
    {
      paramY = getChildClosestToStart();
      localC1 = mLayoutState;
      mExtra += mOrientationHelper.get();
      localC1 = mLayoutState;
      if (mShouldReverseLayout) {
        i = 1;
      }
      mItemDirection = i;
      localC1 = mLayoutState;
      paramInt1 = getPosition(paramY);
      localC2 = mLayoutState;
      mCurrentPosition = (paramInt1 + mItemDirection);
      mOffset = mOrientationHelper.getDecoratedStart(paramY);
      paramInt1 = -mOrientationHelper.getDecoratedStart(paramY) + mOrientationHelper.get();
    }
    paramY = mLayoutState;
    mAvailable = paramInt2;
    if (paramBoolean) {
      mAvailable = (paramInt2 - paramInt1);
    }
    mLayoutState.mScrollingOffset = paramInt1;
  }
  
  public final void updateLayoutStateToFillEnd(int paramInt1, int paramInt2)
  {
    mLayoutState.mAvailable = (paramInt2 - mOrientationHelper.get());
    c localC = mLayoutState;
    mCurrentPosition = paramInt1;
    if (mShouldReverseLayout) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    }
    mItemDirection = paramInt1;
    localC = mLayoutState;
    mLayoutDirection = -1;
    mOffset = paramInt2;
    mScrollingOffset = Integer.MIN_VALUE;
  }
  
  public final void updateLayoutStateToFillEnd(a paramA)
  {
    updateLayoutStateToFillEnd(mPosition, x);
  }
  
  public final void updateLayoutStateToFillStart(int paramInt1, int paramInt2)
  {
    mLayoutState.mAvailable = (mOrientationHelper.a() - paramInt2);
    c localC = mLayoutState;
    int i;
    if (mShouldReverseLayout) {
      i = -1;
    } else {
      i = 1;
    }
    mItemDirection = i;
    localC = mLayoutState;
    mCurrentPosition = paramInt1;
    mLayoutDirection = 1;
    mOffset = paramInt2;
    mScrollingOffset = Integer.MIN_VALUE;
  }
  
  public final void updateLayoutStateToFillStart(a paramA)
  {
    updateLayoutStateToFillStart(mPosition, x);
  }
  
  public static class a
  {
    public OrientationHelper a;
    public boolean c;
    public boolean mLayoutFromEnd;
    public int mPosition;
    public int x;
    
    public a()
    {
      reset();
    }
    
    public void b()
    {
      int i;
      if (c) {
        i = a.a();
      } else {
        i = a.get();
      }
      x = i;
    }
    
    public boolean isViewValidAsAnchor(View paramView, RecyclerView.y paramY)
    {
      paramView = (RecyclerView.p)paramView.getLayoutParams();
      return (!paramView.isItemRemoved()) && (paramView.getViewLayoutPosition() >= 0) && (paramView.getViewLayoutPosition() < paramY.getItemCount());
    }
    
    public void onSaveInstanceState(View paramView, int paramInt)
    {
      if (c) {
        x = (a.getDecoratedEnd(paramView) + a.getTotalSpaceChange());
      } else {
        x = a.getDecoratedStart(paramView);
      }
      mPosition = paramInt;
    }
    
    public void reset()
    {
      mPosition = -1;
      x = Integer.MIN_VALUE;
      c = false;
      mLayoutFromEnd = false;
    }
    
    public void set(View paramView, int paramInt)
    {
      int i = a.getTotalSpaceChange();
      if (i >= 0)
      {
        onSaveInstanceState(paramView, paramInt);
        return;
      }
      mPosition = paramInt;
      int k;
      if (c)
      {
        paramInt = a.a() - i - a.getDecoratedEnd(paramView);
        x = (a.a() - paramInt);
        if (paramInt > 0)
        {
          i = a.getDecoratedMeasurement(paramView);
          j = x;
          k = a.get();
          i = j - i - (Math.min(a.getDecoratedStart(paramView) - k, 0) + k);
          if (i < 0) {
            x += Math.min(paramInt, -i);
          }
        }
        return;
      }
      int j = a.getDecoratedStart(paramView);
      paramInt = j - a.get();
      x = j;
      if (paramInt > 0)
      {
        k = a.getDecoratedMeasurement(paramView);
        int m = a.a();
        int n = a.getDecoratedEnd(paramView);
        i = a.a() - Math.min(0, m - i - n) - (k + j);
        if (i < 0) {
          x -= Math.min(paramInt, -i);
        }
      }
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("AnchorInfo{mPosition=");
      localStringBuilder.append(mPosition);
      localStringBuilder.append(", mCoordinate=");
      localStringBuilder.append(x);
      localStringBuilder.append(", mLayoutFromEnd=");
      localStringBuilder.append(c);
      localStringBuilder.append(", mValid=");
      localStringBuilder.append(mLayoutFromEnd);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }
  }
  
  public static class b
  {
    public int mConsumed;
    public boolean mFinished;
    public boolean mFocusable;
    public boolean mIgnoreConsumed;
    
    public b() {}
    
    public void resetInternal()
    {
      mConsumed = 0;
      mFinished = false;
      mIgnoreConsumed = false;
      mFocusable = false;
    }
  }
  
  public static class c
  {
    public int mAvailable;
    public int mCurrentPosition;
    public int mExtra = 0;
    public boolean mInfinite;
    public boolean mIsPreLayout;
    public int mItemDirection;
    public int mLastScrollDelta;
    public int mLayoutDirection;
    public int mOffset;
    public boolean mRecycle = true;
    public List<RecyclerView.b0> mScrapList = null;
    public int mScrollingOffset;
    
    public c() {}
    
    public void assignPositionFromScrapList()
    {
      assignPositionFromScrapList(null);
    }
    
    public void assignPositionFromScrapList(View paramView)
    {
      paramView = nextViewInLimitedList(paramView);
      if (paramView == null)
      {
        mCurrentPosition = -1;
        return;
      }
      mCurrentPosition = ((RecyclerView.p)paramView.getLayoutParams()).getViewLayoutPosition();
    }
    
    public boolean hasMore(RecyclerView.y paramY)
    {
      int i = mCurrentPosition;
      return (i >= 0) && (i < paramY.getItemCount());
    }
    
    public View next(RecyclerView.u paramU)
    {
      if (mScrapList != null) {
        return nextViewFromScrapList();
      }
      paramU = paramU.add(mCurrentPosition);
      mCurrentPosition += mItemDirection;
      return paramU;
    }
    
    public final View nextViewFromScrapList()
    {
      int j = mScrapList.size();
      int i = 0;
      while (i < j)
      {
        View localView = mScrapList.get(i)).itemView;
        RecyclerView.p localP = (RecyclerView.p)localView.getLayoutParams();
        if ((!localP.isItemRemoved()) && (mCurrentPosition == localP.getViewLayoutPosition()))
        {
          assignPositionFromScrapList(localView);
          return localView;
        }
        i += 1;
      }
      return null;
    }
    
    public View nextViewInLimitedList(View paramView)
    {
      Object localObject1 = mScrapList;
      Object localObject2 = this;
      int n = ((List)localObject1).size();
      localObject1 = null;
      int j = Integer.MAX_VALUE;
      int i = 0;
      while (i < n)
      {
        Object localObject4 = mScrapList;
        Object localObject3 = localObject2;
        localObject4 = getitemView;
        RecyclerView.p localP = (RecyclerView.p)((View)localObject4).getLayoutParams();
        localObject2 = localObject1;
        int k = j;
        if (localObject4 != paramView) {
          if (localP.isItemRemoved())
          {
            localObject2 = localObject1;
            k = j;
          }
          else
          {
            int m = (localP.getViewLayoutPosition() - mCurrentPosition) * mItemDirection;
            if (m < 0)
            {
              localObject2 = localObject1;
              k = j;
            }
            else
            {
              localObject2 = localObject1;
              k = j;
              if (m < j)
              {
                localObject2 = localObject4;
                k = m;
                if (m == 0) {
                  return localObject4;
                }
              }
            }
          }
        }
        i += 1;
        localObject1 = localObject2;
        j = k;
        localObject2 = localObject3;
      }
      return localObject1;
    }
  }
  
  public static class d
    implements Parcelable
  {
    public static final Parcelable.Creator<d> CREATOR = new a();
    public int a;
    public boolean b;
    public int c;
    
    public d() {}
    
    public d(Parcel paramParcel)
    {
      c = paramParcel.readInt();
      a = paramParcel.readInt();
      int i = paramParcel.readInt();
      boolean bool = true;
      if (i != 1) {
        bool = false;
      }
      b = bool;
    }
    
    public d(d paramD)
    {
      c = c;
      a = a;
      b = b;
    }
    
    public void b()
    {
      c = -1;
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public boolean hasValidAnchor()
    {
      return c >= 0;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
    }
    
    public static final class a
      implements Parcelable.Creator<LinearLayoutManager.d>
    {
      public a() {}
      
      public LinearLayoutManager.d[] a(int paramInt)
      {
        return new LinearLayoutManager.d[paramInt];
      }
      
      public LinearLayoutManager.d readDate(Parcel paramParcel)
      {
        return new LinearLayoutManager.d(paramParcel);
      }
    }
  }
}
