package androidx.core.opml;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import org.jdom.Attribute;

public class RemoteActionCompatParcelizer
{
  public RemoteActionCompatParcelizer() {}
  
  public static RemoteActionCompat read(Attribute paramAttribute)
  {
    RemoteActionCompat localRemoteActionCompat = new RemoteActionCompat();
    N = ((IconCompat)paramAttribute.get(N, 1));
    c = paramAttribute.add(c, 2);
    b = paramAttribute.add(b, 3);
    a = ((PendingIntent)paramAttribute.add(a, 4));
    size = paramAttribute.set(size, 5);
    down = paramAttribute.set(down, 6);
    return localRemoteActionCompat;
  }
  
  public static void write(RemoteActionCompat paramRemoteActionCompat, Attribute paramAttribute)
  {
    paramAttribute.name();
    paramAttribute.a(N, 1);
    paramAttribute.a(c, 2);
    paramAttribute.a(b, 3);
    paramAttribute.put(a, 4);
    paramAttribute.write(size, 5);
    paramAttribute.write(down, 6);
  }
}
