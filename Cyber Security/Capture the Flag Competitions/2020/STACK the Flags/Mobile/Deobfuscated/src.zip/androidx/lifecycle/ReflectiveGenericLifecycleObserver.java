package androidx.lifecycle;

import org.util.ClassWriter;
import org.util.Item;
import org.util.MenuItem;
import org.util.Scope;
import org.util.d;

public class ReflectiveGenericLifecycleObserver
  implements MenuItem
{
  public final Item j;
  public final Object o;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject)
  {
    o = paramObject;
    j = ClassWriter.b.get(paramObject.getClass());
  }
  
  public void b(d paramD, Scope paramScope)
  {
    j.a(paramD, paramScope, o);
  }
}
