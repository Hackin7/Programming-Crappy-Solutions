package androidx.coordinatorlayout.widget;

import a.g.d.a;
import a.h.l.e;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region.Op;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.AbsSavedState;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewGroup.OnHierarchyChangeListener;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.core.asm.signature.DrawableCompat;
import org.core.data.RealVector;
import org.core.data.Session;
import org.core.fonts.ContextCompat;
import org.core.view.GravityCompat;
import org.core.view.NestedScrollingParent;
import org.core.view.NestedScrollingParentHelper;
import org.core.view.OnApplyWindowInsetsListener;
import org.core.view.ViewCompat;
import org.net.IpAddress;
import org.net.SocketAddress;
import org.net.TransactionOutputChanges;
import org.net.http.ViewGroupUtilsHoneycomb;
import org.net.http.f;

public class CoordinatorLayout
  extends ViewGroup
  implements NestedScrollingParent
{
  public static final Class<?>[] CONSTRUCTOR_PARAMS;
  public static final Comparator<View> TOP_SORTED_CHILDREN_COMPARATOR;
  public static final String WIDGET_PACKAGE_NAME;
  public static final e<Rect> m = new Session(12);
  public static final ThreadLocal<Map<String, Constructor<c>>> sConstructors;
  public final List<View> a = new ArrayList();
  public final a<View> c = new f();
  public OnApplyWindowInsetsListener data;
  public final int[] h = new int[2];
  public View mBehaviorTouchView;
  public boolean mDisallowInterceptReset;
  public boolean mDrawStatusBarBackground;
  public boolean mIsAttachedToWindow;
  public int[] mKeylines;
  public org.core.view.Item mLastInsets;
  public boolean mNeedsPreDrawListener;
  public final NestedScrollingParentHelper mNestedScrollingParentHelper = new NestedScrollingParentHelper();
  public View mNestedScrollingTarget;
  public ViewGroup.OnHierarchyChangeListener mOnHierarchyChangeListener;
  public g mOnPreDrawListener;
  public Paint mScrimPaint;
  public Drawable mStatusBarBackground;
  public final List<View> mTempList1 = new ArrayList();
  public final List<View> x = new ArrayList();
  
  static
  {
    Object localObject = CoordinatorLayout.class.getPackage();
    if (localObject != null) {
      localObject = ((Package)localObject).getName();
    } else {
      localObject = null;
    }
    WIDGET_PACKAGE_NAME = (String)localObject;
    TOP_SORTED_CHILDREN_COMPARATOR = new i();
    CONSTRUCTOR_PARAMS = new Class[] { android.content.Context.class, AttributeSet.class };
    sConstructors = new ThreadLocal();
  }
  
  public CoordinatorLayout(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, SocketAddress.coordinatorLayoutStyle);
  }
  
  public CoordinatorLayout(android.content.Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    if (paramInt == 0) {
      paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.CoordinatorLayout, 0, TransactionOutputChanges.Widget_Support_CoordinatorLayout);
    } else {
      paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.CoordinatorLayout, paramInt, 0);
    }
    paramInt = paramAttributeSet.getResourceId(IpAddress.CoordinatorLayout_keylines, 0);
    if (paramInt != 0)
    {
      paramContext = paramContext.getResources();
      mKeylines = paramContext.getIntArray(paramInt);
      float f = getDisplayMetricsdensity;
      int i = mKeylines.length;
      paramInt = 0;
      while (paramInt < i)
      {
        paramContext = mKeylines;
        paramContext[paramInt] = ((int)(paramContext[paramInt] * f));
        paramInt += 1;
      }
    }
    mStatusBarBackground = paramAttributeSet.getDrawable(IpAddress.CoordinatorLayout_statusBarBackground);
    paramAttributeSet.recycle();
    getDependencies();
    super.setOnHierarchyChangeListener(new e());
  }
  
  public static int constrain(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 < paramInt2) {
      return paramInt2;
    }
    if (paramInt1 > paramInt3) {
      return paramInt3;
    }
    return paramInt1;
  }
  
  public static Rect get()
  {
    Rect localRect2 = (Rect)m.get();
    Rect localRect1 = localRect2;
    if (localRect2 == null) {
      localRect1 = new Rect();
    }
    return localRect1;
  }
  
  public static void init(Rect paramRect)
  {
    paramRect.setEmpty();
    m.get(paramRect);
  }
  
  public static c parseBehavior(android.content.Context paramContext, AttributeSet paramAttributeSet, String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return null;
    }
    Object localObject1;
    if (paramString.startsWith("."))
    {
      localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append(paramContext.getPackageName());
      ((StringBuilder)localObject1).append(paramString);
      localObject1 = ((StringBuilder)localObject1).toString();
    }
    else if (paramString.indexOf('.') >= 0)
    {
      localObject1 = paramString;
    }
    else
    {
      localObject1 = paramString;
      if (!TextUtils.isEmpty(WIDGET_PACKAGE_NAME))
      {
        localObject1 = new StringBuilder();
        ((StringBuilder)localObject1).append(WIDGET_PACKAGE_NAME);
        ((StringBuilder)localObject1).append('.');
        ((StringBuilder)localObject1).append(paramString);
        localObject1 = ((StringBuilder)localObject1).toString();
      }
    }
    paramString = sConstructors;
    try
    {
      paramString = paramString.get();
      Object localObject2 = (Map)paramString;
      paramString = (String)localObject2;
      if (localObject2 == null)
      {
        localObject2 = new HashMap();
        paramString = (String)localObject2;
        localObject3 = sConstructors;
        ((ThreadLocal)localObject3).set(localObject2);
      }
      localObject2 = (Map)paramString;
      localObject2 = ((Map)localObject2).get(localObject1);
      Object localObject3 = (Constructor)localObject2;
      localObject2 = localObject3;
      if (localObject3 == null)
      {
        localObject2 = paramContext.getClassLoader().loadClass((String)localObject1);
        localObject3 = CONSTRUCTOR_PARAMS;
        localObject3 = ((Class)localObject2).getConstructor((Class[])localObject3);
        localObject2 = localObject3;
        ((Constructor)localObject3).setAccessible(true);
        paramString = (Map)paramString;
        paramString.put(localObject1, localObject3);
      }
      paramContext = ((Constructor)localObject2).newInstance(new Object[] { paramContext, paramAttributeSet });
      return (c)paramContext;
    }
    catch (Exception paramContext)
    {
      paramAttributeSet = new StringBuilder();
      paramAttributeSet.append("Could not inflate Behavior subclass ");
      paramAttributeSet.append((String)localObject1);
      throw new RuntimeException(paramAttributeSet.toString(), paramContext);
    }
  }
  
  public static int resolveAnchoredChildGravity(int paramInt)
  {
    if (paramInt == 0) {
      return 17;
    }
    return paramInt;
  }
  
  public static int resolveGravity(int paramInt)
  {
    int i = paramInt;
    if ((paramInt & 0x7) == 0) {
      i = paramInt | 0x800003;
    }
    paramInt = i;
    if ((i & 0x70) == 0) {
      paramInt = i | 0x30;
    }
    return paramInt;
  }
  
  public static int resolveKeylineGravity(int paramInt)
  {
    if (paramInt == 0) {
      return 8388661;
    }
    return paramInt;
  }
  
  public boolean a(View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    int j = getChildCount();
    boolean bool1 = false;
    int i = 0;
    while (i < j)
    {
      View localView = getChildAt(i);
      if (localView.getVisibility() != 8)
      {
        f localF = (f)localView.getLayoutParams();
        c localC = localF.getBehavior();
        if (localC != null)
        {
          boolean bool2 = localC.onStartNestedScroll(this, localView, paramView1, paramView2, paramInt1, paramInt2);
          localF.a(paramInt2, bool2);
          bool1 |= bool2;
        }
        else
        {
          localF.a(paramInt2, false);
        }
      }
      i += 1;
    }
    return bool1;
  }
  
  public void addPreDrawListener()
  {
    if (mIsAttachedToWindow)
    {
      if (mOnPreDrawListener == null) {
        mOnPreDrawListener = new g();
      }
      getViewTreeObserver().addOnPreDrawListener(mOnPreDrawListener);
    }
    mNeedsPreDrawListener = true;
  }
  
  public f applyFont(AttributeSet paramAttributeSet)
  {
    return new f(getContext(), paramAttributeSet);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return ((paramLayoutParams instanceof f)) && (super.checkLayoutParams(paramLayoutParams));
  }
  
  public final org.core.view.Item dispatchApplyWindowInsetsToBehaviors(org.core.view.Item paramItem)
  {
    if (paramItem.isConsumed()) {
      return paramItem;
    }
    int i = 0;
    int j = getChildCount();
    for (org.core.view.Item localItem = paramItem; i < j; localItem = paramItem)
    {
      Object localObject = getChildAt(i);
      paramItem = localItem;
      if (ViewCompat.getFitsSystemWindows((View)localObject))
      {
        localObject = ((f)((View)localObject).getLayoutParams()).getBehavior();
        paramItem = localItem;
        if (localObject != null)
        {
          localItem = ((c)localObject).onApplyWindowInsets(localItem);
          paramItem = localItem;
          if (localItem.isConsumed()) {
            return localItem;
          }
        }
      }
      i += 1;
    }
    return localItem;
  }
  
  public void dispatchDependentViewsChanged(View paramView)
  {
    List localList = c.get(paramView);
    if ((localList != null) && (!localList.isEmpty()))
    {
      int i = 0;
      while (i < localList.size())
      {
        View localView = (View)localList.get(i);
        c localC = ((f)localView.getLayoutParams()).getBehavior();
        if (localC != null) {
          localC.onDependentViewChanged(this, localView, paramView);
        }
        i += 1;
      }
    }
  }
  
  public void draw(View paramView, Rect paramRect)
  {
    ((f)paramView.getLayoutParams()).setRect(paramRect);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    f localF = (f)paramView.getLayoutParams();
    c localC = mBehavior;
    if (localC != null)
    {
      float f = localC.getScrimOpacity();
      if (f > 0.0F)
      {
        if (mScrimPaint == null) {
          mScrimPaint = new Paint();
        }
        mScrimPaint.setColor(mBehavior.getScrimColor());
        mScrimPaint.setAlpha(constrain(Math.round(255.0F * f), 0, 255));
        int i = paramCanvas.save();
        if (paramView.isOpaque()) {
          paramCanvas.clipRect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom(), Region.Op.DIFFERENCE);
        }
        paramCanvas.drawRect(getPaddingLeft(), getPaddingTop(), getWidth() - getPaddingRight(), getHeight() - getPaddingBottom(), mScrimPaint);
        paramCanvas.restoreToCount(i);
      }
    }
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void drawableStateChanged()
  {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    boolean bool2 = false;
    Drawable localDrawable = mStatusBarBackground;
    boolean bool1 = bool2;
    if (localDrawable != null)
    {
      bool1 = bool2;
      if (localDrawable.isStateful()) {
        bool1 = false | localDrawable.setState(arrayOfInt);
      }
    }
    if (bool1) {
      invalidate();
    }
  }
  
  public void ensurePreDrawListener()
  {
    int n = 0;
    int j = getChildCount();
    int i = 0;
    int k;
    for (;;)
    {
      k = n;
      if (i >= j) {
        break;
      }
      if (hasDependencies(getChildAt(i)))
      {
        k = 1;
        break;
      }
      i += 1;
    }
    if (k != mNeedsPreDrawListener)
    {
      if (k != 0)
      {
        addPreDrawListener();
        return;
      }
      removePreDrawListener();
    }
  }
  
  public List get(View paramView)
  {
    paramView = c.get(paramView);
    a.clear();
    if (paramView != null) {
      a.addAll(paramView);
    }
    return a;
  }
  
  public void getChildRect(View paramView, boolean paramBoolean, Rect paramRect)
  {
    if ((!paramView.isLayoutRequested()) && (paramView.getVisibility() != 8))
    {
      if (paramBoolean)
      {
        getDescendantRect(paramView, paramRect);
        return;
      }
      paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
      return;
    }
    paramRect.setEmpty();
  }
  
  public List getDependencies(View paramView)
  {
    paramView = c.filter(paramView);
    a.clear();
    if (paramView != null) {
      a.addAll(paramView);
    }
    return a;
  }
  
  public final void getDependencies()
  {
    if (ViewCompat.getFitsSystemWindows(this))
    {
      if (data == null) {
        data = new a();
      }
      ViewCompat.setOnApplyWindowInsetsListener(this, data);
      setSystemUiVisibility(1280);
      return;
    }
    ViewCompat.setOnApplyWindowInsetsListener(this, null);
  }
  
  public final List getDependencySortedChildren()
  {
    prepareChildren();
    return Collections.unmodifiableList(x);
  }
  
  public void getDescendantRect(View paramView, Rect paramRect)
  {
    ViewGroupUtilsHoneycomb.getDescendantRect(this, paramView, paramRect);
  }
  
  public final void getDesiredAnchoredChildRect(int paramInt1, Rect paramRect1, Rect paramRect2, f paramF, int paramInt2, int paramInt3)
  {
    int i = GravityCompat.getAbsoluteGravity(resolveAnchoredChildGravity(gravity), paramInt1);
    paramInt1 = GravityCompat.getAbsoluteGravity(resolveGravity(anchorGravity), paramInt1);
    int k = i & 0x7;
    int j = i & 0x70;
    int n = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (n != 1)
    {
      if (n != 5) {
        paramInt1 = left;
      } else {
        paramInt1 = right;
      }
    }
    else {
      paramInt1 = left + paramRect1.width() / 2;
    }
    if (i != 16)
    {
      if (i != 80) {
        i = top;
      } else {
        i = bottom;
      }
    }
    else {
      i = top + paramRect1.height() / 2;
    }
    if (k != 1)
    {
      if (k != 5) {
        paramInt1 -= paramInt2;
      }
    }
    else {
      paramInt1 -= paramInt2 / 2;
    }
    if (j != 16)
    {
      if (j != 80) {
        i -= paramInt3;
      }
    }
    else {
      i -= paramInt3 / 2;
    }
    paramRect2.set(paramInt1, i, paramInt1 + paramInt2, i + paramInt3);
  }
  
  public void getDesiredAnchoredChildRect(View paramView, int paramInt, Rect paramRect1, Rect paramRect2)
  {
    f localF = (f)paramView.getLayoutParams();
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    getDesiredAnchoredChildRect(paramInt, paramRect1, paramRect2, localF, i, j);
    getDesiredAnchoredChildRect(localF, paramRect2, i, j);
  }
  
  public final void getDesiredAnchoredChildRect(f paramF, Rect paramRect, int paramInt1, int paramInt2)
  {
    int j = getWidth();
    int i = getHeight();
    j = Math.max(getPaddingLeft() + leftMargin, Math.min(left, j - getPaddingRight() - paramInt1 - rightMargin));
    i = Math.max(getPaddingTop() + topMargin, Math.min(top, i - getPaddingBottom() - paramInt2 - bottomMargin));
    paramRect.set(j, i, j + paramInt1, i + paramInt2);
  }
  
  public final int getKeyline(int paramInt)
  {
    Object localObject = mKeylines;
    if (localObject == null)
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("No keylines defined for ");
      ((StringBuilder)localObject).append(this);
      ((StringBuilder)localObject).append(" - attempted index lookup ");
      ((StringBuilder)localObject).append(paramInt);
      Log.e("CoordinatorLayout", ((StringBuilder)localObject).toString());
      return 0;
    }
    if ((paramInt >= 0) && (paramInt < localObject.length)) {
      return localObject[paramInt];
    }
    localObject = new StringBuilder();
    ((StringBuilder)localObject).append("Keyline index ");
    ((StringBuilder)localObject).append(paramInt);
    ((StringBuilder)localObject).append(" out of range for ");
    ((StringBuilder)localObject).append(this);
    Log.e("CoordinatorLayout", ((StringBuilder)localObject).toString());
    return 0;
  }
  
  public void getLastChildRect(View paramView, Rect paramRect)
  {
    paramRect.set(((f)paramView.getLayoutParams()).getRect());
  }
  
  public final org.core.view.Item getLastWindowInsets()
  {
    return mLastInsets;
  }
  
  public int getNestedScrollAxes()
  {
    return mNestedScrollingParentHelper.getNestedScrollAxes();
  }
  
  public f getResolvedLayoutParams(View paramView)
  {
    f localF = (f)paramView.getLayoutParams();
    if (!mBehaviorResolved)
    {
      if ((paramView instanceof b))
      {
        paramView = ((b)paramView).getBehavior();
        if (paramView == null) {
          Log.e("CoordinatorLayout", "Attached behavior class is null");
        }
        localF.b(paramView);
        mBehaviorResolved = true;
        return localF;
      }
      Object localObject = paramView.getClass();
      paramView = null;
      View localView;
      for (;;)
      {
        localView = paramView;
        if (localObject == null) {
          break;
        }
        d localD = (d)((Class)localObject).getAnnotation(d.class);
        paramView = localD;
        localView = paramView;
        if (localD != null) {
          break;
        }
        localObject = ((Class)localObject).getSuperclass();
      }
      if (localView != null) {
        try
        {
          paramView = localView.value();
          paramView = paramView.getDeclaredConstructor(new Class[0]);
          paramView = paramView.newInstance(new Object[0]);
          paramView = (c)paramView;
          localF.b(paramView);
        }
        catch (Exception paramView)
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("Default behavior class ");
          ((StringBuilder)localObject).append(localView.value().getName());
          ((StringBuilder)localObject).append(" could not be instantiated. Did you forget");
          ((StringBuilder)localObject).append(" a default constructor?");
          Log.e("CoordinatorLayout", ((StringBuilder)localObject).toString(), paramView);
        }
      }
      mBehaviorResolved = true;
    }
    return localF;
  }
  
  public Drawable getStatusBarBackground()
  {
    return mStatusBarBackground;
  }
  
  public int getSuggestedMinimumHeight()
  {
    return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
  }
  
  public int getSuggestedMinimumWidth()
  {
    return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
  }
  
  public final void getTopSortedChildren(List paramList)
  {
    paramList.clear();
    boolean bool = isChildrenDrawingOrderEnabled();
    int k = getChildCount();
    int i = k - 1;
    while (i >= 0)
    {
      int j;
      if (bool) {
        j = getChildDrawingOrder(k, i);
      } else {
        j = i;
      }
      paramList.add(getChildAt(j));
      i -= 1;
    }
    Comparator localComparator = TOP_SORTED_CHILDREN_COMPARATOR;
    if (localComparator != null) {
      Collections.sort(paramList, localComparator);
    }
  }
  
  public final boolean hasDependencies(View paramView)
  {
    return c.a(paramView);
  }
  
  public boolean isPointInChildBounds(View paramView, int paramInt1, int paramInt2)
  {
    Rect localRect = get();
    getDescendantRect(paramView, localRect);
    try
    {
      boolean bool = localRect.contains(paramInt1, paramInt2);
      init(localRect);
      return bool;
    }
    catch (Throwable paramView)
    {
      init(localRect);
      throw paramView;
    }
  }
  
  public final void layoutChild(View paramView, int paramInt)
  {
    f localF = (f)paramView.getLayoutParams();
    Rect localRect1 = get();
    localRect1.set(getPaddingLeft() + leftMargin, getPaddingTop() + topMargin, getWidth() - getPaddingRight() - rightMargin, getHeight() - getPaddingBottom() - bottomMargin);
    if ((mLastInsets != null) && (ViewCompat.getFitsSystemWindows(this)) && (!ViewCompat.getFitsSystemWindows(paramView)))
    {
      left += mLastInsets.getSystemWindowInsetLeft();
      top += mLastInsets.getSystemWindowInsetTop();
      right -= mLastInsets.getSystemWindowInsetRight();
      bottom -= mLastInsets.getSystemWindowInsetBottom();
    }
    Rect localRect2 = get();
    GravityCompat.apply(resolveGravity(gravity), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), localRect1, localRect2, paramInt);
    paramView.layout(left, top, right, bottom);
    init(localRect1);
    init(localRect2);
  }
  
  public final void layoutChildWithAnchor(View paramView1, View paramView2, int paramInt)
  {
    Rect localRect1 = get();
    Rect localRect2 = get();
    try
    {
      getDescendantRect(paramView2, localRect1);
      getDesiredAnchoredChildRect(paramView1, paramInt, localRect1, localRect2);
      paramView1.layout(left, top, right, bottom);
      init(localRect1);
      init(localRect2);
      return;
    }
    catch (Throwable paramView1)
    {
      init(localRect1);
      init(localRect2);
      throw paramView1;
    }
  }
  
  public final void layoutChildWithKeyline(View paramView, int paramInt1, int paramInt2)
  {
    f localF = (f)paramView.getLayoutParams();
    int i = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(gravity), paramInt2);
    int i3 = i & 0x7;
    int i2 = i & 0x70;
    int i1 = getWidth();
    int n = getHeight();
    int j = paramView.getMeasuredWidth();
    int k = paramView.getMeasuredHeight();
    i = paramInt1;
    if (paramInt2 == 1) {
      i = i1 - paramInt1;
    }
    paramInt1 = getKeyline(i) - j;
    paramInt2 = 0;
    if (i3 != 1)
    {
      if (i3 == 5) {
        paramInt1 += j;
      }
    }
    else {
      paramInt1 += j / 2;
    }
    if (i2 != 16)
    {
      if (i2 == 80) {
        paramInt2 = 0 + k;
      }
    }
    else {
      paramInt2 = 0 + k / 2;
    }
    paramInt1 = Math.max(getPaddingLeft() + leftMargin, Math.min(paramInt1, i1 - getPaddingRight() - j - rightMargin));
    paramInt2 = Math.max(getPaddingTop() + topMargin, Math.min(paramInt2, n - getPaddingBottom() - k - bottomMargin));
    paramView.layout(paramInt1, paramInt2, paramInt1 + j, paramInt2 + k);
  }
  
  public void offsetChildToAnchor(View paramView, int paramInt)
  {
    f localF = (f)paramView.getLayoutParams();
    if (mAnchorView != null)
    {
      Rect localRect1 = get();
      Rect localRect2 = get();
      Rect localRect3 = get();
      getDescendantRect(mAnchorView, localRect1);
      int i = 0;
      getChildRect(paramView, false, localRect2);
      int j = paramView.getMeasuredWidth();
      int k = paramView.getMeasuredHeight();
      getDesiredAnchoredChildRect(paramInt, localRect1, localRect3, localF, j, k);
      if (left == left)
      {
        paramInt = i;
        if (top == top) {}
      }
      else
      {
        paramInt = 1;
      }
      getDesiredAnchoredChildRect(localF, localRect3, j, k);
      i = left - left;
      j = top - top;
      if (i != 0) {
        ViewCompat.offsetLeftAndRight(paramView, i);
      }
      if (j != 0) {
        ViewCompat.offsetTopAndBottom(paramView, j);
      }
      if (paramInt != 0)
      {
        c localC = localF.getBehavior();
        if (localC != null) {
          localC.onDependentViewChanged(this, paramView, mAnchorView);
        }
      }
      init(localRect1);
      init(localRect2);
      init(localRect3);
    }
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    performIntercept(false);
    if (mNeedsPreDrawListener)
    {
      if (mOnPreDrawListener == null) {
        mOnPreDrawListener = new g();
      }
      getViewTreeObserver().addOnPreDrawListener(mOnPreDrawListener);
    }
    if ((mLastInsets == null) && (ViewCompat.getFitsSystemWindows(this))) {
      ViewCompat.requestApplyInsets(this);
    }
    mIsAttachedToWindow = true;
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    performIntercept(false);
    if ((mNeedsPreDrawListener) && (mOnPreDrawListener != null)) {
      getViewTreeObserver().removeOnPreDrawListener(mOnPreDrawListener);
    }
    View localView = mNestedScrollingTarget;
    if (localView != null) {
      onStopNestedScroll(localView);
    }
    mIsAttachedToWindow = false;
  }
  
  public void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if ((mDrawStatusBarBackground) && (mStatusBarBackground != null))
    {
      org.core.view.Item localItem = mLastInsets;
      int i;
      if (localItem != null) {
        i = localItem.getSystemWindowInsetTop();
      } else {
        i = 0;
      }
      if (i > 0)
      {
        mStatusBarBackground.setBounds(0, 0, getWidth(), i);
        mStatusBarBackground.draw(paramCanvas);
      }
    }
  }
  
  public void onDraw(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    int i3 = getChildCount();
    int i2 = 0;
    int j = 0;
    int n = 0;
    int k = 0;
    while (k < i3)
    {
      Object localObject1 = getChildAt(k);
      int i;
      int i1;
      if (((View)localObject1).getVisibility() == 8)
      {
        i = i2;
        i1 = j;
      }
      else
      {
        Object localObject2 = (f)((View)localObject1).getLayoutParams();
        if (!((f)localObject2).get(paramInt3))
        {
          i = i2;
          i1 = j;
        }
        else
        {
          localObject2 = ((f)localObject2).getBehavior();
          i = i2;
          i1 = j;
          if (localObject2 != null)
          {
            int[] arrayOfInt = h;
            arrayOfInt[1] = 0;
            arrayOfInt[0] = 0;
            ((c)localObject2).onNestedPreScroll(this, (View)localObject1, paramView, paramInt1, paramInt2, arrayOfInt, paramInt3);
            localObject1 = h;
            if (paramInt1 > 0) {
              i = Math.max(i2, localObject1[0]);
            } else {
              i = Math.min(i2, localObject1[0]);
            }
            localObject1 = h;
            if (paramInt2 > 0) {
              j = Math.max(j, localObject1[1]);
            } else {
              j = Math.min(j, localObject1[1]);
            }
            n = 1;
            i1 = j;
          }
        }
      }
      k += 1;
      i2 = i;
      j = i1;
    }
    paramArrayOfInt[0] = i2;
    paramArrayOfInt[1] = j;
    if (n != 0) {
      render(1);
    }
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0) {
      performIntercept(true);
    }
    boolean bool = performIntercept(paramMotionEvent, 0);
    if ((i == 1) || (i == 3)) {
      performIntercept(true);
    }
    return bool;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt2 = ViewCompat.getLayoutDirection(this);
    paramInt3 = x.size();
    paramInt1 = 0;
    while (paramInt1 < paramInt3)
    {
      View localView = (View)x.get(paramInt1);
      if (localView.getVisibility() != 8)
      {
        c localC = ((f)localView.getLayoutParams()).getBehavior();
        if ((localC == null) || (!localC.onLayoutChild(this, localView, paramInt2))) {
          onLayoutChild(localView, paramInt2);
        }
      }
      paramInt1 += 1;
    }
  }
  
  public void onLayoutChild(View paramView, int paramInt)
  {
    f localF = (f)paramView.getLayoutParams();
    if (!localF.checkAnchorChanged())
    {
      View localView = mAnchorView;
      if (localView != null)
      {
        layoutChildWithAnchor(paramView, localView, paramInt);
        return;
      }
      int i = keyline;
      if (i >= 0)
      {
        layoutChildWithKeyline(paramView, i, paramInt);
        return;
      }
      layoutChild(paramView, paramInt);
      return;
    }
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    prepareChildren();
    ensurePreDrawListener();
    int i6 = getPaddingLeft();
    int i7 = getPaddingTop();
    int i8 = getPaddingRight();
    int i9 = getPaddingBottom();
    int i10 = ViewCompat.getLayoutDirection(this);
    int k = 1;
    int j;
    if (i10 == 1) {
      j = 1;
    } else {
      j = 0;
    }
    int i11 = View.MeasureSpec.getMode(paramInt1);
    int i12 = View.MeasureSpec.getSize(paramInt1);
    int i13 = View.MeasureSpec.getMode(paramInt2);
    int i14 = View.MeasureSpec.getSize(paramInt2);
    int i3 = getSuggestedMinimumWidth();
    int i2 = getSuggestedMinimumHeight();
    if ((mLastInsets == null) || (!ViewCompat.getFitsSystemWindows(this))) {
      k = 0;
    }
    int i15 = x.size();
    int n = 0;
    int i1 = 0;
    while (n < i15)
    {
      View localView = (View)x.get(n);
      if (localView.getVisibility() != 8)
      {
        f localF = (f)localView.getLayoutParams();
        int i4 = 0;
        int i5 = keyline;
        int i = i4;
        if (i5 >= 0)
        {
          i = i4;
          if (i11 != 0)
          {
            i = getKeyline(i5);
            i5 = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(gravity), i10) & 0x7;
            if (((i5 == 3) && (j == 0)) || ((i5 == 5) && (j != 0))) {
              i = Math.max(0, i12 - i8 - i);
            } else if (((i5 == 5) && (j == 0)) || ((i5 == 3) && (j != 0))) {
              i = Math.max(0, i - i6);
            } else {
              i = i4;
            }
          }
        }
        if ((k != 0) && (!ViewCompat.getFitsSystemWindows(localView)))
        {
          i4 = mLastInsets.getSystemWindowInsetLeft();
          int i17 = mLastInsets.getSystemWindowInsetRight();
          i5 = mLastInsets.getSystemWindowInsetTop();
          int i16 = mLastInsets.getSystemWindowInsetBottom();
          i4 = View.MeasureSpec.makeMeasureSpec(i12 - (i4 + i17), i11);
          i5 = View.MeasureSpec.makeMeasureSpec(i14 - (i5 + i16), i13);
        }
        else
        {
          i4 = paramInt1;
          i5 = paramInt2;
        }
        c localC = localF.getBehavior();
        if (localC != null) {
          if (localC.onMeasureChild(this, localView, i4, i, i5, 0)) {
            break label435;
          }
        }
        onMeasureChild(localView, i4, i, i5, 0);
        label435:
        i3 = Math.max(i3, i6 + i8 + localView.getMeasuredWidth() + leftMargin + rightMargin);
        i2 = Math.max(i2, i7 + i9 + localView.getMeasuredHeight() + topMargin + bottomMargin);
        i1 = View.combineMeasuredStates(i1, localView.getMeasuredState());
      }
      n += 1;
    }
    setMeasuredDimension(View.resolveSizeAndState(i3, paramInt1, 0xFF000000 & i1), View.resolveSizeAndState(i2, paramInt2, i1 << 16));
  }
  
  public final void onMeasureChild(View paramView, int paramInt)
  {
    f localF = (f)paramView.getLayoutParams();
    int i = height;
    if (i != paramInt)
    {
      ViewCompat.offsetTopAndBottom(paramView, paramInt - i);
      height = paramInt;
    }
  }
  
  public void onMeasureChild(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    paramBoolean = false;
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      paramView = getChildAt(i);
      boolean bool;
      if (paramView.getVisibility() == 8)
      {
        bool = paramBoolean;
      }
      else
      {
        paramView = (f)paramView.getLayoutParams();
        if (!paramView.get(0))
        {
          bool = paramBoolean;
        }
        else
        {
          paramView = paramView.getBehavior();
          bool = paramBoolean;
          if (paramView != null) {
            bool = paramBoolean | paramView.onNestedFling();
          }
        }
      }
      i += 1;
      paramBoolean = bool;
    }
    if (paramBoolean) {
      render(1);
    }
    return paramBoolean;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2)
  {
    boolean bool1 = false;
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      View localView = getChildAt(i);
      boolean bool2;
      if (localView.getVisibility() == 8)
      {
        bool2 = bool1;
      }
      else
      {
        Object localObject = (f)localView.getLayoutParams();
        if (!((f)localObject).get(0))
        {
          bool2 = bool1;
        }
        else
        {
          localObject = ((f)localObject).getBehavior();
          bool2 = bool1;
          if (localObject != null) {
            bool2 = bool1 | ((c)localObject).onNestedPreFling(this, localView, paramView, paramFloat1, paramFloat2);
          }
        }
      }
      i += 1;
      bool1 = bool2;
    }
    return bool1;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    onDraw(paramView, paramInt1, paramInt2, paramArrayOfInt, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    performIntercept(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt)
  {
    performIntercept(paramView1, paramView2, paramInt, 0);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof h))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (h)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.next());
    paramParcelable = behaviorStates;
    int i = 0;
    int j = getChildCount();
    while (i < j)
    {
      View localView = getChildAt(i);
      int k = localView.getId();
      c localC = getResolvedLayoutParams(localView).getBehavior();
      if ((k != -1) && (localC != null))
      {
        Parcelable localParcelable = (Parcelable)paramParcelable.get(k);
        if (localParcelable != null) {
          localC.onRestoreInstanceState(this, localView, localParcelable);
        }
      }
      i += 1;
    }
  }
  
  public Parcelable onSaveInstanceState()
  {
    h localH = new h(super.onSaveInstanceState());
    SparseArray localSparseArray = new SparseArray();
    int i = 0;
    int j = getChildCount();
    while (i < j)
    {
      Object localObject = getChildAt(i);
      int k = ((View)localObject).getId();
      c localC = ((f)((View)localObject).getLayoutParams()).getBehavior();
      if ((k != -1) && (localC != null))
      {
        localObject = localC.onSaveInstanceState(this, (View)localObject);
        if (localObject != null) {
          localSparseArray.append(k, localObject);
        }
      }
      i += 1;
    }
    behaviorStates = localSparseArray;
    return localH;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt)
  {
    return a(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView)
  {
    performIntercept(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    boolean bool4 = false;
    boolean bool2 = false;
    Object localObject = null;
    int i = paramMotionEvent.getActionMasked();
    boolean bool1;
    boolean bool3;
    if (mBehaviorTouchView == null)
    {
      boolean bool5 = performIntercept(paramMotionEvent, 1);
      bool2 = bool5;
      bool1 = bool4;
      bool3 = bool2;
      if (!bool5) {}
    }
    else
    {
      c localC = ((f)mBehaviorTouchView.getLayoutParams()).getBehavior();
      bool1 = bool4;
      bool3 = bool2;
      if (localC != null)
      {
        bool1 = localC.onTouchEvent(this, mBehaviorTouchView, paramMotionEvent);
        bool3 = bool2;
      }
    }
    if (mBehaviorTouchView == null)
    {
      bool2 = bool1 | super.onTouchEvent(paramMotionEvent);
      paramMotionEvent = localObject;
    }
    else
    {
      bool2 = bool1;
      paramMotionEvent = localObject;
      if (bool3)
      {
        long l = SystemClock.uptimeMillis();
        paramMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        super.onTouchEvent(paramMotionEvent);
        bool2 = bool1;
      }
    }
    if (paramMotionEvent != null) {
      paramMotionEvent.recycle();
    }
    if ((i == 1) || (i == 3)) {
      performIntercept(false);
    }
    return bool2;
  }
  
  public void performIntercept(View paramView, int paramInt)
  {
    mNestedScrollingParentHelper.onNestedScrollAccepted(paramInt);
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      View localView = getChildAt(i);
      f localF = (f)localView.getLayoutParams();
      if (localF.get(paramInt))
      {
        c localC = localF.getBehavior();
        if (localC != null) {
          localC.onStopNestedScroll(this, localView, paramView, paramInt);
        }
        localF.add(paramInt);
        localF.add();
      }
      i += 1;
    }
    mNestedScrollingTarget = null;
  }
  
  public void performIntercept(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int k = getChildCount();
    int j = 0;
    int i = 0;
    while (i < k)
    {
      View localView = getChildAt(i);
      if (localView.getVisibility() != 8)
      {
        Object localObject = (f)localView.getLayoutParams();
        if (((f)localObject).get(paramInt5))
        {
          localObject = ((f)localObject).getBehavior();
          if (localObject != null)
          {
            ((c)localObject).onNestedPreScroll(this, localView, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
            j = 1;
          }
        }
      }
      i += 1;
    }
    if (j != 0) {
      render(1);
    }
  }
  
  public void performIntercept(View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    mNestedScrollingParentHelper.onStopNestedScroll(paramInt1, paramInt2);
    mNestedScrollingTarget = paramView2;
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      View localView = getChildAt(i);
      Object localObject = (f)localView.getLayoutParams();
      if (((f)localObject).get(paramInt2))
      {
        localObject = ((f)localObject).getBehavior();
        if (localObject != null) {
          ((c)localObject).onNestedPreScroll(this, localView, paramView1, paramView2, paramInt1, paramInt2);
        }
      }
      i += 1;
    }
  }
  
  public final void performIntercept(boolean paramBoolean)
  {
    int j = getChildCount();
    int i = 0;
    while (i < j)
    {
      View localView = getChildAt(i);
      c localC = ((f)localView.getLayoutParams()).getBehavior();
      if (localC != null)
      {
        long l = SystemClock.uptimeMillis();
        MotionEvent localMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          localC.onInterceptTouchEvent(this, localView, localMotionEvent);
        } else {
          localC.onTouchEvent(this, localView, localMotionEvent);
        }
        localMotionEvent.recycle();
      }
      i += 1;
    }
    i = 0;
    while (i < j)
    {
      ((f)getChildAt(i).getLayoutParams()).isBlockingInteractionBelow();
      i += 1;
    }
    mBehaviorTouchView = null;
    mDisallowInterceptReset = false;
  }
  
  public final boolean performIntercept(MotionEvent paramMotionEvent, int paramInt)
  {
    boolean bool1 = false;
    int i = 0;
    Object localObject1 = null;
    int i1 = paramMotionEvent.getActionMasked();
    List localList = mTempList1;
    getTopSortedChildren(localList);
    int i2 = localList.size();
    int j = 0;
    boolean bool2;
    for (;;)
    {
      bool2 = bool1;
      if (j >= i2) {
        break;
      }
      View localView = (View)localList.get(j);
      Object localObject2 = (f)localView.getLayoutParams();
      c localC = ((f)localObject2).getBehavior();
      int k = 1;
      boolean bool3;
      if (((bool1) || (i != 0)) && (i1 != 0))
      {
        bool3 = bool1;
        k = i;
        localObject2 = localObject1;
        if (localC != null)
        {
          localObject2 = localObject1;
          if (localObject1 == null)
          {
            long l = SystemClock.uptimeMillis();
            localObject2 = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
          }
          if (paramInt != 0)
          {
            if (paramInt == 1) {
              localC.onTouchEvent(this, localView, (MotionEvent)localObject2);
            }
          }
          else {
            localC.onInterceptTouchEvent(this, localView, (MotionEvent)localObject2);
          }
          bool3 = bool1;
          k = i;
        }
      }
      else
      {
        bool2 = bool1;
        if (!bool1)
        {
          bool2 = bool1;
          if (localC != null)
          {
            if (paramInt != 0)
            {
              if (paramInt == 1) {
                bool1 = localC.onTouchEvent(this, localView, paramMotionEvent);
              }
            }
            else {
              bool1 = localC.onInterceptTouchEvent(this, localView, paramMotionEvent);
            }
            bool2 = bool1;
            if (bool1)
            {
              mBehaviorTouchView = localView;
              bool2 = bool1;
            }
          }
        }
        bool3 = ((f)localObject2).didBlockInteraction();
        bool1 = ((f)localObject2).isBlockingInteractionBelow(this, localView);
        if ((bool1) && (!bool3)) {
          i = k;
        } else {
          i = 0;
        }
        int n = i;
        bool3 = bool2;
        k = n;
        localObject2 = localObject1;
        if (bool1)
        {
          bool3 = bool2;
          k = n;
          localObject2 = localObject1;
          if (i == 0) {
            break;
          }
        }
      }
      j += 1;
      bool1 = bool3;
      i = k;
      localObject1 = localObject2;
    }
    localList.clear();
    return bool2;
  }
  
  public final void prepareChildren()
  {
    x.clear();
    c.clear();
    int i = 0;
    int k = getChildCount();
    while (i < k)
    {
      View localView1 = getChildAt(i);
      f localF = getResolvedLayoutParams(localView1);
      localF.findAnchorView(this, localView1);
      c.clear(localView1);
      int j = 0;
      while (j < k)
      {
        if (j != i)
        {
          View localView2 = getChildAt(j);
          if (localF.isDirty(this, localView1, localView2))
          {
            if (!c.add(localView2)) {
              c.clear(localView2);
            }
            c.add(localView2, localView1);
          }
        }
        j += 1;
      }
      i += 1;
    }
    x.addAll(c.a());
    Collections.reverse(x);
  }
  
  public void removePreDrawListener()
  {
    if ((mIsAttachedToWindow) && (mOnPreDrawListener != null)) {
      getViewTreeObserver().removeOnPreDrawListener(mOnPreDrawListener);
    }
    mNeedsPreDrawListener = false;
  }
  
  public final void render(int paramInt)
  {
    int k = ViewCompat.getLayoutDirection(this);
    int n = x.size();
    Rect localRect1 = get();
    Rect localRect2 = get();
    Rect localRect3 = get();
    int i = 0;
    while (i < n)
    {
      View localView = (View)x.get(i);
      Object localObject1 = (f)localView.getLayoutParams();
      if ((paramInt != 0) || (localView.getVisibility() != 8))
      {
        int j = 0;
        Object localObject2;
        while (j < i)
        {
          localObject2 = (View)x.get(j);
          if (mAnchorDirectChild == localObject2) {
            offsetChildToAnchor(localView, k);
          }
          j += 1;
        }
        getChildRect(localView, true, localRect2);
        if ((width != 0) && (!localRect2.isEmpty()))
        {
          j = GravityCompat.getAbsoluteGravity(width, k);
          int i1 = j & 0x70;
          if (i1 != 48)
          {
            if (i1 == 80) {
              bottom = Math.max(bottom, getHeight() - top);
            }
          }
          else {
            top = Math.max(top, bottom);
          }
          j &= 0x7;
          if (j != 3)
          {
            if (j == 5) {
              right = Math.max(right, getWidth() - left);
            }
          }
          else {
            left = Math.max(left, right);
          }
        }
        if ((top != 0) && (localView.getVisibility() == 0)) {
          show(localView, localRect1, k);
        }
        if (paramInt != 2)
        {
          getLastChildRect(localView, localRect3);
          if (!localRect3.equals(localRect2)) {
            draw(localView, localRect2);
          }
        }
        else
        {
          j = i + 1;
          while (j < n)
          {
            localObject1 = (View)x.get(j);
            localObject2 = (f)((View)localObject1).getLayoutParams();
            c localC = ((f)localObject2).getBehavior();
            if ((localC != null) && (localC.get(this, (View)localObject1, localView))) {
              if ((paramInt == 0) && (((f)localObject2).isReverse()))
              {
                ((f)localObject2).add();
              }
              else
              {
                boolean bool;
                if (paramInt != 2)
                {
                  bool = localC.onDependentViewChanged(this, (View)localObject1, localView);
                }
                else
                {
                  localC.renderItem();
                  bool = true;
                }
                if (paramInt == 1) {
                  ((f)localObject2).renderItem(bool);
                }
              }
            }
            j += 1;
          }
        }
      }
      i += 1;
    }
    init(localRect1);
    init(localRect2);
    init(localRect3);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean)
  {
    c localC = ((f)paramView.getLayoutParams()).getBehavior();
    if ((localC != null) && (localC.onLayoutChild(this, paramView, paramRect, paramBoolean))) {
      return true;
    }
    return super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean)
  {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if ((paramBoolean) && (!mDisallowInterceptReset))
    {
      performIntercept(false);
      mDisallowInterceptReset = true;
    }
  }
  
  public final void reset(View paramView, int paramInt)
  {
    f localF = (f)paramView.getLayoutParams();
    int i = flags;
    if (i != paramInt)
    {
      ViewCompat.offsetLeftAndRight(paramView, paramInt - i);
      flags = paramInt;
    }
  }
  
  public void setFitsSystemWindows(boolean paramBoolean)
  {
    super.setFitsSystemWindows(paramBoolean);
    getDependencies();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener)
  {
    mOnHierarchyChangeListener = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable)
  {
    Drawable localDrawable2 = mStatusBarBackground;
    if (localDrawable2 != paramDrawable)
    {
      Drawable localDrawable1 = null;
      if (localDrawable2 != null) {
        localDrawable2.setCallback(null);
      }
      if (paramDrawable != null) {
        localDrawable1 = paramDrawable.mutate();
      }
      mStatusBarBackground = localDrawable1;
      if (localDrawable1 != null)
      {
        if (localDrawable1.isStateful()) {
          mStatusBarBackground.setState(getDrawableState());
        }
        DrawableCompat.setLayoutDirection(mStatusBarBackground, ViewCompat.getLayoutDirection(this));
        paramDrawable = mStatusBarBackground;
        boolean bool;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        }
        paramDrawable.setVisible(bool, false);
        mStatusBarBackground.setCallback(this);
      }
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public void setStatusBarBackgroundColor(int paramInt)
  {
    setStatusBarBackground(new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt)
  {
    Drawable localDrawable;
    if (paramInt != 0) {
      localDrawable = ContextCompat.getDrawable(getContext(), paramInt);
    } else {
      localDrawable = null;
    }
    setStatusBarBackground(localDrawable);
  }
  
  public f setTopMargin(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof f)) {
      return new f((f)paramLayoutParams);
    }
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new f((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new f(paramLayoutParams);
  }
  
  public f setVisibility()
  {
    return new f(-2, -2);
  }
  
  public void setVisibility(int paramInt)
  {
    super.setVisibility(paramInt);
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    }
    Drawable localDrawable = mStatusBarBackground;
    if ((localDrawable != null) && (localDrawable.isVisible() != bool)) {
      mStatusBarBackground.setVisible(bool, false);
    }
  }
  
  public final org.core.view.Item setWindowInsets(org.core.view.Item paramItem)
  {
    org.core.view.Item localItem = paramItem;
    if (!RealVector.equals(mLastInsets, paramItem))
    {
      mLastInsets = paramItem;
      boolean bool2 = true;
      boolean bool1;
      if ((paramItem != null) && (paramItem.getSystemWindowInsetTop() > 0)) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      mDrawStatusBarBackground = bool1;
      if ((!bool1) && (getBackground() == null)) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }
      setWillNotDraw(bool1);
      localItem = dispatchApplyWindowInsetsToBehaviors(paramItem);
      requestLayout();
    }
    return localItem;
  }
  
  public final void show(View paramView, Rect paramRect, int paramInt)
  {
    if (!ViewCompat.get(paramView)) {
      return;
    }
    if (paramView.getWidth() > 0)
    {
      if (paramView.getHeight() <= 0) {
        return;
      }
      f localF = (f)paramView.getLayoutParams();
      c localC = localF.getBehavior();
      Rect localRect1 = get();
      Rect localRect2 = get();
      localRect2.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
      if ((localC != null) && (localC.onDependentViewChanged(this, paramView, localRect1)))
      {
        if (!localRect2.contains(localRect1))
        {
          paramView = new StringBuilder();
          paramView.append("Rect should be within the child's bounds. Rect:");
          paramView.append(localRect1.toShortString());
          paramView.append(" | Bounds:");
          paramView.append(localRect2.toShortString());
          throw new IllegalArgumentException(paramView.toString());
        }
      }
      else {
        localRect1.set(localRect2);
      }
      init(localRect2);
      if (localRect1.isEmpty())
      {
        init(localRect1);
        return;
      }
      int j = GravityCompat.getAbsoluteGravity(top, paramInt);
      int i = 0;
      paramInt = i;
      int k;
      int n;
      if ((j & 0x30) == 48)
      {
        k = top - topMargin - height;
        n = top;
        paramInt = i;
        if (k < n)
        {
          onMeasureChild(paramView, n - k);
          paramInt = 1;
        }
      }
      i = paramInt;
      if ((j & 0x50) == 80)
      {
        k = getHeight() - bottom - bottomMargin + height;
        n = bottom;
        i = paramInt;
        if (k < n)
        {
          onMeasureChild(paramView, k - n);
          i = 1;
        }
      }
      if (i == 0) {
        onMeasureChild(paramView, 0);
      }
      i = 0;
      paramInt = i;
      if ((j & 0x3) == 3)
      {
        k = left - leftMargin - flags;
        n = left;
        paramInt = i;
        if (k < n)
        {
          reset(paramView, n - k);
          paramInt = 1;
        }
      }
      i = paramInt;
      if ((j & 0x5) == 5)
      {
        j = getWidth() - right - rightMargin + flags;
        k = right;
        i = paramInt;
        if (j < k)
        {
          reset(paramView, j - k);
          i = 1;
        }
      }
      if (i == 0) {
        reset(paramView, 0);
      }
      init(localRect1);
    }
  }
  
  public boolean verifyDrawable(Drawable paramDrawable)
  {
    return (super.verifyDrawable(paramDrawable)) || (paramDrawable == mStatusBarBackground);
  }
  
  public class a
    implements OnApplyWindowInsetsListener
  {
    public a() {}
    
    public org.core.view.Item onApplyWindowInsets(View paramView, org.core.view.Item paramItem)
    {
      return setWindowInsets(paramItem);
    }
  }
  
  public static abstract interface b
  {
    public abstract CoordinatorLayout.c getBehavior();
  }
  
  public static abstract class c<V extends View>
  {
    public c() {}
    
    public c(android.content.Context paramContext, AttributeSet paramAttributeSet) {}
    
    public void b(CoordinatorLayout.f paramF) {}
    
    public boolean blocksInteractionBelow(CoordinatorLayout paramCoordinatorLayout, View paramView)
    {
      return getScrimOpacity() > 0.0F;
    }
    
    public void e() {}
    
    public boolean get(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
    {
      return false;
    }
    
    public int getScrimColor()
    {
      return -16777216;
    }
    
    public float getScrimOpacity()
    {
      return 0.0F;
    }
    
    public org.core.view.Item onApplyWindowInsets(org.core.view.Item paramItem)
    {
      return paramItem;
    }
    
    public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, View paramView, Rect paramRect)
    {
      return false;
    }
    
    public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
    {
      return false;
    }
    
    public boolean onInterceptTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
    {
      return false;
    }
    
    public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt)
    {
      return false;
    }
    
    public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, View paramView, Rect paramRect, boolean paramBoolean)
    {
      return false;
    }
    
    public boolean onMeasureChild(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      return false;
    }
    
    public boolean onNestedFling()
    {
      return false;
    }
    
    public boolean onNestedPreFling(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, float paramFloat1, float paramFloat2)
    {
      return false;
    }
    
    public void onNestedPreScroll() {}
    
    public void onNestedPreScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
    {
      if (paramInt5 == 0) {
        onNestedScroll(paramCoordinatorLayout, paramView1, paramView2, paramInt1, paramInt2, paramInt3, paramInt4);
      }
    }
    
    public void onNestedPreScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
    {
      if (paramInt3 == 0) {
        e();
      }
    }
    
    public void onNestedPreScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, View paramView3, int paramInt1, int paramInt2)
    {
      if (paramInt2 == 0) {
        onNestedPreScroll();
      }
    }
    
    public void onNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
    
    public void onRestoreInstanceState() {}
    
    public void onRestoreInstanceState(CoordinatorLayout paramCoordinatorLayout, View paramView, Parcelable paramParcelable) {}
    
    public Parcelable onSaveInstanceState(CoordinatorLayout paramCoordinatorLayout, View paramView)
    {
      return AbsSavedState.EMPTY_STATE;
    }
    
    public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, View paramView3, int paramInt)
    {
      return false;
    }
    
    public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, View paramView3, int paramInt1, int paramInt2)
    {
      if (paramInt2 == 0) {
        return onStartNestedScroll(paramCoordinatorLayout, paramView1, paramView2, paramView3, paramInt1);
      }
      return false;
    }
    
    public void onStopNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt)
    {
      if (paramInt == 0) {
        postOnAnimation();
      }
    }
    
    public boolean onTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
    {
      return false;
    }
    
    public void postOnAnimation() {}
    
    public void renderItem() {}
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface d
  {
    Class value();
  }
  
  public class e
    implements ViewGroup.OnHierarchyChangeListener
  {
    public e() {}
    
    public void onChildViewAdded(View paramView1, View paramView2)
    {
      ViewGroup.OnHierarchyChangeListener localOnHierarchyChangeListener = mOnHierarchyChangeListener;
      if (localOnHierarchyChangeListener != null) {
        localOnHierarchyChangeListener.onChildViewAdded(paramView1, paramView2);
      }
    }
    
    public void onChildViewRemoved(View paramView1, View paramView2)
    {
      render(2);
      ViewGroup.OnHierarchyChangeListener localOnHierarchyChangeListener = mOnHierarchyChangeListener;
      if (localOnHierarchyChangeListener != null) {
        localOnHierarchyChangeListener.onChildViewRemoved(paramView1, paramView2);
      }
    }
  }
  
  public static class f
    extends ViewGroup.MarginLayoutParams
  {
    public boolean a;
    public int anchorGravity = 0;
    public boolean c;
    public int flags;
    public int gravity = 0;
    public int height;
    public int keyline = -1;
    public View mAnchorDirectChild;
    public int mAnchorId = -1;
    public View mAnchorView;
    public CoordinatorLayout.c mBehavior;
    public boolean mBehaviorResolved = false;
    public boolean mDidBlockInteraction;
    public final Rect mRect = new Rect();
    public boolean mReverse;
    public int top = 0;
    public int width = 0;
    
    public f(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public f(android.content.Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.CoordinatorLayout_Layout);
      gravity = localTypedArray.getInteger(IpAddress.CoordinatorLayout_Layout_android_layout_gravity, 0);
      mAnchorId = localTypedArray.getResourceId(IpAddress.CoordinatorLayout_Layout_layout_anchor, -1);
      anchorGravity = localTypedArray.getInteger(IpAddress.CoordinatorLayout_Layout_layout_anchorGravity, 0);
      keyline = localTypedArray.getInteger(IpAddress.CoordinatorLayout_Layout_layout_keyline, -1);
      width = localTypedArray.getInt(IpAddress.CoordinatorLayout_Layout_layout_insetEdge, 0);
      top = localTypedArray.getInt(IpAddress.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
      boolean bool = localTypedArray.hasValue(IpAddress.CoordinatorLayout_Layout_layout_behavior);
      mBehaviorResolved = bool;
      if (bool) {
        mBehavior = CoordinatorLayout.parseBehavior(paramContext, paramAttributeSet, localTypedArray.getString(IpAddress.CoordinatorLayout_Layout_layout_behavior));
      }
      localTypedArray.recycle();
      paramContext = mBehavior;
      if (paramContext != null) {
        paramContext.b(this);
      }
    }
    
    public f(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public f(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
    
    public f(f paramF)
    {
      super();
    }
    
    public void a(int paramInt, boolean paramBoolean)
    {
      if (paramInt != 0)
      {
        if (paramInt != 1) {
          return;
        }
        c = paramBoolean;
        return;
      }
      a = paramBoolean;
    }
    
    public void add()
    {
      mReverse = false;
    }
    
    public void add(int paramInt)
    {
      a(paramInt, false);
    }
    
    public void b(CoordinatorLayout.c paramC)
    {
      CoordinatorLayout.c localC = mBehavior;
      if (localC != paramC)
      {
        if (localC != null) {
          localC.onRestoreInstanceState();
        }
        mBehavior = paramC;
        mBehaviorResolved = true;
        if (paramC != null) {
          paramC.b(this);
        }
      }
    }
    
    public boolean checkAnchorChanged()
    {
      return (mAnchorView == null) && (mAnchorId != -1);
    }
    
    public boolean didBlockInteraction()
    {
      if (mBehavior == null) {
        mDidBlockInteraction = false;
      }
      return mDidBlockInteraction;
    }
    
    public View findAnchorView(CoordinatorLayout paramCoordinatorLayout, View paramView)
    {
      if (mAnchorId == -1)
      {
        mAnchorDirectChild = null;
        mAnchorView = null;
        return null;
      }
      if ((mAnchorView == null) || (!verifyAnchorView(paramView, paramCoordinatorLayout))) {
        resolveAnchorView(paramView, paramCoordinatorLayout);
      }
      return mAnchorView;
    }
    
    public boolean get(int paramInt)
    {
      if (paramInt != 0)
      {
        if (paramInt != 1) {
          return false;
        }
        return c;
      }
      return a;
    }
    
    public int getAnchorId()
    {
      return mAnchorId;
    }
    
    public CoordinatorLayout.c getBehavior()
    {
      return mBehavior;
    }
    
    public Rect getRect()
    {
      return mRect;
    }
    
    public void isBlockingInteractionBelow()
    {
      mDidBlockInteraction = false;
    }
    
    public boolean isBlockingInteractionBelow(CoordinatorLayout paramCoordinatorLayout, View paramView)
    {
      boolean bool2 = mDidBlockInteraction;
      if (bool2) {
        return true;
      }
      CoordinatorLayout.c localC = mBehavior;
      if (localC != null) {
        bool1 = localC.blocksInteractionBelow(paramCoordinatorLayout, paramView);
      } else {
        bool1 = false;
      }
      boolean bool1 = bool2 | bool1;
      mDidBlockInteraction = bool1;
      return bool1;
    }
    
    public boolean isDirty(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
    {
      if ((paramView2 != mAnchorDirectChild) && (!onLayoutChild(paramView2, ViewCompat.getLayoutDirection(paramCoordinatorLayout))))
      {
        CoordinatorLayout.c localC = mBehavior;
        if ((localC == null) || (!localC.get(paramCoordinatorLayout, paramView1, paramView2))) {
          return false;
        }
      }
      return true;
    }
    
    public boolean isReverse()
    {
      return mReverse;
    }
    
    public final boolean onLayoutChild(View paramView, int paramInt)
    {
      int i = GravityCompat.getAbsoluteGravity(getLayoutParamswidth, paramInt);
      return (i != 0) && ((GravityCompat.getAbsoluteGravity(top, paramInt) & i) == i);
    }
    
    public void renderItem(boolean paramBoolean)
    {
      mReverse = paramBoolean;
    }
    
    public final void resolveAnchorView(View paramView, CoordinatorLayout paramCoordinatorLayout)
    {
      Object localObject = paramCoordinatorLayout.findViewById(mAnchorId);
      mAnchorView = ((View)localObject);
      if (localObject != null)
      {
        if (localObject == paramCoordinatorLayout)
        {
          if (paramCoordinatorLayout.isInEditMode())
          {
            mAnchorDirectChild = null;
            mAnchorView = null;
            return;
          }
          throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
        }
        View localView = mAnchorView;
        for (localObject = ((View)localObject).getParent(); (localObject != paramCoordinatorLayout) && (localObject != null); localObject = ((ViewParent)localObject).getParent())
        {
          if (localObject == paramView)
          {
            if (paramCoordinatorLayout.isInEditMode())
            {
              mAnchorDirectChild = null;
              mAnchorView = null;
              return;
            }
            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
          }
          if ((localObject instanceof View)) {
            localView = (View)localObject;
          }
        }
        mAnchorDirectChild = localView;
        return;
      }
      if (paramCoordinatorLayout.isInEditMode())
      {
        mAnchorDirectChild = null;
        mAnchorView = null;
        return;
      }
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("Could not find CoordinatorLayout descendant view with id ");
      ((StringBuilder)localObject).append(paramCoordinatorLayout.getResources().getResourceName(mAnchorId));
      ((StringBuilder)localObject).append(" to anchor view ");
      ((StringBuilder)localObject).append(paramView);
      throw new IllegalStateException(((StringBuilder)localObject).toString());
    }
    
    public void setRect(Rect paramRect)
    {
      mRect.set(paramRect);
    }
    
    public final boolean verifyAnchorView(View paramView, CoordinatorLayout paramCoordinatorLayout)
    {
      if (mAnchorView.getId() != mAnchorId) {
        return false;
      }
      View localView = mAnchorView;
      ViewParent localViewParent = mAnchorView.getParent();
      while (localViewParent != paramCoordinatorLayout) {
        if ((localViewParent != null) && (localViewParent != paramView))
        {
          if ((localViewParent instanceof View)) {
            localView = (View)localViewParent;
          }
          localViewParent = localViewParent.getParent();
        }
        else
        {
          mAnchorDirectChild = null;
          mAnchorView = null;
          return false;
        }
      }
      mAnchorDirectChild = localView;
      return true;
    }
  }
  
  public class g
    implements ViewTreeObserver.OnPreDrawListener
  {
    public g() {}
    
    public boolean onPreDraw()
    {
      render(0);
      return true;
    }
  }
  
  public static class h
    extends org.client.params.Item
  {
    public static final Parcelable.Creator<h> CREATOR = new a();
    public SparseArray<Parcelable> behaviorStates;
    
    public h(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(paramClassLoader);
      int j = paramParcel.readInt();
      int[] arrayOfInt = new int[j];
      paramParcel.readIntArray(arrayOfInt);
      paramParcel = paramParcel.readParcelableArray(paramClassLoader);
      behaviorStates = new SparseArray(j);
      int i = 0;
      while (i < j)
      {
        behaviorStates.append(arrayOfInt[i], paramParcel[i]);
        i += 1;
      }
    }
    
    public h(Parcelable paramParcelable)
    {
      super();
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      Object localObject = behaviorStates;
      int i;
      if (localObject != null) {
        i = ((SparseArray)localObject).size();
      } else {
        i = 0;
      }
      paramParcel.writeInt(i);
      localObject = new int[i];
      Parcelable[] arrayOfParcelable = new Parcelable[i];
      int j = 0;
      while (j < i)
      {
        localObject[j] = behaviorStates.keyAt(j);
        arrayOfParcelable[j] = ((Parcelable)behaviorStates.valueAt(j));
        j += 1;
      }
      paramParcel.writeIntArray((int[])localObject);
      paramParcel.writeParcelableArray(arrayOfParcelable, paramInt);
    }
    
    public static final class a
      implements Parcelable.ClassLoaderCreator<CoordinatorLayout.h>
    {
      public a() {}
      
      public CoordinatorLayout.h[] a(int paramInt)
      {
        return new CoordinatorLayout.h[paramInt];
      }
      
      public CoordinatorLayout.h readDate(Parcel paramParcel)
      {
        return new CoordinatorLayout.h(paramParcel, null);
      }
      
      public CoordinatorLayout.h readFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
      {
        return new CoordinatorLayout.h(paramParcel, paramClassLoader);
      }
    }
  }
  
  public static class i
    implements Comparator<View>
  {
    public i() {}
    
    public int compare(View paramView1, View paramView2)
    {
      float f1 = ViewCompat.getZ(paramView1);
      float f2 = ViewCompat.getZ(paramView2);
      if (f1 > f2) {
        return -1;
      }
      if (f1 < f2) {
        return 1;
      }
      return 0;
    }
  }
}
