package androidx.lifecycle;

import org.util.AnnotationVisitor;
import org.util.Attribute;
import org.util.MenuItem;
import org.util.Scope;
import org.util.d;

public class CompositeGeneratedAdaptersObserver
  implements MenuItem
{
  public final Attribute[] a;
  
  public CompositeGeneratedAdaptersObserver(Attribute[] paramArrayOfAttribute)
  {
    a = paramArrayOfAttribute;
  }
  
  public void b(d paramD, Scope paramScope)
  {
    AnnotationVisitor localAnnotationVisitor = new AnnotationVisitor();
    Attribute[] arrayOfAttribute = a;
    int k = arrayOfAttribute.length;
    int j = 0;
    int i = 0;
    while (i < k)
    {
      arrayOfAttribute[i].a(paramD, paramScope, false, localAnnotationVisitor);
      i += 1;
    }
    arrayOfAttribute = a;
    k = arrayOfAttribute.length;
    i = j;
    while (i < k)
    {
      arrayOfAttribute[i].a(paramD, paramScope, true, localAnnotationVisitor);
      i += 1;
    }
  }
}
