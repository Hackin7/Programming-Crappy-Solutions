package androidx.activity;

import java.util.ArrayDeque;
import java.util.Iterator;
import org.util.Log;
import org.util.MenuItem;
import org.util.Scope;
import org.util.c;

public final class OnBackPressedDispatcher
{
  public final ArrayDeque<a.a.b> a = new ArrayDeque();
  public final Runnable r;
  
  public OnBackPressedDispatcher(Runnable paramRunnable)
  {
    r = paramRunnable;
  }
  
  public org.curve.d a(org.curve.b paramB)
  {
    a.add(paramB);
    a localA = new a(paramB);
    paramB.a(localA);
    return localA;
  }
  
  public void a()
  {
    Object localObject = a.descendingIterator();
    while (((Iterator)localObject).hasNext())
    {
      org.curve.b localB = (org.curve.b)((Iterator)localObject).next();
      if (localB.a())
      {
        localB.run();
        return;
      }
    }
    localObject = r;
    if (localObject != null) {
      ((Runnable)localObject).run();
    }
  }
  
  public void a(org.util.d paramD, org.curve.b paramB)
  {
    paramD = paramD.getLifecycle();
    if (paramD.p() == c.c) {
      return;
    }
    paramB.a(new LifecycleOnBackPressedCancellable(paramD, paramB));
  }
  
  public class LifecycleOnBackPressedCancellable
    implements MenuItem, org.curve.d
  {
    public final org.curve.b a;
    public org.curve.d b;
    public final Log l;
    
    public LifecycleOnBackPressedCancellable(Log paramLog, org.curve.b paramB)
    {
      l = paramLog;
      a = paramB;
      paramLog.a(this);
    }
    
    public void b(org.util.d paramD, Scope paramScope)
    {
      if (paramScope == Scope.ON_START)
      {
        b = a(a);
        return;
      }
      if (paramScope == Scope.ON_STOP)
      {
        paramD = b;
        if (paramD != null) {
          paramD.cancel();
        }
      }
      else if (paramScope == Scope.ON_DESTROY)
      {
        cancel();
      }
    }
    
    public void cancel()
    {
      l.e(this);
      a.e(this);
      org.curve.d localD = b;
      if (localD != null)
      {
        localD.cancel();
        b = null;
      }
    }
  }
  
  public class a
    implements org.curve.d
  {
    public final org.curve.b a;
    
    public a(org.curve.b paramB)
    {
      a = paramB;
    }
    
    public void cancel()
    {
      a.remove(a);
      a.e(this);
    }
  }
}
