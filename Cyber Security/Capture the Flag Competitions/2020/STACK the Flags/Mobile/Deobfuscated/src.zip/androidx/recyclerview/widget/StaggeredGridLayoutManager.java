package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import org.core.view.tree.AccessibilityNodeInfoCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat.CollectionItemInfoCompat;
import org.objectweb.asm.Frame;
import org.objectweb.asm.OrientationHelper;
import org.objectweb.asm.ScrollbarHelper;
import org.objectweb.asm.i;

public class StaggeredGridLayoutManager
  extends RecyclerView.o
{
  public OrientationHelper a;
  public f[] b;
  public boolean c = false;
  public d d = new d();
  public int e = Integer.MIN_VALUE;
  public int f = -1;
  public e g;
  public final Frame h;
  public OrientationHelper i;
  public int j = -1;
  public int[] k;
  public final b m = new b();
  public int mFullSizeSpec;
  public int mOrientation;
  public int mSizePerSpan;
  public boolean mSmoothScrollbarEnabled = true;
  public final Rect mTmpRect = new Rect();
  public final Runnable n = new a();
  public boolean o;
  public boolean p;
  public boolean r = false;
  public int t = 2;
  public BitSet v;
  public boolean x = false;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    paramContext = RecyclerView.o.getProperties(paramContext, paramAttributeSet, paramInt1, paramInt2);
    setOrientation(orientation);
    setSpanCount(spanCount);
    setOrientation(reverseLayout);
    h = new Frame();
    fill();
  }
  
  public final int a(int paramInt)
  {
    int i2 = b[0].c(paramInt);
    int i1 = 1;
    while (i1 < f)
    {
      int i4 = b[i1].c(paramInt);
      int i3 = i2;
      if (i4 > i2) {
        i3 = i4;
      }
      i1 += 1;
      i2 = i3;
    }
    return i2;
  }
  
  public final int a(RecyclerView.u paramU, Frame paramFrame, RecyclerView.y paramY)
  {
    v.set(0, f, true);
    int i1;
    if (h.h)
    {
      if (g == 1) {
        i1 = Integer.MAX_VALUE;
      } else {
        i1 = Integer.MIN_VALUE;
      }
    }
    else if (g == 1) {
      i1 = e + x;
    } else {
      i1 = a - x;
    }
    a(g, i1);
    int i4;
    if (c) {
      i4 = a.a();
    } else {
      i4 = a.get();
    }
    int i3;
    for (int i2 = 0; paramFrame.a(paramY); i3 = 1)
    {
      if ((!h.h) && (v.isEmpty())) {
        break;
      }
      View localView = paramFrame.next(paramU);
      c localC = (c)localView.getLayoutParams();
      int i10 = localC.getViewLayoutPosition();
      i2 = d.get(i10);
      int i7;
      if (i2 == -1) {
        i7 = 1;
      } else {
        i7 = 0;
      }
      f localF;
      if (i7 != 0)
      {
        if (f) {
          localF = b[0];
        } else {
          localF = a(paramFrame);
        }
        d.b(i10, localF);
      }
      else
      {
        localF = b[i2];
      }
      b = localF;
      if (g == 1) {
        addView(localView);
      } else {
        addView(localView, 0);
      }
      measureChildWithDecorationsAndMargin(localView, localC, false);
      int i8;
      int i5;
      int i6;
      StaggeredGridLayoutManager.d.a localA;
      if (g == 1)
      {
        if (f) {
          i2 = a(i4);
        } else {
          i2 = localF.c(i4);
        }
        i8 = a.getDecoratedMeasurement(localView) + i2;
        i5 = i2;
        i6 = i8;
        if (i7 != 0)
        {
          i5 = i2;
          i6 = i8;
          if (f)
          {
            localA = b(i2);
            d = -1;
            a = i10;
            d.a(localA);
            i5 = i2;
            i6 = i8;
          }
        }
      }
      else
      {
        if (f) {
          i2 = getValue(i4);
        } else {
          i2 = localF.get(i4);
        }
        i8 = i2;
        int i9 = i2 - a.getDecoratedMeasurement(localView);
        i5 = i9;
        i6 = i8;
        if (i7 != 0)
        {
          i5 = i9;
          i6 = i8;
          if (f)
          {
            localA = d(i2);
            d = 1;
            a = i10;
            d.a(localA);
            i6 = i8;
            i5 = i9;
          }
        }
      }
      if ((f) && (i == -1)) {
        if (i7 != 0)
        {
          r = true;
        }
        else
        {
          boolean bool;
          if (g == 1) {
            bool = f() ^ true;
          } else {
            bool = equals() ^ true;
          }
          if (bool)
          {
            localA = d.d(i10);
            if (localA != null) {
              b = true;
            }
            r = true;
          }
        }
      }
      b(localView, localC, paramFrame);
      if ((isLayoutRTL()) && (mOrientation == 1))
      {
        if (f) {
          i3 = i.a();
        } else {
          i3 = i.a() - (f - 1 - i) * mSizePerSpan;
        }
        i7 = i3 - i.getDecoratedMeasurement(localView);
      }
      else
      {
        if (f) {
          i3 = i.get();
        } else {
          i3 = i * mSizePerSpan + i.get();
        }
        i8 = i.getDecoratedMeasurement(localView) + i3;
        i7 = i3;
        i3 = i8;
      }
      if (mOrientation == 1) {
        measureChildWithDecorationsAndMargin(localView, i7, i5, i3, i6);
      } else {
        measureChildWithDecorationsAndMargin(localView, i5, i7, i6, i3);
      }
      if (f) {
        a(h.g, i1);
      } else {
        a(localF, h.g, i1);
      }
      b(paramU, h);
      if ((h.b) && (localView.hasFocusable())) {
        if (f) {
          v.clear();
        } else {
          v.set(i, false);
        }
      }
    }
    if (i3 == 0) {
      b(paramU, h);
    }
    if (h.g == -1)
    {
      i1 = getValue(a.get());
      i1 = a.get() - i1;
    }
    else
    {
      i1 = a(a.a()) - a.a();
    }
    if (i1 > 0) {
      return Math.min(x, i1);
    }
    return 0;
  }
  
  public View a()
  {
    int i1 = getChildCount() - 1;
    BitSet localBitSet = new BitSet(f);
    localBitSet.set(0, f, true);
    int i2 = mOrientation;
    int i5 = -1;
    if ((i2 == 1) && (isLayoutRTL())) {
      i2 = 1;
    } else {
      i2 = -1;
    }
    int i3;
    if (c)
    {
      i3 = 0 - 1;
    }
    else
    {
      i3 = 0;
      i4 = i1 + 1;
      i1 = i3;
      i3 = i4;
    }
    int i4 = i1;
    if (i1 < i3)
    {
      i5 = 1;
      i4 = i1;
    }
    while (i4 != i3)
    {
      View localView = getChildAt(i4);
      c localC = (c)localView.getLayoutParams();
      if (localBitSet.get(b.i))
      {
        if (a(b)) {
          return localView;
        }
        localBitSet.clear(b.i);
      }
      if ((!f) && (i4 + i5 != i3))
      {
        Object localObject = getChildAt(i4 + i5);
        int i6 = 0;
        i1 = 0;
        int i7;
        if (c)
        {
          i6 = a.getDecoratedEnd(localView);
          i7 = a.getDecoratedEnd((View)localObject);
          if (i6 < i7) {
            return localView;
          }
          if (i6 == i7) {
            i1 = 1;
          }
        }
        else
        {
          i7 = a.getDecoratedStart(localView);
          int i8 = a.getDecoratedStart((View)localObject);
          if (i7 > i8) {
            return localView;
          }
          i1 = i6;
          if (i7 == i8) {
            i1 = 1;
          }
        }
        if (i1 != 0)
        {
          localObject = (c)((View)localObject).getLayoutParams();
          if (b.i - b.i < 0) {
            i1 = 1;
          } else {
            i1 = 0;
          }
          if (i2 < 0) {
            i6 = 1;
          } else {
            i6 = 0;
          }
          if (i1 != i6) {
            return localView;
          }
        }
      }
      i4 += i5;
    }
    return null;
  }
  
  public final f a(Frame paramFrame)
  {
    int i1;
    int i2;
    int i3;
    if (preferLastSpan(g))
    {
      i1 = f - 1;
      i2 = -1;
      i3 = -1;
    }
    else
    {
      i1 = 0;
      i2 = f;
      i3 = 1;
    }
    f localF;
    int i6;
    int i5;
    if (g == 1)
    {
      paramFrame = null;
      i4 = Integer.MAX_VALUE;
      i7 = a.get();
      while (i1 != i2)
      {
        localF = b[i1];
        i6 = localF.c(i7);
        i5 = i4;
        if (i6 < i4)
        {
          paramFrame = localF;
          i5 = i6;
        }
        i1 += i3;
        i4 = i5;
      }
      return paramFrame;
    }
    paramFrame = null;
    int i4 = Integer.MIN_VALUE;
    int i7 = a.a();
    while (i1 != i2)
    {
      localF = b[i1];
      i6 = localF.get(i7);
      i5 = i4;
      if (i6 > i4)
      {
        paramFrame = localF;
        i5 = i6;
      }
      i1 += i3;
      i4 = i5;
    }
    return paramFrame;
  }
  
  public final void a(int paramInt1, int paramInt2)
  {
    int i1 = 0;
    while (i1 < f)
    {
      if (!b[i1].c.isEmpty()) {
        a(b[i1], paramInt1, paramInt2);
      }
      i1 += 1;
    }
  }
  
  public void a(int paramInt1, int paramInt2, RecyclerView.y paramY, RecyclerView.o.c paramC)
  {
    if (mOrientation != 0) {
      paramInt1 = paramInt2;
    }
    if (getChildCount() != 0)
    {
      if (paramInt1 == 0) {
        return;
      }
      b(paramInt1, paramY);
      Object localObject = k;
      if ((localObject == null) || (localObject.length < f)) {
        k = new int[f];
      }
      paramInt1 = 0;
      paramInt2 = 0;
      int i1;
      int i2;
      while (paramInt2 < f)
      {
        localObject = h;
        if (i == -1)
        {
          i1 = a;
          i2 = i1 - b[paramInt2].get(i1);
        }
        else
        {
          i2 = b[paramInt2].c(e) - h.e;
        }
        i1 = paramInt1;
        if (i2 >= 0)
        {
          k[paramInt1] = i2;
          i1 = paramInt1 + 1;
        }
        paramInt2 += 1;
        paramInt1 = i1;
      }
      Arrays.sort(k, 0, paramInt1);
      paramInt2 = 0;
      while ((paramInt2 < paramInt1) && (h.a(paramY)))
      {
        i1 = h.c;
        i2 = k[paramInt2];
        ((i)paramC).add(i1, i2);
        localObject = h;
        c += i;
        paramInt2 += 1;
      }
    }
  }
  
  public final void a(int paramInt, RecyclerView.y paramY)
  {
    paramY = h;
    boolean bool2 = false;
    x = 0;
    c = paramInt;
    onRequestChildFocus();
    if (shouldIgnore())
    {
      h.a = (a.get() - 0);
      h.e = (a.a() + 0);
    }
    else
    {
      h.e = (a.getEnd() + 0);
      h.a = (-0);
    }
    paramY = h;
    b = false;
    f = true;
    boolean bool1 = bool2;
    if (a.getMode() == 0)
    {
      bool1 = bool2;
      if (a.getEnd() == 0) {
        bool1 = true;
      }
    }
    h = bool1;
  }
  
  public final void a(RecyclerView.u paramU, int paramInt)
  {
    while (getChildCount() > 0)
    {
      View localView = getChildAt(0);
      if ((a.getDecoratedEnd(localView) > paramInt) || (a.a(localView) > paramInt)) {
        break;
      }
      c localC = (c)localView.getLayoutParams();
      if (f)
      {
        int i1 = 0;
        while (i1 < f)
        {
          if (b[i1].c.size() == 1) {
            return;
          }
          i1 += 1;
        }
        i1 = 0;
        while (i1 < f)
        {
          b[i1].a();
          i1 += 1;
        }
      }
      else
      {
        if (b.c.size() == 1) {
          return;
        }
        b.a();
      }
      a(localView, paramU);
    }
  }
  
  public final void a(RecyclerView.u paramU, RecyclerView.y paramY, boolean paramBoolean)
  {
    b localB = m;
    if (((g != null) || (j != -1)) && (paramY.getItemCount() == 0))
    {
      removeAndRecycleAllViews(paramU);
      localB.reset();
      return;
    }
    boolean bool = g;
    int i2 = 1;
    if ((bool) && (j == -1) && (g == null)) {
      i1 = 0;
    } else {
      i1 = 1;
    }
    if (i1 != 0)
    {
      localB.reset();
      if (g != null)
      {
        a(localB);
      }
      else
      {
        resolveShouldLayoutReverse();
        c = c;
      }
      recycle(paramY, localB);
      g = true;
    }
    if ((g == null) && (j == -1) && ((c != p) || (isLayoutRTL() != o)))
    {
      d.clear();
      i = true;
    }
    Object localObject;
    if (getChildCount() > 0)
    {
      localObject = g;
      if ((localObject == null) || (d < 1)) {
        if (i)
        {
          i1 = 0;
          while (i1 < f)
          {
            b[i1].close();
            i3 = a;
            if (i3 != Integer.MIN_VALUE) {
              b[i1].a(i3);
            }
            i1 += 1;
          }
        }
        else
        {
          if ((i1 == 0) && (m.z != null)) {
            i1 = 0;
          }
          while (i1 < f)
          {
            localObject = b[i1];
            ((f)localObject).close();
            ((f)localObject).a(m.z[i1]);
            i1 += 1;
            continue;
            i1 = 0;
            while (i1 < f)
            {
              b[i1].b(c, a);
              i1 += 1;
            }
            m.a(b);
          }
        }
      }
    }
    detachAndScrapAttachedViews(paramU);
    h.f = false;
    r = false;
    updateMeasureSpecs(i.getTotalSpace());
    a(j, paramY);
    if (c)
    {
      c(-1);
      a(paramU, h, paramY);
      c(1);
      localObject = h;
      c = (j + i);
      a(paramU, (Frame)localObject, paramY);
    }
    else
    {
      c(1);
      a(paramU, h, paramY);
      c(-1);
      localObject = h;
      c = (j + i);
      a(paramU, (Frame)localObject, paramY);
    }
    repositionToWrapContentIfNecessary();
    if (getChildCount() > 0) {
      if (c)
      {
        fixEndGap(paramU, paramY, true);
        fixStartGap(paramU, paramY, false);
      }
      else
      {
        fixStartGap(paramU, paramY, true);
        fixEndGap(paramU, paramY, false);
      }
    }
    int i3 = 0;
    int i1 = i3;
    if (paramBoolean)
    {
      i1 = i3;
      if (!paramY.isPreLayout())
      {
        if ((t == 0) || (getChildCount() <= 0) || ((r) || (a() == null))) {
          i2 = 0;
        }
        i1 = i3;
        if (i2 != 0)
        {
          removeCallbacks(n);
          i1 = i3;
          if (b()) {
            i1 = 1;
          }
        }
      }
    }
    if (paramY.isPreLayout()) {
      m.reset();
    }
    p = c;
    o = isLayoutRTL();
    if (i1 != 0)
    {
      m.reset();
      a(paramU, paramY, false);
    }
  }
  
  public void a(RecyclerView paramRecyclerView, RecyclerView.u paramU)
  {
    super.a(paramRecyclerView, paramU);
    removeCallbacks(n);
    int i1 = 0;
    while (i1 < f)
    {
      b[i1].close();
      i1 += 1;
    }
    paramRecyclerView.requestLayout();
  }
  
  public final void a(b paramB)
  {
    Object localObject = g;
    int i1 = d;
    if (i1 > 0) {
      if (i1 == f)
      {
        int i2 = 0;
        while (i2 < f)
        {
          b[i2].close();
          localObject = g;
          int i3 = f[i2];
          i1 = i3;
          if (i3 != Integer.MIN_VALUE) {
            if (g) {
              i1 = i3 + a.a();
            } else {
              i1 = i3 + a.get();
            }
          }
          b[i2].a(i1);
          i2 += 1;
        }
      }
      else
      {
        ((e)localObject).a();
        localObject = g;
        c = b;
      }
    }
    localObject = g;
    o = h;
    setOrientation(e);
    resolveShouldLayoutReverse();
    localObject = g;
    i1 = c;
    if (i1 != -1)
    {
      j = i1;
      c = g;
    }
    else
    {
      c = c;
    }
    paramB = g;
    if (a > 1)
    {
      localObject = d;
      a = i;
      c = x;
    }
  }
  
  public final void a(f paramF, int paramInt1, int paramInt2)
  {
    int i1 = paramF.r();
    if (paramInt1 == -1)
    {
      if (paramF.c() + i1 <= paramInt2) {
        v.set(i, false);
      }
      return;
    }
    if (paramF.p() - i1 >= paramInt2) {
      v.set(i, false);
    }
  }
  
  public final boolean a(f paramF)
  {
    if (c)
    {
      if (paramF.p() < a.a())
      {
        ArrayList localArrayList = c;
        return nextgetsize1f ^ true;
      }
    }
    else if (paramF.c() > a.get()) {
      return nextc.get(0)).f ^ true;
    }
    return false;
  }
  
  public void assertNotInLayoutOrScroll(String paramString)
  {
    if (g == null) {
      super.assertNotInLayoutOrScroll(paramString);
    }
  }
  
  public final StaggeredGridLayoutManager.d.a b(int paramInt)
  {
    StaggeredGridLayoutManager.d.a localA = new StaggeredGridLayoutManager.d.a();
    c = new int[f];
    int i1 = 0;
    while (i1 < f)
    {
      c[i1] = (paramInt - b[i1].c(paramInt));
      i1 += 1;
    }
    return localA;
  }
  
  public void b(int paramInt, RecyclerView.y paramY)
  {
    int i1;
    int i2;
    if (paramInt > 0)
    {
      i1 = 1;
      i2 = c();
    }
    else
    {
      i1 = -1;
      i2 = getFirstChildPosition();
    }
    h.f = true;
    a(i2, paramY);
    c(i1);
    paramY = h;
    c = (i + i2);
    x = Math.abs(paramInt);
  }
  
  public final void b(View paramView)
  {
    int i1 = f - 1;
    while (i1 >= 0)
    {
      b[i1].a(paramView);
      i1 -= 1;
    }
  }
  
  public final void b(View paramView, c paramC, Frame paramFrame)
  {
    if (g == 1)
    {
      if (f)
      {
        c(paramView);
        return;
      }
      b.b(paramView);
      return;
    }
    if (f)
    {
      b(paramView);
      return;
    }
    b.a(paramView);
  }
  
  public final void b(RecyclerView.u paramU, int paramInt)
  {
    int i1 = getChildCount() - 1;
    while (i1 >= 0)
    {
      View localView = getChildAt(i1);
      if ((a.getDecoratedStart(localView) < paramInt) || (a.getEnd(localView) < paramInt)) {
        break;
      }
      c localC = (c)localView.getLayoutParams();
      if (f)
      {
        int i2 = 0;
        while (i2 < f)
        {
          if (b[i2].c.size() == 1) {
            return;
          }
          i2 += 1;
        }
        i2 = 0;
        while (i2 < f)
        {
          b[i2].b();
          i2 += 1;
        }
      }
      else
      {
        if (b.c.size() == 1) {
          return;
        }
        b.b();
      }
      a(localView, paramU);
      i1 -= 1;
    }
  }
  
  public final void b(RecyclerView.u paramU, Frame paramFrame)
  {
    if (f)
    {
      if (h) {
        return;
      }
      if (x == 0)
      {
        if (g == -1)
        {
          b(paramU, e);
          return;
        }
        a(paramU, a);
        return;
      }
      if (g == -1)
      {
        i1 = a;
        i1 -= f(i1);
        if (i1 < 0) {
          i1 = e;
        } else {
          i1 = e - Math.min(i1, x);
        }
        b(paramU, i1);
        return;
      }
      int i1 = equals(e) - e;
      if (i1 < 0) {
        i1 = a;
      } else {
        i1 = a + Math.min(i1, x);
      }
      a(paramU, i1);
    }
  }
  
  public boolean b()
  {
    if ((getChildCount() != 0) && (t != 0))
    {
      if (!isAttachedToWindow()) {
        return false;
      }
      int i1;
      int i2;
      if (c)
      {
        i1 = c();
        i2 = getFirstChildPosition();
      }
      else
      {
        i1 = getFirstChildPosition();
        i2 = c();
      }
      if ((i1 == 0) && (a() != null))
      {
        d.clear();
        visitCode();
        requestLayout();
        return true;
      }
      if (!r) {
        return false;
      }
      int i3;
      if (c) {
        i3 = -1;
      } else {
        i3 = 1;
      }
      StaggeredGridLayoutManager.d.a localA1 = d.a(i1, i2 + 1, i3, true);
      if (localA1 == null)
      {
        r = false;
        d.b(i2 + 1);
        return false;
      }
      StaggeredGridLayoutManager.d.a localA2 = d.a(i1, a, i3 * -1, true);
      if (localA2 == null) {
        d.b(a);
      } else {
        d.b(a + 1);
      }
      visitCode();
      requestLayout();
      return true;
    }
    return false;
  }
  
  public boolean b(RecyclerView.y paramY, b paramB)
  {
    boolean bool2 = paramY.isPreLayout();
    boolean bool1 = false;
    if (!bool2)
    {
      int i1 = j;
      if (i1 == -1) {
        return false;
      }
      if ((i1 >= 0) && (i1 < paramY.getItemCount()))
      {
        paramY = g;
        if ((paramY != null) && (c != -1) && (d >= 1))
        {
          a = Integer.MIN_VALUE;
          j = j;
          return true;
        }
        paramY = findViewByPosition(j);
        if (paramY != null)
        {
          if (c) {
            i1 = c();
          } else {
            i1 = getFirstChildPosition();
          }
          j = i1;
          if (e != Integer.MIN_VALUE)
          {
            if (c)
            {
              a = (a.a() - e - a.getDecoratedEnd(paramY));
              return true;
            }
            a = (a.get() + e - a.getDecoratedStart(paramY));
            return true;
          }
          if (a.getDecoratedMeasurement(paramY) > a.getTotalSpace())
          {
            if (c) {
              i1 = a.a();
            } else {
              i1 = a.get();
            }
            a = i1;
            return true;
          }
          i1 = a.getDecoratedStart(paramY) - a.get();
          if (i1 < 0)
          {
            a = (-i1);
            return true;
          }
          i1 = a.a() - a.getDecoratedEnd(paramY);
          if (i1 < 0)
          {
            a = i1;
            return true;
          }
          a = Integer.MIN_VALUE;
        }
        else
        {
          i1 = j;
          j = i1;
          int i2 = e;
          if (i2 == Integer.MIN_VALUE)
          {
            if (calculateScrollDirectionForPosition(i1) == 1) {
              bool1 = true;
            }
            c = bool1;
            paramB.b();
          }
          else
          {
            paramB.b(i2);
          }
          i = true;
        }
        return true;
      }
      j = -1;
      e = Integer.MIN_VALUE;
    }
    return false;
  }
  
  public int c()
  {
    int i1 = getChildCount();
    if (i1 == 0) {
      return 0;
    }
    return getPosition(getChildAt(i1 - 1));
  }
  
  public final void c(int paramInt)
  {
    Frame localFrame = h;
    g = paramInt;
    boolean bool2 = c;
    int i1 = 1;
    boolean bool1;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    if (bool2 == bool1) {
      paramInt = i1;
    } else {
      paramInt = -1;
    }
    i = paramInt;
  }
  
  public final void c(View paramView)
  {
    int i1 = f - 1;
    while (i1 >= 0)
    {
      b[i1].b(paramView);
      i1 -= 1;
    }
  }
  
  public final int calculateScrollDirectionForPosition(int paramInt)
  {
    if (getChildCount() == 0)
    {
      if (c) {
        return 1;
      }
    }
    else
    {
      int i1;
      if (paramInt < getFirstChildPosition()) {
        i1 = 1;
      } else {
        i1 = 0;
      }
      if (i1 != c) {
        return -1;
      }
      return 1;
    }
    return -1;
  }
  
  public boolean canScrollHorizontally()
  {
    return mOrientation == 0;
  }
  
  public boolean canScrollVertically()
  {
    return mOrientation == 1;
  }
  
  public boolean checkLayoutParams(RecyclerView.p paramP)
  {
    return paramP instanceof c;
  }
  
  public int computeHorizontalScrollExtent(RecyclerView.y paramY)
  {
    return computeScrollExtent(paramY);
  }
  
  public int computeHorizontalScrollOffset(RecyclerView.y paramY)
  {
    return computeScrollOffset(paramY);
  }
  
  public int computeHorizontalScrollRange(RecyclerView.y paramY)
  {
    return computeScrollRange(paramY);
  }
  
  public final int computeScrollExtent(RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return 0;
    }
    return ScrollbarHelper.computeScrollExtent(paramY, a, findFirstVisibleItemClosestToStart(mSmoothScrollbarEnabled ^ true), findFirstVisibleItemClosestToEnd(mSmoothScrollbarEnabled ^ true), this, mSmoothScrollbarEnabled);
  }
  
  public final int computeScrollOffset(RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return 0;
    }
    return ScrollbarHelper.computeScrollOffset(paramY, a, findFirstVisibleItemClosestToStart(mSmoothScrollbarEnabled ^ true), findFirstVisibleItemClosestToEnd(mSmoothScrollbarEnabled ^ true), this, mSmoothScrollbarEnabled, c);
  }
  
  public final int computeScrollRange(RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return 0;
    }
    return ScrollbarHelper.computeScrollRange(paramY, a, findFirstVisibleItemClosestToStart(mSmoothScrollbarEnabled ^ true), findFirstVisibleItemClosestToEnd(mSmoothScrollbarEnabled ^ true), this, mSmoothScrollbarEnabled);
  }
  
  public int computeVerticalScrollExtent(RecyclerView.y paramY)
  {
    return computeScrollExtent(paramY);
  }
  
  public int computeVerticalScrollOffset(RecyclerView.y paramY)
  {
    return computeScrollOffset(paramY);
  }
  
  public int computeVerticalScrollRange(RecyclerView.y paramY)
  {
    return computeScrollRange(paramY);
  }
  
  public final int convertFocusDirectionToLayoutDirection(int paramInt)
  {
    if (paramInt != 1)
    {
      if (paramInt != 2)
      {
        if (paramInt != 17)
        {
          if (paramInt != 33)
          {
            if (paramInt != 66)
            {
              if (paramInt != 130) {
                return Integer.MIN_VALUE;
              }
              if (mOrientation == 1) {
                return 1;
              }
              return Integer.MIN_VALUE;
            }
            if (mOrientation == 0) {
              return 1;
            }
            return Integer.MIN_VALUE;
          }
          if (mOrientation == 1) {
            return -1;
          }
          return Integer.MIN_VALUE;
        }
        if (mOrientation == 0) {
          return -1;
        }
        return Integer.MIN_VALUE;
      }
      if (mOrientation == 1) {
        return 1;
      }
      if (isLayoutRTL()) {
        return -1;
      }
      return 1;
    }
    if (mOrientation == 1) {
      return -1;
    }
    if (isLayoutRTL()) {
      return 1;
    }
    return -1;
  }
  
  public Parcelable d()
  {
    if (g != null) {
      return new e(g);
    }
    e localE = new e();
    e = x;
    g = p;
    h = o;
    d localD = d;
    if (localD != null)
    {
      int[] arrayOfInt = a;
      if (arrayOfInt != null)
      {
        i = arrayOfInt;
        a = arrayOfInt.length;
        x = c;
        break label112;
      }
    }
    a = 0;
    label112:
    if (getChildCount() > 0)
    {
      if (p) {
        i1 = c();
      } else {
        i1 = getFirstChildPosition();
      }
      c = i1;
      b = findFirstVisibleItemPositionInt();
      int i1 = f;
      d = i1;
      f = new int[i1];
      int i2 = 0;
      while (i2 < f)
      {
        int i3;
        if (p)
        {
          i3 = b[i2].c(Integer.MIN_VALUE);
          i1 = i3;
          if (i3 != Integer.MIN_VALUE) {
            i1 = i3 - a.a();
          }
        }
        else
        {
          i3 = b[i2].get(Integer.MIN_VALUE);
          i1 = i3;
          if (i3 != Integer.MIN_VALUE) {
            i1 = i3 - a.get();
          }
        }
        f[i2] = i1;
        i2 += 1;
      }
      return localE;
    }
    c = -1;
    b = -1;
    d = 0;
    return localE;
  }
  
  public final StaggeredGridLayoutManager.d.a d(int paramInt)
  {
    StaggeredGridLayoutManager.d.a localA = new StaggeredGridLayoutManager.d.a();
    c = new int[f];
    int i1 = 0;
    while (i1 < f)
    {
      c[i1] = (b[i1].get(paramInt) - paramInt);
      i1 += 1;
    }
    return localA;
  }
  
  public void draw(int paramInt)
  {
    super.draw(paramInt);
    int i1 = 0;
    while (i1 < f)
    {
      b[i1].b(paramInt);
      i1 += 1;
    }
  }
  
  public final int equals(int paramInt)
  {
    int i2 = b[0].c(paramInt);
    int i1 = 1;
    while (i1 < f)
    {
      int i4 = b[i1].c(paramInt);
      int i3 = i2;
      if (i4 < i2) {
        i3 = i4;
      }
      i1 += 1;
      i2 = i3;
    }
    return i2;
  }
  
  public boolean equals()
  {
    int i2 = b[0].get(Integer.MIN_VALUE);
    int i1 = 1;
    while (i1 < f)
    {
      if (b[i1].get(Integer.MIN_VALUE) != i2) {
        return false;
      }
      i1 += 1;
    }
    return true;
  }
  
  public final int f(int paramInt)
  {
    int i2 = b[0].get(paramInt);
    int i1 = 1;
    while (i1 < f)
    {
      int i4 = b[i1].get(paramInt);
      int i3 = i2;
      if (i4 > i2) {
        i3 = i4;
      }
      i1 += 1;
      i2 = i3;
    }
    return i2;
  }
  
  public boolean f()
  {
    int i2 = b[0].c(Integer.MIN_VALUE);
    int i1 = 1;
    while (i1 < f)
    {
      if (b[i1].c(Integer.MIN_VALUE) != i2) {
        return false;
      }
      i1 += 1;
    }
    return true;
  }
  
  public final void fill()
  {
    a = OrientationHelper.toString(this, mOrientation);
    i = OrientationHelper.toString(this, 1 - mOrientation);
  }
  
  public final int findFirstReferenceChildPosition(int paramInt)
  {
    int i2 = getChildCount();
    int i1 = 0;
    while (i1 < i2)
    {
      int i3 = getPosition(getChildAt(i1));
      if ((i3 >= 0) && (i3 < paramInt)) {
        return i3;
      }
      i1 += 1;
    }
    return 0;
  }
  
  public View findFirstVisibleItemClosestToEnd(boolean paramBoolean)
  {
    int i2 = a.get();
    int i3 = a.a();
    Object localObject1 = null;
    int i1 = getChildCount() - 1;
    while (i1 >= 0)
    {
      View localView = getChildAt(i1);
      int i4 = a.getDecoratedStart(localView);
      int i5 = a.getDecoratedEnd(localView);
      Object localObject2 = localObject1;
      if (i5 > i2) {
        if (i4 >= i3)
        {
          localObject2 = localObject1;
        }
        else if (i5 > i3)
        {
          if (!paramBoolean) {
            return localView;
          }
          localObject2 = localObject1;
          if (localObject1 == null) {
            localObject2 = localView;
          }
        }
        else
        {
          return localView;
        }
      }
      i1 -= 1;
      localObject1 = localObject2;
    }
    return localObject1;
  }
  
  public View findFirstVisibleItemClosestToStart(boolean paramBoolean)
  {
    int i2 = a.get();
    int i3 = a.a();
    int i4 = getChildCount();
    Object localObject1 = null;
    int i1 = 0;
    while (i1 < i4)
    {
      View localView = getChildAt(i1);
      int i5 = a.getDecoratedStart(localView);
      Object localObject2 = localObject1;
      if (a.getDecoratedEnd(localView) > i2) {
        if (i5 >= i3)
        {
          localObject2 = localObject1;
        }
        else if (i5 < i2)
        {
          if (!paramBoolean) {
            return localView;
          }
          localObject2 = localObject1;
          if (localObject1 == null) {
            localObject2 = localView;
          }
        }
        else
        {
          return localView;
        }
      }
      i1 += 1;
      localObject1 = localObject2;
    }
    return localObject1;
  }
  
  public int findFirstVisibleItemPositionInt()
  {
    View localView;
    if (c) {
      localView = findFirstVisibleItemClosestToEnd(true);
    } else {
      localView = findFirstVisibleItemClosestToStart(true);
    }
    if (localView == null) {
      return -1;
    }
    return getPosition(localView);
  }
  
  public final int findLastReferenceChildPosition(int paramInt)
  {
    int i1 = getChildCount() - 1;
    while (i1 >= 0)
    {
      int i2 = getPosition(getChildAt(i1));
      if ((i2 >= 0) && (i2 < paramInt)) {
        return i2;
      }
      i1 -= 1;
    }
    return 0;
  }
  
  public final void fixEndGap(RecyclerView.u paramU, RecyclerView.y paramY, boolean paramBoolean)
  {
    int i1 = a(Integer.MIN_VALUE);
    if (i1 == Integer.MIN_VALUE) {
      return;
    }
    i1 = a.a() - i1;
    if (i1 > 0)
    {
      i1 -= -scrollBy(-i1, paramU, paramY);
      if ((paramBoolean) && (i1 > 0)) {
        a.offsetChildren(i1);
      }
    }
  }
  
  public final void fixStartGap(RecyclerView.u paramU, RecyclerView.y paramY, boolean paramBoolean)
  {
    int i1 = getValue(Integer.MAX_VALUE);
    if (i1 == Integer.MAX_VALUE) {
      return;
    }
    i1 -= a.get();
    if (i1 > 0)
    {
      i1 -= scrollBy(i1, paramU, paramY);
      if ((paramBoolean) && (i1 > 0)) {
        a.offsetChildren(-i1);
      }
    }
  }
  
  public RecyclerView.p generateDefaultLayoutParams()
  {
    if (mOrientation == 0) {
      return new c(-2, -1);
    }
    return new c(-1, -2);
  }
  
  public RecyclerView.p generateLayoutParams(Context paramContext, AttributeSet paramAttributeSet)
  {
    return new c(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.p generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new c((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new c(paramLayoutParams);
  }
  
  public int getColumnCountForAccessibility(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mOrientation == 1) {
      return f;
    }
    return super.getColumnCountForAccessibility(paramU, paramY);
  }
  
  public int getFirstChildPosition()
  {
    if (getChildCount() == 0) {
      return 0;
    }
    return getPosition(getChildAt(0));
  }
  
  public int getRowCountForAccessibility(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (mOrientation == 0) {
      return f;
    }
    return super.getRowCountForAccessibility(paramU, paramY);
  }
  
  public final int getValue(int paramInt)
  {
    int i2 = b[0].get(paramInt);
    int i1 = 1;
    while (i1 < f)
    {
      int i4 = b[i1].get(paramInt);
      int i3 = i2;
      if (i4 < i2) {
        i3 = i4;
      }
      i1 += 1;
      i2 = i3;
    }
    return i2;
  }
  
  public final void handleUpdate(int paramInt1, int paramInt2, int paramInt3)
  {
    int i3;
    if (c) {
      i3 = c();
    } else {
      i3 = getFirstChildPosition();
    }
    int i2;
    int i1;
    if (paramInt3 == 8)
    {
      if (paramInt1 < paramInt2)
      {
        i2 = paramInt2 + 1;
        i1 = paramInt1;
      }
      else
      {
        i2 = paramInt1 + 1;
        i1 = paramInt2;
      }
    }
    else
    {
      i1 = paramInt1;
      i2 = paramInt1 + paramInt2;
    }
    d.clear(i1);
    if (paramInt3 != 1)
    {
      if (paramInt3 != 2)
      {
        if (paramInt3 == 8)
        {
          d.close(paramInt1, 1);
          d.set(paramInt2, 1);
        }
      }
      else {
        d.close(paramInt1, paramInt2);
      }
    }
    else {
      d.set(paramInt1, paramInt2);
    }
    if (i2 <= i3) {
      return;
    }
    if (c) {
      paramInt1 = getFirstChildPosition();
    } else {
      paramInt1 = c();
    }
    if (i1 <= paramInt1) {
      requestLayout();
    }
  }
  
  public void invalidateSpanAssignments()
  {
    d.clear();
    requestLayout();
  }
  
  public boolean isLayoutRTL()
  {
    return getLayoutDirection() == 1;
  }
  
  public final void measureChildWithDecorationsAndMargin(View paramView, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    calculateItemDecorationsForChild(paramView, mTmpRect);
    c localC = (c)paramView.getLayoutParams();
    int i1 = leftMargin;
    Rect localRect = mTmpRect;
    paramInt1 = updateSpecWithExtra(paramInt1, i1 + left, rightMargin + right);
    i1 = topMargin;
    localRect = mTmpRect;
    paramInt2 = updateSpecWithExtra(paramInt2, i1 + top, bottomMargin + bottom);
    if (paramBoolean) {
      paramBoolean = shouldReMeasureChild(paramView, paramInt1, paramInt2, localC);
    } else {
      paramBoolean = shouldMeasureChild(paramView, paramInt1, paramInt2, localC);
    }
    if (paramBoolean) {
      paramView.measure(paramInt1, paramInt2);
    }
  }
  
  public final void measureChildWithDecorationsAndMargin(View paramView, c paramC, boolean paramBoolean)
  {
    if (f)
    {
      if (mOrientation == 1)
      {
        measureChildWithDecorationsAndMargin(paramView, mFullSizeSpec, RecyclerView.o.getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingTop() + getPaddingBottom(), height, true), paramBoolean);
        return;
      }
      measureChildWithDecorationsAndMargin(paramView, RecyclerView.o.getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingLeft() + getPaddingRight(), width, true), mFullSizeSpec, paramBoolean);
      return;
    }
    if (mOrientation == 1)
    {
      measureChildWithDecorationsAndMargin(paramView, RecyclerView.o.getChildMeasureSpec(mSizePerSpan, getWidthMode(), 0, width, false), RecyclerView.o.getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingTop() + getPaddingBottom(), height, true), paramBoolean);
      return;
    }
    measureChildWithDecorationsAndMargin(paramView, RecyclerView.o.getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingLeft() + getPaddingRight(), width, true), RecyclerView.o.getChildMeasureSpec(mSizePerSpan, getHeightMode(), 0, height, false), paramBoolean);
  }
  
  public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (getChildCount() == 0) {
      return null;
    }
    paramView = findContainingItemView(paramView);
    if (paramView == null) {
      return null;
    }
    resolveShouldLayoutReverse();
    int i3 = convertFocusDirectionToLayoutDirection(paramInt);
    if (i3 == Integer.MIN_VALUE) {
      return null;
    }
    Object localObject = (c)paramView.getLayoutParams();
    boolean bool1 = f;
    localObject = b;
    if (i3 == 1) {
      paramInt = c();
    } else {
      paramInt = getFirstChildPosition();
    }
    a(paramInt, paramY);
    c(i3);
    Frame localFrame = h;
    c = (i + paramInt);
    x = ((int)(a.getTotalSpace() * 0.33333334F));
    localFrame = h;
    b = true;
    int i2 = 0;
    f = false;
    a(paramU, localFrame, paramY);
    p = c;
    if (!bool1)
    {
      paramU = ((f)localObject).b(paramInt, i3);
      if ((paramU != null) && (paramU != paramView)) {
        return paramU;
      }
    }
    if (preferLastSpan(i3))
    {
      i1 = f - 1;
      while (i1 >= 0)
      {
        paramU = b[i1].b(paramInt, i3);
        if ((paramU != null) && (paramU != paramView)) {
          return paramU;
        }
        i1 -= 1;
      }
    }
    else
    {
      i1 = 0;
      while (i1 < f)
      {
        paramU = b[i1].b(paramInt, i3);
        if ((paramU != null) && (paramU != paramView)) {
          return paramU;
        }
        i1 += 1;
      }
    }
    boolean bool2 = x;
    if (i3 == -1) {
      i1 = 1;
    } else {
      i1 = 0;
    }
    paramInt = i2;
    if ((bool2 ^ true) == i1) {
      paramInt = 1;
    }
    if (!bool1)
    {
      if (paramInt != 0) {
        i1 = ((f)localObject).i();
      } else {
        i1 = ((f)localObject).getFocusableViewAfter();
      }
      paramU = findViewByPosition(i1);
      if ((paramU != null) && (paramU != paramView)) {
        return paramU;
      }
    }
    if (preferLastSpan(i3))
    {
      i1 = f - 1;
      while (i1 >= 0)
      {
        if (i1 != i)
        {
          if (paramInt != 0) {
            i2 = b[i1].i();
          } else {
            i2 = b[i1].getFocusableViewAfter();
          }
          paramU = findViewByPosition(i2);
          if ((paramU != null) && (paramU != paramView)) {
            return paramU;
          }
        }
        i1 -= 1;
      }
      return null;
    }
    int i1 = 0;
    while (i1 < f)
    {
      if (paramInt != 0) {
        i2 = b[i1].i();
      } else {
        i2 = b[i1].getFocusableViewAfter();
      }
      paramU = findViewByPosition(i2);
      if ((paramU != null) && (paramU != paramView)) {
        return paramU;
      }
      i1 += 1;
    }
    return null;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    if (getChildCount() > 0)
    {
      View localView1 = findFirstVisibleItemClosestToStart(false);
      View localView2 = findFirstVisibleItemClosestToEnd(false);
      if (localView1 != null)
      {
        if (localView2 == null) {
          return;
        }
        int i1 = getPosition(localView1);
        int i2 = getPosition(localView2);
        if (i1 < i2)
        {
          paramAccessibilityEvent.setFromIndex(i1);
          paramAccessibilityEvent.setToIndex(i2);
          return;
        }
        paramAccessibilityEvent.setFromIndex(i2);
        paramAccessibilityEvent.setToIndex(i1);
      }
    }
  }
  
  public void onInitializeAccessibilityNodeInfoForItem(RecyclerView.u paramU, RecyclerView.y paramY, View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
    paramU = paramView.getLayoutParams();
    if (!(paramU instanceof c))
    {
      super.onInitializeAccessibilityNodeInfoForItem(paramView, paramAccessibilityNodeInfoCompat);
      return;
    }
    paramU = (c)paramU;
    int i1;
    if (mOrientation == 0)
    {
      i2 = paramU.b();
      if (f) {
        i1 = f;
      } else {
        i1 = 1;
      }
      paramAccessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(i2, i1, -1, -1, f, false));
      return;
    }
    int i2 = paramU.b();
    if (f) {
      i1 = f;
    } else {
      i1 = 1;
    }
    paramAccessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(-1, -1, i2, i1, f, false));
  }
  
  public void onItemsAdded(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    handleUpdate(paramInt1, paramInt2, 1);
  }
  
  public void onItemsChanged(RecyclerView paramRecyclerView)
  {
    d.clear();
    requestLayout();
  }
  
  public void onItemsMoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3)
  {
    handleUpdate(paramInt1, paramInt2, 8);
  }
  
  public void onItemsRemoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    handleUpdate(paramInt1, paramInt2, 2);
  }
  
  public void onItemsUpdated(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject)
  {
    handleUpdate(paramInt1, paramInt2, 4);
  }
  
  public void onLayoutChildren(RecyclerView.u paramU, RecyclerView.y paramY)
  {
    a(paramU, paramY, true);
  }
  
  public void onLayoutChildren(RecyclerView.y paramY)
  {
    super.onLayoutChildren(paramY);
    j = -1;
    e = Integer.MIN_VALUE;
    g = null;
    m.reset();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if ((paramParcelable instanceof e))
    {
      g = ((e)paramParcelable);
      requestLayout();
    }
  }
  
  public void onScrollStateChanged(int paramInt)
  {
    if (paramInt == 0) {
      b();
    }
  }
  
  public final boolean preferLastSpan(int paramInt)
  {
    int i1;
    if (mOrientation == 0)
    {
      if (paramInt == -1) {
        i1 = 1;
      } else {
        i1 = 0;
      }
      return i1 != c;
    }
    if (paramInt == -1) {
      i1 = 1;
    } else {
      i1 = 0;
    }
    if (i1 == c) {
      i1 = 1;
    } else {
      i1 = 0;
    }
    return i1 == isLayoutRTL();
  }
  
  public void recycle(RecyclerView.y paramY, b paramB)
  {
    if (b(paramY, paramB)) {
      return;
    }
    updateAnchorFromChildren(paramY, paramB);
  }
  
  public final void repositionToWrapContentIfNecessary()
  {
    Object localObject1 = i;
    StaggeredGridLayoutManager localStaggeredGridLayoutManager = this;
    if (((OrientationHelper)localObject1).getMode() == 1073741824) {
      return;
    }
    float f1 = 0.0F;
    int i3 = localStaggeredGridLayoutManager.getChildCount();
    int i1 = 0;
    while (i1 < i3)
    {
      localObject1 = localStaggeredGridLayoutManager.getChildAt(i1);
      localObject2 = i;
      float f2 = ((OrientationHelper)localObject2).getDecoratedMeasurement((View)localObject1);
      if (f2 >= f1)
      {
        ((c)((View)localObject1).getLayoutParams()).isLayoutRTL();
        f1 = Math.max(f1, f2);
      }
      i1 += 1;
    }
    int i4 = mSizePerSpan;
    int i2 = Math.round(f * f1);
    i1 = i2;
    Object localObject2 = i;
    localObject1 = localStaggeredGridLayoutManager;
    if (((OrientationHelper)localObject2).getMode() == Integer.MIN_VALUE) {
      i1 = Math.min(i2, i.getTotalSpace());
    }
    localStaggeredGridLayoutManager.updateMeasureSpecs(i1);
    if (mSizePerSpan == i4) {
      return;
    }
    i1 = 0;
    while (i1 < i3)
    {
      localObject1 = localStaggeredGridLayoutManager.getChildAt(i1);
      localObject2 = (c)((View)localObject1).getLayoutParams();
      if (!f)
      {
        int i5;
        if ((localStaggeredGridLayoutManager.isLayoutRTL()) && (mOrientation == 1))
        {
          i2 = f;
          i5 = b.i;
          ((View)localObject1).offsetLeftAndRight(-(i2 - 1 - i5) * mSizePerSpan - -(i2 - 1 - i5) * i4);
        }
        else
        {
          i5 = b.i;
          i2 = mSizePerSpan * i5;
          i5 *= i4;
          if (mOrientation == 1) {
            ((View)localObject1).offsetLeftAndRight(i2 - i5);
          } else {
            ((View)localObject1).offsetTopAndBottom(i2 - i5);
          }
        }
      }
      i1 += 1;
    }
  }
  
  public final void resolveShouldLayoutReverse()
  {
    if ((mOrientation != 1) && (isLayoutRTL()))
    {
      c = (x ^ true);
      return;
    }
    c = x;
  }
  
  public int scrollBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    if (getChildCount() != 0)
    {
      if (paramInt == 0) {
        return 0;
      }
      b(paramInt, paramY);
      int i2 = a(paramU, h, paramY);
      int i1;
      if (h.x < i2)
      {
        i1 = paramInt;
      }
      else
      {
        i1 = i2;
        if (paramInt < 0) {
          i1 = -i2;
        }
      }
      a.offsetChildren(-i1);
      p = c;
      paramY = h;
      x = 0;
      b(paramU, paramY);
      return i1;
    }
    return 0;
  }
  
  public int scrollHorizontallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    return scrollBy(paramInt, paramU, paramY);
  }
  
  public int scrollVerticallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
  {
    return scrollBy(paramInt, paramU, paramY);
  }
  
  public void setMeasuredDimension(Rect paramRect, int paramInt1, int paramInt2)
  {
    int i1 = getPaddingLeft() + getPaddingRight();
    int i2 = getPaddingTop() + getPaddingBottom();
    if (mOrientation == 1)
    {
      paramInt2 = RecyclerView.o.chooseSize(paramInt2, paramRect.height() + i2, getMinimumHeight());
      paramInt1 = RecyclerView.o.chooseSize(paramInt1, mSizePerSpan * f + i1, getMinimumWidth());
    }
    else
    {
      paramInt1 = RecyclerView.o.chooseSize(paramInt1, paramRect.width() + i1, getMinimumWidth());
      paramInt2 = RecyclerView.o.chooseSize(paramInt2, mSizePerSpan * f + i2, getMinimumHeight());
    }
    setMeasuredDimension(paramInt1, paramInt2);
  }
  
  public void setOrientation(int paramInt)
  {
    if ((paramInt != 0) && (paramInt != 1)) {
      throw new IllegalArgumentException("invalid orientation.");
    }
    assertNotInLayoutOrScroll(null);
    if (paramInt == mOrientation) {
      return;
    }
    mOrientation = paramInt;
    OrientationHelper localOrientationHelper = a;
    a = i;
    i = localOrientationHelper;
    requestLayout();
  }
  
  public void setOrientation(boolean paramBoolean)
  {
    assertNotInLayoutOrScroll(null);
    e localE = g;
    if ((localE != null) && (e != paramBoolean)) {
      e = paramBoolean;
    }
    x = paramBoolean;
    requestLayout();
  }
  
  public boolean setOrientation()
  {
    return t != 0;
  }
  
  public void setSpanCount(int paramInt)
  {
    assertNotInLayoutOrScroll(null);
    if (paramInt != f)
    {
      invalidateSpanAssignments();
      f = paramInt;
      v = new BitSet(f);
      b = new f[f];
      paramInt = 0;
      while (paramInt < f)
      {
        b[paramInt] = new f(paramInt);
        paramInt += 1;
      }
      requestLayout();
    }
  }
  
  public boolean supportsPredictiveItemAnimations()
  {
    return g == null;
  }
  
  public final boolean updateAnchorFromChildren(RecyclerView.y paramY, b paramB)
  {
    int i1;
    if (p) {
      i1 = findLastReferenceChildPosition(paramY.getItemCount());
    } else {
      i1 = findFirstReferenceChildPosition(paramY.getItemCount());
    }
    j = i1;
    a = Integer.MIN_VALUE;
    return true;
  }
  
  public void updateMeasureSpecs(int paramInt)
  {
    mSizePerSpan = (paramInt / f);
    mFullSizeSpec = View.MeasureSpec.makeMeasureSpec(paramInt, i.getMode());
  }
  
  public final int updateSpecWithExtra(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt2 == 0) && (paramInt3 == 0)) {
      return paramInt1;
    }
    int i1 = View.MeasureSpec.getMode(paramInt1);
    if ((i1 != Integer.MIN_VALUE) && (i1 != 1073741824)) {
      return paramInt1;
    }
    return View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i1);
  }
  
  public void visitMaxs(int paramInt)
  {
    super.visitMaxs(paramInt);
    int i1 = 0;
    while (i1 < f)
    {
      b[i1].b(paramInt);
      i1 += 1;
    }
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    public void run()
    {
      b();
    }
  }
  
  public class b
  {
    public int a;
    public boolean c;
    public boolean g;
    public boolean i;
    public int j;
    public int[] z;
    
    public b()
    {
      reset();
    }
    
    public void a(StaggeredGridLayoutManager.f[] paramArrayOfF)
    {
      int m = paramArrayOfF.length;
      int[] arrayOfInt = z;
      if ((arrayOfInt == null) || (arrayOfInt.length < m)) {
        z = new int[b.length];
      }
      int k = 0;
      while (k < m)
      {
        z[k] = paramArrayOfF[k].get(Integer.MIN_VALUE);
        k += 1;
      }
    }
    
    public void b()
    {
      int k;
      if (c) {
        k = a.a();
      } else {
        k = a.get();
      }
      a = k;
    }
    
    public void b(int paramInt)
    {
      if (c)
      {
        a = (a.a() - paramInt);
        return;
      }
      a = (a.get() + paramInt);
    }
    
    public void reset()
    {
      j = -1;
      a = Integer.MIN_VALUE;
      c = false;
      i = false;
      g = false;
      int[] arrayOfInt = z;
      if (arrayOfInt != null) {
        Arrays.fill(arrayOfInt, -1);
      }
    }
  }
  
  public static class c
    extends RecyclerView.p
  {
    public StaggeredGridLayoutManager.f b;
    public boolean f;
    
    public c(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public c(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    public c(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public c(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
    
    public final int b()
    {
      StaggeredGridLayoutManager.f localF = b;
      if (localF == null) {
        return -1;
      }
      return i;
    }
    
    public boolean isLayoutRTL()
    {
      return false;
    }
  }
  
  public static class d
  {
    public int[] a;
    public List<a> c;
    
    public d() {}
    
    public a a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
    {
      Object localObject = c;
      if (localObject == null) {
        return null;
      }
      int j = ((List)localObject).size();
      int i = 0;
      while (i < j)
      {
        localObject = (a)c.get(i);
        int k = a;
        if (k >= paramInt2) {
          return null;
        }
        if (k >= paramInt1)
        {
          if ((paramInt3 == 0) || (d == paramInt3)) {
            break label109;
          }
          if ((paramBoolean) && (b)) {
            return localObject;
          }
        }
        i += 1;
      }
      return null;
      label109:
      return localObject;
    }
    
    public void a(int paramInt)
    {
      int[] arrayOfInt1 = a;
      if (arrayOfInt1 == null)
      {
        arrayOfInt1 = new int[Math.max(paramInt, 10) + 1];
        a = arrayOfInt1;
        Arrays.fill(arrayOfInt1, -1);
        return;
      }
      if (paramInt >= arrayOfInt1.length)
      {
        arrayOfInt1 = a;
        int[] arrayOfInt2 = new int[getStep(paramInt)];
        a = arrayOfInt2;
        System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, arrayOfInt1.length);
        arrayOfInt2 = a;
        Arrays.fill(arrayOfInt2, arrayOfInt1.length, arrayOfInt2.length, -1);
      }
    }
    
    public final void a(int paramInt1, int paramInt2)
    {
      Object localObject = c;
      if (localObject == null) {
        return;
      }
      int i = ((List)localObject).size() - 1;
      while (i >= 0)
      {
        localObject = (a)c.get(i);
        int j = a;
        if (j >= paramInt1) {
          a = (j + paramInt2);
        }
        i -= 1;
      }
    }
    
    public void a(a paramA)
    {
      if (c == null) {
        c = new ArrayList();
      }
      int j = c.size();
      int i = 0;
      while (i < j)
      {
        a localA = (a)c.get(i);
        if (a == a) {
          c.remove(i);
        }
        if (a >= a)
        {
          c.add(i, paramA);
          return;
        }
        i += 1;
      }
      c.add(paramA);
    }
    
    public int b(int paramInt)
    {
      List localList = c;
      if (localList != null)
      {
        int i = localList.size() - 1;
        while (i >= 0)
        {
          if (c.get(i)).a >= paramInt) {
            c.remove(i);
          }
          i -= 1;
        }
      }
      return clear(paramInt);
    }
    
    public final void b(int paramInt1, int paramInt2)
    {
      Object localObject = c;
      if (localObject == null) {
        return;
      }
      int i = ((List)localObject).size() - 1;
      while (i >= 0)
      {
        localObject = (a)c.get(i);
        int j = a;
        if (j >= paramInt1) {
          if (j < paramInt1 + paramInt2) {
            c.remove(i);
          } else {
            a = (j - paramInt2);
          }
        }
        i -= 1;
      }
    }
    
    public void b(int paramInt, StaggeredGridLayoutManager.f paramF)
    {
      a(paramInt);
      a[paramInt] = i;
    }
    
    public final int c(int paramInt)
    {
      if (c == null) {
        return -1;
      }
      a localA = d(paramInt);
      if (localA != null) {
        c.remove(localA);
      }
      int k = -1;
      int m = c.size();
      int i = 0;
      int j;
      for (;;)
      {
        j = k;
        if (i >= m) {
          break;
        }
        if (c.get(i)).a >= paramInt)
        {
          j = i;
          break;
        }
        i += 1;
      }
      if (j != -1)
      {
        localA = (a)c.get(j);
        c.remove(j);
        return a;
      }
      return -1;
    }
    
    public int clear(int paramInt)
    {
      int[] arrayOfInt = a;
      if (arrayOfInt == null) {
        return -1;
      }
      if (paramInt >= arrayOfInt.length) {
        return -1;
      }
      int i = c(paramInt);
      if (i == -1)
      {
        arrayOfInt = a;
        Arrays.fill(arrayOfInt, paramInt, arrayOfInt.length, -1);
        return a.length;
      }
      Arrays.fill(a, paramInt, i + 1, -1);
      return i + 1;
    }
    
    public void clear()
    {
      int[] arrayOfInt = a;
      if (arrayOfInt != null) {
        Arrays.fill(arrayOfInt, -1);
      }
      c = null;
    }
    
    public void close(int paramInt1, int paramInt2)
    {
      int[] arrayOfInt = a;
      if (arrayOfInt != null)
      {
        if (paramInt1 >= arrayOfInt.length) {
          return;
        }
        a(paramInt1 + paramInt2);
        arrayOfInt = a;
        System.arraycopy(arrayOfInt, paramInt1 + paramInt2, arrayOfInt, paramInt1, arrayOfInt.length - paramInt1 - paramInt2);
        arrayOfInt = a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - paramInt2, arrayOfInt.length, -1);
        b(paramInt1, paramInt2);
      }
    }
    
    public a d(int paramInt)
    {
      Object localObject = c;
      if (localObject == null) {
        return null;
      }
      int i = ((List)localObject).size() - 1;
      while (i >= 0)
      {
        localObject = (a)c.get(i);
        if (a == paramInt) {
          return localObject;
        }
        i -= 1;
      }
      return null;
    }
    
    public int get(int paramInt)
    {
      int[] arrayOfInt = a;
      if ((arrayOfInt != null) && (paramInt < arrayOfInt.length)) {
        return arrayOfInt[paramInt];
      }
      return -1;
    }
    
    public int getStep(int paramInt)
    {
      int i = a.length;
      while (i <= paramInt) {
        i *= 2;
      }
      return i;
    }
    
    public void set(int paramInt1, int paramInt2)
    {
      int[] arrayOfInt = a;
      if (arrayOfInt != null)
      {
        if (paramInt1 >= arrayOfInt.length) {
          return;
        }
        a(paramInt1 + paramInt2);
        arrayOfInt = a;
        System.arraycopy(arrayOfInt, paramInt1, arrayOfInt, paramInt1 + paramInt2, arrayOfInt.length - paramInt1 - paramInt2);
        Arrays.fill(a, paramInt1, paramInt1 + paramInt2, -1);
        a(paramInt1, paramInt2);
      }
    }
    
    public static class a
      implements Parcelable
    {
      public static final Parcelable.Creator<a> CREATOR = new a();
      public int a;
      public boolean b;
      public int[] c;
      public int d;
      
      public a() {}
      
      public a(Parcel paramParcel)
      {
        a = paramParcel.readInt();
        d = paramParcel.readInt();
        int i = paramParcel.readInt();
        boolean bool = true;
        if (i != 1) {
          bool = false;
        }
        b = bool;
        i = paramParcel.readInt();
        if (i > 0)
        {
          int[] arrayOfInt = new int[i];
          c = arrayOfInt;
          paramParcel.readIntArray(arrayOfInt);
        }
      }
      
      public int describeContents()
      {
        return 0;
      }
      
      public int get(int paramInt)
      {
        int[] arrayOfInt = c;
        if (arrayOfInt == null) {
          return 0;
        }
        return arrayOfInt[paramInt];
      }
      
      public String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("FullSpanItem{mPosition=");
        localStringBuilder.append(a);
        localStringBuilder.append(", mGapDir=");
        localStringBuilder.append(d);
        localStringBuilder.append(", mHasUnwantedGapAfter=");
        localStringBuilder.append(b);
        localStringBuilder.append(", mGapPerSpan=");
        localStringBuilder.append(Arrays.toString(c));
        localStringBuilder.append('}');
        return localStringBuilder.toString();
      }
      
      public void writeToParcel(Parcel paramParcel, int paramInt)
      {
        throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
      }
      
      public static final class a
        implements Parcelable.Creator<StaggeredGridLayoutManager.d.a>
      {
        public a() {}
        
        public StaggeredGridLayoutManager.d.a[] a(int paramInt)
        {
          return new StaggeredGridLayoutManager.d.a[paramInt];
        }
        
        public StaggeredGridLayoutManager.d.a readDate(Parcel paramParcel)
        {
          return new StaggeredGridLayoutManager.d.a(paramParcel);
        }
      }
    }
  }
  
  public static class e
    implements Parcelable
  {
    public static final Parcelable.Creator<e> CREATOR = new a();
    public int a;
    public int b;
    public int c;
    public int d;
    public boolean e;
    public int[] f;
    public boolean g;
    public boolean h;
    public int[] i;
    public List<StaggeredGridLayoutManager.d.a> x;
    
    public e() {}
    
    public e(Parcel paramParcel)
    {
      c = paramParcel.readInt();
      b = paramParcel.readInt();
      int j = paramParcel.readInt();
      d = j;
      int[] arrayOfInt;
      if (j > 0)
      {
        arrayOfInt = new int[j];
        f = arrayOfInt;
        paramParcel.readIntArray(arrayOfInt);
      }
      j = paramParcel.readInt();
      a = j;
      if (j > 0)
      {
        arrayOfInt = new int[j];
        i = arrayOfInt;
        paramParcel.readIntArray(arrayOfInt);
      }
      j = paramParcel.readInt();
      boolean bool2 = false;
      if (j == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      e = bool1;
      if (paramParcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      g = bool1;
      boolean bool1 = bool2;
      if (paramParcel.readInt() == 1) {
        bool1 = true;
      }
      h = bool1;
      x = paramParcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e paramE)
    {
      d = d;
      c = c;
      b = b;
      f = f;
      a = a;
      i = i;
      e = e;
      g = g;
      h = h;
      x = x;
    }
    
    public void a()
    {
      f = null;
      d = 0;
      a = 0;
      i = null;
      x = null;
    }
    
    public int describeContents()
    {
      return 0;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
    }
    
    public static final class a
      implements Parcelable.Creator<StaggeredGridLayoutManager.e>
    {
      public a() {}
      
      public StaggeredGridLayoutManager.e[] a(int paramInt)
      {
        return new StaggeredGridLayoutManager.e[paramInt];
      }
      
      public StaggeredGridLayoutManager.e readDate(Parcel paramParcel)
      {
        return new StaggeredGridLayoutManager.e(paramParcel);
      }
    }
  }
  
  public class f
  {
    public int a = Integer.MIN_VALUE;
    public int b = Integer.MIN_VALUE;
    public ArrayList<View> c = new ArrayList();
    public int d = 0;
    public final int i;
    
    public f(int paramInt)
    {
      i = paramInt;
    }
    
    public int a(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    {
      int n = a.get();
      int i1 = a.a();
      int j;
      if (paramInt2 > paramInt1) {
        j = 1;
      } else {
        j = -1;
      }
      while (paramInt1 != paramInt2)
      {
        View localView = (View)c.get(paramInt1);
        int i2 = a.getDecoratedStart(localView);
        int i3 = a.getDecoratedEnd(localView);
        int m = 0;
        int k;
        if (paramBoolean3 ? i2 <= i1 : i2 < i1) {
          k = 1;
        } else {
          k = 0;
        }
        if (paramBoolean3 ? i3 >= n : i3 > n) {
          m = 1;
        }
        if ((k != 0) && (m != 0)) {
          if ((paramBoolean1) && (paramBoolean2))
          {
            if ((i2 >= n) && (i3 <= i1)) {
              return getPosition(localView);
            }
          }
          else
          {
            if (paramBoolean2) {
              return getPosition(localView);
            }
            if ((i2 < n) || (i3 > i1)) {
              return getPosition(localView);
            }
          }
        }
        paramInt1 += j;
      }
      return -1;
    }
    
    public void a()
    {
      View localView = (View)c.remove(0);
      StaggeredGridLayoutManager.c localC = next(localView);
      b = null;
      if (c.size() == 0) {
        b = Integer.MIN_VALUE;
      }
      if ((localC.isItemRemoved()) || (localC.next())) {
        d -= a.getDecoratedMeasurement(localView);
      }
      a = Integer.MIN_VALUE;
    }
    
    public void a(int paramInt)
    {
      a = paramInt;
      b = paramInt;
    }
    
    public void a(View paramView)
    {
      StaggeredGridLayoutManager.c localC = next(paramView);
      b = this;
      c.add(0, paramView);
      a = Integer.MIN_VALUE;
      if (c.size() == 1) {
        b = Integer.MIN_VALUE;
      }
      if ((localC.isItemRemoved()) || (localC.next())) {
        d += a.getDecoratedMeasurement(paramView);
      }
    }
    
    public int add(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      return a(paramInt1, paramInt2, false, false, paramBoolean);
    }
    
    public View b(int paramInt1, int paramInt2)
    {
      View localView2 = null;
      View localView1 = null;
      StaggeredGridLayoutManager localStaggeredGridLayoutManager;
      if (paramInt2 == -1)
      {
        int j = c.size();
        paramInt2 = 0;
        while (paramInt2 < j)
        {
          localView2 = (View)c.get(paramInt2);
          localStaggeredGridLayoutManager = StaggeredGridLayoutManager.this;
          if ((x) && (localStaggeredGridLayoutManager.getPosition(localView2) <= paramInt1)) {
            break;
          }
          localStaggeredGridLayoutManager = StaggeredGridLayoutManager.this;
          if ((!x) && (localStaggeredGridLayoutManager.getPosition(localView2) >= paramInt1)) {
            return localView1;
          }
          if (!localView2.hasFocusable()) {
            break;
          }
          localView1 = localView2;
          paramInt2 += 1;
        }
        return localView1;
      }
      paramInt2 = c.size() - 1;
      localView1 = localView2;
      while (paramInt2 >= 0)
      {
        localView2 = (View)c.get(paramInt2);
        localStaggeredGridLayoutManager = StaggeredGridLayoutManager.this;
        if ((x) && (localStaggeredGridLayoutManager.getPosition(localView2) >= paramInt1)) {
          break;
        }
        localStaggeredGridLayoutManager = StaggeredGridLayoutManager.this;
        if ((!x) && (localStaggeredGridLayoutManager.getPosition(localView2) <= paramInt1)) {
          return localView1;
        }
        if (!localView2.hasFocusable()) {
          break;
        }
        localView1 = localView2;
        paramInt2 -= 1;
      }
      return localView1;
    }
    
    public void b()
    {
      int j = c.size();
      View localView = (View)c.remove(j - 1);
      StaggeredGridLayoutManager.c localC = next(localView);
      b = null;
      if ((localC.isItemRemoved()) || (localC.next())) {
        d -= a.getDecoratedMeasurement(localView);
      }
      if (j == 1) {
        a = Integer.MIN_VALUE;
      }
      b = Integer.MIN_VALUE;
    }
    
    public void b(int paramInt)
    {
      int j = a;
      if (j != Integer.MIN_VALUE) {
        a = (j + paramInt);
      }
      j = b;
      if (j != Integer.MIN_VALUE) {
        b = (j + paramInt);
      }
    }
    
    public void b(View paramView)
    {
      StaggeredGridLayoutManager.c localC = next(paramView);
      b = this;
      c.add(paramView);
      b = Integer.MIN_VALUE;
      if (c.size() == 1) {
        a = Integer.MIN_VALUE;
      }
      if ((localC.isItemRemoved()) || (localC.next())) {
        d += a.getDecoratedMeasurement(paramView);
      }
    }
    
    public void b(boolean paramBoolean, int paramInt)
    {
      int j;
      if (paramBoolean) {
        j = c(Integer.MIN_VALUE);
      } else {
        j = get(Integer.MIN_VALUE);
      }
      close();
      if (j == Integer.MIN_VALUE) {
        return;
      }
      if ((!paramBoolean) || (j >= a.a()))
      {
        if ((!paramBoolean) && (j > a.get())) {
          return;
        }
        int k = j;
        if (paramInt != Integer.MIN_VALUE) {
          k = j + paramInt;
        }
        b = k;
        a = k;
      }
    }
    
    public int c()
    {
      int j = a;
      if (j != Integer.MIN_VALUE) {
        return j;
      }
      d();
      return a;
    }
    
    public int c(int paramInt)
    {
      int j = b;
      if (j != Integer.MIN_VALUE) {
        return j;
      }
      if (c.size() == 0) {
        return paramInt;
      }
      e();
      return b;
    }
    
    public void close()
    {
      c.clear();
      getInputs();
      d = 0;
    }
    
    public void d()
    {
      Object localObject = (View)c.get(0);
      StaggeredGridLayoutManager.c localC = next((View)localObject);
      a = a.getDecoratedStart((View)localObject);
      if (f)
      {
        localObject = d.d(localC.getViewLayoutPosition());
        if ((localObject != null) && (d == -1)) {
          a -= ((StaggeredGridLayoutManager.d.a)localObject).get(i);
        }
      }
    }
    
    public void e()
    {
      Object localObject = c;
      localObject = (View)((ArrayList)localObject).get(((ArrayList)localObject).size() - 1);
      StaggeredGridLayoutManager.c localC = next((View)localObject);
      b = a.getDecoratedEnd((View)localObject);
      if (f)
      {
        localObject = d.d(localC.getViewLayoutPosition());
        if ((localObject != null) && (d == 1)) {
          b += ((StaggeredGridLayoutManager.d.a)localObject).get(i);
        }
      }
    }
    
    public int get(int paramInt)
    {
      int j = a;
      if (j != Integer.MIN_VALUE) {
        return j;
      }
      if (c.size() == 0) {
        return paramInt;
      }
      d();
      return a;
    }
    
    public int getFocusableViewAfter()
    {
      if (x) {
        return add(0, c.size(), true);
      }
      return add(c.size() - 1, -1, true);
    }
    
    public void getInputs()
    {
      a = Integer.MIN_VALUE;
      b = Integer.MIN_VALUE;
    }
    
    public int i()
    {
      if (x) {
        return add(c.size() - 1, -1, true);
      }
      return add(0, c.size(), true);
    }
    
    public StaggeredGridLayoutManager.c next(View paramView)
    {
      return (StaggeredGridLayoutManager.c)paramView.getLayoutParams();
    }
    
    public int p()
    {
      int j = b;
      if (j != Integer.MIN_VALUE) {
        return j;
      }
      e();
      return b;
    }
    
    public int r()
    {
      return d;
    }
  }
}
