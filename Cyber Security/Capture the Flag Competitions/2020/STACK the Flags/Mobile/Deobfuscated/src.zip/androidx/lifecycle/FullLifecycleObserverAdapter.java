package androidx.lifecycle;

import org.util.MenuItem;
import org.util.Scope;
import org.util.d;
import org.util.h;

public class FullLifecycleObserverAdapter
  implements MenuItem
{
  public final h a;
  public final MenuItem b;
  
  public FullLifecycleObserverAdapter(h paramH, MenuItem paramMenuItem)
  {
    a = paramH;
    b = paramMenuItem;
  }
  
  public void b(d paramD, Scope paramScope)
  {
    switch (paramScope.ordinal())
    {
    default: 
      break;
    case 6: 
      throw new IllegalArgumentException("ON_ANY must not been send by anybody");
    case 5: 
      a.g(paramD);
      break;
    case 4: 
      a.f(paramD);
      break;
    case 3: 
      a.a(paramD);
      break;
    case 2: 
      a.e(paramD);
      break;
    case 1: 
      a.b(paramD);
      break;
    case 0: 
      a.c(paramD);
    }
    MenuItem localMenuItem = b;
    if (localMenuItem != null) {
      localMenuItem.b(paramD, paramScope);
    }
  }
}
