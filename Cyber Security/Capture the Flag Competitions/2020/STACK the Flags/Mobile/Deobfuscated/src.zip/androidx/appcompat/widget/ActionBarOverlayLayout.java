package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewPropertyAnimator;
import android.view.Window.Callback;
import android.view.WindowInsets;
import android.widget.OverScroller;
import org.core.asm.Label;
import org.core.view.Item;
import org.core.view.NestedScrollingParent;
import org.core.view.NestedScrollingParentHelper;
import org.core.view.ViewCompat;
import org.core.view.ViewParentCompat.ViewParentCompatImpl;
import org.core.view.b0.a;
import org.v7.R.attr;
import org.v7.R.id;
import org.v7.app.WindowDecorActionBar;
import org.v7.view.menu.l.a;
import org.v7.widget.DecorContentParent;
import org.v7.widget.DecorToolbar;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout
  extends ViewGroup
  implements DecorContentParent, NestedScrollingParent, ViewParentCompat.ViewParentCompatImpl
{
  public static final int[] ATTRS = { R.attr.actionBarSize, 16842841 };
  public final Rect ACTION_BAR_ANIMATE_DELAY = new Rect();
  public final AnimatorListenerAdapter cache;
  public Item left;
  public int mActionBarHeight;
  public ActionBarContainer mActionBarTop;
  public d mActionBarVisibilityCallback;
  public final Runnable mAddActionBarHideOffset;
  public boolean mAnimatingForFling;
  public final Rect mBaseContentInsets = new Rect();
  public final Rect mBaseInnerInsets = new Rect();
  public ContentFrameLayout mContent;
  public final Rect mContentInsets = new Rect();
  public ViewPropertyAnimator mCurrentActionBarTopAnimator;
  public DecorToolbar mDecorToolbar;
  public OverScroller mFlingEstimator;
  public boolean mHasNonEmbeddedTabs;
  public boolean mHideOnContentScroll;
  public int mHideOnContentScrollReference;
  public boolean mIgnoreWindowContentOverlay;
  public final Rect mInnerInsets = new Rect();
  public final Rect mLastBaseContentInsets = new Rect();
  public final Rect mLastInnerInsets = new Rect();
  public int mLastSystemUiVisibility;
  public boolean mOverlayMode;
  public final NestedScrollingParentHelper mParentHelper;
  public final Runnable mRemoveActionBarHideOffset;
  public Drawable mWindowContentOverlay;
  public int mWindowVisibility = 0;
  public Item right;
  public Item x;
  public Item y;
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramAttributeSet = Item.g;
    left = paramAttributeSet;
    right = paramAttributeSet;
    x = paramAttributeSet;
    y = paramAttributeSet;
    cache = new a();
    mRemoveActionBarHideOffset = new b();
    mAddActionBarHideOffset = new c();
    init(paramContext);
    mParentHelper = new NestedScrollingParentHelper();
  }
  
  public boolean a(View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    return (paramInt2 == 0) && (onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public final void addActionBarHideOffset()
  {
    haltActionBarHideOffsetAnimations();
    mAddActionBarHideOffset.run();
  }
  
  public final boolean applyInsets(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    boolean bool2 = false;
    paramView = (e)paramView.getLayoutParams();
    boolean bool1 = bool2;
    int i;
    int j;
    if (paramBoolean1)
    {
      i = leftMargin;
      j = left;
      bool1 = bool2;
      if (i != j)
      {
        bool1 = true;
        leftMargin = j;
      }
    }
    paramBoolean1 = bool1;
    if (paramBoolean2)
    {
      i = topMargin;
      j = top;
      paramBoolean1 = bool1;
      if (i != j)
      {
        paramBoolean1 = true;
        topMargin = j;
      }
    }
    paramBoolean2 = paramBoolean1;
    if (paramBoolean4)
    {
      i = rightMargin;
      j = right;
      paramBoolean2 = paramBoolean1;
      if (i != j)
      {
        paramBoolean2 = true;
        rightMargin = j;
      }
    }
    if (paramBoolean3)
    {
      i = bottomMargin;
      j = bottom;
      if (i != j)
      {
        bottomMargin = j;
        return true;
      }
    }
    return paramBoolean2;
  }
  
  public boolean canShowOverflowMenu()
  {
    pullChildren();
    return mDecorToolbar.canShowOverflowMenu();
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof e;
  }
  
  public void dismissPopups()
  {
    pullChildren();
    mDecorToolbar.dismissPopupMenus();
  }
  
  public e draw()
  {
    return new e(-1, -1);
  }
  
  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    if ((mWindowContentOverlay != null) && (!mIgnoreWindowContentOverlay))
    {
      int i;
      if (mActionBarTop.getVisibility() == 0) {
        i = (int)(mActionBarTop.getBottom() + mActionBarTop.getTranslationY() + 0.5F);
      } else {
        i = 0;
      }
      mWindowContentOverlay.setBounds(0, i, getWidth(), mWindowContentOverlay.getIntrinsicHeight() + i);
      mWindowContentOverlay.draw(paramCanvas);
    }
  }
  
  public boolean fitSystemWindows(Rect paramRect)
  {
    return super.fitSystemWindows(paramRect);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset()
  {
    ActionBarContainer localActionBarContainer = mActionBarTop;
    if (localActionBarContainer != null) {
      return -(int)localActionBarContainer.getTranslationY();
    }
    return 0;
  }
  
  public final DecorToolbar getDecorToolbar(View paramView)
  {
    if ((paramView instanceof DecorToolbar)) {
      return (DecorToolbar)paramView;
    }
    if ((paramView instanceof Toolbar)) {
      return ((Toolbar)paramView).getWrapper();
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Can't make a decor toolbar out of ");
    localStringBuilder.append(paramView.getClass().getSimpleName());
    throw new IllegalStateException(localStringBuilder.toString());
  }
  
  public int getNestedScrollAxes()
  {
    return mParentHelper.getNestedScrollAxes();
  }
  
  public CharSequence getTitle()
  {
    pullChildren();
    return mDecorToolbar.getTitle();
  }
  
  public void haltActionBarHideOffsetAnimations()
  {
    removeCallbacks(mRemoveActionBarHideOffset);
    removeCallbacks(mAddActionBarHideOffset);
    ViewPropertyAnimator localViewPropertyAnimator = mCurrentActionBarTopAnimator;
    if (localViewPropertyAnimator != null) {
      localViewPropertyAnimator.cancel();
    }
  }
  
  public boolean hideOverflowMenu()
  {
    pullChildren();
    return mDecorToolbar.hideOverflowMenu();
  }
  
  public e init(AttributeSet paramAttributeSet)
  {
    return new e(getContext(), paramAttributeSet);
  }
  
  public final void init(Context paramContext)
  {
    TypedArray localTypedArray = getContext().getTheme().obtainStyledAttributes(ATTRS);
    boolean bool2 = false;
    mActionBarHeight = localTypedArray.getDimensionPixelSize(0, 0);
    Drawable localDrawable = localTypedArray.getDrawable(1);
    mWindowContentOverlay = localDrawable;
    if (localDrawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    setWillNotDraw(bool1);
    localTypedArray.recycle();
    boolean bool1 = bool2;
    if (getApplicationInfotargetSdkVersion < 19) {
      bool1 = true;
    }
    mIgnoreWindowContentOverlay = bool1;
    mFlingEstimator = new OverScroller(paramContext);
  }
  
  public void initFeature(int paramInt)
  {
    pullChildren();
    if (paramInt != 2)
    {
      if (paramInt != 5)
      {
        if (paramInt != 109) {
          return;
        }
        setOverlayMode(true);
        return;
      }
      mDecorToolbar.initProgress();
      return;
    }
    mDecorToolbar.initIndeterminateProgress();
  }
  
  public boolean isInOverlayMode()
  {
    return mOverlayMode;
  }
  
  public boolean isOverflowMenuShowPending()
  {
    pullChildren();
    return mDecorToolbar.isOverflowMenuShowPending();
  }
  
  public boolean isOverflowMenuShowing()
  {
    pullChildren();
    return mDecorToolbar.isOverflowMenuShowing();
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets)
  {
    pullChildren();
    paramWindowInsets = Item.a(paramWindowInsets);
    Object localObject = new Rect(paramWindowInsets.getSystemWindowInsetLeft(), paramWindowInsets.getSystemWindowInsetTop(), paramWindowInsets.getSystemWindowInsetRight(), paramWindowInsets.getSystemWindowInsetBottom());
    boolean bool = applyInsets(mActionBarTop, (Rect)localObject, true, true, false, true);
    ViewCompat.a(this, paramWindowInsets, mBaseContentInsets);
    localObject = mBaseContentInsets;
    localObject = paramWindowInsets.a(left, top, right, bottom);
    left = ((Item)localObject);
    if (!right.equals(localObject))
    {
      bool = true;
      right = left;
    }
    if (!mLastBaseContentInsets.equals(mBaseContentInsets))
    {
      bool = true;
      mLastBaseContentInsets.set(mBaseContentInsets);
    }
    if (bool) {
      requestLayout();
    }
    return paramWindowInsets.b().c().a().unwrap();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    init(getContext());
    ViewCompat.requestApplyInsets(this);
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    haltActionBarHideOffsetAnimations();
  }
  
  public void onDraw(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    if (paramInt3 == 0) {
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfInt);
    }
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    paramInt1 = 0;
    while (paramInt1 < paramInt2)
    {
      View localView = getChildAt(paramInt1);
      if (localView.getVisibility() != 8)
      {
        e localE = (e)localView.getLayoutParams();
        int i = localView.getMeasuredWidth();
        int j = localView.getMeasuredHeight();
        int k = leftMargin + paramInt3;
        int m = topMargin + paramInt4;
        localView.layout(k, m, k + i, m + j);
      }
      paramInt1 += 1;
    }
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    pullChildren();
    int i = 0;
    measureChildWithMargins(mActionBarTop, paramInt1, 0, paramInt2, 0);
    Object localObject1 = (e)mActionBarTop.getLayoutParams();
    int i1 = Math.max(0, mActionBarTop.getMeasuredWidth() + leftMargin + rightMargin);
    int n = Math.max(0, mActionBarTop.getMeasuredHeight() + topMargin + bottomMargin);
    int m = View.combineMeasuredStates(0, mActionBarTop.getMeasuredState());
    if ((ViewCompat.getWindowSystemUiVisibility(this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    }
    if (j != 0)
    {
      k = mActionBarHeight;
      i = k;
      if (mHasNonEmbeddedTabs)
      {
        i = k;
        if (mActionBarTop.getTabContainer() != null) {
          i = k + mActionBarHeight;
        }
      }
    }
    else if (mActionBarTop.getVisibility() != 8)
    {
      i = mActionBarTop.getMeasuredHeight();
    }
    mContentInsets.set(mBaseContentInsets);
    localObject1 = left;
    x = ((Item)localObject1);
    Object localObject2;
    if ((!mOverlayMode) && (j == 0))
    {
      localObject2 = mContentInsets;
      top += i;
      bottom += 0;
      x = ((Item)localObject1).a(0, i, 0, 0);
    }
    else
    {
      localObject1 = Label.set(x.getSystemWindowInsetLeft(), x.getSystemWindowInsetTop() + i, x.getSystemWindowInsetRight(), x.getSystemWindowInsetBottom() + 0);
      localObject2 = new b0.a(x);
      ((b0.a)localObject2).b((Label)localObject1);
      x = ((b0.a)localObject2).b();
    }
    applyInsets(mContent, mContentInsets, true, true, true, true);
    if (!y.equals(x))
    {
      localObject1 = x;
      y = ((Item)localObject1);
      ViewCompat.dispatchApplyWindowInsets(mContent, (Item)localObject1);
    }
    measureChildWithMargins(mContent, paramInt1, 0, paramInt2, 0);
    localObject1 = (e)mContent.getLayoutParams();
    i = Math.max(i1, mContent.getMeasuredWidth() + leftMargin + rightMargin);
    int j = Math.max(n, mContent.getMeasuredHeight() + topMargin + bottomMargin);
    int k = View.combineMeasuredStates(m, mContent.getMeasuredState());
    m = getPaddingLeft();
    n = getPaddingRight();
    j = Math.max(j + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + (m + n), getSuggestedMinimumWidth()), paramInt1, k), View.resolveSizeAndState(j, paramInt2, k << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    if ((mHideOnContentScroll) && (paramBoolean))
    {
      if (shouldHideActionBarOnFling(paramFloat2)) {
        addActionBarHideOffset();
      } else {
        removeActionBarHideOffset();
      }
      mAnimatingForFling = true;
      return true;
    }
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2)
  {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt1 = mHideOnContentScrollReference + paramInt2;
    mHideOnContentScrollReference = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt)
  {
    performIntercept(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt)
  {
    mParentHelper.onNestedScrollAccepted(paramView1, paramView2, paramInt);
    mHideOnContentScrollReference = getActionBarHideOffset();
    haltActionBarHideOffsetAnimations();
    paramView1 = mActionBarVisibilityCallback;
    if (paramView1 != null) {
      ((WindowDecorActionBar)paramView1).onContentScrollStarted();
    }
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt)
  {
    if (((paramInt & 0x2) != 0) && (mActionBarTop.getVisibility() == 0)) {
      return mHideOnContentScroll;
    }
    return false;
  }
  
  public void onStopNestedScroll(View paramView)
  {
    if ((mHideOnContentScroll) && (!mAnimatingForFling)) {
      if (mHideOnContentScrollReference <= mActionBarTop.getHeight()) {
        postRemoveActionBarHideOffset();
      } else {
        postAddActionBarHideOffset();
      }
    }
    paramView = mActionBarVisibilityCallback;
    if (paramView != null) {
      ((WindowDecorActionBar)paramView).onContentScrollStopped();
    }
  }
  
  public void onWindowSystemUiVisibilityChanged(int paramInt)
  {
    super.onWindowSystemUiVisibilityChanged(paramInt);
    pullChildren();
    int k = mLastSystemUiVisibility;
    mLastSystemUiVisibility = paramInt;
    boolean bool = true;
    int i;
    if ((paramInt & 0x4) == 0) {
      i = 1;
    } else {
      i = 0;
    }
    int j;
    if ((paramInt & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    }
    d localD = mActionBarVisibilityCallback;
    if (localD != null)
    {
      if (j != 0) {
        bool = false;
      }
      ((WindowDecorActionBar)localD).enableContentAnimations(bool);
      if ((i == 0) && (j != 0)) {
        ((WindowDecorActionBar)mActionBarVisibilityCallback).hideForSystem();
      } else {
        ((WindowDecorActionBar)mActionBarVisibilityCallback).showForSystem();
      }
    }
    if ((((k ^ paramInt) & 0x100) != 0) && (mActionBarVisibilityCallback != null)) {
      ViewCompat.requestApplyInsets(this);
    }
  }
  
  public void onWindowVisibilityChanged(int paramInt)
  {
    super.onWindowVisibilityChanged(paramInt);
    mWindowVisibility = paramInt;
    d localD = mActionBarVisibilityCallback;
    if (localD != null) {
      ((WindowDecorActionBar)localD).onWindowVisibilityChanged(paramInt);
    }
  }
  
  public void performIntercept(View paramView, int paramInt)
  {
    if (paramInt == 0) {
      onStopNestedScroll(paramView);
    }
  }
  
  public void performIntercept(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (paramInt5 == 0) {
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }
  
  public void performIntercept(View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      onNestedScrollAccepted(paramView1, paramView2, paramInt1);
    }
  }
  
  public final void postAddActionBarHideOffset()
  {
    haltActionBarHideOffsetAnimations();
    postDelayed(mAddActionBarHideOffset, 600L);
  }
  
  public final void postRemoveActionBarHideOffset()
  {
    haltActionBarHideOffsetAnimations();
    postDelayed(mRemoveActionBarHideOffset, 600L);
  }
  
  public void pullChildren()
  {
    if (mContent == null)
    {
      mContent = ((ContentFrameLayout)findViewById(R.id.action_bar_activity_content));
      mActionBarTop = ((ActionBarContainer)findViewById(R.id.action_bar_container));
      mDecorToolbar = getDecorToolbar(findViewById(R.id.action_bar));
    }
  }
  
  public final void removeActionBarHideOffset()
  {
    haltActionBarHideOffsetAnimations();
    mRemoveActionBarHideOffset.run();
  }
  
  public void setActionBarHideOffset(int paramInt)
  {
    haltActionBarHideOffsetAnimations();
    paramInt = Math.max(0, Math.min(paramInt, mActionBarTop.getHeight()));
    mActionBarTop.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramD)
  {
    mActionBarVisibilityCallback = paramD;
    if (getWindowToken() != null)
    {
      paramD = mActionBarVisibilityCallback;
      int i = mWindowVisibility;
      ((WindowDecorActionBar)paramD).onWindowVisibilityChanged(i);
      if (mLastSystemUiVisibility != 0)
      {
        onWindowSystemUiVisibilityChanged(mLastSystemUiVisibility);
        ViewCompat.requestApplyInsets(this);
      }
    }
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean)
  {
    mHasNonEmbeddedTabs = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean)
  {
    if (paramBoolean != mHideOnContentScroll)
    {
      mHideOnContentScroll = paramBoolean;
      if (!paramBoolean)
      {
        haltActionBarHideOffsetAnimations();
        setActionBarHideOffset(0);
      }
    }
  }
  
  public void setIcon(int paramInt)
  {
    pullChildren();
    mDecorToolbar.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable)
  {
    pullChildren();
    mDecorToolbar.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt)
  {
    pullChildren();
    mDecorToolbar.setLogo(paramInt);
  }
  
  public void setMenu(Menu paramMenu, l.a paramA)
  {
    pullChildren();
    mDecorToolbar.setMenu(paramMenu, paramA);
  }
  
  public void setMenuPrepared()
  {
    pullChildren();
    mDecorToolbar.setMenuPrepared();
  }
  
  public void setOverlayMode(boolean paramBoolean)
  {
    mOverlayMode = paramBoolean;
    if ((paramBoolean) && (getContextgetApplicationInfotargetSdkVersion < 19)) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    }
    mIgnoreWindowContentOverlay = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback)
  {
    pullChildren();
    mDecorToolbar.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence)
  {
    pullChildren();
    mDecorToolbar.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return false;
  }
  
  public final boolean shouldHideActionBarOnFling(float paramFloat)
  {
    mFlingEstimator.fling(0, 0, 0, (int)paramFloat, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
    return mFlingEstimator.getFinalY() > mActionBarTop.getHeight();
  }
  
  public boolean showOverflowMenu()
  {
    pullChildren();
    return mDecorToolbar.showOverflowMenu();
  }
  
  public class a
    extends AnimatorListenerAdapter
  {
    public a() {}
    
    public void onAnimationCancel(Animator paramAnimator)
    {
      paramAnimator = ActionBarOverlayLayout.this;
      mCurrentActionBarTopAnimator = null;
      mAnimatingForFling = false;
    }
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      paramAnimator = ActionBarOverlayLayout.this;
      mCurrentActionBarTopAnimator = null;
      mAnimatingForFling = false;
    }
  }
  
  public class b
    implements Runnable
  {
    public b() {}
    
    public void run()
    {
      haltActionBarHideOffsetAnimations();
      ActionBarOverlayLayout localActionBarOverlayLayout = ActionBarOverlayLayout.this;
      mCurrentActionBarTopAnimator = mActionBarTop.animate().translationY(0.0F).setListener(cache);
    }
  }
  
  public class c
    implements Runnable
  {
    public c() {}
    
    public void run()
    {
      haltActionBarHideOffsetAnimations();
      ActionBarOverlayLayout localActionBarOverlayLayout = ActionBarOverlayLayout.this;
      mCurrentActionBarTopAnimator = mActionBarTop.animate().translationY(-mActionBarTop.getHeight()).setListener(cache);
    }
  }
  
  public static abstract interface d {}
  
  public static class e
    extends ViewGroup.MarginLayoutParams
  {
    public e(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public e(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    public e(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
  }
}
