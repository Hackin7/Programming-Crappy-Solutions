package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import org.jdom.Attribute;
import org.jdom.ByteVector;
import org.jdom.CharSequence;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl
  implements Parcelable
{
  public static final Parcelable.Creator<ParcelImpl> CREATOR = new a();
  public final CharSequence mName;
  
  public ParcelImpl(Parcel paramParcel)
  {
    mName = new ByteVector(paramParcel).getName();
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    new ByteVector(paramParcel).d(mName);
  }
  
  public static final class a
    implements Parcelable.Creator<ParcelImpl>
  {
    public a() {}
    
    public ParcelImpl[] a(int paramInt)
    {
      return new ParcelImpl[paramInt];
    }
    
    public ParcelImpl readDate(Parcel paramParcel)
    {
      return new ParcelImpl(paramParcel);
    }
  }
}
