package androidx.recyclerview.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.core.view.NestedScrollingChild;
import org.core.view.NestedScrollingChildHelper;
import org.core.view.ViewCompat;
import org.core.view.tree.AccessibilityEventCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat.CollectionInfoCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat.CollectionItemInfoCompat;
import org.objectweb.ChartData;
import org.objectweb.IpAddress;
import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.AnnotationWriter;
import org.objectweb.asm.ByteVector;
import org.objectweb.asm.ChildHelper;
import org.objectweb.asm.DefaultItemAnimator;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.RecyclerViewAccessibilityDelegate;
import org.objectweb.asm.b;
import org.objectweb.asm.f;
import org.objectweb.asm.g;
import org.objectweb.asm.i;

public class RecyclerView
  extends ViewGroup
  implements NestedScrollingChild
{
  public static final boolean ALLOW_SIZE_IN_UNSPECIFIED_SPEC;
  public static final Class<?>[] LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE;
  public static final int[] SearchView = { 16843830 };
  public static final int[] Spinner = { 16842987 };
  public static final boolean mHasStableIds;
  public static final Interpolator mInterpolator = new c();
  public static final boolean mScale;
  public static final boolean mWidth;
  public static final boolean this$0;
  public float TAG;
  public k args;
  public i d;
  public int f;
  public v i;
  public final int[] itemView;
  public final List<b0> m;
  public RecyclerViewAccessibilityDelegate mAccessibilityDelegate;
  public final AccessibilityManager mAccessibilityManager;
  public r mActiveOnItemTouchListener;
  public g mAdapter;
  public ByteVector mAdapterHelper;
  public boolean mAdapterUpdateDuringMeasure;
  public EdgeEffect mBottomGlow;
  public j mChildDrawingOrderCallback;
  public ChildHelper mChildHelper;
  public boolean mClipToPadding;
  public boolean mDataSetHasChangedAfterLayout;
  public boolean mDirection;
  public int mEatRequestLayout;
  public int mEatenAccessibilityChangeFlags;
  public boolean mFirstLayoutComplete;
  public boolean mHasFixedSize;
  public boolean mIgnoreMotionEventTillDown;
  public int mInitialTouchX;
  public int mInitialTouchY;
  public final Rect mInsets;
  public boolean mIsAttached;
  public l mItemAnimator;
  public RecyclerView.l.b mItemAnimatorListener;
  public Runnable mItemAnimatorRunner;
  public final ArrayList<n> mItemDecorations;
  public boolean mItemsAddedOrRemoved;
  public boolean mItemsChanged;
  public int mLastTouchX;
  public int mLastTouchY;
  public o mLayout;
  public boolean mLayoutFrozen;
  public int mLayoutOrScrollCounter;
  public boolean mLayoutRequestEaten;
  public EdgeEffect mLeftGlow;
  public final int mMaxFlingVelocity;
  public final int mMinFlingVelocity;
  public final int[] mMinMaxLayoutPositions;
  public final int[] mNestedOffsets;
  public final w mObserver = new w();
  public final ArrayList<r> mOnItemTouchListeners;
  public x mPendingSavedState;
  public final RectF mPosition;
  public boolean mPostedAnimatorRunner;
  public final u mRecycler = new u();
  public q mRecyclerListener;
  public EdgeEffect mRightGlow;
  public boolean mRunningLayoutOrScroll;
  public final int[] mScrollConsumed;
  public float mScrollFactor;
  public s mScrollListener;
  public List<s> mScrollListeners;
  public final int[] mScrollOffset;
  public int mScrollPointerId;
  public int mScrollState;
  public NestedScrollingChildHelper mScrollingChildHelper;
  public boolean mShowDefault;
  public final y mState;
  public final Rect mTempRect;
  public EdgeEffect mTopGlow;
  public int mTouchSlop;
  public VelocityTracker mVelocityTracker;
  public final a0 mViewFlinger;
  public final MethodVisitor mViewInfoProcessCallback;
  public final f mViewInfoStore = new f();
  public b q;
  
  static
  {
    int j = Build.VERSION.SDK_INT;
    mHasStableIds = false;
    boolean bool;
    if (j >= 23) {
      bool = true;
    } else {
      bool = false;
    }
    ALLOW_SIZE_IN_UNSPECIFIED_SPEC = bool;
    this$0 = true;
    mWidth = false;
    mScale = false;
    Class localClass = Integer.TYPE;
    LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE = new Class[] { Context.class, AttributeSet.class, localClass, localClass };
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    new a();
    mTempRect = new Rect();
    mInsets = new Rect();
    mPosition = new RectF();
    mItemDecorations = new ArrayList();
    mOnItemTouchListeners = new ArrayList();
    mEatRequestLayout = 0;
    mDataSetHasChangedAfterLayout = false;
    mRunningLayoutOrScroll = false;
    mLayoutOrScrollCounter = 0;
    f = 0;
    args = new k();
    mItemAnimator = new DefaultItemAnimator();
    mScrollState = 0;
    mScrollPointerId = -1;
    TAG = Float.MIN_VALUE;
    mScrollFactor = Float.MIN_VALUE;
    mDirection = true;
    mViewFlinger = new a0();
    if (this$0) {
      localObject = new i();
    } else {
      localObject = null;
    }
    d = ((i)localObject);
    mState = new y();
    mItemsAddedOrRemoved = false;
    mItemsChanged = false;
    mItemAnimatorListener = new m();
    mPostedAnimatorRunner = false;
    mMinMaxLayoutPositions = new int[2];
    mScrollOffset = new int[2];
    mScrollConsumed = new int[2];
    mNestedOffsets = new int[2];
    itemView = new int[2];
    m = new ArrayList();
    mItemAnimatorRunner = new b();
    mViewInfoProcessCallback = new d();
    if (paramAttributeSet != null)
    {
      localObject = paramContext.obtainStyledAttributes(paramAttributeSet, Spinner, paramInt, 0);
      mClipToPadding = ((TypedArray)localObject).getBoolean(0, true);
      ((TypedArray)localObject).recycle();
    }
    else
    {
      mClipToPadding = true;
    }
    setScrollContainer(true);
    setFocusableInTouchMode(true);
    Object localObject = ViewConfiguration.get(paramContext);
    mTouchSlop = ((ViewConfiguration)localObject).getScaledTouchSlop();
    TAG = org.core.view.ClassWriter.a((ViewConfiguration)localObject, paramContext);
    mScrollFactor = org.core.view.ClassWriter.init((ViewConfiguration)localObject, paramContext);
    mMinFlingVelocity = ((ViewConfiguration)localObject).getScaledMinimumFlingVelocity();
    mMaxFlingVelocity = ((ViewConfiguration)localObject).getScaledMaximumFlingVelocity();
    if (getOverScrollMode() == 2) {
      bool = true;
    } else {
      bool = false;
    }
    setWillNotDraw(bool);
    mItemAnimator.setListener(mItemAnimatorListener);
    initAdapterManager();
    initChildrenHelper();
    smoothScrollBy();
    if (ViewCompat.getImportantForAccessibility(this) == 0) {
      ViewCompat.put(this, 1);
    }
    mAccessibilityManager = ((AccessibilityManager)getContext().getSystemService("accessibility"));
    setAccessibilityDelegateCompat(new RecyclerViewAccessibilityDelegate(this));
    boolean bool = true;
    if (paramAttributeSet != null)
    {
      localObject = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.RecyclerView, paramInt, 0);
      String str = ((TypedArray)localObject).getString(IpAddress.RecyclerView_layoutManager);
      if (((TypedArray)localObject).getInt(IpAddress.RecyclerView_android_descendantFocusability, -1) == -1) {
        setDescendantFocusability(262144);
      }
      bool = ((TypedArray)localObject).getBoolean(IpAddress.RecyclerView_fastScrollEnabled, false);
      mShowDefault = bool;
      if (bool) {
        init((StateListDrawable)((TypedArray)localObject).getDrawable(IpAddress.RecyclerView_fastScrollVerticalThumbDrawable), ((TypedArray)localObject).getDrawable(IpAddress.RecyclerView_fastScrollVerticalTrackDrawable), (StateListDrawable)((TypedArray)localObject).getDrawable(IpAddress.RecyclerView_fastScrollHorizontalThumbDrawable), ((TypedArray)localObject).getDrawable(IpAddress.RecyclerView_fastScrollHorizontalTrackDrawable));
      }
      ((TypedArray)localObject).recycle();
      createLayoutManager(paramContext, str, paramAttributeSet, paramInt, 0);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, SearchView, paramInt, 0);
      bool = paramContext.getBoolean(0, true);
      paramContext.recycle();
    }
    else
    {
      setDescendantFocusability(262144);
    }
    setNestedScrollingEnabled(bool);
  }
  
  public static RecyclerView a(View paramView)
  {
    if (!(paramView instanceof ViewGroup)) {
      return null;
    }
    if ((paramView instanceof RecyclerView)) {
      return (RecyclerView)paramView;
    }
    paramView = (ViewGroup)paramView;
    int k = paramView.getChildCount();
    int j = 0;
    while (j < k)
    {
      RecyclerView localRecyclerView = a(paramView.getChildAt(j));
      if (localRecyclerView != null) {
        return localRecyclerView;
      }
      j += 1;
    }
    return null;
  }
  
  public static b0 getChildViewHolderInt(View paramView)
  {
    if (paramView == null) {
      return null;
    }
    return getLayoutParamsmViewHolder;
  }
  
  private NestedScrollingChildHelper getScrollingChildHelper()
  {
    if (mScrollingChildHelper == null) {
      mScrollingChildHelper = new NestedScrollingChildHelper(this);
    }
    return mScrollingChildHelper;
  }
  
  public static void next(b0 paramB0)
  {
    Object localObject = l;
    if (localObject != null)
    {
      localObject = (View)((WeakReference)localObject).get();
      while (localObject != null)
      {
        if (localObject == itemView) {
          return;
        }
        localObject = ((View)localObject).getParent();
        if ((localObject instanceof View)) {
          localObject = (View)localObject;
        } else {
          localObject = null;
        }
      }
      l = null;
    }
  }
  
  public static void onLayoutChild(View paramView, Rect paramRect)
  {
    p localP = (p)paramView.getLayoutParams();
    Rect localRect = mDecorInsets;
    paramRect.set(paramView.getLeft() - left - leftMargin, paramView.getTop() - top - topMargin, paramView.getRight() + right + rightMargin, paramView.getBottom() + bottom + bottomMargin);
  }
  
  public void a()
  {
    int j = m.size() - 1;
    while (j >= 0)
    {
      b0 localB0 = (b0)m.get(j);
      if ((itemView.getParent() == this) && (!localB0.shouldIgnore()))
      {
        int k = f;
        if (k != -1)
        {
          ViewCompat.put(itemView, k);
          f = -1;
        }
      }
      j -= 1;
    }
    m.clear();
  }
  
  public boolean a(b0 paramB0, int paramInt)
  {
    if (isComputingLayout())
    {
      f = paramInt;
      m.add(paramB0);
      return false;
    }
    ViewCompat.put(itemView, paramInt);
    return true;
  }
  
  public void absorbGlows(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
    {
      ensureLeftGlow();
      mLeftGlow.onAbsorb(-paramInt1);
    }
    else if (paramInt1 > 0)
    {
      ensureRightGlow();
      mRightGlow.onAbsorb(paramInt1);
    }
    if (paramInt2 < 0)
    {
      ensureTopGlow();
      mTopGlow.onAbsorb(-paramInt2);
    }
    else if (paramInt2 > 0)
    {
      ensureBottomGlow();
      mBottomGlow.onAbsorb(paramInt2);
    }
    if ((paramInt1 != 0) || (paramInt2 != 0)) {
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public final void addAnimatingView(b0 paramB0)
  {
    View localView = itemView;
    int j;
    if (localView.getParent() == this) {
      j = 1;
    } else {
      j = 0;
    }
    mRecycler.unscrapView(getChildViewHolder(localView));
    if (paramB0.isTmpDetached())
    {
      mChildHelper.attachViewToParent(localView, -1, localView.getLayoutParams(), true);
      return;
    }
    if (j == 0)
    {
      mChildHelper.addView(localView, true);
      return;
    }
    mChildHelper.hide(localView);
  }
  
  public void addFocusables(ArrayList paramArrayList, int paramInt1, int paramInt2)
  {
    o localO = mLayout;
    if ((localO == null) || (!localO.onAddFocusables())) {
      super.addFocusables(paramArrayList, paramInt1, paramInt2);
    }
  }
  
  public void addItemDecoration(n paramN)
  {
    addItemDecoration(paramN, -1);
  }
  
  public void addItemDecoration(n paramN, int paramInt)
  {
    o localO = mLayout;
    if (localO != null) {
      localO.assertNotInLayoutOrScroll("Cannot add item decoration during a scroll  or layout");
    }
    if (mItemDecorations.isEmpty()) {
      setWillNotDraw(false);
    }
    if (paramInt < 0) {
      mItemDecorations.add(paramN);
    } else {
      mItemDecorations.add(paramInt, paramN);
    }
    markItemDecorInsetsDirty();
    requestLayout();
  }
  
  public void addItemDecoration(r paramR)
  {
    mOnItemTouchListeners.add(paramR);
  }
  
  public void addOnScrollListener(s paramS)
  {
    if (mScrollListeners == null) {
      mScrollListeners = new ArrayList();
    }
    mScrollListeners.add(paramS);
  }
  
  public final void animateChange(b0 paramB01, b0 paramB02, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2, boolean paramBoolean1, boolean paramBoolean2)
  {
    paramB01.setIsRecyclable(false);
    if (paramBoolean1) {
      addAnimatingView(paramB01);
    }
    if (paramB01 != paramB02)
    {
      if (paramBoolean2) {
        addAnimatingView(paramB02);
      }
      mShadowedHolder = paramB02;
      addAnimatingView(paramB01);
      mRecycler.unscrapView(paramB01);
      paramB02.setIsRecyclable(false);
      mShadowingHolder = paramB01;
    }
    if (mItemAnimator.animateChange(paramB01, paramB02, paramC1, paramC2)) {
      postAnimationRunner();
    }
  }
  
  public void animateChange(b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
  {
    paramB0.setIsRecyclable(false);
    if (mItemAnimator.animateChange(paramB0, paramC1, paramC2)) {
      postAnimationRunner();
    }
  }
  
  public void animateDisappearance(b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
  {
    addAnimatingView(paramB0);
    paramB0.setIsRecyclable(false);
    if (mItemAnimator.animateDisappearance(paramB0, paramC1, paramC2)) {
      postAnimationRunner();
    }
  }
  
  public String append()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(" ");
    localStringBuilder.append(super.toString());
    localStringBuilder.append(", adapter:");
    localStringBuilder.append(mAdapter);
    localStringBuilder.append(", layout:");
    localStringBuilder.append(mLayout);
    localStringBuilder.append(", context:");
    localStringBuilder.append(getContext());
    return localStringBuilder.toString();
  }
  
  public final boolean arrowScroll(View paramView1, View paramView2, int paramInt)
  {
    if (paramView2 != null)
    {
      if (paramView2 == this) {
        return false;
      }
      if (findContainingItemView(paramView2) == null) {
        return false;
      }
      if (paramView1 == null) {
        return true;
      }
      if (findContainingItemView(paramView1) == null) {
        return true;
      }
      mTempRect.set(0, 0, paramView1.getWidth(), paramView1.getHeight());
      mInsets.set(0, 0, paramView2.getWidth(), paramView2.getHeight());
      offsetDescendantRectToMyCoords(paramView1, mTempRect);
      offsetDescendantRectToMyCoords(paramView2, mInsets);
      int n;
      if (mLayout.getLayoutDirection() == 1) {
        n = -1;
      } else {
        n = 1;
      }
      int k = 0;
      paramView1 = mTempRect;
      int j = left;
      int i1 = mInsets.left;
      if (((j < i1) || (right <= i1)) && (mTempRect.right < mInsets.right))
      {
        j = 1;
      }
      else
      {
        paramView1 = mTempRect;
        j = right;
        i1 = mInsets.right;
        if (j <= i1)
        {
          j = k;
          if (left < i1) {}
        }
        else
        {
          j = k;
          if (mTempRect.left > mInsets.left) {
            j = -1;
          }
        }
      }
      i1 = 0;
      paramView1 = mTempRect;
      k = top;
      int i2 = mInsets.top;
      if (((k < i2) || (bottom <= i2)) && (mTempRect.bottom < mInsets.bottom))
      {
        k = 1;
      }
      else
      {
        paramView1 = mTempRect;
        k = bottom;
        i2 = mInsets.bottom;
        if (k <= i2)
        {
          k = i1;
          if (top < i2) {}
        }
        else
        {
          k = i1;
          if (mTempRect.top > mInsets.top) {
            k = -1;
          }
        }
      }
      if (paramInt != 1)
      {
        if (paramInt != 2)
        {
          if (paramInt != 17)
          {
            if (paramInt != 33)
            {
              if (paramInt != 66)
              {
                if (paramInt == 130)
                {
                  if (k > 0) {
                    return true;
                  }
                }
                else
                {
                  paramView1 = new StringBuilder();
                  paramView1.append("Invalid direction: ");
                  paramView1.append(paramInt);
                  paramView1.append(append());
                  throw new IllegalArgumentException(paramView1.toString());
                }
              }
              else if (j > 0) {
                return true;
              }
            }
            else if (k < 0) {
              return true;
            }
          }
          else if (j < 0) {
            return true;
          }
        }
        else if ((k > 0) || ((k == 0) && (j * n >= 0))) {
          return true;
        }
      }
      else if ((k < 0) || ((k == 0) && (j * n <= 0))) {
        return true;
      }
    }
    return false;
  }
  
  public boolean canReuseUpdatedViewHolder(b0 paramB0)
  {
    l localL = mItemAnimator;
    return (localL == null) || (localL.canReuseUpdatedViewHolder(paramB0, paramB0.getUnmodifiedPayloads()));
  }
  
  public final void cancelTouch()
  {
    resetTouch();
    setScrollState(0);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return ((paramLayoutParams instanceof p)) && (mLayout.checkLayoutParams((p)paramLayoutParams));
  }
  
  public final int clear(View paramView)
  {
    int j = paramView.getId();
    while ((!paramView.isFocused()) && ((paramView instanceof ViewGroup)) && (paramView.hasFocus()))
    {
      View localView2 = ((ViewGroup)paramView).getFocusedChild();
      View localView1 = localView2;
      paramView = localView1;
      if (localView2.getId() != -1)
      {
        j = localView2.getId();
        paramView = localView1;
      }
    }
    return j;
  }
  
  public final void clear()
  {
    y localY = mState;
    id = -1L;
    progress = -1;
    progressBar = -1;
  }
  
  public void clearOldPositions()
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      if (!localB0.shouldIgnore()) {
        localB0.clearOldPosition();
      }
      j += 1;
    }
    mRecycler.clearOldPositions();
  }
  
  public int computeHorizontalScrollExtent()
  {
    o localO = mLayout;
    if (localO == null) {
      return 0;
    }
    if (localO.canScrollHorizontally()) {
      return mLayout.computeHorizontalScrollExtent(mState);
    }
    return 0;
  }
  
  public int computeHorizontalScrollOffset()
  {
    o localO = mLayout;
    if (localO == null) {
      return 0;
    }
    if (localO.canScrollHorizontally()) {
      return mLayout.computeHorizontalScrollOffset(mState);
    }
    return 0;
  }
  
  public int computeHorizontalScrollRange()
  {
    o localO = mLayout;
    if (localO == null) {
      return 0;
    }
    if (localO.canScrollHorizontally()) {
      return mLayout.computeHorizontalScrollRange(mState);
    }
    return 0;
  }
  
  public int computeVerticalScrollExtent()
  {
    o localO = mLayout;
    if (localO == null) {
      return 0;
    }
    if (localO.canScrollVertically()) {
      return mLayout.computeVerticalScrollExtent(mState);
    }
    return 0;
  }
  
  public int computeVerticalScrollOffset()
  {
    o localO = mLayout;
    if (localO == null) {
      return 0;
    }
    if (localO.canScrollVertically()) {
      return mLayout.computeVerticalScrollOffset(mState);
    }
    return 0;
  }
  
  public int computeVerticalScrollRange()
  {
    o localO = mLayout;
    if (localO == null) {
      return 0;
    }
    if (localO.canScrollVertically()) {
      return mLayout.computeVerticalScrollRange(mState);
    }
    return 0;
  }
  
  public void considerReleasingGlowsOnScroll(int paramInt1, int paramInt2)
  {
    boolean bool2 = false;
    EdgeEffect localEdgeEffect = mLeftGlow;
    boolean bool1 = bool2;
    if (localEdgeEffect != null)
    {
      bool1 = bool2;
      if (!localEdgeEffect.isFinished())
      {
        bool1 = bool2;
        if (paramInt1 > 0)
        {
          mLeftGlow.onRelease();
          bool1 = mLeftGlow.isFinished();
        }
      }
    }
    localEdgeEffect = mRightGlow;
    bool2 = bool1;
    if (localEdgeEffect != null)
    {
      bool2 = bool1;
      if (!localEdgeEffect.isFinished())
      {
        bool2 = bool1;
        if (paramInt1 < 0)
        {
          mRightGlow.onRelease();
          bool2 = bool1 | mRightGlow.isFinished();
        }
      }
    }
    localEdgeEffect = mTopGlow;
    bool1 = bool2;
    if (localEdgeEffect != null)
    {
      bool1 = bool2;
      if (!localEdgeEffect.isFinished())
      {
        bool1 = bool2;
        if (paramInt2 > 0)
        {
          mTopGlow.onRelease();
          bool1 = bool2 | mTopGlow.isFinished();
        }
      }
    }
    localEdgeEffect = mBottomGlow;
    bool2 = bool1;
    if (localEdgeEffect != null)
    {
      bool2 = bool1;
      if (!localEdgeEffect.isFinished())
      {
        bool2 = bool1;
        if (paramInt2 < 0)
        {
          mBottomGlow.onRelease();
          bool2 = bool1 | mBottomGlow.isFinished();
        }
      }
    }
    if (bool2) {
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public void consumePendingUpdateOperations()
  {
    if ((mFirstLayoutComplete) && (!mDataSetHasChangedAfterLayout))
    {
      if (!mAdapterHelper.add()) {
        return;
      }
      if ((mAdapterHelper.add(4)) && (!mAdapterHelper.add(11)))
      {
        org.core.models.RecyclerView.beginSection("RV PartialInvalidate");
        eatRequestLayout();
        onEnterLayoutOrScroll();
        mAdapterHelper.a();
        if (!mLayoutRequestEaten) {
          if (hasUpdatedView()) {
            dispatchLayout();
          } else {
            mAdapterHelper.d();
          }
        }
        resumeRequestLayout(true);
        resumeRequestLayout();
        org.core.models.RecyclerView.endSection();
        return;
      }
      if (mAdapterHelper.add())
      {
        org.core.models.RecyclerView.beginSection("RV FullInvalidate");
        dispatchLayout();
        org.core.models.RecyclerView.endSection();
      }
    }
    else
    {
      org.core.models.RecyclerView.beginSection("RV FullInvalidate");
      dispatchLayout();
      org.core.models.RecyclerView.endSection();
    }
  }
  
  public final void createLayoutManager(Context paramContext, String paramString, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    if (paramString != null)
    {
      paramString = paramString.trim();
      if (!paramString.isEmpty())
      {
        String str = getFullClassName(paramContext, paramString);
        try
        {
          boolean bool = isInEditMode();
          if (bool) {
            paramString = getClass().getClassLoader();
          } else {
            paramString = paramContext.getClassLoader();
          }
          Class localClass = paramString.loadClass(str).asSubclass(o.class);
          Object localObject = null;
          paramString = LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE;
          try
          {
            paramString = localClass.getConstructor(paramString);
            paramContext = new Object[] { paramContext, paramAttributeSet, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) };
          }
          catch (NoSuchMethodException paramContext) {}
          try
          {
            paramString = localClass.getConstructor(new Class[0]);
            paramContext = localObject;
            paramString.setAccessible(true);
            paramContext = paramString.newInstance(paramContext);
            paramContext = (o)paramContext;
            setLayoutManager(paramContext);
            return;
          }
          catch (NoSuchMethodException paramString)
          {
            paramString.initCause(paramContext);
            paramContext = new StringBuilder();
            paramContext.append(paramAttributeSet.getPositionDescription());
            paramContext.append(": Error creating LayoutManager ");
            paramContext.append(str);
            paramContext = new IllegalStateException(paramContext.toString(), paramString);
            throw paramContext;
          }
          return;
        }
        catch (ClassCastException paramContext)
        {
          paramString = new StringBuilder();
          paramString.append(paramAttributeSet.getPositionDescription());
          paramString.append(": Class is not a LayoutManager ");
          paramString.append(str);
          throw new IllegalStateException(paramString.toString(), paramContext);
        }
        catch (IllegalAccessException paramContext)
        {
          paramString = new StringBuilder();
          paramString.append(paramAttributeSet.getPositionDescription());
          paramString.append(": Cannot access non-public constructor ");
          paramString.append(str);
          throw new IllegalStateException(paramString.toString(), paramContext);
        }
        catch (InstantiationException paramContext)
        {
          paramString = new StringBuilder();
          paramString.append(paramAttributeSet.getPositionDescription());
          paramString.append(": Could not instantiate the LayoutManager: ");
          paramString.append(str);
          throw new IllegalStateException(paramString.toString(), paramContext);
        }
        catch (InvocationTargetException paramContext)
        {
          paramString = new StringBuilder();
          paramString.append(paramAttributeSet.getPositionDescription());
          paramString.append(": Could not instantiate the LayoutManager: ");
          paramString.append(str);
          throw new IllegalStateException(paramString.toString(), paramContext);
        }
        catch (ClassNotFoundException paramContext)
        {
          paramString = new StringBuilder();
          paramString.append(paramAttributeSet.getPositionDescription());
          paramString.append(": Unable to find LayoutManager ");
          paramString.append(str);
          throw new IllegalStateException(paramString.toString(), paramContext);
        }
      }
    }
  }
  
  public void defaultOnMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(o.chooseSize(paramInt1, getPaddingLeft() + getPaddingRight(), ViewCompat.getMinimumWidth(this)), o.chooseSize(paramInt2, getPaddingTop() + getPaddingBottom(), ViewCompat.getMinimumHeight(this)));
  }
  
  public final boolean didChildRangeChange(int paramInt1, int paramInt2)
  {
    findMinMaxChildLayoutPositions(mMinMaxLayoutPositions);
    int[] arrayOfInt = mMinMaxLayoutPositions;
    return (arrayOfInt[0] != paramInt1) || (arrayOfInt[1] != paramInt2);
  }
  
  public void dispatchChildDetached(View paramView)
  {
    paramView = getChildViewHolderInt(paramView);
    onChildDetachedFromWindow();
    g localG = mAdapter;
    if ((localG != null) && (paramView != null)) {
      localG.onViewDetachedFromWindow();
    }
  }
  
  public final void dispatchContentChangedIfNecessary()
  {
    int j = mEatenAccessibilityChangeFlags;
    mEatenAccessibilityChangeFlags = 0;
    if ((j != 0) && (isAccessibilityEnabled()))
    {
      AccessibilityEvent localAccessibilityEvent = AccessibilityEvent.obtain();
      localAccessibilityEvent.setEventType(2048);
      AccessibilityEventCompat.setContentChangeTypes(localAccessibilityEvent, j);
      sendAccessibilityEventUnchecked(localAccessibilityEvent);
    }
  }
  
  public void dispatchLayout()
  {
    if (mAdapter == null)
    {
      Log.e("RecyclerView", "No adapter attached; skipping layout");
      return;
    }
    if (mLayout == null)
    {
      Log.e("RecyclerView", "No layout manager attached; skipping layout");
      return;
    }
    y localY = mState;
    mIsMeasuring = false;
    if (mLayoutStep == 1)
    {
      dispatchLayoutStep1();
      mLayout.setExactMeasureSpecsFrom(this);
      dispatchLayoutStep2();
    }
    else if ((!mAdapterHelper.get()) && (mLayout.getWidth() == getWidth()) && (mLayout.getHeight() == getHeight()))
    {
      mLayout.setExactMeasureSpecsFrom(this);
    }
    else
    {
      mLayout.setExactMeasureSpecsFrom(this);
      dispatchLayoutStep2();
    }
    dispatchLayoutStep3();
  }
  
  public final void dispatchLayoutStep1()
  {
    Object localObject1 = mState;
    boolean bool = true;
    ((y)localObject1).assertLayoutStep(1);
    smoothScrollBy(mState);
    mState.mIsMeasuring = false;
    eatRequestLayout();
    mViewInfoStore.clear();
    onEnterLayoutOrScroll();
    processAdapterUpdatesAndSetAnimationFlags();
    onCreate();
    localObject1 = mState;
    if ((!mRunSimpleAnimations) || (!mItemsChanged)) {
      bool = false;
    }
    mTrackOldChangeHolders = bool;
    mItemsChanged = false;
    mItemsAddedOrRemoved = false;
    localObject1 = mState;
    mInPreLayout = mRunPredictiveAnimations;
    mItemCount = mAdapter.getItemCount();
    findMinMaxChildLayoutPositions(mMinMaxLayoutPositions);
    int j;
    Object localObject2;
    if (mState.mRunSimpleAnimations)
    {
      int k = mChildHelper.getChildCount();
      j = 0;
      while (j < k)
      {
        localObject1 = getChildViewHolderInt(mChildHelper.getChildAt(j));
        if ((!((b0)localObject1).shouldIgnore()) && ((!((b0)localObject1).isInvalid()) || (mAdapter.hasStableIds())))
        {
          localObject2 = mItemAnimator;
          l.buildAdapterChangeFlagsForAnimations((b0)localObject1);
          ((b0)localObject1).getUnmodifiedPayloads();
          localObject2 = ((l)localObject2).setFrom((b0)localObject1);
          mViewInfoStore.c((b0)localObject1, (RecyclerView.l.c)localObject2);
          if ((mState.mTrackOldChangeHolders) && (((b0)localObject1).isUpdated()) && (!((b0)localObject1).isRemoved()) && (!((b0)localObject1).shouldIgnore()) && (!((b0)localObject1).isInvalid()))
          {
            long l = getChangedHolderKey((b0)localObject1);
            mViewInfoStore.clear(l, (b0)localObject1);
          }
        }
        j += 1;
      }
    }
    if (mState.mRunPredictiveAnimations)
    {
      offsetPositionRecordsForInsert();
      localObject1 = mState;
      bool = mStructureChanged;
      mStructureChanged = false;
      mLayout.onLayoutChildren(mRecycler, (y)localObject1);
      mState.mStructureChanged = bool;
      j = 0;
      while (j < mChildHelper.getChildCount())
      {
        localObject1 = getChildViewHolderInt(mChildHelper.getChildAt(j));
        if ((!((b0)localObject1).shouldIgnore()) && (!mViewInfoStore.f((b0)localObject1)))
        {
          l.buildAdapterChangeFlagsForAnimations((b0)localObject1);
          bool = ((b0)localObject1).hasAnyOfTheFlags(8192);
          if (!bool) {}
          localObject2 = mItemAnimator;
          ((b0)localObject1).getUnmodifiedPayloads();
          localObject2 = ((l)localObject2).setFrom((b0)localObject1);
          if (bool) {
            recordAnimationInfoIfBouncedHiddenView((b0)localObject1, (RecyclerView.l.c)localObject2);
          } else {
            mViewInfoStore.b((b0)localObject1, (RecyclerView.l.c)localObject2);
          }
        }
        j += 1;
      }
      clearOldPositions();
    }
    else
    {
      clearOldPositions();
    }
    resumeRequestLayout();
    resumeRequestLayout(false);
    mState.mLayoutStep = 2;
  }
  
  public final void dispatchLayoutStep2()
  {
    eatRequestLayout();
    onEnterLayoutOrScroll();
    mState.assertLayoutStep(6);
    mAdapterHelper.b();
    mState.mItemCount = mAdapter.getItemCount();
    y localY = mState;
    mDeletedInvisibleItemCountSincePreviousLayout = 0;
    mInPreLayout = false;
    mLayout.onLayoutChildren(mRecycler, localY);
    localY = mState;
    mStructureChanged = false;
    mPendingSavedState = null;
    boolean bool;
    if ((mRunSimpleAnimations) && (mItemAnimator != null)) {
      bool = true;
    } else {
      bool = false;
    }
    mRunSimpleAnimations = bool;
    mState.mLayoutStep = 4;
    resumeRequestLayout();
    resumeRequestLayout(false);
  }
  
  public final void dispatchLayoutStep3()
  {
    mState.assertLayoutStep(4);
    eatRequestLayout();
    onEnterLayoutOrScroll();
    Object localObject = mState;
    mLayoutStep = 1;
    if (mRunSimpleAnimations)
    {
      int j = mChildHelper.getChildCount() - 1;
      while (j >= 0)
      {
        localObject = getChildViewHolderInt(mChildHelper.getChildAt(j));
        if (!((b0)localObject).shouldIgnore())
        {
          long l = getChangedHolderKey((b0)localObject);
          RecyclerView.l.c localC2 = mItemAnimator.b((b0)localObject);
          b0 localB0 = mViewInfoStore.getFromOldChangeHolders(l);
          if ((localB0 != null) && (!localB0.shouldIgnore()))
          {
            boolean bool1 = mViewInfoStore.isDisappearing(localB0);
            boolean bool2 = mViewInfoStore.isDisappearing((b0)localObject);
            if ((bool1) && (localB0 == localObject))
            {
              mViewInfoStore.a((b0)localObject, localC2);
            }
            else
            {
              RecyclerView.l.c localC1 = mViewInfoStore.popFromPreLayout(localB0);
              mViewInfoStore.a((b0)localObject, localC2);
              localC2 = mViewInfoStore.popFromPostLayout((b0)localObject);
              if (localC1 == null) {
                handleMissingPreInfoForChangeError(l, (b0)localObject, localB0);
              } else {
                animateChange(localB0, (b0)localObject, localC1, localC2, bool1, bool2);
              }
            }
          }
          else
          {
            mViewInfoStore.a((b0)localObject, localC2);
          }
        }
        j -= 1;
      }
      mViewInfoStore.a(mViewInfoProcessCallback);
    }
    mLayout.removeAndRecycleScrapInt(mRecycler);
    localObject = mState;
    mPreviousLayoutItemCount = mItemCount;
    mDataSetHasChangedAfterLayout = false;
    mRunningLayoutOrScroll = false;
    mRunSimpleAnimations = false;
    mRunPredictiveAnimations = false;
    mLayout.mDataSetHasChangedAfterLayout = false;
    localObject = mRecycler.mChangedScrap;
    if (localObject != null) {
      ((ArrayList)localObject).clear();
    }
    localObject = mLayout;
    if (l)
    {
      b = 0;
      l = false;
      mRecycler.write();
    }
    mLayout.onLayoutChildren(mState);
    resumeRequestLayout();
    resumeRequestLayout(false);
    mViewInfoStore.clear();
    localObject = mMinMaxLayoutPositions;
    if (didChildRangeChange(localObject[0], localObject[1])) {
      dispatchOnScrolled(0, 0);
    }
    run();
    clear();
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    return getScrollingChildHelper().dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2)
  {
    return getScrollingChildHelper().dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    return getScrollingChildHelper().dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt3)
  {
    return getScrollingChildHelper().dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramInt3);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    return getScrollingChildHelper().dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5)
  {
    return getScrollingChildHelper().dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt, paramInt5);
  }
  
  public final boolean dispatchOnItemTouch(MotionEvent paramMotionEvent)
  {
    int j = paramMotionEvent.getAction();
    r localR = mActiveOnItemTouchListener;
    if (localR != null) {
      if (j == 0)
      {
        mActiveOnItemTouchListener = null;
      }
      else
      {
        localR.a(this, paramMotionEvent);
        if ((j != 3) && (j != 1)) {
          break label115;
        }
        mActiveOnItemTouchListener = null;
        return true;
      }
    }
    if (j != 0)
    {
      int k = mOnItemTouchListeners.size();
      j = 0;
      while (j < k)
      {
        localR = (r)mOnItemTouchListeners.get(j);
        if (localR.onInterceptTouchEvent(this, paramMotionEvent))
        {
          mActiveOnItemTouchListener = localR;
          return true;
        }
        j += 1;
      }
    }
    return false;
    label115:
    return true;
  }
  
  public final boolean dispatchOnItemTouchIntercept(MotionEvent paramMotionEvent)
  {
    int k = paramMotionEvent.getAction();
    if ((k == 3) || (k == 0)) {
      mActiveOnItemTouchListener = null;
    }
    int n = mOnItemTouchListeners.size();
    int j = 0;
    while (j < n)
    {
      r localR = (r)mOnItemTouchListeners.get(j);
      if ((localR.onInterceptTouchEvent(this, paramMotionEvent)) && (k != 3))
      {
        mActiveOnItemTouchListener = localR;
        return true;
      }
      j += 1;
    }
    return false;
  }
  
  public void dispatchOnScrollStateChanged(int paramInt)
  {
    Object localObject = mLayout;
    if (localObject != null) {
      ((o)localObject).onScrollStateChanged(paramInt);
    }
    onScrollStateChanged();
    localObject = mScrollListener;
    if (localObject != null) {
      ((s)localObject).onScrollStateChanged();
    }
    localObject = mScrollListeners;
    if (localObject != null)
    {
      paramInt = ((List)localObject).size() - 1;
      while (paramInt >= 0)
      {
        ((s)mScrollListeners.get(paramInt)).onScrollStateChanged();
        paramInt -= 1;
      }
    }
  }
  
  public void dispatchOnScrolled(int paramInt1, int paramInt2)
  {
    f += 1;
    int j = getScrollX();
    int k = getScrollY();
    onScrollChanged(j, k, j, k);
    onScrolled();
    Object localObject = mScrollListener;
    if (localObject != null) {
      ((s)localObject).onScrolled(this, paramInt1, paramInt2);
    }
    localObject = mScrollListeners;
    if (localObject != null)
    {
      j = ((List)localObject).size() - 1;
      while (j >= 0)
      {
        ((s)mScrollListeners.get(j)).onScrolled(this, paramInt1, paramInt2);
        j -= 1;
      }
    }
    f -= 1;
  }
  
  public void dispatchRestoreInstanceState(SparseArray paramSparseArray)
  {
    dispatchThawSelfOnly(paramSparseArray);
  }
  
  public void dispatchSaveInstanceState(SparseArray paramSparseArray)
  {
    dispatchFreezeSelfOnly(paramSparseArray);
  }
  
  public final View draw()
  {
    int j = mState.progress;
    if (j == -1) {
      j = 0;
    }
    int n = mState.getItemCount();
    int k = j;
    b0 localB0;
    while (k < n)
    {
      localB0 = findViewHolderForAdapterPosition(k);
      if (localB0 == null) {
        break;
      }
      if (itemView.hasFocusable()) {
        return itemView;
      }
      k += 1;
    }
    j = Math.min(n, j) - 1;
    while (j >= 0)
    {
      localB0 = findViewHolderForAdapterPosition(j);
      if (localB0 == null) {
        return null;
      }
      if (itemView.hasFocusable()) {
        return itemView;
      }
      j -= 1;
    }
    return null;
  }
  
  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    int k = mItemDecorations.size();
    int j = 0;
    while (j < k)
    {
      ((n)mItemDecorations.get(j)).a(paramCanvas, this, mState);
      j += 1;
    }
    j = 0;
    EdgeEffect localEdgeEffect = mLeftGlow;
    int n = 1;
    k = j;
    int i1;
    if (localEdgeEffect != null)
    {
      k = j;
      if (!localEdgeEffect.isFinished())
      {
        i1 = paramCanvas.save();
        if (mClipToPadding) {
          j = getPaddingBottom();
        } else {
          j = 0;
        }
        paramCanvas.rotate(270.0F);
        paramCanvas.translate(-getHeight() + j, 0.0F);
        localEdgeEffect = mLeftGlow;
        if ((localEdgeEffect != null) && (localEdgeEffect.draw(paramCanvas))) {
          k = 1;
        } else {
          k = 0;
        }
        paramCanvas.restoreToCount(i1);
      }
    }
    localEdgeEffect = mTopGlow;
    j = k;
    if (localEdgeEffect != null)
    {
      j = k;
      if (!localEdgeEffect.isFinished())
      {
        i1 = paramCanvas.save();
        if (mClipToPadding) {
          paramCanvas.translate(getPaddingLeft(), getPaddingTop());
        }
        localEdgeEffect = mTopGlow;
        if ((localEdgeEffect != null) && (localEdgeEffect.draw(paramCanvas))) {
          j = 1;
        } else {
          j = 0;
        }
        j = k | j;
        paramCanvas.restoreToCount(i1);
      }
    }
    localEdgeEffect = mRightGlow;
    k = j;
    if (localEdgeEffect != null)
    {
      k = j;
      if (!localEdgeEffect.isFinished())
      {
        i1 = paramCanvas.save();
        int i2 = getWidth();
        if (mClipToPadding) {
          k = getPaddingTop();
        } else {
          k = 0;
        }
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-k, -i2);
        localEdgeEffect = mRightGlow;
        if ((localEdgeEffect != null) && (localEdgeEffect.draw(paramCanvas))) {
          k = 1;
        } else {
          k = 0;
        }
        k = j | k;
        paramCanvas.restoreToCount(i1);
      }
    }
    localEdgeEffect = mBottomGlow;
    j = k;
    if (localEdgeEffect != null)
    {
      j = k;
      if (!localEdgeEffect.isFinished())
      {
        i1 = paramCanvas.save();
        paramCanvas.rotate(180.0F);
        if (mClipToPadding) {
          paramCanvas.translate(-getWidth() + getPaddingRight(), -getHeight() + getPaddingBottom());
        } else {
          paramCanvas.translate(-getWidth(), -getHeight());
        }
        localEdgeEffect = mBottomGlow;
        if ((localEdgeEffect != null) && (localEdgeEffect.draw(paramCanvas))) {
          j = n;
        } else {
          j = 0;
        }
        j = k | j;
        paramCanvas.restoreToCount(i1);
      }
    }
    k = j;
    if (j == 0)
    {
      k = j;
      if (mItemAnimator != null)
      {
        k = j;
        if (mItemDecorations.size() > 0)
        {
          k = j;
          if (mItemAnimator.isRunning()) {
            k = 1;
          }
        }
      }
    }
    if (k != 0) {
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public final void draw(View paramView1, View paramView2)
  {
    if (paramView2 != null) {
      localObject = paramView2;
    } else {
      localObject = paramView1;
    }
    mTempRect.set(0, 0, ((View)localObject).getWidth(), ((View)localObject).getHeight());
    Object localObject = ((View)localObject).getLayoutParams();
    if ((localObject instanceof p))
    {
      localObject = (p)localObject;
      if (!mInsetsDirty)
      {
        localObject = mDecorInsets;
        localRect = mTempRect;
        left -= left;
        right += right;
        top -= top;
        bottom += bottom;
      }
    }
    if (paramView2 != null)
    {
      offsetDescendantRectToMyCoords(paramView2, mTempRect);
      offsetRectIntoDescendantCoords(paramView1, mTempRect);
    }
    localObject = mLayout;
    Rect localRect = mTempRect;
    boolean bool2 = mFirstLayoutComplete;
    boolean bool1;
    if (paramView2 == null) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    ((o)localObject).requestChildRectangleOnScreen(this, paramView1, localRect, bool2 ^ true, bool1);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void eatRequestLayout()
  {
    int j = mEatRequestLayout + 1;
    mEatRequestLayout = j;
    if ((j == 1) && (!mLayoutFrozen)) {
      mLayoutRequestEaten = false;
    }
  }
  
  public void ensureBottomGlow()
  {
    if (mBottomGlow != null) {
      return;
    }
    EdgeEffect localEdgeEffect = args.setSize(this);
    mBottomGlow = localEdgeEffect;
    if (mClipToPadding)
    {
      localEdgeEffect.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
      return;
    }
    localEdgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public void ensureLeftGlow()
  {
    if (mLeftGlow != null) {
      return;
    }
    EdgeEffect localEdgeEffect = args.setSize(this);
    mLeftGlow = localEdgeEffect;
    if (mClipToPadding)
    {
      localEdgeEffect.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
      return;
    }
    localEdgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
  }
  
  public void ensureRightGlow()
  {
    if (mRightGlow != null) {
      return;
    }
    EdgeEffect localEdgeEffect = args.setSize(this);
    mRightGlow = localEdgeEffect;
    if (mClipToPadding)
    {
      localEdgeEffect.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
      return;
    }
    localEdgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
  }
  
  public void ensureTopGlow()
  {
    if (mTopGlow != null) {
      return;
    }
    EdgeEffect localEdgeEffect = args.setSize(this);
    mTopGlow = localEdgeEffect;
    if (mClipToPadding)
    {
      localEdgeEffect.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
      return;
    }
    localEdgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public View findContainingItemView(View paramView)
  {
    ViewParent localViewParent = paramView.getParent();
    View localView = paramView;
    for (paramView = localViewParent; (paramView != null) && (paramView != this) && ((paramView instanceof View)); paramView = localView.getParent()) {
      localView = (View)paramView;
    }
    if (paramView == this) {
      return localView;
    }
    return null;
  }
  
  public b0 findContainingViewHolder(View paramView)
  {
    paramView = findContainingItemView(paramView);
    if (paramView == null) {
      return null;
    }
    return getChildViewHolder(paramView);
  }
  
  public final void findMinMaxChildLayoutPositions(int[] paramArrayOfInt)
  {
    int i4 = mChildHelper.getChildCount();
    if (i4 == 0)
    {
      paramArrayOfInt[0] = -1;
      paramArrayOfInt[1] = -1;
      return;
    }
    int k = Integer.MAX_VALUE;
    int i1 = Integer.MIN_VALUE;
    int n = 0;
    while (n < i4)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getChildAt(n));
      int i3;
      if (localB0.shouldIgnore())
      {
        i3 = i1;
      }
      else
      {
        int i2 = localB0.getLayoutPosition();
        int j = k;
        if (i2 < k) {
          j = i2;
        }
        k = j;
        i3 = i1;
        if (i2 > i1)
        {
          i3 = i2;
          k = j;
        }
      }
      n += 1;
      i1 = i3;
    }
    paramArrayOfInt[0] = k;
    paramArrayOfInt[1] = i1;
  }
  
  public b0 findViewHolderForAdapterPosition(int paramInt)
  {
    if (mDataSetHasChangedAfterLayout) {
      return null;
    }
    int k = mChildHelper.getUnfilteredChildCount();
    Object localObject1 = null;
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      Object localObject2 = localObject1;
      if (localB0 != null)
      {
        localObject2 = localObject1;
        if (!localB0.isRemoved())
        {
          localObject2 = localObject1;
          if (getAdapterPositionFor(localB0) == paramInt) {
            if (mChildHelper.isHidden(itemView)) {
              localObject2 = localB0;
            } else {
              return localB0;
            }
          }
        }
      }
      j += 1;
      localObject1 = localObject2;
    }
    return localObject1;
  }
  
  public b0 findViewHolderForItemId(long paramLong)
  {
    Object localObject1 = mAdapter;
    if ((localObject1 != null) && (((g)localObject1).hasStableIds()))
    {
      int k = mChildHelper.getUnfilteredChildCount();
      localObject1 = null;
      int j = 0;
      while (j < k)
      {
        b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
        Object localObject2 = localObject1;
        if (localB0 != null)
        {
          localObject2 = localObject1;
          if (!localB0.isRemoved())
          {
            localObject2 = localObject1;
            if (localB0.getItemId() == paramLong) {
              if (mChildHelper.isHidden(itemView)) {
                localObject2 = localB0;
              } else {
                return localB0;
              }
            }
          }
        }
        j += 1;
        localObject1 = localObject2;
      }
      return localObject1;
    }
    return null;
  }
  
  public b0 findViewHolderForPosition(int paramInt, boolean paramBoolean)
  {
    int k = mChildHelper.getUnfilteredChildCount();
    Object localObject1 = null;
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      Object localObject2 = localObject1;
      if (localB0 != null)
      {
        localObject2 = localObject1;
        if (!localB0.isRemoved())
        {
          if (paramBoolean)
          {
            if (mPosition != paramInt)
            {
              localObject2 = localObject1;
              break label115;
            }
          }
          else if (localB0.getLayoutPosition() != paramInt)
          {
            localObject2 = localObject1;
            break label115;
          }
          if (mChildHelper.isHidden(itemView)) {
            localObject2 = localB0;
          } else {
            return localB0;
          }
        }
      }
      label115:
      j += 1;
      localObject1 = localObject2;
    }
    return localObject1;
  }
  
  public boolean fling(int paramInt1, int paramInt2)
  {
    o localO = mLayout;
    if (localO == null)
    {
      Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return false;
    }
    if (mLayoutFrozen) {
      return false;
    }
    boolean bool2 = localO.canScrollHorizontally();
    boolean bool3 = mLayout.canScrollVertically();
    int j;
    if (bool2)
    {
      j = paramInt1;
      if (Math.abs(paramInt1) >= mMinFlingVelocity) {}
    }
    else
    {
      j = 0;
    }
    int k;
    if (bool3)
    {
      k = paramInt2;
      if (Math.abs(paramInt2) >= mMinFlingVelocity) {}
    }
    else
    {
      k = 0;
    }
    if ((j == 0) && (k == 0)) {
      return false;
    }
    if (!dispatchNestedPreFling(j, k))
    {
      boolean bool1;
      if ((!bool2) && (!bool3)) {
        bool1 = false;
      } else {
        bool1 = true;
      }
      dispatchNestedFling(j, k, bool1);
      if (bool1)
      {
        paramInt1 = 0;
        if (bool2) {
          paramInt1 = 0x0 | 0x1;
        }
        paramInt2 = paramInt1;
        if (bool3) {
          paramInt2 = paramInt1 | 0x2;
        }
        startNestedScroll(paramInt2, 1);
        paramInt1 = mMaxFlingVelocity;
        paramInt1 = Math.max(-paramInt1, Math.min(j, paramInt1));
        paramInt2 = mMaxFlingVelocity;
        paramInt2 = Math.max(-paramInt2, Math.min(k, paramInt2));
        mViewFlinger.fling(paramInt1, paramInt2);
        return true;
      }
    }
    return false;
  }
  
  public View focusSearch(View paramView, int paramInt)
  {
    Object localObject = mLayout.onFocusSearchFailed();
    if (localObject != null) {
      return localObject;
    }
    localObject = mAdapter;
    int i2 = 1;
    int j;
    if ((localObject != null) && (mLayout != null) && (!isComputingLayout()) && (!mLayoutFrozen)) {
      j = 1;
    } else {
      j = 0;
    }
    localObject = FocusFinder.getInstance();
    int k;
    if ((j != 0) && ((paramInt == 2) || (paramInt == 1)))
    {
      int n = 0;
      j = paramInt;
      if (mLayout.canScrollVertically())
      {
        if (paramInt == 2) {
          k = 130;
        } else {
          k = 33;
        }
        if (((FocusFinder)localObject).findNextFocus(this, paramView, k) == null) {
          i1 = 1;
        } else {
          i1 = 0;
        }
        n = i1;
        j = paramInt;
        if (mWidth)
        {
          j = k;
          n = i1;
        }
      }
      int i1 = n;
      k = j;
      if (n == 0)
      {
        i1 = n;
        k = j;
        if (mLayout.canScrollHorizontally())
        {
          if (mLayout.getLayoutDirection() == 1) {
            paramInt = 1;
          } else {
            paramInt = 0;
          }
          if (j == 2) {
            k = 1;
          } else {
            k = 0;
          }
          if ((k ^ paramInt) != 0) {
            paramInt = 66;
          } else {
            paramInt = 17;
          }
          if (((FocusFinder)localObject).findNextFocus(this, paramView, paramInt) == null) {
            k = i2;
          } else {
            k = 0;
          }
          n = k;
          i1 = n;
          k = j;
          if (mWidth)
          {
            k = paramInt;
            i1 = n;
          }
        }
      }
      if (i1 != 0)
      {
        consumePendingUpdateOperations();
        if (findContainingItemView(paramView) == null) {
          return null;
        }
        eatRequestLayout();
        mLayout.onFocusSearchFailed(paramView, k, mRecycler, mState);
        resumeRequestLayout(false);
      }
      localObject = ((FocusFinder)localObject).findNextFocus(this, paramView, k);
    }
    else
    {
      View localView2 = ((FocusFinder)localObject).findNextFocus(this, paramView, paramInt);
      View localView1 = localView2;
      localObject = localView1;
      k = paramInt;
      if (localView2 == null)
      {
        localObject = localView1;
        k = paramInt;
        if (j != 0)
        {
          consumePendingUpdateOperations();
          if (findContainingItemView(paramView) == null) {
            return null;
          }
          eatRequestLayout();
          localObject = mLayout.onFocusSearchFailed(paramView, paramInt, mRecycler, mState);
          resumeRequestLayout(false);
          k = paramInt;
        }
      }
    }
    if ((localObject != null) && (!((View)localObject).hasFocusable()))
    {
      if (getFocusedChild() == null) {
        return super.focusSearch(paramView, k);
      }
      draw((View)localObject, null);
      return paramView;
    }
    if (arrowScroll(paramView, (View)localObject, k)) {
      return localObject;
    }
    return super.focusSearch(paramView, k);
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams()
  {
    Object localObject = mLayout;
    if (localObject != null) {
      return ((o)localObject).generateDefaultLayoutParams();
    }
    localObject = new StringBuilder();
    ((StringBuilder)localObject).append("RecyclerView has no LayoutManager");
    ((StringBuilder)localObject).append(append());
    throw new IllegalStateException(((StringBuilder)localObject).toString());
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    o localO = mLayout;
    if (localO != null) {
      return localO.generateLayoutParams(getContext(), paramAttributeSet);
    }
    paramAttributeSet = new StringBuilder();
    paramAttributeSet.append("RecyclerView has no LayoutManager");
    paramAttributeSet.append(append());
    throw new IllegalStateException(paramAttributeSet.toString());
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    o localO = mLayout;
    if (localO != null) {
      return localO.generateLayoutParams(paramLayoutParams);
    }
    paramLayoutParams = new StringBuilder();
    paramLayoutParams.append("RecyclerView has no LayoutManager");
    paramLayoutParams.append(append());
    throw new IllegalStateException(paramLayoutParams.toString());
  }
  
  public g getAdapter()
  {
    return mAdapter;
  }
  
  public int getAdapterPositionFor(b0 paramB0)
  {
    if ((!paramB0.hasAnyOfTheFlags(524)) && (paramB0.isBound())) {
      return mAdapterHelper.a(mPosition);
    }
    return -1;
  }
  
  public int getBaseline()
  {
    o localO = mLayout;
    if (localO != null)
    {
      localO.getBaseline();
      return -1;
    }
    return super.getBaseline();
  }
  
  public long getChangedHolderKey(b0 paramB0)
  {
    if (mAdapter.hasStableIds()) {
      return paramB0.getItemId();
    }
    return mPosition;
  }
  
  public int getChildDrawingOrder(int paramInt1, int paramInt2)
  {
    j localJ = mChildDrawingOrderCallback;
    if (localJ == null) {
      return super.getChildDrawingOrder(paramInt1, paramInt2);
    }
    return localJ.onGetChildDrawingOrder(paramInt1, paramInt2);
  }
  
  public b0 getChildViewHolder(View paramView)
  {
    Object localObject = paramView.getParent();
    if ((localObject != null) && (localObject != this))
    {
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("View ");
      ((StringBuilder)localObject).append(paramView);
      ((StringBuilder)localObject).append(" is not a direct child of ");
      ((StringBuilder)localObject).append(this);
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    return getChildViewHolderInt(paramView);
  }
  
  public boolean getClipToPadding()
  {
    return mClipToPadding;
  }
  
  public RecyclerViewAccessibilityDelegate getCompatAccessibilityDelegate()
  {
    return mAccessibilityDelegate;
  }
  
  public k getEdgeEffectFactory()
  {
    return args;
  }
  
  public final String getFullClassName(Context paramContext, String paramString)
  {
    if (paramString.charAt(0) == '.')
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramContext.getPackageName());
      localStringBuilder.append(paramString);
      return localStringBuilder.toString();
    }
    if (paramString.contains(".")) {
      return paramString;
    }
    paramContext = new StringBuilder();
    paramContext.append(RecyclerView.class.getPackage().getName());
    paramContext.append('.');
    paramContext.append(paramString);
    return paramContext.toString();
  }
  
  public l getItemAnimator()
  {
    return mItemAnimator;
  }
  
  public Rect getItemDecorInsetsForChild(View paramView)
  {
    p localP = (p)paramView.getLayoutParams();
    if (!mInsetsDirty) {
      return mDecorInsets;
    }
    if ((mState.isPreLayout()) && ((localP.next()) || (localP.isViewInvalid()))) {
      return mDecorInsets;
    }
    Rect localRect1 = mDecorInsets;
    localRect1.set(0, 0, 0, 0);
    int k = mItemDecorations.size();
    int j = 0;
    while (j < k)
    {
      mTempRect.set(0, 0, 0, 0);
      ((n)mItemDecorations.get(j)).getItemOffsets(mTempRect, paramView, this);
      int n = left;
      Rect localRect2 = mTempRect;
      left = (n + left);
      top += top;
      right += right;
      bottom += bottom;
      j += 1;
    }
    mInsetsDirty = false;
    return localRect1;
  }
  
  public int getItemDecorationCount()
  {
    return mItemDecorations.size();
  }
  
  public o getLayoutManager()
  {
    return mLayout;
  }
  
  public int getMaxFlingVelocity()
  {
    return mMaxFlingVelocity;
  }
  
  public int getMinFlingVelocity()
  {
    return mMinFlingVelocity;
  }
  
  public long getNanoTime()
  {
    if (this$0) {
      return System.nanoTime();
    }
    return 0L;
  }
  
  public q getOnFlingListener()
  {
    return null;
  }
  
  public boolean getPreserveFocusAfterLayout()
  {
    return mDirection;
  }
  
  public t getRecycledViewPool()
  {
    return mRecycler.getRecycledViewPool();
  }
  
  public int getScrollState()
  {
    return mScrollState;
  }
  
  public final void handleMissingPreInfoForChangeError(long paramLong, b0 paramB01, b0 paramB02)
  {
    int k = mChildHelper.getChildCount();
    int j = 0;
    while (j < k)
    {
      localObject = getChildViewHolderInt(mChildHelper.getChildAt(j));
      if ((localObject != paramB01) && (getChangedHolderKey((b0)localObject) == paramLong))
      {
        paramB02 = mAdapter;
        if ((paramB02 != null) && (paramB02.hasStableIds()))
        {
          paramB02 = new StringBuilder();
          paramB02.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
          paramB02.append(localObject);
          paramB02.append(" \n View Holder 2:");
          paramB02.append(paramB01);
          paramB02.append(append());
          throw new IllegalStateException(paramB02.toString());
        }
        paramB02 = new StringBuilder();
        paramB02.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
        paramB02.append(localObject);
        paramB02.append(" \n View Holder 2:");
        paramB02.append(paramB01);
        paramB02.append(append());
        throw new IllegalStateException(paramB02.toString());
      }
      j += 1;
    }
    Object localObject = new StringBuilder();
    ((StringBuilder)localObject).append("Problem while matching changed view holders with the newones. The pre-layout information for the change holder ");
    ((StringBuilder)localObject).append(paramB02);
    ((StringBuilder)localObject).append(" cannot be found but it is necessary for ");
    ((StringBuilder)localObject).append(paramB01);
    ((StringBuilder)localObject).append(append());
    Log.e("RecyclerView", ((StringBuilder)localObject).toString());
  }
  
  public boolean hasNestedScrollingParent()
  {
    return getScrollingChildHelper().hasNestedScrollingParent();
  }
  
  public boolean hasNestedScrollingParent(int paramInt)
  {
    return getScrollingChildHelper().hasNestedScrollingParent(paramInt);
  }
  
  public boolean hasPendingAdapterUpdates()
  {
    return (!mFirstLayoutComplete) || (mDataSetHasChangedAfterLayout) || (mAdapterHelper.add());
  }
  
  public final boolean hasUpdatedView()
  {
    int k = mChildHelper.getChildCount();
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getChildAt(j));
      if ((localB0 != null) && (!localB0.shouldIgnore()) && (localB0.isUpdated())) {
        return true;
      }
      j += 1;
    }
    return false;
  }
  
  public void init(StateListDrawable paramStateListDrawable1, Drawable paramDrawable1, StateListDrawable paramStateListDrawable2, Drawable paramDrawable2)
  {
    if ((paramStateListDrawable1 != null) && (paramDrawable1 != null) && (paramStateListDrawable2 != null) && (paramDrawable2 != null))
    {
      Resources localResources = getContext().getResources();
      new org.objectweb.asm.ClassWriter(this, paramStateListDrawable1, paramDrawable1, paramStateListDrawable2, paramDrawable2, localResources.getDimensionPixelSize(ChartData.fastscroll_default_thickness), localResources.getDimensionPixelSize(ChartData.fastscroll_minimum_range), localResources.getDimensionPixelOffset(ChartData.fastscroll_margin));
      return;
    }
    paramStateListDrawable1 = new StringBuilder();
    paramStateListDrawable1.append("Trying to set fast scroller without both required drawables.");
    paramStateListDrawable1.append(append());
    throw new IllegalArgumentException(paramStateListDrawable1.toString());
  }
  
  public void initAdapterManager()
  {
    mAdapterHelper = new ByteVector(new f());
  }
  
  public final void initChildrenHelper()
  {
    mChildHelper = new ChildHelper(new e());
  }
  
  public void invalidateGlows()
  {
    mBottomGlow = null;
    mTopGlow = null;
    mRightGlow = null;
    mLeftGlow = null;
  }
  
  public boolean isAccessibilityEnabled()
  {
    AccessibilityManager localAccessibilityManager = mAccessibilityManager;
    return (localAccessibilityManager != null) && (localAccessibilityManager.isEnabled());
  }
  
  public boolean isAttachedToWindow()
  {
    return mIsAttached;
  }
  
  public boolean isComputingLayout()
  {
    return mLayoutOrScrollCounter > 0;
  }
  
  public boolean isNestedScrollingEnabled()
  {
    return getScrollingChildHelper().isNestedScrollingEnabled();
  }
  
  public void markItemDecorInsetsDirty()
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      mChildHelper.getUnfilteredChildAt(j).getLayoutParams()).mInsetsDirty = true;
      j += 1;
    }
    mRecycler.markItemDecorInsetsDirty();
  }
  
  public void markKnownViewsInvalid()
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      if ((localB0 != null) && (!localB0.shouldIgnore())) {
        localB0.addFlags(6);
      }
      j += 1;
    }
    markItemDecorInsetsDirty();
    mRecycler.markKnownViewsInvalid();
  }
  
  public void offsetChildrenHorizontal(int paramInt)
  {
    int k = mChildHelper.getChildCount();
    int j = 0;
    while (j < k)
    {
      mChildHelper.getChildAt(j).offsetLeftAndRight(paramInt);
      j += 1;
    }
  }
  
  public void offsetChildrenVertical(int paramInt)
  {
    int k = mChildHelper.getChildCount();
    int j = 0;
    while (j < k)
    {
      mChildHelper.getChildAt(j).offsetTopAndBottom(paramInt);
      j += 1;
    }
  }
  
  public void offsetPositionRecordsForInsert()
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      if (!localB0.shouldIgnore()) {
        localB0.offsetPosition();
      }
      j += 1;
    }
  }
  
  public void offsetPositionRecordsForMove(int paramInt1, int paramInt2)
  {
    int i2 = mChildHelper.getUnfilteredChildCount();
    int j;
    int k;
    int n;
    if (paramInt1 < paramInt2)
    {
      j = paramInt1;
      k = paramInt2;
      n = -1;
    }
    else
    {
      j = paramInt2;
      k = paramInt1;
      n = 1;
    }
    int i1 = 0;
    while (i1 < i2)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(i1));
      if (localB0 != null)
      {
        int i3 = mPosition;
        if ((i3 >= j) && (i3 <= k))
        {
          if (i3 == paramInt1) {
            localB0.offsetPosition(paramInt2 - paramInt1, false);
          } else {
            localB0.offsetPosition(n, false);
          }
          mState.mStructureChanged = true;
        }
      }
      i1 += 1;
    }
    mRecycler.offsetPositionRecordsForMove(paramInt1, paramInt2);
    requestLayout();
  }
  
  public void offsetPositionRecordsForRemove(int paramInt1, int paramInt2)
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      if ((localB0 != null) && (!localB0.shouldIgnore()) && (mPosition >= paramInt1))
      {
        localB0.offsetPosition(paramInt2, false);
        mState.mStructureChanged = true;
      }
      j += 1;
    }
    mRecycler.offsetPositionRecordsForInsert(paramInt1, paramInt2);
    requestLayout();
  }
  
  public void offsetPositionRecordsForRemove(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      b0 localB0 = getChildViewHolderInt(mChildHelper.getUnfilteredChildAt(j));
      if ((localB0 != null) && (!localB0.shouldIgnore()))
      {
        int n = mPosition;
        if (n >= paramInt1 + paramInt2)
        {
          localB0.offsetPosition(-paramInt2, paramBoolean);
          mState.mStructureChanged = true;
        }
        else if (n >= paramInt1)
        {
          localB0.flagRemovedAndOffsetPosition(paramInt1 - 1, -paramInt2, paramBoolean);
          mState.mStructureChanged = true;
        }
      }
      j += 1;
    }
    mRecycler.offsetPositionRecordsForRemove(paramInt1, paramInt2, paramBoolean);
    requestLayout();
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    mLayoutOrScrollCounter = 0;
    boolean bool = true;
    mIsAttached = true;
    if ((!mFirstLayoutComplete) || (isLayoutRequested())) {
      bool = false;
    }
    mFirstLayoutComplete = bool;
    Object localObject = mLayout;
    if (localObject != null) {
      ((o)localObject).dispatchAttachedToWindow(this);
    }
    mPostedAnimatorRunner = false;
    if (this$0)
    {
      localObject = (b)b.random.get();
      q = ((b)localObject);
      if (localObject == null)
      {
        q = new b();
        localObject = ViewCompat.getDisplay(this);
        float f2 = 60.0F;
        float f1 = f2;
        if (!isInEditMode())
        {
          f1 = f2;
          if (localObject != null)
          {
            float f3 = ((Display)localObject).getRefreshRate();
            f1 = f2;
            if (f3 >= 30.0F) {
              f1 = f3;
            }
          }
        }
        localObject = q;
        d = ((1.0E9F / f1));
        b.random.set(localObject);
      }
      q.start(this);
    }
  }
  
  public void onChildDetachedFromWindow() {}
  
  public final void onCreate()
  {
    y localY = null;
    Object localObject = localY;
    if (mDirection)
    {
      localObject = localY;
      if (hasFocus())
      {
        localObject = localY;
        if (mAdapter != null) {
          localObject = getFocusedChild();
        }
      }
    }
    if (localObject == null) {
      localObject = null;
    } else {
      localObject = findContainingViewHolder((View)localObject);
    }
    if (localObject == null)
    {
      clear();
      return;
    }
    localY = mState;
    long l;
    if (mAdapter.hasStableIds()) {
      l = ((b0)localObject).getItemId();
    } else {
      l = -1L;
    }
    id = l;
    localY = mState;
    int j;
    if (mDataSetHasChangedAfterLayout) {
      j = -1;
    } else if (((b0)localObject).isRemoved()) {
      j = mOldPosition;
    } else {
      j = ((b0)localObject).a();
    }
    progress = j;
    mState.progressBar = clear(itemView);
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    Object localObject = mItemAnimator;
    if (localObject != null) {
      ((l)localObject).endAnimations();
    }
    stopScroll();
    mIsAttached = false;
    localObject = mLayout;
    if (localObject != null) {
      ((o)localObject).onDetachedFromWindow(this, mRecycler);
    }
    m.clear();
    removeCallbacks(mItemAnimatorRunner);
    mViewInfoStore.e();
    if (this$0)
    {
      localObject = q;
      if (localObject != null)
      {
        ((b)localObject).a(this);
        q = null;
      }
    }
  }
  
  public void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    int k = mItemDecorations.size();
    int j = 0;
    while (j < k)
    {
      ((n)mItemDecorations.get(j)).a(paramCanvas, this);
      j += 1;
    }
  }
  
  public void onEnterLayoutOrScroll()
  {
    mLayoutOrScrollCounter += 1;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    if (mLayout == null) {
      return false;
    }
    if (mLayoutFrozen) {
      return false;
    }
    if (paramMotionEvent.getAction() == 8)
    {
      float f1;
      float f2;
      if ((paramMotionEvent.getSource() & 0x2) != 0)
      {
        if (mLayout.canScrollVertically()) {
          f1 = -paramMotionEvent.getAxisValue(9);
        } else {
          f1 = 0.0F;
        }
        if (mLayout.canScrollHorizontally()) {
          f2 = paramMotionEvent.getAxisValue(10);
        } else {
          f2 = 0.0F;
        }
      }
      else if ((paramMotionEvent.getSource() & 0x400000) != 0)
      {
        f2 = paramMotionEvent.getAxisValue(26);
        if (mLayout.canScrollVertically())
        {
          f1 = -f2;
          f2 = 0.0F;
        }
        else if (mLayout.canScrollHorizontally())
        {
          f1 = 0.0F;
        }
        else
        {
          f1 = 0.0F;
          f2 = 0.0F;
        }
      }
      else
      {
        f1 = 0.0F;
        f2 = 0.0F;
      }
      if ((f1 != 0.0F) || (f2 != 0.0F)) {
        scrollByInternal((int)(TAG * f2), (int)(mScrollFactor * f1), paramMotionEvent);
      }
    }
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    if (mLayoutFrozen) {
      return false;
    }
    if (dispatchOnItemTouchIntercept(paramMotionEvent))
    {
      cancelTouch();
      return true;
    }
    o localO = mLayout;
    if (localO == null) {
      return false;
    }
    boolean bool1 = localO.canScrollHorizontally();
    boolean bool2 = mLayout.canScrollVertically();
    if (mVelocityTracker == null) {
      mVelocityTracker = VelocityTracker.obtain();
    }
    mVelocityTracker.addMovement(paramMotionEvent);
    int k = paramMotionEvent.getActionMasked();
    int j = paramMotionEvent.getActionIndex();
    if (k != 0)
    {
      if (k != 1)
      {
        if (k != 2)
        {
          if (k != 3)
          {
            if (k != 5)
            {
              if (k == 6) {
                onPointerUp(paramMotionEvent);
              }
            }
            else
            {
              mScrollPointerId = paramMotionEvent.getPointerId(j);
              k = (int)(paramMotionEvent.getX(j) + 0.5F);
              mLastTouchX = k;
              mInitialTouchX = k;
              j = (int)(paramMotionEvent.getY(j) + 0.5F);
              mLastTouchY = j;
              mInitialTouchY = j;
            }
          }
          else {
            cancelTouch();
          }
        }
        else
        {
          j = paramMotionEvent.findPointerIndex(mScrollPointerId);
          if (j < 0)
          {
            paramMotionEvent = new StringBuilder();
            paramMotionEvent.append("Error processing scroll; pointer index for id ");
            paramMotionEvent.append(mScrollPointerId);
            paramMotionEvent.append(" not found. Did any MotionEvents get skipped?");
            Log.e("RecyclerView", paramMotionEvent.toString());
            return false;
          }
          int i2 = (int)(paramMotionEvent.getX(j) + 0.5F);
          int n = (int)(paramMotionEvent.getY(j) + 0.5F);
          if (mScrollState != 1)
          {
            int i3 = mInitialTouchX;
            int i1 = mInitialTouchY;
            k = 0;
            j = k;
            if (bool1)
            {
              j = k;
              if (Math.abs(i2 - i3) > mTouchSlop)
              {
                mLastTouchX = i2;
                j = 1;
              }
            }
            k = j;
            if (bool2)
            {
              k = j;
              if (Math.abs(n - i1) > mTouchSlop)
              {
                mLastTouchY = n;
                k = 1;
              }
            }
            if (k != 0) {
              setScrollState(1);
            }
          }
        }
      }
      else
      {
        mVelocityTracker.clear();
        stopNestedScroll(0);
      }
    }
    else
    {
      if (mIgnoreMotionEventTillDown) {
        mIgnoreMotionEventTillDown = false;
      }
      mScrollPointerId = paramMotionEvent.getPointerId(0);
      j = (int)(paramMotionEvent.getX() + 0.5F);
      mLastTouchX = j;
      mInitialTouchX = j;
      j = (int)(paramMotionEvent.getY() + 0.5F);
      mLastTouchY = j;
      mInitialTouchY = j;
      if (mScrollState == 2)
      {
        getParent().requestDisallowInterceptTouchEvent(true);
        setScrollState(1);
      }
      paramMotionEvent = mNestedOffsets;
      paramMotionEvent[1] = 0;
      paramMotionEvent[0] = 0;
      j = 0;
      if (bool1) {
        j = 0x0 | 0x1;
      }
      k = j;
      if (bool2) {
        k = j | 0x2;
      }
      startNestedScroll(k, 0);
    }
    return mScrollState == 1;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    org.core.models.RecyclerView.beginSection("RV OnLayout");
    dispatchLayout();
    org.core.models.RecyclerView.endSection();
    mFirstLayoutComplete = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    Object localObject = mLayout;
    if (localObject == null)
    {
      defaultOnMeasure(paramInt1, paramInt2);
      return;
    }
    boolean bool = ((o)localObject).setOrientation();
    int k = 0;
    if (bool)
    {
      int n = View.MeasureSpec.getMode(paramInt1);
      int i1 = View.MeasureSpec.getMode(paramInt2);
      mLayout.onMeasure(paramInt1, paramInt2);
      int j = k;
      if (n == 1073741824)
      {
        j = k;
        if (i1 == 1073741824) {
          j = 1;
        }
      }
      if (j == 0)
      {
        if (mAdapter == null) {
          return;
        }
        if (mState.mLayoutStep == 1) {
          dispatchLayoutStep1();
        }
        mLayout.setMeasureSpecs(paramInt1, paramInt2);
        mState.mIsMeasuring = true;
        dispatchLayoutStep2();
        mLayout.draw(paramInt1, paramInt2);
        if (mLayout.shouldMeasureTwice())
        {
          mLayout.setMeasureSpecs(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
          mState.mIsMeasuring = true;
          dispatchLayoutStep2();
          mLayout.draw(paramInt1, paramInt2);
        }
      }
      return;
    }
    if (mHasFixedSize)
    {
      mLayout.onMeasure(paramInt1, paramInt2);
      return;
    }
    if (mAdapterUpdateDuringMeasure)
    {
      eatRequestLayout();
      onEnterLayoutOrScroll();
      processAdapterUpdatesAndSetAnimationFlags();
      resumeRequestLayout();
      localObject = mState;
      if (mRunPredictiveAnimations)
      {
        mInPreLayout = true;
      }
      else
      {
        mAdapterHelper.b();
        mState.mInPreLayout = false;
      }
      mAdapterUpdateDuringMeasure = false;
      resumeRequestLayout(false);
    }
    else if (mState.mRunPredictiveAnimations)
    {
      setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
      return;
    }
    localObject = mAdapter;
    if (localObject != null) {
      mState.mItemCount = ((g)localObject).getItemCount();
    } else {
      mState.mItemCount = 0;
    }
    eatRequestLayout();
    mLayout.onMeasure(paramInt1, paramInt2);
    resumeRequestLayout(false);
    mState.mInPreLayout = false;
  }
  
  public final void onPointerUp(MotionEvent paramMotionEvent)
  {
    int j = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(j) == mScrollPointerId)
    {
      if (j == 0) {
        j = 1;
      } else {
        j = 0;
      }
      mScrollPointerId = paramMotionEvent.getPointerId(j);
      int k = (int)(paramMotionEvent.getX(j) + 0.5F);
      mLastTouchX = k;
      mInitialTouchX = k;
      j = (int)(paramMotionEvent.getY(j) + 0.5F);
      mLastTouchY = j;
      mInitialTouchY = j;
    }
  }
  
  public void onPostExecute(String paramString)
  {
    if (isComputingLayout())
    {
      if (paramString == null)
      {
        paramString = new StringBuilder();
        paramString.append("Cannot call this method while RecyclerView is computing a layout or scrolling");
        paramString.append(append());
        throw new IllegalStateException(paramString.toString());
      }
      throw new IllegalStateException(paramString);
    }
    if (f > 0)
    {
      paramString = new StringBuilder();
      paramString.append("");
      paramString.append(append());
      Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(paramString.toString()));
    }
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect)
  {
    if (isComputingLayout()) {
      return false;
    }
    return super.onRequestFocusInDescendants(paramInt, paramRect);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof x))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (x)paramParcelable;
    mPendingSavedState = paramParcelable;
    super.onRestoreInstanceState(paramParcelable.next());
    paramParcelable = mLayout;
    if (paramParcelable != null)
    {
      Parcelable localParcelable = mPendingSavedState.mLayoutState;
      if (localParcelable != null) {
        paramParcelable.onRestoreInstanceState(localParcelable);
      }
    }
  }
  
  public Parcelable onSaveInstanceState()
  {
    x localX = new x(super.onSaveInstanceState());
    Object localObject = mPendingSavedState;
    if (localObject != null)
    {
      localX.access$1900((x)localObject);
      return localX;
    }
    localObject = mLayout;
    if (localObject != null)
    {
      mLayoutState = ((o)localObject).d();
      return localX;
    }
    mLayoutState = null;
    return localX;
  }
  
  public void onScrollStateChanged() {}
  
  public void onScrolled() {}
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if ((paramInt1 != paramInt3) || (paramInt2 != paramInt4)) {
      invalidateGlows();
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    boolean bool1 = mLayoutFrozen;
    int i4 = 0;
    if (!bool1)
    {
      if (mIgnoreMotionEventTillDown) {
        return false;
      }
      if (dispatchOnItemTouch(paramMotionEvent))
      {
        cancelTouch();
        return true;
      }
      Object localObject = mLayout;
      if (localObject == null) {
        return false;
      }
      bool1 = ((o)localObject).canScrollHorizontally();
      boolean bool2 = mLayout.canScrollVertically();
      if (mVelocityTracker == null) {
        mVelocityTracker = VelocityTracker.obtain();
      }
      int i3 = 0;
      localObject = MotionEvent.obtain(paramMotionEvent);
      int k = paramMotionEvent.getActionMasked();
      int j = paramMotionEvent.getActionIndex();
      if (k == 0)
      {
        arrayOfInt = mNestedOffsets;
        arrayOfInt[1] = 0;
        arrayOfInt[0] = 0;
      }
      int[] arrayOfInt = mNestedOffsets;
      ((MotionEvent)localObject).offsetLocation(arrayOfInt[0], arrayOfInt[1]);
      if (k != 0)
      {
        if (k != 1)
        {
          if (k != 2)
          {
            if (k != 3)
            {
              if (k != 5)
              {
                if (k != 6)
                {
                  j = i3;
                }
                else
                {
                  onPointerUp(paramMotionEvent);
                  j = i3;
                }
              }
              else
              {
                mScrollPointerId = paramMotionEvent.getPointerId(j);
                k = (int)(paramMotionEvent.getX(j) + 0.5F);
                mLastTouchX = k;
                mInitialTouchX = k;
                j = (int)(paramMotionEvent.getY(j) + 0.5F);
                mLastTouchY = j;
                mInitialTouchY = j;
                j = i3;
              }
            }
            else
            {
              cancelTouch();
              j = i3;
            }
          }
          else
          {
            j = paramMotionEvent.findPointerIndex(mScrollPointerId);
            if (j < 0)
            {
              paramMotionEvent = new StringBuilder();
              paramMotionEvent.append("Error processing scroll; pointer index for id ");
              paramMotionEvent.append(mScrollPointerId);
              paramMotionEvent.append(" not found. Did any MotionEvents get skipped?");
              Log.e("RecyclerView", paramMotionEvent.toString());
              return false;
            }
            int i5 = (int)(paramMotionEvent.getX(j) + 0.5F);
            int i6 = (int)(paramMotionEvent.getY(j) + 0.5F);
            int i1 = mLastTouchX - i5;
            int n = mLastTouchY - i6;
            k = i1;
            j = n;
            if (dispatchNestedPreScroll(i1, n, mScrollConsumed, mScrollOffset, 0))
            {
              paramMotionEvent = mScrollConsumed;
              k = i1 - paramMotionEvent[0];
              j = n - paramMotionEvent[1];
              paramMotionEvent = mScrollOffset;
              ((MotionEvent)localObject).offsetLocation(paramMotionEvent[0], paramMotionEvent[1]);
              paramMotionEvent = mNestedOffsets;
              n = paramMotionEvent[0];
              arrayOfInt = mScrollOffset;
              paramMotionEvent[0] = (n + arrayOfInt[0]);
              paramMotionEvent[1] += arrayOfInt[1];
            }
            n = k;
            i1 = j;
            if (mScrollState != 1)
            {
              int i2 = 0;
              n = k;
              i1 = i2;
              int i7;
              int i8;
              if (bool1)
              {
                i7 = Math.abs(k);
                i8 = mTouchSlop;
                n = k;
                i1 = i2;
                if (i7 > i8)
                {
                  if (k > 0) {
                    n = k - i8;
                  } else {
                    n = k + i8;
                  }
                  i1 = 1;
                }
              }
              k = j;
              i2 = i1;
              if (bool2)
              {
                i7 = Math.abs(j);
                i8 = mTouchSlop;
                k = j;
                i2 = i1;
                if (i7 > i8)
                {
                  if (j > 0) {
                    k = j - i8;
                  } else {
                    k = j + i8;
                  }
                  i2 = 1;
                }
              }
              if (i2 != 0) {
                setScrollState(1);
              }
              i1 = k;
            }
            if (mScrollState == 1)
            {
              paramMotionEvent = mScrollOffset;
              mLastTouchX = (i5 - paramMotionEvent[0]);
              mLastTouchY = (i6 - paramMotionEvent[1]);
              if (bool1) {
                j = n;
              } else {
                j = 0;
              }
              k = i4;
              if (bool2) {
                k = i1;
              }
              if (scrollByInternal(j, k, (MotionEvent)localObject)) {
                getParent().requestDisallowInterceptTouchEvent(true);
              }
              if ((q != null) && ((n != 0) || (i1 != 0))) {
                q.a(this, n, i1);
              }
            }
            j = i3;
          }
        }
        else
        {
          mVelocityTracker.addMovement((MotionEvent)localObject);
          j = 1;
          mVelocityTracker.computeCurrentVelocity(1000, mMaxFlingVelocity);
          float f1;
          if (bool1) {
            f1 = -mVelocityTracker.getXVelocity(mScrollPointerId);
          } else {
            f1 = 0.0F;
          }
          float f2;
          if (bool2) {
            f2 = -mVelocityTracker.getYVelocity(mScrollPointerId);
          } else {
            f2 = 0.0F;
          }
          if (((f1 == 0.0F) && (f2 == 0.0F)) || (!fling((int)f1, (int)f2))) {
            setScrollState(0);
          }
          resetTouch();
        }
      }
      else
      {
        mScrollPointerId = paramMotionEvent.getPointerId(0);
        j = (int)(paramMotionEvent.getX() + 0.5F);
        mLastTouchX = j;
        mInitialTouchX = j;
        j = (int)(paramMotionEvent.getY() + 0.5F);
        mLastTouchY = j;
        mInitialTouchY = j;
        j = 0;
        if (bool1) {
          j = 0x0 | 0x1;
        }
        k = j;
        if (bool2) {
          k = j | 0x2;
        }
        startNestedScroll(k, 0);
        j = i3;
      }
      if (j == 0) {
        mVelocityTracker.addMovement((MotionEvent)localObject);
      }
      ((MotionEvent)localObject).recycle();
      return true;
    }
    return false;
  }
  
  public void postAnimationRunner()
  {
    if ((!mPostedAnimatorRunner) && (mIsAttached))
    {
      ViewCompat.postOnAnimation(this, mItemAnimatorRunner);
      mPostedAnimatorRunner = true;
    }
  }
  
  public final boolean predictiveItemAnimationsEnabled()
  {
    return (mItemAnimator != null) && (mLayout.supportsPredictiveItemAnimations());
  }
  
  public final void processAdapterUpdatesAndSetAnimationFlags()
  {
    if (mDataSetHasChangedAfterLayout)
    {
      mAdapterHelper.write();
      if (mRunningLayoutOrScroll) {
        mLayout.onItemsChanged(this);
      }
    }
    if (predictiveItemAnimationsEnabled()) {
      mAdapterHelper.a();
    } else {
      mAdapterHelper.b();
    }
    boolean bool1 = mItemsAddedOrRemoved;
    boolean bool2 = false;
    int j;
    if ((!bool1) && (!mItemsChanged)) {
      j = 0;
    } else {
      j = 1;
    }
    y localY = mState;
    if ((mFirstLayoutComplete) && (mItemAnimator != null) && ((mDataSetHasChangedAfterLayout) || (j != 0) || (mLayout.mDataSetHasChangedAfterLayout)) && ((!mDataSetHasChangedAfterLayout) || (mAdapter.hasStableIds()))) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    mRunSimpleAnimations = bool1;
    localY = mState;
    bool1 = bool2;
    if (mRunSimpleAnimations)
    {
      bool1 = bool2;
      if (j != 0)
      {
        bool1 = bool2;
        if (!mDataSetHasChangedAfterLayout)
        {
          bool1 = bool2;
          if (predictiveItemAnimationsEnabled()) {
            bool1 = true;
          }
        }
      }
    }
    mRunPredictiveAnimations = bool1;
  }
  
  public final void pullGlows(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    int j = 0;
    if (paramFloat2 < 0.0F)
    {
      ensureLeftGlow();
      org.core.widget.EdgeEffectCompat.onPull(mLeftGlow, -paramFloat2 / getWidth(), 1.0F - paramFloat3 / getHeight());
      j = 1;
    }
    else if (paramFloat2 > 0.0F)
    {
      ensureRightGlow();
      org.core.widget.EdgeEffectCompat.onPull(mRightGlow, paramFloat2 / getWidth(), paramFloat3 / getHeight());
      j = 1;
    }
    if (paramFloat4 < 0.0F)
    {
      ensureTopGlow();
      org.core.widget.EdgeEffectCompat.onPull(mTopGlow, -paramFloat4 / getHeight(), paramFloat1 / getWidth());
      j = 1;
    }
    else if (paramFloat4 > 0.0F)
    {
      ensureBottomGlow();
      org.core.widget.EdgeEffectCompat.onPull(mBottomGlow, paramFloat4 / getHeight(), 1.0F - paramFloat1 / getWidth());
      j = 1;
    }
    if ((j != 0) || (paramFloat2 != 0.0F) || (paramFloat4 != 0.0F)) {
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public void recordAnimationInfoIfBouncedHiddenView(b0 paramB0, RecyclerView.l.c paramC)
  {
    paramB0.setFlags(0, 8192);
    if ((mState.mTrackOldChangeHolders) && (paramB0.isUpdated()) && (!paramB0.isRemoved()) && (!paramB0.shouldIgnore()))
    {
      long l = getChangedHolderKey(paramB0);
      mViewInfoStore.clear(l, paramB0);
    }
    mViewInfoStore.c(paramB0, paramC);
  }
  
  public final void releaseGlows()
  {
    boolean bool2 = false;
    EdgeEffect localEdgeEffect = mLeftGlow;
    if (localEdgeEffect != null)
    {
      localEdgeEffect.onRelease();
      bool2 = mLeftGlow.isFinished();
    }
    localEdgeEffect = mTopGlow;
    boolean bool1 = bool2;
    if (localEdgeEffect != null)
    {
      localEdgeEffect.onRelease();
      bool1 = bool2 | mTopGlow.isFinished();
    }
    localEdgeEffect = mRightGlow;
    bool2 = bool1;
    if (localEdgeEffect != null)
    {
      localEdgeEffect.onRelease();
      bool2 = bool1 | mRightGlow.isFinished();
    }
    localEdgeEffect = mBottomGlow;
    bool1 = bool2;
    if (localEdgeEffect != null)
    {
      localEdgeEffect.onRelease();
      bool1 = bool2 | mBottomGlow.isFinished();
    }
    if (bool1) {
      ViewCompat.postInvalidateOnAnimation(this);
    }
  }
  
  public boolean removeAnimatingView(View paramView)
  {
    eatRequestLayout();
    boolean bool = mChildHelper.removeViewIfHidden(paramView);
    if (bool)
    {
      paramView = getChildViewHolderInt(paramView);
      mRecycler.unscrapView(paramView);
      mRecycler.recycleViewHolderInternal(paramView);
    }
    resumeRequestLayout(bool ^ true);
    return bool;
  }
  
  public void removeDetachedView(View paramView, boolean paramBoolean)
  {
    b0 localB0 = getChildViewHolderInt(paramView);
    if (localB0 != null) {
      if (localB0.isTmpDetached())
      {
        localB0.clearTmpDetachFlag();
      }
      else if (!localB0.shouldIgnore())
      {
        paramView = new StringBuilder();
        paramView.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
        paramView.append(localB0);
        paramView.append(append());
        throw new IllegalArgumentException(paramView.toString());
      }
    }
    paramView.clearAnimation();
    dispatchChildDetached(paramView);
    super.removeDetachedView(paramView, paramBoolean);
  }
  
  public void removeItemDecoration(n paramN)
  {
    o localO = mLayout;
    if (localO != null) {
      localO.assertNotInLayoutOrScroll("Cannot remove item decoration during a scroll  or layout");
    }
    mItemDecorations.remove(paramN);
    if (mItemDecorations.isEmpty())
    {
      boolean bool;
      if (getOverScrollMode() == 2) {
        bool = true;
      } else {
        bool = false;
      }
      setWillNotDraw(bool);
    }
    markItemDecorInsetsDirty();
    requestLayout();
  }
  
  public void removeOnItemTouchListener(r paramR)
  {
    mOnItemTouchListeners.remove(paramR);
    if (mActiveOnItemTouchListener == paramR) {
      mActiveOnItemTouchListener = null;
    }
  }
  
  public void removeOnScrollListener(s paramS)
  {
    List localList = mScrollListeners;
    if (localList != null) {
      localList.remove(paramS);
    }
  }
  
  public void repositionShadowingViews()
  {
    int k = mChildHelper.getChildCount();
    int j = 0;
    while (j < k)
    {
      View localView = mChildHelper.getChildAt(j);
      Object localObject = getChildViewHolder(localView);
      if (localObject != null)
      {
        localObject = mShadowingHolder;
        if (localObject != null)
        {
          localObject = itemView;
          int n = localView.getLeft();
          int i1 = localView.getTop();
          if ((n != ((View)localObject).getLeft()) || (i1 != ((View)localObject).getTop())) {
            ((View)localObject).layout(n, i1, ((View)localObject).getWidth() + n, ((View)localObject).getHeight() + i1);
          }
        }
      }
      j += 1;
    }
  }
  
  public void requestChildFocus(View paramView1, View paramView2)
  {
    if ((!mLayout.onRequestChildFocus(this, paramView1, paramView2)) && (paramView2 != null)) {
      draw(paramView1, paramView2);
    }
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean)
  {
    return mLayout.requestChildRectangleOnScreen(this, paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean)
  {
    int k = mOnItemTouchListeners.size();
    int j = 0;
    while (j < k)
    {
      ((r)mOnItemTouchListeners.get(j)).onRequestDisallowInterceptTouchEvent(paramBoolean);
      j += 1;
    }
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout()
  {
    if ((mEatRequestLayout == 0) && (!mLayoutFrozen))
    {
      super.requestLayout();
      return;
    }
    mLayoutRequestEaten = true;
  }
  
  public final void resetTouch()
  {
    VelocityTracker localVelocityTracker = mVelocityTracker;
    if (localVelocityTracker != null) {
      localVelocityTracker.clear();
    }
    stopNestedScroll(0);
    releaseGlows();
  }
  
  public void resumeRequestLayout()
  {
    scrollByInternal(true);
  }
  
  public void resumeRequestLayout(boolean paramBoolean)
  {
    if (mEatRequestLayout < 1) {
      mEatRequestLayout = 1;
    }
    if ((!paramBoolean) && (!mLayoutFrozen)) {
      mLayoutRequestEaten = false;
    }
    if (mEatRequestLayout == 1)
    {
      if ((paramBoolean) && (mLayoutRequestEaten) && (!mLayoutFrozen) && (mLayout != null) && (mAdapter != null)) {
        dispatchLayout();
      }
      if (!mLayoutFrozen) {
        mLayoutRequestEaten = false;
      }
    }
    mEatRequestLayout -= 1;
  }
  
  public final void run()
  {
    if ((mDirection) && (mAdapter != null) && (hasFocus()) && (getDescendantFocusability() != 393216))
    {
      if ((getDescendantFocusability() == 131072) && (isFocused())) {
        return;
      }
      if (!isFocused())
      {
        localObject1 = getFocusedChild();
        if ((mScale) && ((((View)localObject1).getParent() == null) || (!((View)localObject1).hasFocus())))
        {
          if (mChildHelper.getChildCount() == 0) {
            requestFocus();
          }
        }
        else if (!mChildHelper.isHidden((View)localObject1)) {
          return;
        }
      }
      Object localObject2 = null;
      Object localObject1 = localObject2;
      if (mState.id != -1L)
      {
        localObject1 = localObject2;
        if (mAdapter.hasStableIds()) {
          localObject1 = findViewHolderForItemId(mState.id);
        }
      }
      localObject2 = null;
      if ((localObject1 != null) && (!mChildHelper.isHidden(itemView)) && (itemView.hasFocusable()))
      {
        localObject1 = itemView;
      }
      else
      {
        localObject1 = localObject2;
        if (mChildHelper.getChildCount() > 0) {
          localObject1 = draw();
        }
      }
      if (localObject1 != null)
      {
        int j = mState.progressBar;
        localObject2 = localObject1;
        if (j != -1L)
        {
          View localView = ((View)localObject1).findViewById(j);
          localObject2 = localObject1;
          if (localView != null)
          {
            localObject2 = localObject1;
            if (localView.isFocusable()) {
              localObject2 = localView;
            }
          }
        }
        localObject2.requestFocus();
      }
    }
  }
  
  public void scrollBy(int paramInt1, int paramInt2)
  {
    o localO = mLayout;
    if (localO == null)
    {
      Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    }
    if (mLayoutFrozen) {
      return;
    }
    boolean bool1 = localO.canScrollHorizontally();
    boolean bool2 = mLayout.canScrollVertically();
    if ((bool1) || (bool2))
    {
      int j = 0;
      if (!bool1) {
        paramInt1 = 0;
      }
      if (bool2) {
        j = paramInt2;
      }
      scrollByInternal(paramInt1, j, null);
    }
  }
  
  public void scrollByInternal(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    eatRequestLayout();
    onEnterLayoutOrScroll();
    org.core.models.RecyclerView.beginSection("RV Scroll");
    smoothScrollBy(mState);
    int j = 0;
    int k = 0;
    if (paramInt1 != 0) {
      j = mLayout.scrollHorizontallyBy(paramInt1, mRecycler, mState);
    }
    paramInt1 = k;
    if (paramInt2 != 0) {
      paramInt1 = mLayout.scrollVerticallyBy(paramInt2, mRecycler, mState);
    }
    org.core.models.RecyclerView.endSection();
    repositionShadowingViews();
    resumeRequestLayout();
    resumeRequestLayout(false);
    if (paramArrayOfInt != null)
    {
      paramArrayOfInt[0] = j;
      paramArrayOfInt[1] = paramInt1;
    }
  }
  
  public void scrollByInternal(boolean paramBoolean)
  {
    int j = mLayoutOrScrollCounter - 1;
    mLayoutOrScrollCounter = j;
    if (j < 1)
    {
      mLayoutOrScrollCounter = 0;
      if (paramBoolean)
      {
        dispatchContentChangedIfNecessary();
        a();
      }
    }
  }
  
  public boolean scrollByInternal(int paramInt1, int paramInt2, MotionEvent paramMotionEvent)
  {
    consumePendingUpdateOperations();
    int[] arrayOfInt;
    int j;
    int k;
    int n;
    int i1;
    if (mAdapter != null)
    {
      scrollByInternal(paramInt1, paramInt2, itemView);
      arrayOfInt = itemView;
      j = arrayOfInt[0];
      k = arrayOfInt[1];
      n = paramInt1 - j;
      i1 = paramInt2 - k;
    }
    else
    {
      n = 0;
      i1 = 0;
      j = 0;
      k = 0;
    }
    if (!mItemDecorations.isEmpty()) {
      invalidate();
    }
    if (dispatchNestedScroll(j, k, n, i1, mScrollOffset, 0))
    {
      paramInt1 = mLastTouchX;
      arrayOfInt = mScrollOffset;
      mLastTouchX = (paramInt1 - arrayOfInt[0]);
      mLastTouchY -= arrayOfInt[1];
      if (paramMotionEvent != null) {
        paramMotionEvent.offsetLocation(arrayOfInt[0], arrayOfInt[1]);
      }
      paramMotionEvent = mNestedOffsets;
      paramInt1 = paramMotionEvent[0];
      arrayOfInt = mScrollOffset;
      paramMotionEvent[0] = (paramInt1 + arrayOfInt[0]);
      paramMotionEvent[1] += arrayOfInt[1];
    }
    else if (getOverScrollMode() != 2)
    {
      if ((paramMotionEvent != null) && (!org.core.view.EdgeEffectCompat.process(paramMotionEvent, 8194))) {
        pullGlows(paramMotionEvent.getX(), n, paramMotionEvent.getY(), i1);
      }
      considerReleasingGlowsOnScroll(paramInt1, paramInt2);
    }
    if (j == 0) {
      if (k == 0) {
        break label257;
      }
    }
    dispatchOnScrolled(j, k);
    label257:
    if (!awakenScrollBars()) {
      invalidate();
    }
    if (j == 0) {
      return k != 0;
    }
    return true;
  }
  
  public void scrollTo(int paramInt1, int paramInt2)
  {
    Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
  }
  
  public void sendAccessibilityEventUnchecked(AccessibilityEvent paramAccessibilityEvent)
  {
    if (shouldDeferAccessibilityEvent(paramAccessibilityEvent)) {
      return;
    }
    super.sendAccessibilityEventUnchecked(paramAccessibilityEvent);
  }
  
  public void setAccessibilityDelegateCompat(RecyclerViewAccessibilityDelegate paramRecyclerViewAccessibilityDelegate)
  {
    mAccessibilityDelegate = paramRecyclerViewAccessibilityDelegate;
    ViewCompat.setAccessibilityDelegate(this, paramRecyclerViewAccessibilityDelegate);
  }
  
  public void setAdapter(g paramG)
  {
    setLayoutFrozen(false);
    setAdapterInternal(paramG, false, true);
    setAdapterInternal(false);
    requestLayout();
  }
  
  public void setAdapterInternal()
  {
    Object localObject = mItemAnimator;
    if (localObject != null) {
      ((l)localObject).endAnimations();
    }
    localObject = mLayout;
    if (localObject != null)
    {
      ((o)localObject).removeAndRecycleAllViews(mRecycler);
      mLayout.removeAndRecycleScrapInt(mRecycler);
    }
    mRecycler.clear();
  }
  
  public final void setAdapterInternal(g paramG, boolean paramBoolean1, boolean paramBoolean2)
  {
    g localG = mAdapter;
    if (localG != null)
    {
      localG.unregisterAdapterDataObserver(mObserver);
      mAdapter.unregisterAdapterDataObserver();
    }
    if ((!paramBoolean1) || (paramBoolean2)) {
      setAdapterInternal();
    }
    mAdapterHelper.write();
    localG = mAdapter;
    mAdapter = paramG;
    if (paramG != null)
    {
      paramG.registerAdapterDataObserver(mObserver);
      paramG.registerAdapterDataObserver();
    }
    paramG = mLayout;
    if (paramG != null) {
      paramG.removeAndRecycleAllViews();
    }
    mRecycler.onAdapterChanged(localG, mAdapter, paramBoolean1);
    mState.mStructureChanged = true;
  }
  
  public void setAdapterInternal(boolean paramBoolean)
  {
    mRunningLayoutOrScroll |= paramBoolean;
    mDataSetHasChangedAfterLayout = true;
    markKnownViewsInvalid();
  }
  
  public void setChildDrawingOrderCallback(j paramJ)
  {
    if (paramJ == mChildDrawingOrderCallback) {
      return;
    }
    mChildDrawingOrderCallback = paramJ;
    boolean bool;
    if (paramJ != null) {
      bool = true;
    } else {
      bool = false;
    }
    setChildrenDrawingOrderEnabled(bool);
  }
  
  public void setClipToPadding(boolean paramBoolean)
  {
    if (paramBoolean != mClipToPadding) {
      invalidateGlows();
    }
    mClipToPadding = paramBoolean;
    super.setClipToPadding(paramBoolean);
    if (mFirstLayoutComplete) {
      requestLayout();
    }
  }
  
  public void setEdgeEffectFactory(k paramK)
  {
    org.core.data.Item.invoke(paramK);
    args = paramK;
    invalidateGlows();
  }
  
  public void setHasFixedSize(boolean paramBoolean)
  {
    mHasFixedSize = paramBoolean;
  }
  
  public void setItemAnimator(l paramL)
  {
    l localL = mItemAnimator;
    if (localL != null)
    {
      localL.endAnimations();
      mItemAnimator.setListener(null);
    }
    mItemAnimator = paramL;
    if (paramL != null) {
      paramL.setListener(mItemAnimatorListener);
    }
  }
  
  public void setItemViewCacheSize(int paramInt)
  {
    mRecycler.setViewCacheSize(paramInt);
  }
  
  public void setLayoutFrozen(boolean paramBoolean)
  {
    if (paramBoolean != mLayoutFrozen)
    {
      onPostExecute("Do not setLayoutFrozen in layout or scroll");
      if (!paramBoolean)
      {
        mLayoutFrozen = false;
        if ((mLayoutRequestEaten) && (mLayout != null) && (mAdapter != null)) {
          requestLayout();
        }
        mLayoutRequestEaten = false;
        return;
      }
      long l = SystemClock.uptimeMillis();
      onTouchEvent(MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0));
      mLayoutFrozen = true;
      mIgnoreMotionEventTillDown = true;
      stopScroll();
    }
  }
  
  public void setLayoutManager(o paramO)
  {
    if (paramO == mLayout) {
      return;
    }
    stopScroll();
    Object localObject;
    if (mLayout != null)
    {
      localObject = mItemAnimator;
      if (localObject != null) {
        ((l)localObject).endAnimations();
      }
      mLayout.removeAndRecycleAllViews(mRecycler);
      mLayout.removeAndRecycleScrapInt(mRecycler);
      mRecycler.clear();
      if (mIsAttached) {
        mLayout.onDetachedFromWindow(this, mRecycler);
      }
      mLayout.setRecyclerView(null);
      mLayout = null;
    }
    else
    {
      mRecycler.clear();
    }
    mChildHelper.removeAllViewsUnfiltered();
    mLayout = paramO;
    if (paramO != null) {
      if (mRecyclerView == null)
      {
        paramO.setRecyclerView(this);
        if (mIsAttached) {
          mLayout.dispatchAttachedToWindow(this);
        }
      }
      else
      {
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append("LayoutManager ");
        ((StringBuilder)localObject).append(paramO);
        ((StringBuilder)localObject).append(" is already attached to a RecyclerView:");
        ((StringBuilder)localObject).append(mRecyclerView.append());
        throw new IllegalArgumentException(((StringBuilder)localObject).toString());
      }
    }
    mRecycler.write();
    requestLayout();
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean)
  {
    getScrollingChildHelper().setNestedScrollingEnabled(paramBoolean);
  }
  
  public void setOnFlingListener(q paramQ)
  {
    mRecyclerListener = paramQ;
  }
  
  public void setOnScrollListener(s paramS)
  {
    mScrollListener = paramS;
  }
  
  public void setPreserveFocusAfterLayout(boolean paramBoolean)
  {
    mDirection = paramBoolean;
  }
  
  public void setRecycledViewPool(t paramT)
  {
    mRecycler.setRecycledViewPool(paramT);
  }
  
  public void setRecyclerListener(v paramV)
  {
    i = paramV;
  }
  
  public void setScrollState(int paramInt)
  {
    if (paramInt == mScrollState) {
      return;
    }
    mScrollState = paramInt;
    if (paramInt != 2) {
      stopScrollersInternal();
    }
    dispatchOnScrollStateChanged(paramInt);
  }
  
  public void setScrollingTouchSlop(int paramInt)
  {
    ViewConfiguration localViewConfiguration = ViewConfiguration.get(getContext());
    if (paramInt != 0) {
      if (paramInt != 1)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("setScrollingTouchSlop(): bad argument constant ");
        localStringBuilder.append(paramInt);
        localStringBuilder.append("; using default value");
        Log.w("RecyclerView", localStringBuilder.toString());
      }
      else
      {
        mTouchSlop = localViewConfiguration.getScaledPagingTouchSlop();
        return;
      }
    }
    mTouchSlop = localViewConfiguration.getScaledTouchSlop();
  }
  
  public void setViewCacheExtension(z paramZ)
  {
    mRecycler.setViewCacheExtension(paramZ);
  }
  
  public boolean shouldDeferAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    if (isComputingLayout())
    {
      int j = 0;
      if (paramAccessibilityEvent != null) {
        j = AccessibilityEventCompat.getContentChangeTypes(paramAccessibilityEvent);
      }
      int k = j;
      if (j == 0) {
        k = 0;
      }
      mEatenAccessibilityChangeFlags |= k;
      return true;
    }
    return false;
  }
  
  public final void smoothScrollBy()
  {
    if (ViewCompat.create(this) == 0) {
      ViewCompat.postInvalidateOnAnimation(this, 8);
    }
  }
  
  public void smoothScrollBy(int paramInt1, int paramInt2)
  {
    smoothScrollBy(paramInt1, paramInt2, null);
  }
  
  public void smoothScrollBy(int paramInt1, int paramInt2, Interpolator paramInterpolator)
  {
    o localO = mLayout;
    if (localO == null)
    {
      Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    }
    if (mLayoutFrozen) {
      return;
    }
    if (!localO.canScrollHorizontally()) {
      paramInt1 = 0;
    }
    if (!mLayout.canScrollVertically()) {
      paramInt2 = 0;
    }
    if ((paramInt1 != 0) || (paramInt2 != 0)) {
      mViewFlinger.smoothScrollBy(paramInt1, paramInt2, paramInterpolator);
    }
  }
  
  public final void smoothScrollBy(y paramY)
  {
    if (getScrollState() == 2)
    {
      OverScroller localOverScroller = mViewFlinger.mScroller;
      mTouchMode = (localOverScroller.getFinalX() - localOverScroller.getCurrX());
      localOverScroller.getFinalY();
      localOverScroller.getCurrY();
      return;
    }
    mTouchMode = 0;
  }
  
  public boolean startNestedScroll(int paramInt)
  {
    return getScrollingChildHelper().startNestedScroll(paramInt);
  }
  
  public boolean startNestedScroll(int paramInt1, int paramInt2)
  {
    return getScrollingChildHelper().startNestedScroll(paramInt1, paramInt2);
  }
  
  public void stopNestedScroll()
  {
    getScrollingChildHelper().stopNestedScroll();
  }
  
  public void stopNestedScroll(int paramInt)
  {
    getScrollingChildHelper().stopNestedScroll(paramInt);
  }
  
  public void stopScroll()
  {
    setScrollState(0);
    stopScrollersInternal();
  }
  
  public final void stopScrollersInternal()
  {
    mViewFlinger.stop();
    o localO = mLayout;
    if (localO != null) {
      localO.stopSmoothScroller();
    }
  }
  
  public void supportsChangeAnimations() {}
  
  public void viewRangeUpdate(int paramInt1, int paramInt2, Object paramObject)
  {
    int k = mChildHelper.getUnfilteredChildCount();
    int j = 0;
    while (j < k)
    {
      View localView = mChildHelper.getUnfilteredChildAt(j);
      b0 localB0 = getChildViewHolderInt(localView);
      if ((localB0 != null) && (!localB0.shouldIgnore()))
      {
        int n = mPosition;
        if ((n >= paramInt1) && (n < paramInt1 + paramInt2))
        {
          localB0.addFlags(2);
          localB0.addChangePayload(paramObject);
          getLayoutParamsmInsetsDirty = true;
        }
      }
      j += 1;
    }
    mRecycler.viewRangeUpdate(paramInt1, paramInt2);
  }
  
  public void viewRangeUpdate(View paramView)
  {
    paramView = getChildViewHolderInt(paramView);
    supportsChangeAnimations();
    g localG = mAdapter;
    if ((localG != null) && (paramView != null)) {
      localG.setHasStableIds();
    }
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    public void run()
    {
      RecyclerView localRecyclerView = RecyclerView.this;
      if (mFirstLayoutComplete)
      {
        if (localRecyclerView.isLayoutRequested()) {
          return;
        }
        localRecyclerView = RecyclerView.this;
        if (!mIsAttached)
        {
          localRecyclerView.requestLayout();
          return;
        }
        if (mLayoutFrozen)
        {
          mLayoutRequestEaten = true;
          return;
        }
        localRecyclerView.consumePendingUpdateOperations();
      }
    }
  }
  
  public class a0
    implements Runnable
  {
    public boolean h = false;
    public boolean i = false;
    public Interpolator mInterpolator = RecyclerView.mInterpolator;
    public int mLastFlingX;
    public int mLastFlingY;
    public OverScroller mScroller = new OverScroller(getContext(), RecyclerView.mInterpolator);
    
    public a0() {}
    
    public final void b()
    {
      h = false;
      i = true;
    }
    
    public final int computeScrollDuration(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      int k = Math.abs(paramInt1);
      int m = Math.abs(paramInt2);
      int j;
      if (k > m) {
        j = 1;
      } else {
        j = 0;
      }
      paramInt3 = (int)Math.sqrt(paramInt3 * paramInt3 + paramInt4 * paramInt4);
      paramInt2 = (int)Math.sqrt(paramInt1 * paramInt1 + paramInt2 * paramInt2);
      RecyclerView localRecyclerView = RecyclerView.this;
      if (j != 0) {
        paramInt1 = localRecyclerView.getWidth();
      } else {
        paramInt1 = localRecyclerView.getHeight();
      }
      paramInt4 = paramInt1 / 2;
      float f3 = Math.min(1.0F, paramInt2 * 1.0F / paramInt1);
      float f1 = paramInt4;
      float f2 = paramInt4;
      f3 = distanceInfluenceForSnapDuration(f3);
      if (paramInt3 > 0)
      {
        paramInt1 = Math.round(Math.abs((f1 + f2 * f3) / paramInt3) * 1000.0F) * 4;
      }
      else
      {
        if (j != 0) {
          paramInt2 = k;
        } else {
          paramInt2 = m;
        }
        paramInt1 = (int)((paramInt2 / paramInt1 + 1.0F) * 300.0F);
      }
      return Math.min(paramInt1, 2000);
    }
    
    public final void d()
    {
      i = false;
      if (h) {
        postOnAnimation();
      }
    }
    
    public final float distanceInfluenceForSnapDuration(float paramFloat)
    {
      return (float)Math.sin((paramFloat - 0.5F) * 0.47123894F);
    }
    
    public void fling(int paramInt1, int paramInt2)
    {
      setScrollState(2);
      mLastFlingY = 0;
      mLastFlingX = 0;
      mScroller.fling(0, 0, paramInt1, paramInt2, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
      postOnAnimation();
    }
    
    public void postOnAnimation()
    {
      if (i)
      {
        h = true;
        return;
      }
      removeCallbacks(this);
      ViewCompat.postOnAnimation(RecyclerView.this, this);
    }
    
    public void run()
    {
      if (mLayout == null)
      {
        stop();
        return;
      }
      b();
      consumePendingUpdateOperations();
      Object localObject1 = mScroller;
      Object localObject2 = mLayout;
      if (((OverScroller)localObject1).computeScrollOffset())
      {
        localObject2 = mScrollConsumed;
        int i6 = ((OverScroller)localObject1).getCurrX();
        int i7 = ((OverScroller)localObject1).getCurrY();
        int k = i6 - mLastFlingX;
        int j = i7 - mLastFlingY;
        int i1 = 0;
        int i2 = 0;
        mLastFlingX = i6;
        mLastFlingY = i7;
        int i3 = 0;
        int n = k;
        int m = j;
        if (dispatchNestedPreScroll(k, j, (int[])localObject2, null, 1))
        {
          n = k - localObject2[0];
          m = j - localObject2[1];
        }
        localObject2 = RecyclerView.this;
        int i4;
        if (mAdapter != null)
        {
          ((RecyclerView)localObject2).scrollByInternal(n, m, itemView);
          localObject2 = itemView;
          i1 = localObject2[0];
          i2 = localObject2[1];
          i3 = n - i1;
          i4 = m - i2;
        }
        else
        {
          i4 = 0;
        }
        if (!mItemDecorations.isEmpty()) {
          invalidate();
        }
        if (getOverScrollMode() != 2) {
          considerReleasingGlowsOnScroll(n, m);
        }
        if ((!dispatchNestedScroll(i1, i2, i3, i4, null, 1)) && ((i3 != 0) || (i4 != 0)))
        {
          int i5 = (int)((OverScroller)localObject1).getCurrVelocity();
          j = 0;
          if (i3 != i6) {
            if (i3 < 0) {
              j = -i5;
            } else if (i3 > 0) {
              j = i5;
            } else {
              j = 0;
            }
          }
          k = 0;
          if (i4 != i7) {
            if (i4 < 0) {
              k = -i5;
            } else if (i4 > 0) {
              k = i5;
            } else {
              k = 0;
            }
          }
          if (getOverScrollMode() != 2) {
            absorbGlows(j, k);
          }
          if (((j != 0) || (i3 == i6) || (((OverScroller)localObject1).getFinalX() == 0)) && ((k != 0) || (i4 == i7) || (((OverScroller)localObject1).getFinalY() == 0))) {
            ((OverScroller)localObject1).abortAnimation();
          }
        }
        if ((i1 != 0) || (i2 != 0)) {
          dispatchOnScrolled(i1, i2);
        }
        if (!RecyclerView.access$getAwakenScrollBars(RecyclerView.this)) {
          invalidate();
        }
        if ((m != 0) && (mLayout.canScrollVertically()) && (i2 == m)) {
          j = 1;
        } else {
          j = 0;
        }
        if ((n != 0) && (mLayout.canScrollHorizontally()) && (i1 == n)) {
          k = 1;
        } else {
          k = 0;
        }
        if (((n != 0) || (m != 0)) && (k == 0) && (j == 0)) {
          j = 0;
        } else {
          j = 1;
        }
        if ((!((OverScroller)localObject1).isFinished()) && ((j != 0) || (hasNestedScrollingParent(1))))
        {
          postOnAnimation();
          localObject1 = RecyclerView.this;
          localObject2 = q;
          if (localObject2 != null) {
            ((b)localObject2).a((RecyclerView)localObject1, n, m);
          }
        }
        else
        {
          setScrollState(0);
          if (RecyclerView.this$0) {
            d.a();
          }
          stopNestedScroll(1);
        }
      }
      d();
    }
    
    public void smoothScrollBy(int paramInt1, int paramInt2, int paramInt3, Interpolator paramInterpolator)
    {
      if (mInterpolator != paramInterpolator)
      {
        mInterpolator = paramInterpolator;
        mScroller = new OverScroller(getContext(), paramInterpolator);
      }
      setScrollState(2);
      mLastFlingY = 0;
      mLastFlingX = 0;
      mScroller.startScroll(0, 0, paramInt1, paramInt2, paramInt3);
      if (Build.VERSION.SDK_INT < 23) {
        mScroller.computeScrollOffset();
      }
      postOnAnimation();
    }
    
    public void smoothScrollBy(int paramInt1, int paramInt2, Interpolator paramInterpolator)
    {
      int j = computeScrollDuration(paramInt1, paramInt2, 0, 0);
      Interpolator localInterpolator = paramInterpolator;
      if (paramInterpolator == null) {
        localInterpolator = RecyclerView.mInterpolator;
      }
      smoothScrollBy(paramInt1, paramInt2, j, localInterpolator);
    }
    
    public void stop()
    {
      removeCallbacks(this);
      mScroller.abortAnimation();
    }
  }
  
  public class b
    implements Runnable
  {
    public b() {}
    
    public void run()
    {
      RecyclerView.l localL = mItemAnimator;
      if (localL != null) {
        localL.runPendingAnimations();
      }
      mPostedAnimatorRunner = false;
    }
  }
  
  public static abstract class b0
  {
    public static final List<Object> FULLUPDATE_PAYLOADS = ;
    public int a = 0;
    public int f = -1;
    public final View itemView;
    public WeakReference<RecyclerView> l;
    public int mFlags;
    public boolean mInChangeScrap = false;
    public int mIsRecyclableCount = 0;
    public long mItemId = -1L;
    public int mItemViewType = -1;
    public int mOldPosition = -1;
    public RecyclerView mOwnerRecyclerView;
    public List<Object> mPayloads = null;
    public int mPosition = -1;
    public int mPreLayoutPosition = -1;
    public RecyclerView.u mScrapContainer = null;
    public b0 mShadowedHolder = null;
    public b0 mShadowingHolder = null;
    public List<Object> mUnmodifiedPayloads = null;
    
    public b0(View paramView)
    {
      if (paramView != null)
      {
        itemView = paramView;
        return;
      }
      throw new IllegalArgumentException("itemView may not be null");
    }
    
    public final int a()
    {
      RecyclerView localRecyclerView = mOwnerRecyclerView;
      if (localRecyclerView == null) {
        return -1;
      }
      return localRecyclerView.getAdapterPositionFor(this);
    }
    
    public void a(RecyclerView paramRecyclerView)
    {
      paramRecyclerView.a(this, a);
      a = 0;
    }
    
    public void access$1500(RecyclerView paramRecyclerView)
    {
      int i = f;
      if (i != -1) {
        a = i;
      } else {
        a = ViewCompat.getImportantForAccessibility(itemView);
      }
      paramRecyclerView.a(this, 4);
    }
    
    public void addChangePayload(Object paramObject)
    {
      if (paramObject == null)
      {
        addFlags(1024);
        return;
      }
      if ((0x400 & mFlags) == 0)
      {
        createPayloadsIfNeeded();
        mPayloads.add(paramObject);
      }
    }
    
    public void addFlags(int paramInt)
    {
      mFlags |= paramInt;
    }
    
    public void clearOldPosition()
    {
      mOldPosition = -1;
      mPreLayoutPosition = -1;
    }
    
    public void clearPayload()
    {
      List localList = mPayloads;
      if (localList != null) {
        localList.clear();
      }
      mFlags &= 0xFBFF;
    }
    
    public void clearReturnedFromScrapFlag()
    {
      mFlags &= 0xFFFFFFDF;
    }
    
    public void clearTmpDetachFlag()
    {
      mFlags &= 0xFEFF;
    }
    
    public final void createPayloadsIfNeeded()
    {
      if (mPayloads == null)
      {
        ArrayList localArrayList = new ArrayList();
        mPayloads = localArrayList;
        mUnmodifiedPayloads = Collections.unmodifiableList(localArrayList);
      }
    }
    
    public boolean doesTransientStatePreventRecycling()
    {
      return ((mFlags & 0x10) == 0) && (ViewCompat.hasTransientState(itemView));
    }
    
    public void flagRemovedAndOffsetPosition(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      addFlags(8);
      offsetPosition(paramInt2, paramBoolean);
      mPosition = paramInt1;
    }
    
    public final long getItemId()
    {
      return mItemId;
    }
    
    public final int getItemViewType()
    {
      return mItemViewType;
    }
    
    public final int getLayoutPosition()
    {
      int j = mPreLayoutPosition;
      int i = j;
      if (j == -1) {
        i = mPosition;
      }
      return i;
    }
    
    public final int getOldPosition()
    {
      return mOldPosition;
    }
    
    public List getUnmodifiedPayloads()
    {
      if ((mFlags & 0x400) == 0)
      {
        List localList = mPayloads;
        if ((localList != null) && (localList.size() != 0)) {
          return mUnmodifiedPayloads;
        }
        return FULLUPDATE_PAYLOADS;
      }
      return FULLUPDATE_PAYLOADS;
    }
    
    public boolean hasAnyOfTheFlags(int paramInt)
    {
      return (mFlags & paramInt) != 0;
    }
    
    public boolean isAdapterPositionUnknown()
    {
      return ((mFlags & 0x200) != 0) || (isInvalid());
    }
    
    public boolean isBound()
    {
      return (mFlags & 0x1) != 0;
    }
    
    public boolean isInvalid()
    {
      return (mFlags & 0x4) != 0;
    }
    
    public final boolean isRecyclable()
    {
      return ((mFlags & 0x10) == 0) && (!ViewCompat.hasTransientState(itemView));
    }
    
    public boolean isRemoved()
    {
      return (mFlags & 0x8) != 0;
    }
    
    public boolean isScrap()
    {
      return mScrapContainer != null;
    }
    
    public boolean isTmpDetached()
    {
      return (mFlags & 0x100) != 0;
    }
    
    public boolean isUpdated()
    {
      return (mFlags & 0x2) != 0;
    }
    
    public boolean needsUpdate()
    {
      return (mFlags & 0x2) != 0;
    }
    
    public void offsetPosition()
    {
      if (mOldPosition == -1) {
        mOldPosition = mPosition;
      }
    }
    
    public void offsetPosition(int paramInt, boolean paramBoolean)
    {
      if (mOldPosition == -1) {
        mOldPosition = mPosition;
      }
      if (mPreLayoutPosition == -1) {
        mPreLayoutPosition = mPosition;
      }
      if (paramBoolean) {
        mPreLayoutPosition += paramInt;
      }
      mPosition += paramInt;
      if (itemView.getLayoutParams() != null) {
        itemView.getLayoutParams()).mInsetsDirty = true;
      }
    }
    
    public void resetInternal()
    {
      mFlags = 0;
      mPosition = -1;
      mOldPosition = -1;
      mItemId = -1L;
      mPreLayoutPosition = -1;
      mIsRecyclableCount = 0;
      mShadowedHolder = null;
      mShadowingHolder = null;
      clearPayload();
      a = 0;
      f = -1;
      RecyclerView.next(this);
    }
    
    public void setFlags(int paramInt1, int paramInt2)
    {
      mFlags = (mFlags & paramInt2 | paramInt1 & paramInt2);
    }
    
    public final void setIsRecyclable(boolean paramBoolean)
    {
      int i = mIsRecyclableCount;
      if (paramBoolean) {
        i -= 1;
      } else {
        i += 1;
      }
      mIsRecyclableCount = i;
      if (i < 0)
      {
        mIsRecyclableCount = 0;
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for ");
        localStringBuilder.append(this);
        Log.e("View", localStringBuilder.toString());
        return;
      }
      if ((!paramBoolean) && (i == 1))
      {
        mFlags |= 0x10;
        return;
      }
      if ((paramBoolean) && (mIsRecyclableCount == 0)) {
        mFlags &= 0xFFFFFFEF;
      }
    }
    
    public void setScrapContainer(RecyclerView.u paramU, boolean paramBoolean)
    {
      mScrapContainer = paramU;
      mInChangeScrap = paramBoolean;
    }
    
    public boolean shouldBeKeptAsChild()
    {
      return (mFlags & 0x10) != 0;
    }
    
    public boolean shouldIgnore()
    {
      return (mFlags & 0x80) != 0;
    }
    
    public String toString()
    {
      Object localObject = new StringBuilder();
      ((StringBuilder)localObject).append("ViewHolder{");
      ((StringBuilder)localObject).append(Integer.toHexString(hashCode()));
      ((StringBuilder)localObject).append(" position=");
      ((StringBuilder)localObject).append(mPosition);
      ((StringBuilder)localObject).append(" id=");
      ((StringBuilder)localObject).append(mItemId);
      ((StringBuilder)localObject).append(", oldPos=");
      ((StringBuilder)localObject).append(mOldPosition);
      ((StringBuilder)localObject).append(", pLpos:");
      ((StringBuilder)localObject).append(mPreLayoutPosition);
      StringBuilder localStringBuilder = new StringBuilder(((StringBuilder)localObject).toString());
      if (isScrap())
      {
        localStringBuilder.append(" scrap ");
        if (mInChangeScrap) {
          localObject = "[changeScrap]";
        } else {
          localObject = "[attachedScrap]";
        }
        localStringBuilder.append((String)localObject);
      }
      if (isInvalid()) {
        localStringBuilder.append(" invalid");
      }
      if (!isBound()) {
        localStringBuilder.append(" unbound");
      }
      if (needsUpdate()) {
        localStringBuilder.append(" update");
      }
      if (isRemoved()) {
        localStringBuilder.append(" removed");
      }
      if (shouldIgnore()) {
        localStringBuilder.append(" ignored");
      }
      if (isTmpDetached()) {
        localStringBuilder.append(" tmpDetached");
      }
      if (!isRecyclable())
      {
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append(" not recyclable(");
        ((StringBuilder)localObject).append(mIsRecyclableCount);
        ((StringBuilder)localObject).append(")");
        localStringBuilder.append(((StringBuilder)localObject).toString());
      }
      if (isAdapterPositionUnknown()) {
        localStringBuilder.append(" undefined adapter position");
      }
      if (itemView.getParent() == null) {
        localStringBuilder.append(" no parent");
      }
      localStringBuilder.append("}");
      return localStringBuilder.toString();
    }
    
    public void unScrap()
    {
      mScrapContainer.unscrapView(this);
    }
    
    public boolean wasReturnedFromScrap()
    {
      return (mFlags & 0x20) != 0;
    }
  }
  
  public static final class c
    implements Interpolator
  {
    public c() {}
    
    public float getInterpolation(float paramFloat)
    {
      paramFloat -= 1.0F;
      return paramFloat * paramFloat * paramFloat * paramFloat * paramFloat + 1.0F;
    }
  }
  
  public class d
    implements MethodVisitor
  {
    public d() {}
    
    public void a(RecyclerView.b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
    {
      RecyclerView.this.animateChange(paramB0, paramC1, paramC2);
    }
    
    public void animateChange(RecyclerView.b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
    {
      paramB0.setIsRecyclable(false);
      RecyclerView localRecyclerView = RecyclerView.this;
      if (mDataSetHasChangedAfterLayout)
      {
        if (mItemAnimator.animateChange(paramB0, paramB0, paramC1, paramC2)) {
          postAnimationRunner();
        }
      }
      else if (mItemAnimator.animatePersistence(paramB0, paramC1, paramC2)) {
        postAnimationRunner();
      }
    }
    
    public void run(RecyclerView.b0 paramB0)
    {
      RecyclerView localRecyclerView = RecyclerView.this;
      mLayout.a(itemView, mRecycler);
    }
    
    public void visitFrame(RecyclerView.b0 paramB0, RecyclerView.l.c paramC1, RecyclerView.l.c paramC2)
    {
      mRecycler.unscrapView(paramB0);
      animateDisappearance(paramB0, paramC1, paramC2);
    }
  }
  
  public class e
    implements AnnotationVisitor
  {
    public e() {}
    
    public void addView(View paramView, int paramInt)
    {
      RecyclerView.this.addView(paramView, paramInt);
      viewRangeUpdate(paramView);
    }
    
    public void attachViewToParent(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
    {
      RecyclerView.b0 localB0 = RecyclerView.getChildViewHolderInt(paramView);
      if (localB0 != null)
      {
        if ((!localB0.isTmpDetached()) && (!localB0.shouldIgnore()))
        {
          paramView = new StringBuilder();
          paramView.append("Called attach on a child which is not detached: ");
          paramView.append(localB0);
          paramView.append(append());
          throw new IllegalArgumentException(paramView.toString());
        }
        localB0.clearTmpDetachFlag();
      }
      RecyclerView.access$getAttachViewToParent(RecyclerView.this, paramView, paramInt, paramLayoutParams);
    }
    
    public void detachViewFromParent(int paramInt)
    {
      Object localObject = getChildAt(paramInt);
      if (localObject != null)
      {
        localObject = RecyclerView.getChildViewHolderInt((View)localObject);
        if (localObject != null)
        {
          if ((((RecyclerView.b0)localObject).isTmpDetached()) && (!((RecyclerView.b0)localObject).shouldIgnore()))
          {
            StringBuilder localStringBuilder = new StringBuilder();
            localStringBuilder.append("called detach on an already detached child ");
            localStringBuilder.append(localObject);
            localStringBuilder.append(append());
            throw new IllegalArgumentException(localStringBuilder.toString());
          }
          ((RecyclerView.b0)localObject).addFlags(256);
        }
      }
      RecyclerView.access$getDetachViewFromParent(RecyclerView.this, paramInt);
    }
    
    public View getChildAt(int paramInt)
    {
      return RecyclerView.this.getChildAt(paramInt);
    }
    
    public int getChildCount()
    {
      return RecyclerView.this.getChildCount();
    }
    
    public RecyclerView.b0 getChildViewHolder(View paramView)
    {
      return RecyclerView.getChildViewHolderInt(paramView);
    }
    
    public int indexOfChild(View paramView)
    {
      return RecyclerView.this.indexOfChild(paramView);
    }
    
    public void onEnteredHiddenState(View paramView)
    {
      paramView = RecyclerView.getChildViewHolderInt(paramView);
      if (paramView != null) {
        paramView.access$1500(RecyclerView.this);
      }
    }
    
    public void onLeftHiddenState(View paramView)
    {
      paramView = RecyclerView.getChildViewHolderInt(paramView);
      if (paramView != null) {
        paramView.a(RecyclerView.this);
      }
    }
    
    public void removeAllViews()
    {
      int j = getChildCount();
      int i = 0;
      while (i < j)
      {
        View localView = getChildAt(i);
        dispatchChildDetached(localView);
        localView.clearAnimation();
        i += 1;
      }
      RecyclerView.this.removeAllViews();
    }
    
    public void removeViewAt(int paramInt)
    {
      View localView = RecyclerView.this.getChildAt(paramInt);
      if (localView != null)
      {
        dispatchChildDetached(localView);
        localView.clearAnimation();
      }
      RecyclerView.this.removeViewAt(paramInt);
    }
  }
  
  public class f
    implements org.objectweb.asm.Item
  {
    public f() {}
    
    public RecyclerView.b0 a(int paramInt)
    {
      RecyclerView.b0 localB0 = findViewHolderForPosition(paramInt, true);
      if (localB0 == null) {
        return null;
      }
      if (mChildHelper.isHidden(itemView)) {
        return null;
      }
      return localB0;
    }
    
    public void a(int paramInt1, int paramInt2)
    {
      offsetPositionRecordsForMove(paramInt1, paramInt2);
      mItemsAddedOrRemoved = true;
    }
    
    public void a(int paramInt1, int paramInt2, Object paramObject)
    {
      viewRangeUpdate(paramInt1, paramInt2, paramObject);
      mItemsChanged = true;
    }
    
    public void a(Label paramLabel)
    {
      b(paramLabel);
    }
    
    public void append(int paramInt1, int paramInt2)
    {
      offsetPositionRecordsForRemove(paramInt1, paramInt2);
      mItemsAddedOrRemoved = true;
    }
    
    public void b(Label paramLabel)
    {
      int i = d;
      if (i != 1)
      {
        if (i != 2)
        {
          if (i != 4)
          {
            if (i != 8) {
              return;
            }
            localRecyclerView = RecyclerView.this;
            mLayout.onItemsMoved(localRecyclerView, a, c, 1);
            return;
          }
          localRecyclerView = RecyclerView.this;
          mLayout.onItemsUpdated(localRecyclerView, a, c, b);
          return;
        }
        localRecyclerView = RecyclerView.this;
        mLayout.onItemsRemoved(localRecyclerView, a, c);
        return;
      }
      RecyclerView localRecyclerView = RecyclerView.this;
      mLayout.onItemsAdded(localRecyclerView, a, c);
    }
    
    public void offsetPositionsForRemovingInvisible(int paramInt1, int paramInt2)
    {
      offsetPositionRecordsForRemove(paramInt1, paramInt2, true);
      Object localObject = RecyclerView.this;
      mItemsAddedOrRemoved = true;
      localObject = mState;
      mDeletedInvisibleItemCountSincePreviousLayout += paramInt2;
    }
    
    public void offsetPositionsForRemovingLaidOutOrNewView(int paramInt1, int paramInt2)
    {
      offsetPositionRecordsForRemove(paramInt1, paramInt2, false);
      mItemsAddedOrRemoved = true;
    }
    
    public void visitFrame(Label paramLabel)
    {
      b(paramLabel);
    }
  }
  
  public static abstract class g<VH extends RecyclerView.b0>
  {
    public boolean mHasStableIds = false;
    public final RecyclerView.h mObservable = new RecyclerView.h();
    
    public g() {}
    
    public abstract RecyclerView.b0 a(ViewGroup paramViewGroup, int paramInt);
    
    public void a() {}
    
    public abstract void a(RecyclerView.b0 paramB0, int paramInt);
    
    public void b(RecyclerView.b0 paramB0, int paramInt)
    {
      a(paramB0, paramInt);
    }
    
    public abstract int getItemCount();
    
    public long getItemId()
    {
      return -1L;
    }
    
    public final void getViewForPosition(RecyclerView.b0 paramB0, int paramInt)
    {
      mPosition = paramInt;
      if (hasStableIds())
      {
        getItemId();
        mItemId = -1L;
      }
      paramB0.setFlags(1, 519);
      org.core.models.RecyclerView.beginSection("RV OnBindView");
      paramB0.getUnmodifiedPayloads();
      b(paramB0, paramInt);
      paramB0.clearPayload();
      paramB0 = itemView.getLayoutParams();
      if ((paramB0 instanceof RecyclerView.p)) {
        mInsetsDirty = true;
      }
      org.core.models.RecyclerView.endSection();
    }
    
    public final boolean hasStableIds()
    {
      return mHasStableIds;
    }
    
    public int isSpecial(int paramInt)
    {
      return 0;
    }
    
    public final RecyclerView.b0 onCreateViewHolder(ViewGroup paramViewGroup, int paramInt)
    {
      try
      {
        org.core.models.RecyclerView.beginSection("RV CreateView");
        paramViewGroup = a(paramViewGroup, paramInt);
        ViewParent localViewParent = itemView.getParent();
        if (localViewParent == null)
        {
          mItemViewType = paramInt;
          org.core.models.RecyclerView.endSection();
          return paramViewGroup;
        }
        throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
      }
      catch (Throwable paramViewGroup)
      {
        org.core.models.RecyclerView.endSection();
        throw paramViewGroup;
      }
    }
    
    public boolean onFailedToRecycleView()
    {
      return false;
    }
    
    public void onViewDetachedFromWindow() {}
    
    public void registerAdapterDataObserver() {}
    
    public void registerAdapterDataObserver(RecyclerView.i paramI)
    {
      mObservable.registerObserver(paramI);
    }
    
    public void setHasStableIds() {}
    
    public void unregisterAdapterDataObserver() {}
    
    public void unregisterAdapterDataObserver(RecyclerView.i paramI)
    {
      mObservable.unregisterObserver(paramI);
    }
  }
  
  public static class h
    extends Observable<RecyclerView.i>
  {
    public h() {}
  }
  
  public static abstract class i
  {
    public i() {}
  }
  
  public static abstract interface j
  {
    public abstract int onGetChildDrawingOrder(int paramInt1, int paramInt2);
  }
  
  public static class k
  {
    public k() {}
    
    public EdgeEffect setSize(RecyclerView paramRecyclerView)
    {
      return new EdgeEffect(paramRecyclerView.getContext());
    }
  }
  
  public static abstract class l
  {
    public long animationDuration = 120L;
    public ArrayList<a> j = new ArrayList();
    public long mChangeDuration = 250L;
    public b mListener = null;
    public long mMoveDuration = 250L;
    public long mRemoveDuration = 120L;
    
    public l() {}
    
    public static int buildAdapterChangeFlagsForAnimations(RecyclerView.b0 paramB0)
    {
      int k = mFlags & 0xE;
      if (paramB0.isInvalid()) {
        return 4;
      }
      int i = k;
      if ((k & 0x4) == 0)
      {
        int m = paramB0.getOldPosition();
        int n = paramB0.a();
        i = k;
        if (m != -1)
        {
          i = k;
          if (n != -1)
          {
            i = k;
            if (m != n) {
              i = k | 0x800;
            }
          }
        }
      }
      return i;
    }
    
    public abstract boolean animateChange(RecyclerView.b0 paramB01, RecyclerView.b0 paramB02, c paramC1, c paramC2);
    
    public abstract boolean animateChange(RecyclerView.b0 paramB0, c paramC1, c paramC2);
    
    public abstract boolean animateDisappearance(RecyclerView.b0 paramB0, c paramC1, c paramC2);
    
    public abstract boolean animatePersistence(RecyclerView.b0 paramB0, c paramC1, c paramC2);
    
    public c b()
    {
      return new c();
    }
    
    public c b(RecyclerView.b0 paramB0)
    {
      c localC = b();
      localC.putShort(paramB0);
      return localC;
    }
    
    public abstract boolean canReuseUpdatedViewHolder(RecyclerView.b0 paramB0);
    
    public boolean canReuseUpdatedViewHolder(RecyclerView.b0 paramB0, List paramList)
    {
      return canReuseUpdatedViewHolder(paramB0);
    }
    
    public final void dispatchAnimationFinished(RecyclerView.b0 paramB0)
    {
      onAnimationFinished();
      b localB = mListener;
      if (localB != null) {
        ((RecyclerView.m)localB).onAnimationFinished(paramB0);
      }
    }
    
    public abstract void endAnimation(RecyclerView.b0 paramB0);
    
    public abstract void endAnimations();
    
    public long getAnimationDuration()
    {
      return animationDuration;
    }
    
    public long getChangeDuration()
    {
      return mChangeDuration;
    }
    
    public long getMoveDuration()
    {
      return mMoveDuration;
    }
    
    public long getRemoveDuration()
    {
      return mRemoveDuration;
    }
    
    public final void i()
    {
      int k = j.size();
      int i = 0;
      while (i < k)
      {
        ((a)j.get(i)).i();
        i += 1;
      }
      j.clear();
    }
    
    public abstract boolean isRunning();
    
    public void onAnimationFinished() {}
    
    public abstract void runPendingAnimations();
    
    public c setFrom(RecyclerView.b0 paramB0)
    {
      c localC = b();
      localC.putShort(paramB0);
      return localC;
    }
    
    public void setListener(b paramB)
    {
      mListener = paramB;
    }
    
    public static abstract interface a
    {
      public abstract void i();
    }
    
    public static abstract interface b {}
    
    public static class c
    {
      public int left;
      public int top;
      
      public c() {}
      
      public c putShort(RecyclerView.b0 paramB0)
      {
        setFrom(paramB0);
        return this;
      }
      
      public c setFrom(RecyclerView.b0 paramB0)
      {
        paramB0 = itemView;
        left = paramB0.getLeft();
        top = paramB0.getTop();
        paramB0.getRight();
        paramB0.getBottom();
        return this;
      }
    }
  }
  
  public class m
    implements RecyclerView.l.b
  {
    public m() {}
    
    public void onAnimationFinished(RecyclerView.b0 paramB0)
    {
      paramB0.setIsRecyclable(true);
      if ((mShadowedHolder != null) && (mShadowingHolder == null)) {
        mShadowedHolder = null;
      }
      mShadowingHolder = null;
      if ((!paramB0.shouldBeKeptAsChild()) && (!removeAnimatingView(itemView)) && (paramB0.isTmpDetached())) {
        removeDetachedView(itemView, false);
      }
    }
  }
  
  public static abstract class n
  {
    public n() {}
    
    public void a(Canvas paramCanvas, RecyclerView paramRecyclerView)
    {
      visitField();
    }
    
    public void a(Canvas paramCanvas, RecyclerView paramRecyclerView, RecyclerView.y paramY)
    {
      visitFrame();
    }
    
    public void getItemOffsets(Rect paramRect)
    {
      paramRect.set(0, 0, 0, 0);
    }
    
    public void getItemOffsets(Rect paramRect, View paramView, RecyclerView paramRecyclerView)
    {
      ((RecyclerView.p)paramView.getLayoutParams()).getViewLayoutPosition();
      getItemOffsets(paramRect);
    }
    
    public void visitField() {}
    
    public void visitFrame() {}
  }
  
  public static abstract class o
  {
    public final g a = new a();
    public int b;
    public final g d = new b();
    public AnnotationWriter g = new AnnotationWriter(a);
    public boolean l;
    public boolean mAutoMeasure = false;
    public ChildHelper mChildHelper;
    public boolean mDataSetHasChangedAfterLayout = false;
    public int mHeight;
    public int mHeightMode;
    public boolean mIsAttachedToWindow = false;
    public boolean mMeasurementCacheEnabled = true;
    public RecyclerView mRecyclerView;
    public int mWidth;
    public int mWidthMode;
    public boolean showIcons = true;
    public AnnotationWriter u = new AnnotationWriter(d);
    
    public o() {}
    
    public static int chooseSize(int paramInt1, int paramInt2, int paramInt3)
    {
      int i = View.MeasureSpec.getMode(paramInt1);
      paramInt1 = View.MeasureSpec.getSize(paramInt1);
      if (i != Integer.MIN_VALUE)
      {
        if (i != 1073741824) {
          paramInt1 = Math.max(paramInt2, paramInt3);
        }
        return paramInt1;
      }
      return Math.min(paramInt1, Math.max(paramInt2, paramInt3));
    }
    
    public static int getChildMeasureSpec(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
    {
      int i = Math.max(0, paramInt1 - paramInt3);
      int j = 0;
      paramInt3 = 0;
      int k = 0;
      paramInt1 = 0;
      if (paramBoolean)
      {
        if (paramInt4 >= 0)
        {
          paramInt3 = paramInt4;
          paramInt1 = 1073741824;
        }
        else if (paramInt4 == -1)
        {
          if (paramInt2 != Integer.MIN_VALUE) {
            if (paramInt2 != 0)
            {
              if (paramInt2 != 1073741824) {
                break label72;
              }
            }
            else
            {
              paramInt3 = 0;
              paramInt1 = 0;
              break label72;
            }
          }
          paramInt3 = i;
          paramInt1 = paramInt2;
        }
        else
        {
          label72:
          paramInt1 = k;
          paramInt3 = j;
          if (paramInt4 == -2)
          {
            paramInt3 = 0;
            paramInt1 = 0;
          }
        }
      }
      else if (paramInt4 >= 0)
      {
        paramInt3 = paramInt4;
        paramInt1 = 1073741824;
      }
      else if (paramInt4 == -1)
      {
        paramInt3 = i;
        paramInt1 = paramInt2;
      }
      else
      {
        paramInt1 = k;
        paramInt3 = j;
        if (paramInt4 == -2)
        {
          paramInt3 = i;
          if ((paramInt2 != Integer.MIN_VALUE) && (paramInt2 != 1073741824)) {
            paramInt1 = 0;
          } else {
            paramInt1 = Integer.MIN_VALUE;
          }
        }
      }
      return View.MeasureSpec.makeMeasureSpec(paramInt3, paramInt1);
    }
    
    public static d getProperties(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
    {
      d localD = new d();
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.RecyclerView, paramInt1, paramInt2);
      orientation = paramContext.getInt(IpAddress.RecyclerView_android_orientation, 1);
      spanCount = paramContext.getInt(IpAddress.RecyclerView_spanCount, 1);
      reverseLayout = paramContext.getBoolean(IpAddress.RecyclerView_reverseLayout, false);
      stackFromEnd = paramContext.getBoolean(IpAddress.RecyclerView_stackFromEnd, false);
      paramContext.recycle();
      return localD;
    }
    
    public static boolean isMeasurementUpToDate(int paramInt1, int paramInt2, int paramInt3)
    {
      int i = View.MeasureSpec.getMode(paramInt2);
      paramInt2 = View.MeasureSpec.getSize(paramInt2);
      if ((paramInt3 > 0) && (paramInt1 != paramInt3)) {
        return false;
      }
      if (i != Integer.MIN_VALUE)
      {
        if (i != 0)
        {
          if (i != 1073741824) {
            return false;
          }
          if (paramInt2 == paramInt1) {
            return true;
          }
        }
        else
        {
          return true;
        }
      }
      else if (paramInt2 >= paramInt1) {
        return true;
      }
      return false;
    }
    
    public void a(int paramInt1, int paramInt2, RecyclerView.y paramY, c paramC) {}
    
    public void a(int paramInt, c paramC) {}
    
    public void a(View paramView, RecyclerView.u paramU)
    {
      removeView(paramView);
      paramU.recycleView(paramView);
    }
    
    public void a(RecyclerView paramRecyclerView, RecyclerView.u paramU)
    {
      visitFrame();
    }
    
    public boolean a(View paramView, boolean paramBoolean)
    {
      boolean bool;
      if ((g.a(paramView, 24579)) && (u.a(paramView, 24579))) {
        bool = true;
      } else {
        bool = false;
      }
      if (paramBoolean) {
        return bool;
      }
      return !bool;
    }
    
    public void addDisappearingView(View paramView)
    {
      addDisappearingView(paramView, -1);
    }
    
    public void addDisappearingView(View paramView, int paramInt)
    {
      addViewInt(paramView, paramInt, true);
    }
    
    public void addView(View paramView)
    {
      addView(paramView, -1);
    }
    
    public void addView(View paramView, int paramInt)
    {
      addViewInt(paramView, paramInt, false);
    }
    
    public final void addViewInt(View paramView, int paramInt, boolean paramBoolean)
    {
      Object localObject = RecyclerView.getChildViewHolderInt(paramView);
      if ((!paramBoolean) && (!((RecyclerView.b0)localObject).isRemoved())) {
        mRecyclerView.mViewInfoStore.a((RecyclerView.b0)localObject);
      } else {
        mRecyclerView.mViewInfoStore.c((RecyclerView.b0)localObject);
      }
      RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
      if ((!((RecyclerView.b0)localObject).wasReturnedFromScrap()) && (!((RecyclerView.b0)localObject).isScrap()))
      {
        if (paramView.getParent() == mRecyclerView)
        {
          int j = mChildHelper.indexOfChild(paramView);
          int i = paramInt;
          if (paramInt == -1) {
            i = mChildHelper.getChildCount();
          }
          if (j != -1)
          {
            if (j != i) {
              mRecyclerView.mLayout.moveView(j, i);
            }
          }
          else
          {
            localObject = new StringBuilder();
            ((StringBuilder)localObject).append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
            ((StringBuilder)localObject).append(mRecyclerView.indexOfChild(paramView));
            ((StringBuilder)localObject).append(mRecyclerView.append());
            throw new IllegalStateException(((StringBuilder)localObject).toString());
          }
        }
        else
        {
          mChildHelper.addView(paramView, paramInt, false);
          mInsetsDirty = true;
        }
      }
      else
      {
        if (((RecyclerView.b0)localObject).isScrap()) {
          ((RecyclerView.b0)localObject).unScrap();
        } else {
          ((RecyclerView.b0)localObject).clearReturnedFromScrapFlag();
        }
        mChildHelper.attachViewToParent(paramView, paramInt, paramView.getLayoutParams(), false);
      }
      if (mPendingInvalidate)
      {
        itemView.invalidate();
        mPendingInvalidate = false;
      }
    }
    
    public void assertNotInLayoutOrScroll(String paramString)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        localRecyclerView.onPostExecute(paramString);
      }
    }
    
    public void attachView(View paramView, int paramInt)
    {
      attachView(paramView, paramInt, (RecyclerView.p)paramView.getLayoutParams());
    }
    
    public void attachView(View paramView, int paramInt, RecyclerView.p paramP)
    {
      RecyclerView.b0 localB0 = RecyclerView.getChildViewHolderInt(paramView);
      if (localB0.isRemoved()) {
        mRecyclerView.mViewInfoStore.c(localB0);
      } else {
        mRecyclerView.mViewInfoStore.a(localB0);
      }
      mChildHelper.attachViewToParent(paramView, paramInt, paramP, localB0.isRemoved());
    }
    
    public void calculateItemDecorationsForChild(View paramView, Rect paramRect)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView == null)
      {
        paramRect.set(0, 0, 0, 0);
        return;
      }
      paramRect.set(localRecyclerView.getItemDecorInsetsForChild(paramView));
    }
    
    public boolean canScrollHorizontally()
    {
      return false;
    }
    
    public boolean canScrollVertically()
    {
      return false;
    }
    
    public boolean checkLayoutParams(RecyclerView.p paramP)
    {
      return paramP != null;
    }
    
    public int computeHorizontalScrollExtent(RecyclerView.y paramY)
    {
      return 0;
    }
    
    public int computeHorizontalScrollOffset(RecyclerView.y paramY)
    {
      return 0;
    }
    
    public int computeHorizontalScrollRange(RecyclerView.y paramY)
    {
      return 0;
    }
    
    public int computeVerticalScrollExtent(RecyclerView.y paramY)
    {
      return 0;
    }
    
    public int computeVerticalScrollOffset(RecyclerView.y paramY)
    {
      return 0;
    }
    
    public int computeVerticalScrollRange(RecyclerView.y paramY)
    {
      return 0;
    }
    
    public Parcelable d()
    {
      return null;
    }
    
    public void detachAndScrapAttachedViews(RecyclerView.u paramU)
    {
      int i = getChildCount() - 1;
      while (i >= 0)
      {
        scrapOrRecycleView(paramU, i, getChildAt(i));
        i -= 1;
      }
    }
    
    public void detachViewAt(int paramInt)
    {
      getChildAt(paramInt);
      detachViewInternal(paramInt);
    }
    
    public final void detachViewInternal(int paramInt)
    {
      mChildHelper.detachViewFromParent(paramInt);
    }
    
    public void dispatchAttachedToWindow(RecyclerView paramRecyclerView)
    {
      mIsAttachedToWindow = true;
      onAttachedToWindow();
    }
    
    public void draw(int paramInt)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        localRecyclerView.offsetChildrenVertical(paramInt);
      }
    }
    
    public void draw(int paramInt1, int paramInt2)
    {
      int i4 = getChildCount();
      if (i4 == 0)
      {
        mRecyclerView.defaultOnMeasure(paramInt1, paramInt2);
        return;
      }
      int i2 = Integer.MAX_VALUE;
      int k = Integer.MAX_VALUE;
      int n = Integer.MIN_VALUE;
      int j = Integer.MIN_VALUE;
      int i = 0;
      while (i < i4)
      {
        View localView = getChildAt(i);
        Rect localRect = mRecyclerView.mTempRect;
        draw(localView, localRect);
        int m = i2;
        if (left < i2) {
          m = left;
        }
        int i1 = n;
        if (right > n) {
          i1 = right;
        }
        n = k;
        if (top < k) {
          n = top;
        }
        int i3 = j;
        if (bottom > j) {
          i3 = bottom;
        }
        i += 1;
        i2 = m;
        k = n;
        n = i1;
        j = i3;
      }
      mRecyclerView.mTempRect.set(i2, k, n, j);
      setMeasuredDimension(mRecyclerView.mTempRect, paramInt1, paramInt2);
    }
    
    public void draw(View paramView, Rect paramRect)
    {
      RecyclerView.onLayoutChild(paramView, paramRect);
    }
    
    public void draw(View paramView, boolean paramBoolean, Rect paramRect)
    {
      Object localObject;
      if (paramBoolean)
      {
        localObject = getLayoutParamsmDecorInsets;
        paramRect.set(-left, -top, paramView.getWidth() + right, paramView.getHeight() + bottom);
      }
      else
      {
        paramRect.set(0, 0, paramView.getWidth(), paramView.getHeight());
      }
      if (mRecyclerView != null)
      {
        localObject = paramView.getMatrix();
        if ((localObject != null) && (!((Matrix)localObject).isIdentity()))
        {
          RectF localRectF = mRecyclerView.mPosition;
          localRectF.set(paramRect);
          ((Matrix)localObject).mapRect(localRectF);
          paramRect.set((int)Math.floor(left), (int)Math.floor(top), (int)Math.ceil(right), (int)Math.ceil(bottom));
        }
      }
      paramRect.offset(paramView.getLeft(), paramView.getTop());
    }
    
    public final boolean draw(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
    {
      paramRecyclerView = paramRecyclerView.getFocusedChild();
      if (paramRecyclerView == null) {
        return false;
      }
      int i = getPaddingLeft();
      int j = getPaddingTop();
      int k = getWidth();
      int m = getPaddingRight();
      int n = getHeight();
      int i1 = getPaddingBottom();
      Rect localRect = mRecyclerView.mTempRect;
      draw(paramRecyclerView, localRect);
      if ((left - paramInt1 < k - m) && (right - paramInt1 > i) && (top - paramInt2 < n - i1)) {
        return bottom - paramInt2 > j;
      }
      return false;
    }
    
    public View findContainingItemView(View paramView)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView == null) {
        return null;
      }
      paramView = localRecyclerView.findContainingItemView(paramView);
      if (paramView == null) {
        return null;
      }
      if (mChildHelper.isHidden(paramView)) {
        return null;
      }
      return paramView;
    }
    
    public View findViewByPosition(int paramInt)
    {
      int j = getChildCount();
      int i = 0;
      View localView;
      while (i < j)
      {
        localView = getChildAt(i);
        RecyclerView.b0 localB0 = RecyclerView.getChildViewHolderInt(localView);
        if ((localB0 != null) && (localB0.getLayoutPosition() == paramInt) && (!localB0.shouldIgnore()))
        {
          if (mRecyclerView.mState.isPreLayout()) {
            break label84;
          }
          if (!localB0.isRemoved()) {
            return localView;
          }
        }
        i += 1;
      }
      return null;
      label84:
      return localView;
    }
    
    public abstract RecyclerView.p generateDefaultLayoutParams();
    
    public RecyclerView.p generateLayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      return new RecyclerView.p(paramContext, paramAttributeSet);
    }
    
    public RecyclerView.p generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      if ((paramLayoutParams instanceof RecyclerView.p)) {
        return new RecyclerView.p((RecyclerView.p)paramLayoutParams);
      }
      if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
        return new RecyclerView.p((ViewGroup.MarginLayoutParams)paramLayoutParams);
      }
      return new RecyclerView.p(paramLayoutParams);
    }
    
    public int getBaseline()
    {
      return -1;
    }
    
    public int getBottomDecorationHeight(View paramView)
    {
      return getLayoutParamsmDecorInsets.bottom;
    }
    
    public View getChildAt(int paramInt)
    {
      ChildHelper localChildHelper = mChildHelper;
      if (localChildHelper != null) {
        return localChildHelper.getChildAt(paramInt);
      }
      return null;
    }
    
    public int getChildCount()
    {
      ChildHelper localChildHelper = mChildHelper;
      if (localChildHelper != null) {
        return localChildHelper.getChildCount();
      }
      return 0;
    }
    
    public int getColumnCountForAccessibility()
    {
      return 0;
    }
    
    public int getColumnCountForAccessibility(RecyclerView.u paramU, RecyclerView.y paramY)
    {
      paramU = mRecyclerView;
      if (paramU != null)
      {
        if (mAdapter == null) {
          return 1;
        }
        if (canScrollHorizontally()) {
          return mRecyclerView.mAdapter.getItemCount();
        }
      }
      return 1;
    }
    
    public int getDecoratedBottom(View paramView)
    {
      return paramView.getBottom() + getBottomDecorationHeight(paramView);
    }
    
    public int getDecoratedLeft(View paramView)
    {
      return paramView.getLeft() - getLeftDecorationWidth(paramView);
    }
    
    public int getDecoratedMeasuredHeight(View paramView)
    {
      Rect localRect = getLayoutParamsmDecorInsets;
      return paramView.getMeasuredHeight() + top + bottom;
    }
    
    public int getDecoratedMeasuredWidth(View paramView)
    {
      Rect localRect = getLayoutParamsmDecorInsets;
      return paramView.getMeasuredWidth() + left + right;
    }
    
    public int getDecoratedRight(View paramView)
    {
      return paramView.getRight() + getRightDecorationWidth(paramView);
    }
    
    public int getDecoratedTop(View paramView)
    {
      return paramView.getTop() - getTopDecorationHeight(paramView);
    }
    
    public View getFocusedChild()
    {
      Object localObject = mRecyclerView;
      if (localObject == null) {
        return null;
      }
      localObject = ((ViewGroup)localObject).getFocusedChild();
      if (localObject != null)
      {
        if (mChildHelper.isHidden((View)localObject)) {
          return null;
        }
        return localObject;
      }
      return null;
    }
    
    public int getHeight()
    {
      return mHeight;
    }
    
    public int getHeightMode()
    {
      return mHeightMode;
    }
    
    public int getLayoutDirection()
    {
      return ViewCompat.getLayoutDirection(mRecyclerView);
    }
    
    public int getLeftDecorationWidth(View paramView)
    {
      return getLayoutParamsmDecorInsets.left;
    }
    
    public int getMinimumHeight()
    {
      return ViewCompat.getMinimumHeight(mRecyclerView);
    }
    
    public int getMinimumWidth()
    {
      return ViewCompat.getMinimumWidth(mRecyclerView);
    }
    
    public int getPaddingBottom()
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        return localRecyclerView.getPaddingBottom();
      }
      return 0;
    }
    
    public int getPaddingLeft()
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        return localRecyclerView.getPaddingLeft();
      }
      return 0;
    }
    
    public int getPaddingRight()
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        return localRecyclerView.getPaddingRight();
      }
      return 0;
    }
    
    public int getPaddingTop()
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        return localRecyclerView.getPaddingTop();
      }
      return 0;
    }
    
    public int getPosition(View paramView)
    {
      return ((RecyclerView.p)paramView.getLayoutParams()).getViewLayoutPosition();
    }
    
    public int getRightDecorationWidth(View paramView)
    {
      return getLayoutParamsmDecorInsets.right;
    }
    
    public int getRowCountForAccessibility(RecyclerView.u paramU, RecyclerView.y paramY)
    {
      paramU = mRecyclerView;
      if (paramU != null)
      {
        if (mAdapter == null) {
          return 1;
        }
        if (canScrollVertically()) {
          return mRecyclerView.mAdapter.getItemCount();
        }
      }
      return 1;
    }
    
    public int getTopDecorationHeight(View paramView)
    {
      return getLayoutParamsmDecorInsets.top;
    }
    
    public int getWidth()
    {
      return mWidth;
    }
    
    public int getWidthMode()
    {
      return mWidthMode;
    }
    
    public void handleUpdate() {}
    
    public boolean hasFlexibleChildInBothOrientations()
    {
      int j = getChildCount();
      int i = 0;
      while (i < j)
      {
        ViewGroup.LayoutParams localLayoutParams = getChildAt(i).getLayoutParams();
        if ((width < 0) && (height < 0)) {
          return true;
        }
        i += 1;
      }
      return false;
    }
    
    public boolean isAttachedToWindow()
    {
      return mIsAttachedToWindow;
    }
    
    public boolean isLayoutHierarchical()
    {
      return false;
    }
    
    public void measureChildWithDecorationsAndMargin(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
      Rect localRect = mDecorInsets;
      paramView.layout(left + paramInt1 + leftMargin, top + paramInt2 + topMargin, paramInt3 - right - rightMargin, paramInt4 - bottom - bottomMargin);
    }
    
    public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2)
    {
      RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
      Rect localRect = mRecyclerView.getItemDecorInsetsForChild(paramView);
      int k = left;
      int m = right;
      int i = top;
      int j = bottom;
      paramInt1 = getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingLeft() + getPaddingRight() + leftMargin + rightMargin + (paramInt1 + (k + m)), width, canScrollHorizontally());
      paramInt2 = getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingTop() + getPaddingBottom() + topMargin + bottomMargin + (paramInt2 + (i + j)), height, canScrollVertically());
      if (shouldMeasureChild(paramView, paramInt1, paramInt2, localP)) {
        paramView.measure(paramInt1, paramInt2);
      }
    }
    
    public void moveView(int paramInt1, int paramInt2)
    {
      Object localObject = getChildAt(paramInt1);
      if (localObject != null)
      {
        detachViewAt(paramInt1);
        attachView((View)localObject, paramInt2);
        return;
      }
      localObject = new StringBuilder();
      ((StringBuilder)localObject).append("Cannot move a child from non-existing index:");
      ((StringBuilder)localObject).append(paramInt1);
      ((StringBuilder)localObject).append(mRecyclerView.toString());
      throw new IllegalArgumentException(((StringBuilder)localObject).toString());
    }
    
    public boolean onAddFocusables()
    {
      return false;
    }
    
    public void onAttachedToWindow() {}
    
    public void onDetachedFromWindow(RecyclerView paramRecyclerView, RecyclerView.u paramU)
    {
      mIsAttachedToWindow = false;
      a(paramRecyclerView, paramU);
    }
    
    public View onFocusSearchFailed()
    {
      return null;
    }
    
    public View onFocusSearchFailed(View paramView, int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
    {
      return null;
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
    {
      Object localObject = mRecyclerView;
      RecyclerView.u localU = mRecycler;
      localObject = mState;
      onInitializeAccessibilityNodeInfo(paramAccessibilityEvent);
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityEvent paramAccessibilityEvent)
    {
      Object localObject = mRecyclerView;
      if (localObject != null)
      {
        if (paramAccessibilityEvent == null) {
          return;
        }
        boolean bool2 = true;
        boolean bool1 = bool2;
        if (!((View)localObject).canScrollVertically(1))
        {
          bool1 = bool2;
          if (!mRecyclerView.canScrollVertically(-1))
          {
            bool1 = bool2;
            if (!mRecyclerView.canScrollHorizontally(-1)) {
              if (mRecyclerView.canScrollHorizontally(1)) {
                bool1 = bool2;
              } else {
                bool1 = false;
              }
            }
          }
        }
        paramAccessibilityEvent.setScrollable(bool1);
        localObject = mRecyclerView.mAdapter;
        if (localObject != null) {
          paramAccessibilityEvent.setItemCount(((RecyclerView.g)localObject).getItemCount());
        }
      }
    }
    
    public void onInitializeAccessibilityNodeInfo(RecyclerView.u paramU, RecyclerView.y paramY, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      if ((mRecyclerView.canScrollVertically(-1)) || (mRecyclerView.canScrollHorizontally(-1)))
      {
        paramAccessibilityNodeInfoCompat.addAction(8192);
        paramAccessibilityNodeInfoCompat.setScrollable(true);
      }
      if ((mRecyclerView.canScrollVertically(1)) || (mRecyclerView.canScrollHorizontally(1)))
      {
        paramAccessibilityNodeInfoCompat.addAction(4096);
        paramAccessibilityNodeInfoCompat.setScrollable(true);
      }
      paramAccessibilityNodeInfoCompat.setCollectionInfo(AccessibilityNodeInfoCompat.CollectionInfoCompat.obtain(getRowCountForAccessibility(paramU, paramY), getColumnCountForAccessibility(paramU, paramY), isLayoutHierarchical(), getColumnCountForAccessibility()));
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      onInitializeAccessibilityNodeInfo(mRecycler, mState, paramAccessibilityNodeInfoCompat);
    }
    
    public void onInitializeAccessibilityNodeInfoForItem(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      Object localObject = RecyclerView.getChildViewHolderInt(paramView);
      if ((localObject != null) && (!((RecyclerView.b0)localObject).isRemoved()) && (!mChildHelper.isHidden(itemView)))
      {
        localObject = mRecyclerView;
        onInitializeAccessibilityNodeInfoForItem(mRecycler, mState, paramView, paramAccessibilityNodeInfoCompat);
      }
    }
    
    public void onInitializeAccessibilityNodeInfoForItem(RecyclerView.u paramU, RecyclerView.y paramY, View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      int i;
      if (canScrollVertically()) {
        i = getPosition(paramView);
      } else {
        i = 0;
      }
      int j;
      if (canScrollHorizontally()) {
        j = getPosition(paramView);
      } else {
        j = 0;
      }
      paramAccessibilityNodeInfoCompat.setCollectionItemInfo(AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(i, 1, j, 1, false, false));
    }
    
    public void onItemsAdded(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
    
    public void onItemsChanged(RecyclerView paramRecyclerView) {}
    
    public void onItemsMoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {}
    
    public void onItemsRemoved(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
    
    public void onItemsUpdated(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject)
    {
      handleUpdate();
    }
    
    public void onLayoutChildren(RecyclerView.u paramU, RecyclerView.y paramY)
    {
      Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
    }
    
    public void onLayoutChildren(RecyclerView.y paramY) {}
    
    public void onMeasure(int paramInt1, int paramInt2)
    {
      mRecyclerView.defaultOnMeasure(paramInt1, paramInt2);
    }
    
    public boolean onRequestChildFocus()
    {
      return false;
    }
    
    public boolean onRequestChildFocus(RecyclerView paramRecyclerView)
    {
      onRequestChildFocus();
      return paramRecyclerView.isComputingLayout();
    }
    
    public boolean onRequestChildFocus(RecyclerView paramRecyclerView, View paramView1, View paramView2)
    {
      return onRequestChildFocus(paramRecyclerView);
    }
    
    public void onRestoreInstanceState(Parcelable paramParcelable) {}
    
    public void onScrollStateChanged(int paramInt) {}
    
    public boolean performAccessibilityAction(int paramInt)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView == null) {
        return false;
      }
      int k = 0;
      int m = 0;
      int i = 0;
      int j = 0;
      if (paramInt != 4096)
      {
        if (paramInt != 8192)
        {
          paramInt = m;
        }
        else
        {
          if (localRecyclerView.canScrollVertically(-1)) {
            i = -(getHeight() - getPaddingTop() - getPaddingBottom());
          }
          paramInt = i;
          if (mRecyclerView.canScrollHorizontally(-1))
          {
            j = -(getWidth() - getPaddingLeft() - getPaddingRight());
            paramInt = i;
          }
        }
      }
      else
      {
        i = k;
        if (localRecyclerView.canScrollVertically(1)) {
          i = getHeight() - getPaddingTop() - getPaddingBottom();
        }
        paramInt = i;
        if (mRecyclerView.canScrollHorizontally(1))
        {
          j = getWidth() - getPaddingLeft() - getPaddingRight();
          paramInt = i;
        }
      }
      if ((paramInt == 0) && (j == 0)) {
        return false;
      }
      mRecyclerView.smoothScrollBy(j, paramInt);
      return true;
    }
    
    public boolean performAccessibilityAction(int paramInt, Bundle paramBundle)
    {
      paramBundle = mRecyclerView;
      RecyclerView.u localU = mRecycler;
      paramBundle = mState;
      return performAccessibilityAction(paramInt);
    }
    
    public boolean performAccessibilityAction(View paramView, int paramInt, Bundle paramBundle)
    {
      paramView = mRecyclerView;
      paramBundle = mRecycler;
      paramView = mState;
      return performAccessibilityActionForItem();
    }
    
    public boolean performAccessibilityActionForItem()
    {
      return false;
    }
    
    public void removeAndRecycleAllViews() {}
    
    public void removeAndRecycleAllViews(RecyclerView.u paramU)
    {
      int i = getChildCount() - 1;
      while (i >= 0)
      {
        if (!RecyclerView.getChildViewHolderInt(getChildAt(i)).shouldIgnore()) {
          removeAndRecycleViewAt(i, paramU);
        }
        i -= 1;
      }
    }
    
    public void removeAndRecycleScrapInt(RecyclerView.u paramU)
    {
      int j = paramU.getScrapCount();
      int i = j - 1;
      while (i >= 0)
      {
        View localView = paramU.getScrapViewAt(i);
        RecyclerView.b0 localB0 = RecyclerView.getChildViewHolderInt(localView);
        if (!localB0.shouldIgnore())
        {
          localB0.setIsRecyclable(false);
          if (localB0.isTmpDetached()) {
            mRecyclerView.removeDetachedView(localView, false);
          }
          RecyclerView.l localL = mRecyclerView.mItemAnimator;
          if (localL != null) {
            localL.endAnimation(localB0);
          }
          localB0.setIsRecyclable(true);
          paramU.quickRecycleScrapView(localView);
        }
        i -= 1;
      }
      paramU.clearScrap();
      if (j > 0) {
        mRecyclerView.invalidate();
      }
    }
    
    public void removeAndRecycleViewAt(int paramInt, RecyclerView.u paramU)
    {
      View localView = getChildAt(paramInt);
      removeViewAt(paramInt);
      paramU.recycleView(localView);
    }
    
    public boolean removeCallbacks(Runnable paramRunnable)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        return localRecyclerView.removeCallbacks(paramRunnable);
      }
      return false;
    }
    
    public void removeView(View paramView)
    {
      mChildHelper.removeView(paramView);
    }
    
    public void removeViewAt(int paramInt)
    {
      if (getChildAt(paramInt) != null) {
        mChildHelper.removeViewAt(paramInt);
      }
    }
    
    public final boolean requestChildRectangleOnScreen()
    {
      return showIcons;
    }
    
    public boolean requestChildRectangleOnScreen(RecyclerView paramRecyclerView, View paramView, Rect paramRect, boolean paramBoolean)
    {
      return requestChildRectangleOnScreen(paramRecyclerView, paramView, paramRect, paramBoolean, false);
    }
    
    public boolean requestChildRectangleOnScreen(RecyclerView paramRecyclerView, View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2)
    {
      paramView = requestChildRectangleOnScreen(paramView, paramRect);
      int i = paramView[0];
      int j = paramView[1];
      if ((!paramBoolean2) || (draw(paramRecyclerView, i, j)))
      {
        if (i == 0) {
          if (j == 0) {
            break label74;
          }
        }
      }
      else {
        return false;
      }
      if (paramBoolean1)
      {
        paramRecyclerView.scrollBy(i, j);
        return true;
      }
      paramRecyclerView.smoothScrollBy(i, j);
      return true;
      label74:
      return false;
    }
    
    public final int[] requestChildRectangleOnScreen(View paramView, Rect paramRect)
    {
      int i2 = getPaddingLeft();
      int m = getPaddingTop();
      int i3 = getWidth() - getPaddingRight();
      int i1 = getHeight();
      int i6 = getPaddingBottom();
      int i4 = paramView.getLeft() + left - paramView.getScrollX();
      int n = paramView.getTop() + top - paramView.getScrollY();
      int i5 = paramRect.width() + i4;
      int i7 = paramRect.height();
      int i = Math.min(0, i4 - i2);
      int j = Math.min(0, n - m);
      int k = Math.max(0, i5 - i3);
      i1 = Math.max(0, i7 + n - (i1 - i6));
      if (getLayoutDirection() == 1)
      {
        if (k != 0) {
          i = k;
        } else {
          i = Math.max(i, i5 - i3);
        }
      }
      else if (i == 0) {
        i = Math.min(i4 - i2, k);
      }
      if (j == 0) {
        j = Math.min(n - m, i1);
      }
      return new int[] { i, j };
    }
    
    public void requestLayout()
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        localRecyclerView.requestLayout();
      }
    }
    
    public final void scrapOrRecycleView(RecyclerView.u paramU, int paramInt, View paramView)
    {
      RecyclerView.b0 localB0 = RecyclerView.getChildViewHolderInt(paramView);
      if (localB0.shouldIgnore()) {
        return;
      }
      if ((localB0.isInvalid()) && (!localB0.isRemoved()) && (!mRecyclerView.mAdapter.hasStableIds()))
      {
        removeViewAt(paramInt);
        paramU.recycleViewHolderInternal(localB0);
        return;
      }
      detachViewAt(paramInt);
      paramU.scrapView(paramView);
      mRecyclerView.mViewInfoStore.clear(localB0);
    }
    
    public int scrollHorizontallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
    {
      return 0;
    }
    
    public int scrollVerticallyBy(int paramInt, RecyclerView.u paramU, RecyclerView.y paramY)
    {
      return 0;
    }
    
    public void setExactMeasureSpecsFrom(RecyclerView paramRecyclerView)
    {
      setMeasureSpecs(View.MeasureSpec.makeMeasureSpec(paramRecyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(paramRecyclerView.getHeight(), 1073741824));
    }
    
    public void setMeasureSpecs(int paramInt1, int paramInt2)
    {
      mWidth = View.MeasureSpec.getSize(paramInt1);
      paramInt1 = View.MeasureSpec.getMode(paramInt1);
      mWidthMode = paramInt1;
      if ((paramInt1 == 0) && (!RecyclerView.ALLOW_SIZE_IN_UNSPECIFIED_SPEC)) {
        mWidth = 0;
      }
      mHeight = View.MeasureSpec.getSize(paramInt2);
      paramInt1 = View.MeasureSpec.getMode(paramInt2);
      mHeightMode = paramInt1;
      if ((paramInt1 == 0) && (!RecyclerView.ALLOW_SIZE_IN_UNSPECIFIED_SPEC)) {
        mHeight = 0;
      }
    }
    
    public void setMeasuredDimension(int paramInt1, int paramInt2)
    {
      RecyclerView.access$getSetMeasuredDimension(mRecyclerView, paramInt1, paramInt2);
    }
    
    public void setMeasuredDimension(Rect paramRect, int paramInt1, int paramInt2)
    {
      int i = paramRect.width();
      int j = getPaddingLeft();
      int k = getPaddingRight();
      int m = paramRect.height();
      int n = getPaddingTop();
      int i1 = getPaddingBottom();
      setMeasuredDimension(chooseSize(paramInt1, i + j + k, getMinimumWidth()), chooseSize(paramInt2, m + n + i1, getMinimumHeight()));
    }
    
    public boolean setOrientation()
    {
      return mAutoMeasure;
    }
    
    public void setRecyclerView(RecyclerView paramRecyclerView)
    {
      if (paramRecyclerView == null)
      {
        mRecyclerView = null;
        mChildHelper = null;
        mWidth = 0;
        mHeight = 0;
      }
      else
      {
        mRecyclerView = paramRecyclerView;
        mChildHelper = mChildHelper;
        mWidth = paramRecyclerView.getWidth();
        mHeight = paramRecyclerView.getHeight();
      }
      mWidthMode = 1073741824;
      mHeightMode = 1073741824;
    }
    
    public boolean shouldIgnore()
    {
      RecyclerView localRecyclerView = mRecyclerView;
      return (localRecyclerView != null) && (mClipToPadding);
    }
    
    public boolean shouldMeasureChild(View paramView, int paramInt1, int paramInt2, RecyclerView.p paramP)
    {
      return (paramView.isLayoutRequested()) || (!mMeasurementCacheEnabled) || (!isMeasurementUpToDate(paramView.getWidth(), paramInt1, width)) || (!isMeasurementUpToDate(paramView.getHeight(), paramInt2, height));
    }
    
    public boolean shouldMeasureTwice()
    {
      return false;
    }
    
    public boolean shouldReMeasureChild(View paramView, int paramInt1, int paramInt2, RecyclerView.p paramP)
    {
      return (!mMeasurementCacheEnabled) || (!isMeasurementUpToDate(paramView.getMeasuredWidth(), paramInt1, width)) || (!isMeasurementUpToDate(paramView.getMeasuredHeight(), paramInt2, height));
    }
    
    public void stopSmoothScroller() {}
    
    public boolean supportsPredictiveItemAnimations()
    {
      return false;
    }
    
    public void visitCode()
    {
      mDataSetHasChangedAfterLayout = true;
    }
    
    public void visitFrame() {}
    
    public void visitMaxs(int paramInt)
    {
      RecyclerView localRecyclerView = mRecyclerView;
      if (localRecyclerView != null) {
        localRecyclerView.offsetChildrenHorizontal(paramInt);
      }
    }
    
    public class a
      implements g
    {
      public a() {}
      
      public int a()
      {
        return getWidth() - getPaddingRight();
      }
      
      public int b()
      {
        return getPaddingLeft();
      }
      
      public int b(View paramView)
      {
        RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
        return getDecoratedRight(paramView) + rightMargin;
      }
      
      public int c(View paramView)
      {
        RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
        return getDecoratedLeft(paramView) - leftMargin;
      }
      
      public View c(int paramInt)
      {
        return getChildAt(paramInt);
      }
    }
    
    public class b
      implements g
    {
      public b() {}
      
      public int a()
      {
        return getHeight() - getPaddingBottom();
      }
      
      public int b()
      {
        return getPaddingTop();
      }
      
      public int b(View paramView)
      {
        RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
        return getDecoratedBottom(paramView) + bottomMargin;
      }
      
      public int c(View paramView)
      {
        RecyclerView.p localP = (RecyclerView.p)paramView.getLayoutParams();
        return getDecoratedTop(paramView) - topMargin;
      }
      
      public View c(int paramInt)
      {
        return getChildAt(paramInt);
      }
    }
    
    public static abstract interface c {}
    
    public static class d
    {
      public int orientation;
      public boolean reverseLayout;
      public int spanCount;
      public boolean stackFromEnd;
      
      public d() {}
    }
  }
  
  public static class p
    extends ViewGroup.MarginLayoutParams
  {
    public final Rect mDecorInsets = new Rect();
    public boolean mInsetsDirty = true;
    public boolean mPendingInvalidate = false;
    public RecyclerView.b0 mViewHolder;
    
    public p(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public p(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    public p(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public p(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
    
    public p(p paramP)
    {
      super();
    }
    
    public int getViewLayoutPosition()
    {
      return mViewHolder.getLayoutPosition();
    }
    
    public boolean isItemRemoved()
    {
      return mViewHolder.isRemoved();
    }
    
    public boolean isViewInvalid()
    {
      return mViewHolder.isInvalid();
    }
    
    public boolean next()
    {
      return mViewHolder.isUpdated();
    }
  }
  
  public static abstract class q {}
  
  public static abstract interface r
  {
    public abstract void a(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent);
    
    public abstract boolean onInterceptTouchEvent(RecyclerView paramRecyclerView, MotionEvent paramMotionEvent);
    
    public abstract void onRequestDisallowInterceptTouchEvent(boolean paramBoolean);
  }
  
  public static abstract class s
  {
    public s() {}
    
    public void onScrollStateChanged() {}
    
    public void onScrolled(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {}
  }
  
  public static class t
  {
    public SparseArray<a> data = new SparseArray();
    public int mAttachCount = 0;
    
    public t() {}
    
    public long a(long paramLong1, long paramLong2)
    {
      if (paramLong1 == 0L) {
        return paramLong2;
      }
      return paramLong1 / 4L * 3L + paramLong2 / 4L;
    }
    
    public void a(RecyclerView.b0 paramB0)
    {
      int i = paramB0.getItemViewType();
      ArrayList localArrayList = appendm;
      if (data.get(i)).k <= localArrayList.size()) {
        return;
      }
      paramB0.resetInternal();
      localArrayList.add(paramB0);
    }
    
    public boolean a(int paramInt, long paramLong1, long paramLong2)
    {
      long l = appendt;
      return (l == 0L) || (paramLong1 + l < paramLong2);
    }
    
    public final a append(int paramInt)
    {
      a localA2 = (a)data.get(paramInt);
      a localA1 = localA2;
      if (localA2 == null)
      {
        localA1 = new a();
        data.put(paramInt, localA1);
      }
      return localA1;
    }
    
    public void attach()
    {
      mAttachCount += 1;
    }
    
    public RecyclerView.b0 b(int paramInt)
    {
      Object localObject = (a)data.get(paramInt);
      if ((localObject != null) && (!m.isEmpty()))
      {
        localObject = m;
        return (RecyclerView.b0)((ArrayList)localObject).remove(((ArrayList)localObject).size() - 1);
      }
      return null;
    }
    
    public void b(int paramInt, long paramLong)
    {
      a localA = append(paramInt);
      a = a(a, paramLong);
    }
    
    public void clear()
    {
      int i = 0;
      while (i < data.size())
      {
        data.valueAt(i)).m.clear();
        i += 1;
      }
    }
    
    public void d(int paramInt, long paramLong)
    {
      a localA = append(paramInt);
      t = a(t, paramLong);
    }
    
    public void detach()
    {
      mAttachCount -= 1;
    }
    
    public boolean get(int paramInt, long paramLong1, long paramLong2)
    {
      long l = appenda;
      return (l == 0L) || (paramLong1 + l < paramLong2);
    }
    
    public void onAdapterChanged(RecyclerView.g paramG1, RecyclerView.g paramG2, boolean paramBoolean)
    {
      if (paramG1 != null) {
        detach();
      }
      if ((!paramBoolean) && (mAttachCount == 0)) {
        clear();
      }
      if (paramG2 != null) {
        attach();
      }
    }
    
    public static class a
    {
      public long a = 0L;
      public int k = 5;
      public final ArrayList<RecyclerView.b0> m = new ArrayList();
      public long t = 0L;
      
      public a() {}
    }
  }
  
  public final class u
  {
    public final ArrayList<RecyclerView.b0> mAttachedScrap = new ArrayList();
    public final ArrayList<RecyclerView.b0> mCachedViews = new ArrayList();
    public ArrayList<RecyclerView.b0> mChangedScrap = null;
    public RecyclerView.t mRecyclerPool;
    public int mState = 2;
    public final List<RecyclerView.b0> mUnmodifiableAttachedScrap = Collections.unmodifiableList(mAttachedScrap);
    public RecyclerView.z mViewCacheExtension;
    public int mViewCacheMax = 2;
    
    public u() {}
    
    public View add(int paramInt)
    {
      return next(paramInt, false);
    }
    
    public final void attachAccessibilityDelegate(RecyclerView.b0 paramB0)
    {
      if (isAccessibilityEnabled())
      {
        View localView = itemView;
        if (ViewCompat.getImportantForAccessibility(localView) == 0) {
          ViewCompat.put(localView, 1);
        }
        if (!ViewCompat.onLongClick(localView))
        {
          paramB0.addFlags(16384);
          ViewCompat.setAccessibilityDelegate(localView, mAccessibilityDelegate.getItemDelegate());
        }
      }
    }
    
    public void b()
    {
      int i = mCachedViews.size() - 1;
      while (i >= 0)
      {
        get(i);
        i -= 1;
      }
      mCachedViews.clear();
      if (RecyclerView.this$0) {
        d.a();
      }
    }
    
    public final void b(ViewGroup paramViewGroup, boolean paramBoolean)
    {
      int i = paramViewGroup.getChildCount() - 1;
      while (i >= 0)
      {
        View localView = paramViewGroup.getChildAt(i);
        if ((localView instanceof ViewGroup)) {
          b((ViewGroup)localView, true);
        }
        i -= 1;
      }
      if (!paramBoolean) {
        return;
      }
      if (paramViewGroup.getVisibility() == 4)
      {
        paramViewGroup.setVisibility(0);
        paramViewGroup.setVisibility(4);
        return;
      }
      i = paramViewGroup.getVisibility();
      paramViewGroup.setVisibility(4);
      paramViewGroup.setVisibility(i);
    }
    
    public final void b(RecyclerView.b0 paramB0)
    {
      paramB0 = itemView;
      if ((paramB0 instanceof ViewGroup)) {
        b((ViewGroup)paramB0, false);
      }
    }
    
    public void b(RecyclerView.b0 paramB0, boolean paramBoolean)
    {
      RecyclerView.next(paramB0);
      if (paramB0.hasAnyOfTheFlags(16384))
      {
        paramB0.setFlags(0, 16384);
        ViewCompat.setAccessibilityDelegate(itemView, null);
      }
      if (paramBoolean) {
        f(paramB0);
      }
      mOwnerRecyclerView = null;
      getRecycledViewPool().a(paramB0);
    }
    
    public void clear()
    {
      mAttachedScrap.clear();
      b();
    }
    
    public void clearOldPositions()
    {
      int j = mCachedViews.size();
      int i = 0;
      while (i < j)
      {
        ((RecyclerView.b0)mCachedViews.get(i)).clearOldPosition();
        i += 1;
      }
      j = mAttachedScrap.size();
      i = 0;
      while (i < j)
      {
        ((RecyclerView.b0)mAttachedScrap.get(i)).clearOldPosition();
        i += 1;
      }
      ArrayList localArrayList = mChangedScrap;
      if (localArrayList != null)
      {
        j = localArrayList.size();
        i = 0;
        while (i < j)
        {
          ((RecyclerView.b0)mChangedScrap.get(i)).clearOldPosition();
          i += 1;
        }
      }
    }
    
    public void clearScrap()
    {
      mAttachedScrap.clear();
      ArrayList localArrayList = mChangedScrap;
      if (localArrayList != null) {
        localArrayList.clear();
      }
    }
    
    public int convertPreLayoutPositionToPostLayout(int paramInt)
    {
      if ((paramInt >= 0) && (paramInt < mState.getItemCount()))
      {
        if (!mState.isPreLayout()) {
          return paramInt;
        }
        return mAdapterHelper.findPositionOffset(paramInt);
      }
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("invalid position ");
      localStringBuilder.append(paramInt);
      localStringBuilder.append(". State ");
      localStringBuilder.append("item count is ");
      localStringBuilder.append(mState.getItemCount());
      localStringBuilder.append(append());
      throw new IndexOutOfBoundsException(localStringBuilder.toString());
    }
    
    public void f(RecyclerView.b0 paramB0)
    {
      Object localObject = i;
      if (localObject != null) {
        ((RecyclerView.v)localObject).a(paramB0);
      }
      localObject = mAdapter;
      if (localObject != null) {
        ((RecyclerView.g)localObject).a();
      }
      localObject = RecyclerView.this;
      if (mState != null) {
        mViewInfoStore.b(paramB0);
      }
    }
    
    public void get(int paramInt)
    {
      b((RecyclerView.b0)mCachedViews.get(paramInt), true);
      mCachedViews.remove(paramInt);
    }
    
    public RecyclerView.b0 getChangedScrapViewForPosition(int paramInt)
    {
      Object localObject = mChangedScrap;
      u localU = this;
      if (localObject != null)
      {
        int j = ((ArrayList)localObject).size();
        if (j == 0) {
          return null;
        }
        int i = 0;
        while (i < j)
        {
          localObject = mChangedScrap;
          localObject = (RecyclerView.b0)((ArrayList)localObject).get(i);
          if ((!((RecyclerView.b0)localObject).wasReturnedFromScrap()) && (((RecyclerView.b0)localObject).getLayoutPosition() == paramInt))
          {
            ((RecyclerView.b0)localObject).addFlags(32);
            return localObject;
          }
          i += 1;
        }
        if (this$0.mAdapter.hasStableIds())
        {
          paramInt = this$0.mAdapterHelper.findPositionOffset(paramInt);
          if ((paramInt > 0) && (paramInt < this$0.mAdapter.getItemCount()))
          {
            this$0.mAdapter.getItemId();
            paramInt = 0;
            while (paramInt < j)
            {
              localObject = mChangedScrap;
              localObject = (RecyclerView.b0)((ArrayList)localObject).get(paramInt);
              if ((!((RecyclerView.b0)localObject).wasReturnedFromScrap()) && (((RecyclerView.b0)localObject).getItemId() == -1L))
              {
                ((RecyclerView.b0)localObject).addFlags(32);
                return localObject;
              }
              paramInt += 1;
            }
          }
        }
      }
      return null;
    }
    
    public RecyclerView.t getRecycledViewPool()
    {
      if (mRecyclerPool == null) {
        mRecyclerPool = new RecyclerView.t();
      }
      return mRecyclerPool;
    }
    
    public int getScrapCount()
    {
      return mAttachedScrap.size();
    }
    
    public List getScrapList()
    {
      return mUnmodifiableAttachedScrap;
    }
    
    public View getScrapViewAt(int paramInt)
    {
      return mAttachedScrap.get(paramInt)).itemView;
    }
    
    public RecyclerView.b0 getScrapViewForId(long paramLong, int paramInt, boolean paramBoolean)
    {
      Object localObject2 = mAttachedScrap;
      Object localObject1 = this;
      int i = ((ArrayList)localObject2).size() - 1;
      Object localObject3;
      while (i >= 0)
      {
        localObject3 = mAttachedScrap;
        localObject2 = localObject1;
        localObject3 = (RecyclerView.b0)((ArrayList)localObject3).get(i);
        if ((((RecyclerView.b0)localObject3).getItemId() == paramLong) && (!((RecyclerView.b0)localObject3).wasReturnedFromScrap()))
        {
          if (paramInt == ((RecyclerView.b0)localObject3).getItemViewType())
          {
            ((RecyclerView.b0)localObject3).addFlags(32);
            localObject1 = localObject3;
            if (!((RecyclerView.b0)localObject3).isRemoved()) {
              break label289;
            }
            localObject1 = localObject3;
            if (this$0.mState.isPreLayout()) {
              break label289;
            }
            ((RecyclerView.b0)localObject3).setFlags(2, 14);
            return localObject3;
          }
          if (!paramBoolean)
          {
            ArrayList localArrayList = mAttachedScrap;
            localArrayList.remove(i);
            this$0.removeDetachedView(itemView, false);
            ((u)localObject2).quickRecycleScrapView(itemView);
          }
        }
        i -= 1;
      }
      localObject2 = mCachedViews;
      i = ((ArrayList)localObject2).size() - 1;
      while (i >= 0)
      {
        localObject3 = mCachedViews;
        localObject2 = localObject1;
        localObject3 = (RecyclerView.b0)((ArrayList)localObject3).get(i);
        if (((RecyclerView.b0)localObject3).getItemId() == paramLong)
        {
          if (paramInt == ((RecyclerView.b0)localObject3).getItemViewType())
          {
            localObject1 = localObject3;
            if (paramBoolean) {
              break label289;
            }
            mCachedViews.remove(i);
            return localObject3;
          }
          if (!paramBoolean)
          {
            ((u)localObject2).get(i);
            return null;
          }
        }
        i -= 1;
        localObject1 = localObject2;
      }
      return null;
      label289:
      return localObject1;
    }
    
    public RecyclerView.b0 getScrapViewForPosition(int paramInt, boolean paramBoolean)
    {
      Object localObject1 = mAttachedScrap;
      u localU = this;
      int j = ((ArrayList)localObject1).size();
      int i = 0;
      while (i < j)
      {
        localObject1 = mAttachedScrap;
        localObject1 = (RecyclerView.b0)((ArrayList)localObject1).get(i);
        if ((!((RecyclerView.b0)localObject1).wasReturnedFromScrap()) && (((RecyclerView.b0)localObject1).getLayoutPosition() == paramInt) && (!((RecyclerView.b0)localObject1).isInvalid()) && ((this$0.mState.mInPreLayout) || (!((RecyclerView.b0)localObject1).isRemoved())))
        {
          ((RecyclerView.b0)localObject1).addFlags(32);
          return localObject1;
        }
        i += 1;
      }
      if (!paramBoolean)
      {
        Object localObject2 = this$0.mChildHelper.findHiddenNonRemovedView(paramInt);
        if (localObject2 != null)
        {
          localObject1 = RecyclerView.getChildViewHolderInt((View)localObject2);
          this$0.mChildHelper.unhide((View)localObject2);
          paramInt = this$0.mChildHelper.indexOfChild((View)localObject2);
          if (paramInt != -1)
          {
            this$0.mChildHelper.detachViewFromParent(paramInt);
            localU.scrapView((View)localObject2);
            ((RecyclerView.b0)localObject1).addFlags(8224);
            return localObject1;
          }
          localObject2 = new StringBuilder();
          ((StringBuilder)localObject2).append("layout index should not be -1 after unhiding a view:");
          ((StringBuilder)localObject2).append(localObject1);
          ((StringBuilder)localObject2).append(this$0.append());
          throw new IllegalStateException(((StringBuilder)localObject2).toString());
        }
      }
      localObject1 = mCachedViews;
      j = ((ArrayList)localObject1).size();
      i = 0;
      while (i < j)
      {
        localObject1 = mCachedViews;
        localObject1 = (RecyclerView.b0)((ArrayList)localObject1).get(i);
        if ((!((RecyclerView.b0)localObject1).isInvalid()) && (((RecyclerView.b0)localObject1).getLayoutPosition() == paramInt))
        {
          if (paramBoolean) {
            break label334;
          }
          mCachedViews.remove(i);
          return localObject1;
        }
        i += 1;
      }
      return null;
      label334:
      return localObject1;
    }
    
    public RecyclerView.b0 getViewForPosition(int paramInt, boolean paramBoolean, long paramLong)
    {
      if ((paramInt >= 0) && (paramInt < mState.getItemCount()))
      {
        int j = 0;
        Object localObject2 = null;
        boolean bool2 = mState.isPreLayout();
        boolean bool1 = true;
        if (bool2)
        {
          localObject1 = getChangedScrapViewForPosition(paramInt);
          localObject2 = localObject1;
          if (localObject1 != null) {
            j = 1;
          } else {
            j = 0;
          }
        }
        int i = j;
        localObject1 = localObject2;
        Object localObject3;
        if (localObject2 == null)
        {
          localObject3 = getScrapViewForPosition(paramInt, paramBoolean);
          localObject2 = localObject3;
          i = j;
          localObject1 = localObject2;
          if (localObject3 != null) {
            if (!validateViewHolderForOffsetPosition((RecyclerView.b0)localObject3))
            {
              if (!paramBoolean)
              {
                ((RecyclerView.b0)localObject3).addFlags(4);
                if (((RecyclerView.b0)localObject3).isScrap())
                {
                  removeDetachedView(itemView, false);
                  ((RecyclerView.b0)localObject3).unScrap();
                }
                else if (((RecyclerView.b0)localObject3).wasReturnedFromScrap())
                {
                  ((RecyclerView.b0)localObject3).clearReturnedFromScrapFlag();
                }
                recycleViewHolderInternal((RecyclerView.b0)localObject3);
              }
              localObject1 = null;
              i = j;
            }
            else
            {
              i = 1;
              localObject1 = localObject2;
            }
          }
        }
        if (localObject1 == null)
        {
          int m = mAdapterHelper.findPositionOffset(paramInt);
          if ((m >= 0) && (m < mAdapter.getItemCount()))
          {
            int k = mAdapter.isSpecial(m);
            j = i;
            if (mAdapter.hasStableIds())
            {
              mAdapter.getItemId();
              localObject3 = getScrapViewForId(-1L, k, paramBoolean);
              localObject2 = localObject3;
              j = i;
              localObject1 = localObject2;
              if (localObject3 != null)
              {
                mPosition = m;
                j = 1;
                localObject1 = localObject2;
              }
            }
            if (localObject1 == null) {}
            localObject2 = localObject1;
            if (localObject1 == null)
            {
              localObject3 = getRecycledViewPool().b(k);
              localObject1 = localObject3;
              localObject2 = localObject1;
              if (localObject3 != null)
              {
                ((RecyclerView.b0)localObject3).resetInternal();
                localObject2 = localObject1;
                if (RecyclerView.mHasStableIds)
                {
                  b((RecyclerView.b0)localObject3);
                  localObject2 = localObject1;
                }
              }
            }
            if (localObject2 == null)
            {
              long l1 = getNanoTime();
              if ((paramLong != Long.MAX_VALUE) && (!mRecyclerPool.a(k, l1, paramLong))) {
                return null;
              }
              localObject1 = RecyclerView.this;
              localObject1 = mAdapter.onCreateViewHolder((ViewGroup)localObject1, k);
              if (RecyclerView.this$0)
              {
                localObject2 = RecyclerView.a(itemView);
                if (localObject2 != null) {
                  l = new WeakReference(localObject2);
                }
              }
              long l2 = getNanoTime();
              mRecyclerPool.d(k, l2 - l1);
              i = j;
            }
            else
            {
              i = j;
              localObject1 = localObject2;
            }
          }
          else
          {
            localObject1 = new StringBuilder();
            ((StringBuilder)localObject1).append("Inconsistency detected. Invalid item position ");
            ((StringBuilder)localObject1).append(paramInt);
            ((StringBuilder)localObject1).append("(offset:");
            ((StringBuilder)localObject1).append(m);
            ((StringBuilder)localObject1).append(").");
            ((StringBuilder)localObject1).append("state:");
            ((StringBuilder)localObject1).append(mState.getItemCount());
            ((StringBuilder)localObject1).append(append());
            throw new IndexOutOfBoundsException(((StringBuilder)localObject1).toString());
          }
        }
        if ((i != 0) && (!mState.isPreLayout()) && (((RecyclerView.b0)localObject1).hasAnyOfTheFlags(8192)))
        {
          ((RecyclerView.b0)localObject1).setFlags(0, 8192);
          if (mState.mRunSimpleAnimations)
          {
            RecyclerView.l.buildAdapterChangeFlagsForAnimations((RecyclerView.b0)localObject1);
            localObject3 = RecyclerView.this;
            localObject2 = mItemAnimator;
            localObject3 = mState;
            ((RecyclerView.b0)localObject1).getUnmodifiedPayloads();
            localObject2 = ((RecyclerView.l)localObject2).setFrom((RecyclerView.b0)localObject1);
            recordAnimationInfoIfBouncedHiddenView((RecyclerView.b0)localObject1, (RecyclerView.l.c)localObject2);
          }
        }
        paramBoolean = false;
        if ((mState.isPreLayout()) && (((RecyclerView.b0)localObject1).isBound())) {
          mPreLayoutPosition = paramInt;
        } else if ((!((RecyclerView.b0)localObject1).isBound()) || (((RecyclerView.b0)localObject1).needsUpdate()) || (((RecyclerView.b0)localObject1).isInvalid())) {
          paramBoolean = getViewForPosition((RecyclerView.b0)localObject1, mAdapterHelper.findPositionOffset(paramInt), paramInt, paramLong);
        }
        localObject2 = itemView.getLayoutParams();
        if (localObject2 == null)
        {
          localObject2 = (RecyclerView.p)generateDefaultLayoutParams();
          itemView.setLayoutParams((ViewGroup.LayoutParams)localObject2);
        }
        else if (!checkLayoutParams((ViewGroup.LayoutParams)localObject2))
        {
          localObject2 = (RecyclerView.p)generateLayoutParams((ViewGroup.LayoutParams)localObject2);
          itemView.setLayoutParams((ViewGroup.LayoutParams)localObject2);
        }
        else
        {
          localObject2 = (RecyclerView.p)localObject2;
        }
        mViewHolder = ((RecyclerView.b0)localObject1);
        if ((i != 0) && (paramBoolean)) {
          paramBoolean = bool1;
        } else {
          paramBoolean = false;
        }
        mPendingInvalidate = paramBoolean;
        return localObject1;
      }
      Object localObject1 = new StringBuilder();
      ((StringBuilder)localObject1).append("Invalid item position ");
      ((StringBuilder)localObject1).append(paramInt);
      ((StringBuilder)localObject1).append("(");
      ((StringBuilder)localObject1).append(paramInt);
      ((StringBuilder)localObject1).append("). Item count:");
      ((StringBuilder)localObject1).append(mState.getItemCount());
      ((StringBuilder)localObject1).append(append());
      throw new IndexOutOfBoundsException(((StringBuilder)localObject1).toString());
    }
    
    public final boolean getViewForPosition(RecyclerView.b0 paramB0, int paramInt1, int paramInt2, long paramLong)
    {
      mOwnerRecyclerView = RecyclerView.this;
      int i = paramB0.getItemViewType();
      long l = getNanoTime();
      if ((paramLong != Long.MAX_VALUE) && (!mRecyclerPool.get(i, l, paramLong))) {
        return false;
      }
      mAdapter.getViewForPosition(paramB0, paramInt1);
      paramLong = getNanoTime();
      mRecyclerPool.b(paramB0.getItemViewType(), paramLong - l);
      attachAccessibilityDelegate(paramB0);
      if (mState.isPreLayout()) {
        mPreLayoutPosition = paramInt2;
      }
      return true;
    }
    
    public void markItemDecorInsetsDirty()
    {
      int j = mCachedViews.size();
      int i = 0;
      while (i < j)
      {
        RecyclerView.p localP = (RecyclerView.p)mCachedViews.get(i)).itemView.getLayoutParams();
        if (localP != null) {
          mInsetsDirty = true;
        }
        i += 1;
      }
    }
    
    public void markKnownViewsInvalid()
    {
      int j = mCachedViews.size();
      int i = 0;
      while (i < j)
      {
        localObject = (RecyclerView.b0)mCachedViews.get(i);
        if (localObject != null)
        {
          ((RecyclerView.b0)localObject).addFlags(6);
          ((RecyclerView.b0)localObject).addChangePayload(null);
        }
        i += 1;
      }
      Object localObject = mAdapter;
      if ((localObject == null) || (!((RecyclerView.g)localObject).hasStableIds())) {
        b();
      }
    }
    
    public View next(int paramInt, boolean paramBoolean)
    {
      return getViewForPositionMAX_VALUEitemView;
    }
    
    public void offsetPositionRecordsForInsert(int paramInt1, int paramInt2)
    {
      int j = mCachedViews.size();
      int i = 0;
      while (i < j)
      {
        RecyclerView.b0 localB0 = (RecyclerView.b0)mCachedViews.get(i);
        if ((localB0 != null) && (mPosition >= paramInt1)) {
          localB0.offsetPosition(paramInt2, true);
        }
        i += 1;
      }
    }
    
    public void offsetPositionRecordsForMove(int paramInt1, int paramInt2)
    {
      int i;
      int j;
      int k;
      if (paramInt1 < paramInt2)
      {
        i = paramInt1;
        j = paramInt2;
        k = -1;
      }
      else
      {
        i = paramInt2;
        j = paramInt1;
        k = 1;
      }
      int n = mCachedViews.size();
      int m = 0;
      while (m < n)
      {
        RecyclerView.b0 localB0 = (RecyclerView.b0)mCachedViews.get(m);
        if (localB0 != null)
        {
          int i1 = mPosition;
          if ((i1 >= i) && (i1 <= j)) {
            if (i1 == paramInt1) {
              localB0.offsetPosition(paramInt2 - paramInt1, false);
            } else {
              localB0.offsetPosition(k, false);
            }
          }
        }
        m += 1;
      }
    }
    
    public void offsetPositionRecordsForRemove(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      int i = mCachedViews.size() - 1;
      while (i >= 0)
      {
        RecyclerView.b0 localB0 = (RecyclerView.b0)mCachedViews.get(i);
        if (localB0 != null)
        {
          int j = mPosition;
          if (j >= paramInt1 + paramInt2)
          {
            localB0.offsetPosition(-paramInt2, paramBoolean);
          }
          else if (j >= paramInt1)
          {
            localB0.addFlags(8);
            get(i);
          }
        }
        i -= 1;
      }
    }
    
    public void onAdapterChanged(RecyclerView.g paramG1, RecyclerView.g paramG2, boolean paramBoolean)
    {
      clear();
      getRecycledViewPool().onAdapterChanged(paramG1, paramG2, paramBoolean);
    }
    
    public void quickRecycleScrapView(View paramView)
    {
      paramView = RecyclerView.getChildViewHolderInt(paramView);
      mScrapContainer = null;
      mInChangeScrap = false;
      paramView.clearReturnedFromScrapFlag();
      recycleViewHolderInternal(paramView);
    }
    
    public void recycleView(View paramView)
    {
      RecyclerView.b0 localB0 = RecyclerView.getChildViewHolderInt(paramView);
      if (localB0.isTmpDetached()) {
        removeDetachedView(paramView, false);
      }
      if (localB0.isScrap()) {
        localB0.unScrap();
      } else if (localB0.wasReturnedFromScrap()) {
        localB0.clearReturnedFromScrapFlag();
      }
      recycleViewHolderInternal(localB0);
    }
    
    public void recycleViewHolderInternal(RecyclerView.b0 paramB0)
    {
      boolean bool2 = paramB0.isScrap();
      boolean bool1 = false;
      Object localObject;
      if ((!bool2) && (itemView.getParent() == null))
      {
        if (!paramB0.isTmpDetached())
        {
          if (!paramB0.shouldIgnore())
          {
            bool1 = paramB0.doesTransientStatePreventRecycling();
            localObject = mAdapter;
            if ((localObject != null) && (bool1)) {
              ((RecyclerView.g)localObject).onFailedToRecycleView();
            }
            int k = 0;
            int n = 0;
            int m = 0;
            int j = m;
            if (paramB0.isRecyclable())
            {
              int i = n;
              if (mState > 0)
              {
                i = n;
                if (!paramB0.hasAnyOfTheFlags(526))
                {
                  k = mCachedViews.size();
                  j = k;
                  i = j;
                  if (k >= mState)
                  {
                    i = j;
                    if (k > 0)
                    {
                      get(0);
                      i = k - 1;
                    }
                  }
                  j = i;
                  k = j;
                  if (RecyclerView.this$0)
                  {
                    k = j;
                    if (i > 0)
                    {
                      k = j;
                      if (!d.b(mPosition))
                      {
                        i -= 1;
                        while (i >= 0)
                        {
                          j = mCachedViews.get(i)).mPosition;
                          if (!d.b(j)) {
                            break;
                          }
                          i -= 1;
                        }
                        k = i + 1;
                      }
                    }
                  }
                  mCachedViews.add(k, paramB0);
                  i = 1;
                }
              }
              j = m;
              k = i;
              if (i == 0)
              {
                b(paramB0, true);
                j = 1;
                k = i;
              }
            }
            mViewInfoStore.b(paramB0);
            if ((k == 0) && (j == 0) && (bool1)) {
              mOwnerRecyclerView = null;
            }
          }
          else
          {
            paramB0 = new StringBuilder();
            paramB0.append("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.");
            paramB0.append(append());
            throw new IllegalArgumentException(paramB0.toString());
          }
        }
        else
        {
          localObject = new StringBuilder();
          ((StringBuilder)localObject).append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
          ((StringBuilder)localObject).append(paramB0);
          ((StringBuilder)localObject).append(append());
          throw new IllegalArgumentException(((StringBuilder)localObject).toString());
        }
      }
      else
      {
        localObject = new StringBuilder();
        ((StringBuilder)localObject).append("Scrapped or attached views may not be recycled. isScrap:");
        ((StringBuilder)localObject).append(paramB0.isScrap());
        ((StringBuilder)localObject).append(" isAttached:");
        if (itemView.getParent() != null) {
          bool1 = true;
        }
        ((StringBuilder)localObject).append(bool1);
        ((StringBuilder)localObject).append(append());
        throw new IllegalArgumentException(((StringBuilder)localObject).toString());
      }
    }
    
    public void scrapView(View paramView)
    {
      paramView = RecyclerView.getChildViewHolderInt(paramView);
      if ((!paramView.hasAnyOfTheFlags(12)) && (paramView.isUpdated()) && (!canReuseUpdatedViewHolder(paramView)))
      {
        if (mChangedScrap == null) {
          mChangedScrap = new ArrayList();
        }
        paramView.setScrapContainer(this, true);
        mChangedScrap.add(paramView);
        return;
      }
      if ((paramView.isInvalid()) && (!paramView.isRemoved()) && (!mAdapter.hasStableIds()))
      {
        paramView = new StringBuilder();
        paramView.append("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
        paramView.append(append());
        throw new IllegalArgumentException(paramView.toString());
      }
      paramView.setScrapContainer(this, false);
      mAttachedScrap.add(paramView);
    }
    
    public void setRecycledViewPool(RecyclerView.t paramT)
    {
      RecyclerView.t localT = mRecyclerPool;
      if (localT != null) {
        localT.detach();
      }
      mRecyclerPool = paramT;
      if ((paramT != null) && (getAdapter() != null)) {
        mRecyclerPool.attach();
      }
    }
    
    public void setViewCacheExtension(RecyclerView.z paramZ)
    {
      mViewCacheExtension = paramZ;
    }
    
    public void setViewCacheSize(int paramInt)
    {
      mViewCacheMax = paramInt;
      write();
    }
    
    public void unscrapView(RecyclerView.b0 paramB0)
    {
      if (mInChangeScrap) {
        mChangedScrap.remove(paramB0);
      } else {
        mAttachedScrap.remove(paramB0);
      }
      mScrapContainer = null;
      mInChangeScrap = false;
      paramB0.clearReturnedFromScrapFlag();
    }
    
    public boolean validateViewHolderForOffsetPosition(RecyclerView.b0 paramB0)
    {
      if (paramB0.isRemoved()) {
        return mState.isPreLayout();
      }
      int i = mPosition;
      if ((i >= 0) && (i < mAdapter.getItemCount()))
      {
        if ((!mState.isPreLayout()) && (mAdapter.isSpecial(mPosition) != paramB0.getItemViewType())) {
          return false;
        }
        if (mAdapter.hasStableIds())
        {
          long l = paramB0.getItemId();
          mAdapter.getItemId();
          if (l == -1L) {
            return true;
          }
        }
        else
        {
          return true;
        }
      }
      else
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append("Inconsistency detected. Invalid view holder adapter position");
        localStringBuilder.append(paramB0);
        localStringBuilder.append(append());
        throw new IndexOutOfBoundsException(localStringBuilder.toString());
      }
      return false;
    }
    
    public void viewRangeUpdate(int paramInt1, int paramInt2)
    {
      int i = mCachedViews.size() - 1;
      while (i >= 0)
      {
        RecyclerView.b0 localB0 = (RecyclerView.b0)mCachedViews.get(i);
        if (localB0 != null)
        {
          int j = mPosition;
          if ((j >= paramInt1) && (j < paramInt1 + paramInt2))
          {
            localB0.addFlags(2);
            get(i);
          }
        }
        i -= 1;
      }
    }
    
    public void write()
    {
      RecyclerView.o localO = mLayout;
      if (localO != null) {
        i = b;
      } else {
        i = 0;
      }
      mState = (mViewCacheMax + i);
      int i = mCachedViews.size() - 1;
      while ((i >= 0) && (mCachedViews.size() > mState))
      {
        get(i);
        i -= 1;
      }
    }
  }
  
  public static abstract interface v
  {
    public abstract void a(RecyclerView.b0 paramB0);
  }
  
  public class w
    extends RecyclerView.i
  {
    public w() {}
  }
  
  public static class x
    extends org.client.params.Item
  {
    public static final Parcelable.Creator<x> CREATOR = new a();
    public Parcelable mLayoutState;
    
    public x(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(paramClassLoader);
      if (paramClassLoader == null) {
        paramClassLoader = RecyclerView.o.class.getClassLoader();
      }
      mLayoutState = paramParcel.readParcelable(paramClassLoader);
    }
    
    public x(Parcelable paramParcelable)
    {
      super();
    }
    
    public void access$1900(x paramX)
    {
      mLayoutState = mLayoutState;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeParcelable(mLayoutState, 0);
    }
    
    public static final class a
      implements Parcelable.ClassLoaderCreator<RecyclerView.x>
    {
      public a() {}
      
      public RecyclerView.x[] a(int paramInt)
      {
        return new RecyclerView.x[paramInt];
      }
      
      public RecyclerView.x readDate(Parcel paramParcel)
      {
        return new RecyclerView.x(paramParcel, null);
      }
      
      public RecyclerView.x readFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
      {
        return new RecyclerView.x(paramParcel, paramClassLoader);
      }
    }
  }
  
  public static class y
  {
    public int bottom = -1;
    public long id;
    public int mDeletedInvisibleItemCountSincePreviousLayout = 0;
    public boolean mInPreLayout = false;
    public boolean mIsMeasuring = false;
    public int mItemCount = 0;
    public int mLayoutStep = 1;
    public int mPreviousLayoutItemCount = 0;
    public boolean mRunPredictiveAnimations = false;
    public boolean mRunSimpleAnimations = false;
    public boolean mStructureChanged = false;
    public int mTouchMode;
    public boolean mTrackOldChangeHolders = false;
    public int progress;
    public int progressBar;
    
    public y() {}
    
    public void assertLayoutStep(int paramInt)
    {
      if ((mLayoutStep & paramInt) != 0) {
        return;
      }
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("Layout state should be one of ");
      localStringBuilder.append(Integer.toBinaryString(paramInt));
      localStringBuilder.append(" but it is ");
      localStringBuilder.append(Integer.toBinaryString(mLayoutStep));
      throw new IllegalStateException(localStringBuilder.toString());
    }
    
    public boolean b()
    {
      return bottom != -1;
    }
    
    public void dispatchLayoutStep1(RecyclerView.g paramG)
    {
      mLayoutStep = 1;
      mItemCount = paramG.getItemCount();
      mInPreLayout = false;
      mTrackOldChangeHolders = false;
      mIsMeasuring = false;
    }
    
    public int getItemCount()
    {
      if (mInPreLayout) {
        return mPreviousLayoutItemCount - mDeletedInvisibleItemCountSincePreviousLayout;
      }
      return mItemCount;
    }
    
    public boolean isPreLayout()
    {
      return mInPreLayout;
    }
    
    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("State{mTargetPosition=");
      localStringBuilder.append(bottom);
      localStringBuilder.append(", mData=");
      localStringBuilder.append(null);
      localStringBuilder.append(", mItemCount=");
      localStringBuilder.append(mItemCount);
      localStringBuilder.append(", mIsMeasuring=");
      localStringBuilder.append(mIsMeasuring);
      localStringBuilder.append(", mPreviousLayoutItemCount=");
      localStringBuilder.append(mPreviousLayoutItemCount);
      localStringBuilder.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
      localStringBuilder.append(mDeletedInvisibleItemCountSincePreviousLayout);
      localStringBuilder.append(", mStructureChanged=");
      localStringBuilder.append(mStructureChanged);
      localStringBuilder.append(", mInPreLayout=");
      localStringBuilder.append(mInPreLayout);
      localStringBuilder.append(", mRunSimpleAnimations=");
      localStringBuilder.append(mRunSimpleAnimations);
      localStringBuilder.append(", mRunPredictiveAnimations=");
      localStringBuilder.append(mRunPredictiveAnimations);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }
    
    public boolean willRunPredictiveAnimations()
    {
      return mRunPredictiveAnimations;
    }
  }
  
  public static abstract class z {}
}
