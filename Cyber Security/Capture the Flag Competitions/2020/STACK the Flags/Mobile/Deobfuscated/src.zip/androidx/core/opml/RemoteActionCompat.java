package androidx.core.opml;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat
  implements org.jdom.CharSequence
{
  public IconCompat N;
  public PendingIntent a;
  public CharSequence b;
  public CharSequence c;
  public boolean down;
  public boolean size;
  
  public RemoteActionCompat() {}
}
