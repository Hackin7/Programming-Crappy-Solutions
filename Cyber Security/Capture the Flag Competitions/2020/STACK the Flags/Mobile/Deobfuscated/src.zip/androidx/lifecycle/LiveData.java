package androidx.lifecycle;

import a.c.a.b.b;
import a.m.m;
import java.util.Map.Entry;
import org.spongycastle.crypto.params.f;
import org.util.Log;
import org.util.Scope;
import org.util.c;

public abstract class LiveData<T>
{
  public static final Object d = new Object();
  public volatile Object a = d;
  public b<m<? super T>, LiveData<T>.b> b = new f();
  public volatile Object e = d;
  public int f = -1;
  public boolean l;
  public boolean o;
  public int u = 0;
  public final Object x = new Object();
  
  public LiveData()
  {
    new a();
  }
  
  public static void a(String paramString)
  {
    if (org.spongycastle.crypto.util.a.a().close()) {
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("Cannot invoke ");
    localStringBuilder.append(paramString);
    localStringBuilder.append(" on a background");
    localStringBuilder.append(" thread");
    throw new IllegalStateException(localStringBuilder.toString());
  }
  
  public void a(b paramB)
  {
    if (o)
    {
      l = true;
      return;
    }
    o = true;
    do
    {
      l = false;
      b localB;
      if (paramB != null)
      {
        b(paramB);
        localB = null;
      }
      else
      {
        org.spongycastle.crypto.params.d localD = b.a();
        do
        {
          localB = paramB;
          if (!localD.hasNext()) {
            break;
          }
          b((b)((Map.Entry)localD.next()).getValue());
        } while (!l);
        localB = paramB;
      }
      paramB = localB;
    } while (l);
    o = false;
  }
  
  public void a(Object paramObject)
  {
    a("setValue");
    f += 1;
    a = paramObject;
    a(null);
  }
  
  public void a(org.util.a paramA)
  {
    a("removeObserver");
    paramA = (b)b.a(paramA);
    if (paramA == null) {
      return;
    }
    paramA.b();
    paramA.b(false);
  }
  
  public void b() {}
  
  public final void b(b paramB)
  {
    if (!r) {
      return;
    }
    if (!paramB.a())
    {
      paramB.b(false);
      return;
    }
    int i = a;
    int j = f;
    if (i >= j) {
      return;
    }
    a = j;
    j.a(a);
  }
  
  public void h() {}
  
  public class LifecycleBoundObserver
    extends LiveData<T>.b
    implements Object
  {
    public final org.util.d a;
    
    public boolean a()
    {
      return a.getLifecycle().p().a(c.f);
    }
    
    public void b()
    {
      a.getLifecycle().e(this);
    }
    
    public void b(org.util.d paramD, Scope paramScope)
    {
      if (a.getLifecycle().p() == c.c)
      {
        o.a(j);
        return;
      }
      b(a());
    }
  }
  
  public class a
    implements Runnable
  {
    public a() {}
    
    /* Error */
    public void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 14	androidx/lifecycle/LiveData$a:j	Landroidx/lifecycle/LiveData;
      //   4: getfield 25	androidx/lifecycle/LiveData:x	Ljava/lang/Object;
      //   7: astore_2
      //   8: aload_2
      //   9: monitorenter
      //   10: aload_0
      //   11: getfield 14	androidx/lifecycle/LiveData$a:j	Landroidx/lifecycle/LiveData;
      //   14: getfield 28	androidx/lifecycle/LiveData:e	Ljava/lang/Object;
      //   17: astore_1
      //   18: aload_0
      //   19: getfield 14	androidx/lifecycle/LiveData$a:j	Landroidx/lifecycle/LiveData;
      //   22: getstatic 31	androidx/lifecycle/LiveData:d	Ljava/lang/Object;
      //   25: putfield 28	androidx/lifecycle/LiveData:e	Ljava/lang/Object;
      //   28: aload_2
      //   29: monitorexit
      //   30: aload_0
      //   31: getfield 14	androidx/lifecycle/LiveData$a:j	Landroidx/lifecycle/LiveData;
      //   34: aload_1
      //   35: invokevirtual 35	androidx/lifecycle/LiveData:a	(Ljava/lang/Object;)V
      //   38: return
      //   39: astore_1
      //   40: aload_2
      //   41: monitorexit
      //   42: aload_1
      //   43: athrow
      //   44: astore_1
      //   45: goto -5 -> 40
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	48	0	this	a
      //   17	18	1	localObject1	Object
      //   39	4	1	localThrowable1	Throwable
      //   44	1	1	localThrowable2	Throwable
      //   7	34	2	localObject2	Object
      // Exception table:
      //   from	to	target	type
      //   10	18	39	java/lang/Throwable
      //   18	30	44	java/lang/Throwable
      //   40	42	44	java/lang/Throwable
    }
  }
  
  public abstract class b
  {
    public int a;
    public final m<? super T> j;
    public boolean r;
    
    public abstract boolean a();
    
    public void b() {}
    
    public void b(boolean paramBoolean)
    {
      if (paramBoolean == r) {
        return;
      }
      r = paramBoolean;
      int i = b.u;
      int k = 1;
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      }
      LiveData localLiveData = b;
      int m = u;
      if (!r) {
        k = -1;
      }
      u = (m + k);
      if ((i != 0) && (r)) {
        b.h();
      }
      localLiveData = b;
      if ((u == 0) && (!r)) {
        localLiveData.b();
      }
      if (r) {
        b.a(this);
      }
    }
  }
}
