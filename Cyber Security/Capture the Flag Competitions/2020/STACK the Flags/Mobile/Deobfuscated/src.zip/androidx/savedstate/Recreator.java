package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import org.misc.Paint;
import org.util.Log;
import org.util.MenuItem;
import org.util.Scope;
import org.util.d;

@SuppressLint({"RestrictedApi"})
public final class Recreator
  implements MenuItem
{
  public final Paint h;
  
  public Recreator(Paint paramPaint)
  {
    h = paramPaint;
  }
  
  public void b(d paramD, Scope paramScope)
  {
    if (paramScope == Scope.ON_CREATE)
    {
      paramD.getLifecycle().e(this);
      paramD = h.getSavedStateRegistry().a("androidx.savedstate.Restarter");
      if (paramD == null) {
        return;
      }
      paramD = paramD.getStringArrayList("classes_to_restore");
      if (paramD != null)
      {
        paramD = paramD.iterator();
        while (paramD.hasNext()) {
          create((String)paramD.next());
        }
        return;
      }
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    }
    throw new AssertionError("Next event must be ON_CREATE");
  }
  
  /* Error */
  public final void create(String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: iconst_0
    //   2: ldc 2
    //   4: invokevirtual 108	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   7: invokestatic 112	java/lang/Class:forName	(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    //   10: ldc 114
    //   12: invokevirtual 118	java/lang/Class:asSubclass	(Ljava/lang/Class;)Ljava/lang/Class;
    //   15: astore_2
    //   16: aload_2
    //   17: iconst_0
    //   18: anewarray 104	java/lang/Class
    //   21: invokevirtual 122	java/lang/Class:getDeclaredConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   24: astore_3
    //   25: aload_3
    //   26: iconst_1
    //   27: invokevirtual 128	java/lang/reflect/Constructor:setAccessible	(Z)V
    //   30: aload_3
    //   31: iconst_0
    //   32: anewarray 4	java/lang/Object
    //   35: invokevirtual 132	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   38: astore_2
    //   39: aload_2
    //   40: checkcast 114	androidx/savedstate/SavedStateRegistry$a
    //   43: aload_0
    //   44: getfield 18	androidx/savedstate/Recreator:h	Lorg/misc/Paint;
    //   47: invokeinterface 135 2 0
    //   52: return
    //   53: astore_2
    //   54: new 137	java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial 138	java/lang/StringBuilder:<init>	()V
    //   61: astore_3
    //   62: aload_3
    //   63: ldc -116
    //   65: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload_3
    //   70: aload_1
    //   71: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: pop
    //   75: new 146	java/lang/RuntimeException
    //   78: dup
    //   79: aload_3
    //   80: invokevirtual 150	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   83: aload_2
    //   84: invokespecial 153	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   87: athrow
    //   88: astore_1
    //   89: new 137	java/lang/StringBuilder
    //   92: dup
    //   93: invokespecial 138	java/lang/StringBuilder:<init>	()V
    //   96: astore_3
    //   97: aload_3
    //   98: ldc -101
    //   100: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload_3
    //   105: aload_2
    //   106: invokevirtual 158	java/lang/Class:getSimpleName	()Ljava/lang/String;
    //   109: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_3
    //   114: ldc -96
    //   116: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: new 85	java/lang/IllegalStateException
    //   123: dup
    //   124: aload_3
    //   125: invokevirtual 150	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   128: aload_1
    //   129: invokespecial 161	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   132: athrow
    //   133: astore_2
    //   134: new 137	java/lang/StringBuilder
    //   137: dup
    //   138: invokespecial 138	java/lang/StringBuilder:<init>	()V
    //   141: astore_3
    //   142: aload_3
    //   143: ldc -93
    //   145: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: aload_3
    //   150: aload_1
    //   151: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: pop
    //   155: aload_3
    //   156: ldc -91
    //   158: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: new 146	java/lang/RuntimeException
    //   165: dup
    //   166: aload_3
    //   167: invokevirtual 150	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   170: aload_2
    //   171: invokespecial 153	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   174: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	175	0	this	Recreator
    //   0	175	1	paramString	String
    //   15	25	2	localObject1	Object
    //   53	53	2	localException	Exception
    //   133	38	2	localClassNotFoundException	ClassNotFoundException
    //   24	143	3	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   30	39	53	java/lang/Exception
    //   16	25	88	java/lang/NoSuchMethodException
    //   0	16	133	java/lang/ClassNotFoundException
  }
}
