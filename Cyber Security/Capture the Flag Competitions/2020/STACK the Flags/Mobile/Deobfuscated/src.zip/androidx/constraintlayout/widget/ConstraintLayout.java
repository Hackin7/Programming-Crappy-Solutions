package androidx.constraintlayout.widget;

import a.f.b.i.e;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.ArrayList;
import java.util.HashMap;
import org.codehaus.asm.asm.Frame;
import org.codehaus.asm.asm.Type;
import org.codehaus.asm.asm.XLayoutStyle;
import org.codehaus.asm.asm.asm.a;
import org.codehaus.asm.asm.b;
import org.codehaus.asm.asm.f;
import org.codehaus.asm.asm.i;
import org.codehaus.ui.ActionMenuItemView;
import org.codehaus.ui.Body;
import org.codehaus.ui.IpAddress;
import org.codehaus.ui.ProgressBar;
import org.codehaus.ui.Toolbar;
import org.codehaus.ui.d;

public class ConstraintLayout
  extends ViewGroup
{
  public ArrayList<a.f.c.c> a = new ArrayList(4);
  public int b = 257;
  public org.codehaus.asm.asm.MethodWriter c = new org.codehaus.asm.asm.MethodWriter();
  public b d = new b(this);
  public int e = 0;
  public int f = 0;
  public org.codehaus.ui.Item g = null;
  public boolean h = true;
  public int i = -1;
  public int j = Integer.MAX_VALUE;
  public int k = -1;
  public SparseArray<View> l = new SparseArray();
  public HashMap<String, Integer> m = new HashMap();
  public int p = -1;
  public d u = null;
  public SparseArray<e> v = new SparseArray();
  public int viewHeight = 0;
  public int viewWidth = 0;
  public int w = Integer.MAX_VALUE;
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramAttributeSet, 0, 0);
  }
  
  private int getPaddingWidth()
  {
    int n = Math.max(0, getPaddingLeft());
    int i1 = Math.max(0, getPaddingRight());
    int i2 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
    if (i2 > 0) {
      return i2;
    }
    return n + i1;
  }
  
  public Object a(int paramInt, Object paramObject)
  {
    if ((paramInt == 0) && ((paramObject instanceof String)))
    {
      paramObject = (String)paramObject;
      HashMap localHashMap = m;
      if ((localHashMap != null) && (localHashMap.containsKey(paramObject))) {
        return m.get(paramObject);
      }
    }
    return null;
  }
  
  public final f a(int paramInt)
  {
    if (paramInt == 0) {
      return c;
    }
    Object localObject2 = (View)l.get(paramInt);
    Object localObject1 = localObject2;
    if (localObject2 == null)
    {
      View localView = findViewById(paramInt);
      localObject2 = localView;
      localObject1 = localObject2;
      if (localView != null)
      {
        localObject1 = localObject2;
        if (localView != this)
        {
          localObject1 = localObject2;
          if (localView.getParent() == this)
          {
            onViewAdded(localView);
            localObject1 = localObject2;
          }
        }
      }
    }
    if (localObject1 == this) {
      return c;
    }
    if (localObject1 == null) {
      return null;
    }
    return getLayoutParamsa;
  }
  
  public final f a(View paramView)
  {
    if (paramView == this) {
      return c;
    }
    if (paramView == null) {
      return null;
    }
    return getLayoutParamsa;
  }
  
  public final void a()
  {
    boolean bool = isInEditMode();
    int i1 = getChildCount();
    int n = 0;
    Object localObject1;
    while (n < i1)
    {
      localObject1 = a(getChildAt(n));
      if (localObject1 != null) {
        ((f)localObject1).init();
      }
      n += 1;
    }
    Object localObject4;
    Object localObject3;
    if (bool)
    {
      n = 0;
      while (n < i1)
      {
        localObject4 = getChildAt(n);
        try
        {
          localObject3 = getResources().getResourceName(((View)localObject4).getId());
          localObject1 = localObject3;
          add(0, localObject3, Integer.valueOf(((View)localObject4).getId()));
          i2 = ((String)localObject3).indexOf('/');
          if (i2 != -1) {
            localObject1 = ((String)localObject3).substring(i2 + 1);
          }
          a(((View)localObject4).getId()).b((String)localObject1);
        }
        catch (Resources.NotFoundException localNotFoundException) {}
        n += 1;
      }
    }
    if (p != -1)
    {
      n = 0;
      while (n < i1)
      {
        localObject2 = getChildAt(n);
        if ((((View)localObject2).getId() == p) && ((localObject2 instanceof Toolbar))) {
          g = ((Toolbar)localObject2).getConstraintSet();
        }
        n += 1;
      }
    }
    Object localObject2 = g;
    if (localObject2 != null) {
      ((org.codehaus.ui.Item)localObject2).a(this, true);
    }
    c.close();
    int i2 = a.size();
    if (i2 > 0)
    {
      n = 0;
      while (n < i2)
      {
        ((org.codehaus.ui.Label)a.get(n)).a(this);
        n += 1;
      }
    }
    n = 0;
    while (n < i1)
    {
      localObject2 = getChildAt(n);
      if ((localObject2 instanceof org.codehaus.ui.MethodWriter)) {
        ((org.codehaus.ui.MethodWriter)localObject2).a(this);
      }
      n += 1;
    }
    v.clear();
    v.put(0, c);
    v.put(getId(), c);
    n = 0;
    while (n < i1)
    {
      localObject2 = getChildAt(n);
      localObject3 = a((View)localObject2);
      v.put(((View)localObject2).getId(), localObject3);
      n += 1;
    }
    n = 0;
    while (n < i1)
    {
      localObject2 = getChildAt(n);
      localObject3 = a((View)localObject2);
      if (localObject3 != null)
      {
        localObject4 = (a)((View)localObject2).getLayoutParams();
        c.a((f)localObject3);
        a(bool, (View)localObject2, (f)localObject3, (a)localObject4, v);
      }
      n += 1;
    }
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2)
  {
    b localB = d;
    int n = e;
    paramInt1 = View.resolveSizeAndState(paramInt3 + c, paramInt1, 0);
    paramInt3 = View.resolveSizeAndState(paramInt4 + n, paramInt2, 0 << 16);
    paramInt4 = Math.min(j, paramInt1 & 0xFFFFFF);
    paramInt2 = paramInt4;
    paramInt3 = Math.min(w, paramInt3 & 0xFFFFFF);
    paramInt1 = paramInt3;
    if (paramBoolean1) {
      paramInt2 = paramInt4 | 0x1000000;
    }
    if (paramBoolean2) {
      paramInt1 = paramInt3 | 0x1000000;
    }
    setMeasuredDimension(paramInt2, paramInt1);
    i = paramInt2;
    k = paramInt1;
  }
  
  public final void a(AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    c.a(this);
    c.a(d);
    l.put(getId(), this);
    g = null;
    if (paramAttributeSet != null)
    {
      paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, IpAddress.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = paramAttributeSet.getIndexCount();
      paramInt1 = 0;
      while (paramInt1 < paramInt2)
      {
        int n = paramAttributeSet.getIndex(paramInt1);
        if (n == IpAddress.ConstraintLayout_Layout_android_minWidth)
        {
          e = paramAttributeSet.getDimensionPixelOffset(n, e);
        }
        else if (n == IpAddress.ConstraintLayout_Layout_android_minHeight)
        {
          f = paramAttributeSet.getDimensionPixelOffset(n, f);
        }
        else if (n == IpAddress.ConstraintLayout_Layout_android_maxWidth)
        {
          j = paramAttributeSet.getDimensionPixelOffset(n, j);
        }
        else if (n == IpAddress.ConstraintLayout_Layout_android_maxHeight)
        {
          w = paramAttributeSet.getDimensionPixelOffset(n, w);
        }
        else if (n == IpAddress.ConstraintLayout_Layout_layout_optimizationLevel)
        {
          b = paramAttributeSet.getInt(n, b);
        }
        else if (n == IpAddress.ConstraintLayout_Layout_layoutDescription)
        {
          n = paramAttributeSet.getResourceId(n, 0);
          if (n != 0) {
            try
            {
              d(n);
            }
            catch (Resources.NotFoundException localNotFoundException1)
            {
              u = null;
            }
          }
        }
        else if (n == IpAddress.ConstraintLayout_Layout_constraintSet)
        {
          n = paramAttributeSet.getResourceId(n, 0);
          try
          {
            org.codehaus.ui.Item localItem = new org.codehaus.ui.Item();
            g = localItem;
            localItem.a(getContext(), n);
          }
          catch (Resources.NotFoundException localNotFoundException2)
          {
            g = null;
          }
          p = n;
        }
        paramInt1 += 1;
      }
      paramAttributeSet.recycle();
    }
    c.d(b);
  }
  
  public void a(org.codehaus.asm.asm.MethodWriter paramMethodWriter, int paramInt1, int paramInt2, int paramInt3)
  {
    int n = View.MeasureSpec.getMode(paramInt2);
    int i5 = View.MeasureSpec.getSize(paramInt2);
    int i1 = View.MeasureSpec.getMode(paramInt3);
    int i3 = View.MeasureSpec.getSize(paramInt3);
    int i2 = Math.max(0, getPaddingTop());
    int i7 = Math.max(0, getPaddingBottom());
    int i4 = i2 + i7;
    int i6 = getPaddingWidth();
    d.b(paramInt2, paramInt3, i2, i7, i6, i4);
    paramInt2 = Math.max(0, getPaddingStart());
    paramInt3 = Math.max(0, getPaddingEnd());
    if ((paramInt2 <= 0) && (paramInt3 <= 0)) {
      paramInt2 = Math.max(0, getPaddingLeft());
    } else if (get()) {
      paramInt2 = paramInt3;
    }
    paramInt3 = i5 - i6;
    i3 -= i4;
    a(paramMethodWriter, n, paramInt3, i1, i3);
    paramMethodWriter.a(paramInt1, n, paramInt3, i1, i3, i, k, paramInt2, i2);
  }
  
  public void a(org.codehaus.asm.asm.MethodWriter paramMethodWriter, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Object localObject1 = d;
    int i2 = e;
    int i3 = c;
    localObject1 = XLayoutStyle.b;
    Object localObject2 = XLayoutStyle.b;
    int i1 = 0;
    int n = 0;
    int i4 = getChildCount();
    XLayoutStyle localXLayoutStyle;
    if (paramInt1 != Integer.MIN_VALUE)
    {
      if (paramInt1 != 0)
      {
        if (paramInt1 != 1073741824) {
          paramInt1 = i1;
        } else {
          paramInt1 = Math.min(j - i3, paramInt2);
        }
      }
      else
      {
        localXLayoutStyle = XLayoutStyle.c;
        localObject1 = localXLayoutStyle;
        paramInt1 = i1;
        if (i4 == 0)
        {
          paramInt1 = Math.max(0, e);
          localObject1 = localXLayoutStyle;
        }
      }
    }
    else
    {
      localXLayoutStyle = XLayoutStyle.c;
      paramInt1 = paramInt2;
      localObject1 = localXLayoutStyle;
      if (i4 == 0)
      {
        paramInt1 = Math.max(0, e);
        localObject1 = localXLayoutStyle;
      }
    }
    if (paramInt3 != Integer.MIN_VALUE)
    {
      if (paramInt3 != 0)
      {
        if (paramInt3 != 1073741824) {
          paramInt2 = n;
        } else {
          paramInt2 = Math.min(w - i2, paramInt4);
        }
      }
      else
      {
        localXLayoutStyle = XLayoutStyle.c;
        localObject2 = localXLayoutStyle;
        paramInt2 = n;
        if (i4 == 0)
        {
          paramInt2 = Math.max(0, f);
          localObject2 = localXLayoutStyle;
        }
      }
    }
    else
    {
      localXLayoutStyle = XLayoutStyle.c;
      paramInt2 = paramInt4;
      localObject2 = localXLayoutStyle;
      if (i4 == 0)
      {
        paramInt2 = Math.max(0, f);
        localObject2 = localXLayoutStyle;
      }
    }
    if ((paramInt1 != paramMethodWriter.getValue()) || (paramInt2 != paramMethodWriter.size())) {
      paramMethodWriter.visitLocalVariable();
    }
    paramMethodWriter.g(0);
    paramMethodWriter.setText(0);
    paramMethodWriter.clear(j - i3);
    paramMethodWriter.l(w - i2);
    paramMethodWriter.p(0);
    paramMethodWriter.create(0);
    paramMethodWriter.add((XLayoutStyle)localObject1);
    paramMethodWriter.append(paramInt1);
    paramMethodWriter.a((XLayoutStyle)localObject2);
    paramMethodWriter.add(paramInt2);
    paramMethodWriter.p(e - i3);
    paramMethodWriter.create(f - i2);
  }
  
  public void a(boolean paramBoolean, View paramView, f paramF, a paramA, SparseArray paramSparseArray)
  {
    paramA.add();
    paramF.setVisibility(paramView.getVisibility());
    if (G)
    {
      paramF.d(true);
      paramF.setVisibility(8);
    }
    paramF.a(paramView);
    if ((paramView instanceof org.codehaus.ui.Label)) {
      ((org.codehaus.ui.Label)paramView).a(paramF, c.visitParameterAnnotation());
    }
    if (alignment)
    {
      paramView = (i)paramF;
      n = range;
      i1 = code;
      f1 = value;
      if (f1 != -1.0F)
      {
        paramView.a(f1);
        return;
      }
      if (n != -1)
      {
        paramView.d(n);
        return;
      }
      if (i1 != -1) {
        paramView.init(i1);
      }
      return;
    }
    int n = length;
    int i1 = offset;
    int i2 = position;
    int i3 = width;
    int i4 = mCurrentPage;
    int i5 = mNextPage;
    float f1 = step;
    int i6 = min;
    if (i6 != -1)
    {
      paramView = (f)paramSparseArray.get(i6);
      if (paramView != null) {
        paramF.a(paramView, m, n);
      }
    }
    else
    {
      org.codehaus.asm.asm.c localC;
      if (n != -1)
      {
        paramView = (f)paramSparseArray.get(n);
        if (paramView != null)
        {
          localC = org.codehaus.asm.asm.c.d;
          paramF.a(localC, paramView, localC, leftMargin, i4);
        }
      }
      else if (i1 != -1)
      {
        paramView = (f)paramSparseArray.get(i1);
        if (paramView != null) {
          paramF.a(org.codehaus.asm.asm.c.d, paramView, org.codehaus.asm.asm.c.i, leftMargin, i4);
        }
      }
      if (i2 != -1)
      {
        paramView = (f)paramSparseArray.get(i2);
        if (paramView != null) {
          paramF.a(org.codehaus.asm.asm.c.i, paramView, org.codehaus.asm.asm.c.d, rightMargin, i5);
        }
      }
      else if (i3 != -1)
      {
        paramView = (f)paramSparseArray.get(i3);
        if (paramView != null)
        {
          localC = org.codehaus.asm.asm.c.i;
          paramF.a(localC, paramView, localC, rightMargin, i5);
        }
      }
      n = g;
      if (n != -1)
      {
        paramView = (f)paramSparseArray.get(n);
        if (paramView != null)
        {
          localC = org.codehaus.asm.asm.c.a;
          paramF.a(localC, paramView, localC, topMargin, t);
        }
      }
      else
      {
        n = l;
        if (n != -1)
        {
          paramView = (f)paramSparseArray.get(n);
          if (paramView != null) {
            paramF.a(org.codehaus.asm.asm.c.a, paramView, org.codehaus.asm.asm.c.b, topMargin, t);
          }
        }
      }
      n = j;
      if (n != -1)
      {
        paramView = (f)paramSparseArray.get(n);
        if (paramView != null) {
          paramF.a(org.codehaus.asm.asm.c.b, paramView, org.codehaus.asm.asm.c.a, bottomMargin, s);
        }
      }
      else
      {
        n = k;
        if (n != -1)
        {
          paramView = (f)paramSparseArray.get(n);
          if (paramView != null)
          {
            localC = org.codehaus.asm.asm.c.b;
            paramF.a(localC, paramView, localC, bottomMargin, s);
          }
        }
      }
      n = i;
      if (n != -1)
      {
        paramView = (View)l.get(n);
        paramSparseArray = (f)paramSparseArray.get(i);
        if ((paramSparseArray != null) && (paramView != null) && ((paramView.getLayoutParams() instanceof a)))
        {
          paramView = (a)paramView.getLayoutParams();
          K = true;
          K = true;
          paramF.a(org.codehaus.asm.asm.c.g).a(paramSparseArray.a(org.codehaus.asm.asm.c.g), 0, -1, true);
          paramF.a(true);
          a.a(true);
          paramF.a(org.codehaus.asm.asm.c.a).a();
          paramF.a(org.codehaus.asm.asm.c.b).a();
        }
      }
      if (f1 >= 0.0F) {
        paramF.add(f1);
      }
      f1 = next;
      if (f1 >= 0.0F) {
        paramF.put(f1);
      }
    }
    if ((paramBoolean) && ((type != -1) || (state != -1))) {
      paramF.d(type, state);
    }
    if (!height)
    {
      if (width == -1)
      {
        if (w) {
          paramF.add(XLayoutStyle.a);
        } else {
          paramF.add(XLayoutStyle.r);
        }
        adj = leftMargin;
        aij = rightMargin;
      }
      else
      {
        paramF.add(XLayoutStyle.a);
        paramF.append(0);
      }
    }
    else
    {
      paramF.add(XLayoutStyle.b);
      paramF.append(width);
      if (width == -2) {
        paramF.add(XLayoutStyle.c);
      }
    }
    if (!bottom)
    {
      if (height == -1)
      {
        if (z) {
          paramF.a(XLayoutStyle.a);
        } else {
          paramF.a(XLayoutStyle.r);
        }
        aaj = topMargin;
        abj = bottomMargin;
      }
      else
      {
        paramF.a(XLayoutStyle.a);
        paramF.add(0);
      }
    }
    else
    {
      paramF.a(XLayoutStyle.b);
      paramF.add(height);
      if (height == -2) {
        paramF.a(XLayoutStyle.c);
      }
    }
    paramF.format(data);
    paramF.d(buffer);
    paramF.b(key);
    paramF.putInt(flags);
    paramF.writeInt(count);
    paramF.b(top, A, N, L);
    paramF.a(left, H, M, r);
  }
  
  public void add(int paramInt, Object paramObject1, Object paramObject2)
  {
    if ((paramInt == 0) && ((paramObject1 instanceof String)) && ((paramObject2 instanceof Integer)))
    {
      if (m == null) {
        m = new HashMap();
      }
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1) {
        paramObject1 = str.substring(paramInt + 1);
      }
      paramInt = ((Integer)paramObject2).intValue();
      m.put(paramObject1, Integer.valueOf(paramInt));
    }
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public a applyFont(AttributeSet paramAttributeSet)
  {
    return new a(getContext(), paramAttributeSet);
  }
  
  public View b(int paramInt)
  {
    return (View)l.get(paramInt);
  }
  
  public final void b()
  {
    h = true;
    i = -1;
    k = -1;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof a;
  }
  
  public void d(int paramInt)
  {
    u = new d(getContext(), this, paramInt);
  }
  
  public void dispatchDraw(Canvas paramCanvas)
  {
    Object localObject = a;
    int i1;
    int n;
    if (localObject != null)
    {
      i1 = ((ArrayList)localObject).size();
      if (i1 > 0)
      {
        n = 0;
        while (n < i1)
        {
          ((org.codehaus.ui.Label)a.get(n)).draw();
          n += 1;
        }
      }
    }
    super.dispatchDraw(paramCanvas);
    if (isInEditMode())
    {
      i1 = getChildCount();
      float f1 = getWidth();
      float f2 = getHeight();
      n = 0;
      while (n < i1)
      {
        localObject = getChildAt(n);
        if (((View)localObject).getVisibility() != 8)
        {
          localObject = ((View)localObject).getTag();
          if ((localObject != null) && ((localObject instanceof String)))
          {
            localObject = ((String)localObject).split(",");
            if (localObject.length == 4)
            {
              int i3 = Integer.parseInt(localObject[0]);
              int i5 = Integer.parseInt(localObject[1]);
              int i4 = Integer.parseInt(localObject[2]);
              int i2 = Integer.parseInt(localObject[3]);
              i3 = (int)(i3 / 1080.0F * f1);
              i5 = (int)(i5 / 1920.0F * f2);
              i4 = (int)(i4 / 1080.0F * f1);
              i2 = (int)(i2 / 1920.0F * f2);
              localObject = new Paint();
              ((Paint)localObject).setColor(-65536);
              paramCanvas.drawLine(i3, i5, i3 + i4, i5, (Paint)localObject);
              paramCanvas.drawLine(i3 + i4, i5, i3 + i4, i5 + i2, (Paint)localObject);
              paramCanvas.drawLine(i3 + i4, i5 + i2, i3, i5 + i2, (Paint)localObject);
              paramCanvas.drawLine(i3, i5 + i2, i3, i5, (Paint)localObject);
              ((Paint)localObject).setColor(-16711936);
              paramCanvas.drawLine(i3, i5, i3 + i4, i5 + i2, (Paint)localObject);
              paramCanvas.drawLine(i3, i5 + i2, i3 + i4, i5, (Paint)localObject);
            }
            else {}
          }
        }
        n += 1;
      }
    }
  }
  
  public void forceLayout()
  {
    b();
    super.forceLayout();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new a(paramLayoutParams);
  }
  
  public boolean get()
  {
    int n;
    if ((getContextgetApplicationInfoflags & 0x400000) != 0) {
      n = 1;
    } else {
      n = 0;
    }
    return (n != 0) && (1 == getLayoutDirection());
  }
  
  public int getMaxHeight()
  {
    return w;
  }
  
  public int getMaxWidth()
  {
    return j;
  }
  
  public int getMinHeight()
  {
    return f;
  }
  
  public int getMinWidth()
  {
    return e;
  }
  
  public int getOptimizationLevel()
  {
    return c.remove();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramInt2 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt1 = 0;
    while (paramInt1 < paramInt2)
    {
      View localView = getChildAt(paramInt1);
      a localA = (a)localView.getLayoutParams();
      f localF = a;
      if (((localView.getVisibility() != 8) || (alignment) || (offsetX) || (mExpanded) || (paramBoolean)) && (!G))
      {
        paramInt3 = localF.e();
        paramInt4 = localF.getTitle();
        int n = localF.getValue() + paramInt3;
        int i1 = localF.size() + paramInt4;
        localView.layout(paramInt3, paramInt4, n, i1);
        if ((localView instanceof org.codehaus.ui.MethodWriter))
        {
          localView = ((org.codehaus.ui.MethodWriter)localView).getContent();
          if (localView != null)
          {
            localView.setVisibility(0);
            localView.layout(paramInt3, paramInt4, n, i1);
          }
        }
      }
      paramInt1 += 1;
    }
    paramInt2 = a.size();
    if (paramInt2 > 0)
    {
      paramInt1 = 0;
      while (paramInt1 < paramInt2)
      {
        ((org.codehaus.ui.Label)a.get(paramInt1)).addTouchDelegate();
        paramInt1 += 1;
      }
    }
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    if (!h)
    {
      if ((viewWidth == paramInt1) && (viewHeight == paramInt2))
      {
        a(paramInt1, paramInt2, c.getValue(), c.size(), c.put(), c.getSize());
        return;
      }
      if ((viewWidth == paramInt1) && (View.MeasureSpec.getMode(paramInt1) == 1073741824) && (View.MeasureSpec.getMode(paramInt2) == Integer.MIN_VALUE) && (View.MeasureSpec.getMode(viewHeight) == Integer.MIN_VALUE) && (View.MeasureSpec.getSize(paramInt2) >= c.size()))
      {
        viewWidth = paramInt1;
        viewHeight = paramInt2;
        a(paramInt1, paramInt2, c.getValue(), c.size(), c.put(), c.getSize());
        return;
      }
    }
    viewWidth = paramInt1;
    viewHeight = paramInt2;
    c.put(get());
    if (h)
    {
      h = false;
      if (refreshDisplay()) {
        c.visitInvokeDynamicInsn();
      }
    }
    a(c, b, paramInt1, paramInt2);
    a(paramInt1, paramInt2, c.getValue(), c.size(), c.put(), c.getSize());
  }
  
  public void onViewAdded(View paramView)
  {
    super.onViewAdded(paramView);
    Object localObject = a(paramView);
    if (((paramView instanceof ProgressBar)) && (!(localObject instanceof i)))
    {
      localObject = (a)paramView.getLayoutParams();
      i localI = new i();
      a = localI;
      alignment = true;
      ((i)localI).a(id);
    }
    if ((paramView instanceof org.codehaus.ui.Label))
    {
      localObject = (org.codehaus.ui.Label)paramView;
      ((org.codehaus.ui.Label)localObject).a();
      getLayoutParamsoffsetX = true;
      if (!a.contains(localObject)) {
        a.add(localObject);
      }
    }
    l.put(paramView.getId(), paramView);
    h = true;
  }
  
  public void onViewRemoved(View paramView)
  {
    super.onViewRemoved(paramView);
    l.remove(paramView.getId());
    f localF = a(paramView);
    c.close(localF);
    a.remove(paramView);
    h = true;
  }
  
  public a putShort()
  {
    return new a(-2, -2);
  }
  
  public final boolean refreshDisplay()
  {
    int i1 = getChildCount();
    boolean bool2 = false;
    int n = 0;
    boolean bool1;
    for (;;)
    {
      bool1 = bool2;
      if (n >= i1) {
        break;
      }
      if (getChildAt(n).isLayoutRequested())
      {
        bool1 = true;
        break;
      }
      n += 1;
    }
    if (bool1) {
      a();
    }
    return bool1;
  }
  
  public void removeView(View paramView)
  {
    super.removeView(paramView);
  }
  
  public void requestLayout()
  {
    b();
    super.requestLayout();
  }
  
  public void setConstraintSet(org.codehaus.ui.Item paramItem)
  {
    g = paramItem;
  }
  
  public void setId(int paramInt)
  {
    l.remove(getId());
    super.setId(paramInt);
    l.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt)
  {
    if (paramInt == w) {
      return;
    }
    w = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt)
  {
    if (paramInt == j) {
      return;
    }
    j = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt)
  {
    if (paramInt == f) {
      return;
    }
    f = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt)
  {
    if (paramInt == e) {
      return;
    }
    e = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(Body paramBody)
  {
    d localD = u;
    if (localD != null) {
      localD.c(paramBody);
    }
  }
  
  public void setOptimizationLevel(int paramInt)
  {
    b = paramInt;
    c.d(paramInt);
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return false;
  }
  
  public static class a
    extends ViewGroup.MarginLayoutParams
  {
    public int A = 0;
    public boolean G = false;
    public int H = 0;
    public boolean K = false;
    public float L = 1.0F;
    public int M = 0;
    public int N = 0;
    public f a = new f();
    public boolean alignment = false;
    public int b = -1;
    public boolean bottom = true;
    public float buffer = -1.0F;
    public float c = -1.0F;
    public int code;
    public int color = -1;
    public int count = 0;
    public int d = -1;
    public String data = null;
    public int e = -1;
    public int f = -1;
    public int flags = 0;
    public int g = -1;
    public int h = -1;
    public boolean height = true;
    public int i = -1;
    public int id = -1;
    public int index = -1;
    public int j = -1;
    public int k = -1;
    public float key = -1.0F;
    public int l = -1;
    public int left = 0;
    public int len = 1;
    public int length = -1;
    public float m = 0.0F;
    public int mCurrentPage = -1;
    public boolean mExpanded = false;
    public int mNextPage = -1;
    public int min = -1;
    public int n = 0;
    public float next = 0.5F;
    public int o = -1;
    public int offset = -1;
    public boolean offsetX = false;
    public int p = -1;
    public int position = -1;
    public int q = -1;
    public float r = 1.0F;
    public int range;
    public int s = -1;
    public int size = -1;
    public int state = -1;
    public float step = 0.5F;
    public int t = -1;
    public String time = null;
    public int top = 0;
    public int type = -1;
    public int u = -1;
    public int v = -1;
    public float value;
    public boolean w = false;
    public int width = -1;
    public int x = -1;
    public float y = 0.5F;
    public boolean z = false;
    
    public a(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }
    
    public a(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, IpAddress.ConstraintLayout_Layout);
      int i3 = paramContext.getIndexCount();
      int i1 = 0;
      while (i1 < i3)
      {
        int i2 = paramContext.getIndex(i1);
        int i4 = a.subdomains.get(i2);
        float f1;
        switch (i4)
        {
        default: 
          switch (i4)
          {
          default: 
            break;
          case 51: 
            time = paramContext.getString(i2);
            break;
          case 50: 
            state = paramContext.getDimensionPixelOffset(i2, state);
            break;
          case 49: 
            type = paramContext.getDimensionPixelOffset(i2, type);
            break;
          case 48: 
            count = paramContext.getInt(i2, 0);
            break;
          case 47: 
            flags = paramContext.getInt(i2, 0);
            break;
          case 46: 
            key = paramContext.getFloat(i2, key);
            break;
          case 45: 
            buffer = paramContext.getFloat(i2, buffer);
            break;
          case 44: 
            paramAttributeSet = paramContext.getString(i2);
            data = paramAttributeSet;
            len = -1;
            if (paramAttributeSet != null)
            {
              i4 = paramAttributeSet.length();
              i2 = data.indexOf(',');
              if ((i2 > 0) && (i2 < i4 - 1))
              {
                paramAttributeSet = data.substring(0, i2);
                if (paramAttributeSet.equalsIgnoreCase("W")) {
                  len = 0;
                } else if (paramAttributeSet.equalsIgnoreCase("H")) {
                  len = 1;
                }
                i2 += 1;
              }
              else
              {
                i2 = 0;
              }
              int i5 = data.indexOf(':');
              if ((i5 >= 0) && (i5 < i4 - 1))
              {
                paramAttributeSet = data.substring(i2, i5);
                String str = data.substring(i5 + 1);
                if ((paramAttributeSet.length() > 0) && (str.length() > 0)) {
                  try
                  {
                    f1 = Float.parseFloat(paramAttributeSet);
                    float f2 = Float.parseFloat(str);
                    if ((f1 > 0.0F) && (f2 > 0.0F)) {
                      if (len == 1)
                      {
                        f1 = f2 / f1;
                        Math.abs(f1);
                      }
                      else
                      {
                        f1 /= f2;
                        Math.abs(f1);
                      }
                    }
                  }
                  catch (NumberFormatException paramAttributeSet) {}
                }
              }
              else
              {
                paramAttributeSet = data.substring(i2);
                if (paramAttributeSet.length() > 0) {
                  try
                  {
                    Float.parseFloat(paramAttributeSet);
                  }
                  catch (NumberFormatException paramAttributeSet) {}
                }
              }
            }
            break;
          }
          break;
        case 38: 
          r = Math.max(0.0F, paramContext.getFloat(i2, r));
          left = 2;
          break;
        case 37: 
          i4 = M;
          try
          {
            i4 = paramContext.getDimensionPixelSize(i2, i4);
            M = i4;
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(i2, M) == -2) {
              M = -2;
            }
          }
        case 36: 
          i4 = H;
          try
          {
            i4 = paramContext.getDimensionPixelSize(i2, i4);
            H = i4;
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(i2, H) == -2) {
              H = -2;
            }
          }
        case 35: 
          L = Math.max(0.0F, paramContext.getFloat(i2, L));
          top = 2;
          break;
        case 34: 
          i4 = N;
          try
          {
            i4 = paramContext.getDimensionPixelSize(i2, i4);
            N = i4;
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(i2, N) == -2) {
              N = -2;
            }
          }
        case 33: 
          i4 = A;
          try
          {
            i4 = paramContext.getDimensionPixelSize(i2, i4);
            A = i4;
          }
          catch (Exception paramAttributeSet)
          {
            if (paramContext.getInt(i2, A) == -2) {
              A = -2;
            }
          }
        case 32: 
          i2 = paramContext.getInt(i2, 0);
          left = i2;
          if (i2 == 1) {
            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
          }
          break;
        case 31: 
          i2 = paramContext.getInt(i2, 0);
          top = i2;
          if (i2 == 1) {
            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
          }
          break;
        case 30: 
          next = paramContext.getFloat(i2, next);
          break;
        case 29: 
          y = paramContext.getFloat(i2, y);
          break;
        case 28: 
          z = paramContext.getBoolean(i2, z);
          break;
        case 27: 
          w = paramContext.getBoolean(i2, w);
          break;
        case 26: 
          q = paramContext.getDimensionPixelSize(i2, q);
          break;
        case 25: 
          x = paramContext.getDimensionPixelSize(i2, x);
          break;
        case 24: 
          s = paramContext.getDimensionPixelSize(i2, s);
          break;
        case 23: 
          u = paramContext.getDimensionPixelSize(i2, u);
          break;
        case 22: 
          t = paramContext.getDimensionPixelSize(i2, t);
          break;
        case 21: 
          v = paramContext.getDimensionPixelSize(i2, v);
          break;
        case 20: 
          i4 = paramContext.getResourceId(i2, index);
          index = i4;
          if (i4 == -1) {
            index = paramContext.getInt(i2, -1);
          }
          break;
        case 19: 
          i4 = paramContext.getResourceId(i2, size);
          size = i4;
          if (i4 == -1) {
            size = paramContext.getInt(i2, -1);
          }
          break;
        case 18: 
          i4 = paramContext.getResourceId(i2, color);
          color = i4;
          if (i4 == -1) {
            color = paramContext.getInt(i2, -1);
          }
          break;
        case 17: 
          i4 = paramContext.getResourceId(i2, b);
          b = i4;
          if (i4 == -1) {
            b = paramContext.getInt(i2, -1);
          }
          break;
        case 16: 
          i4 = paramContext.getResourceId(i2, i);
          i = i4;
          if (i4 == -1) {
            i = paramContext.getInt(i2, -1);
          }
          break;
        case 15: 
          i4 = paramContext.getResourceId(i2, k);
          k = i4;
          if (i4 == -1) {
            k = paramContext.getInt(i2, -1);
          }
          break;
        case 14: 
          i4 = paramContext.getResourceId(i2, j);
          j = i4;
          if (i4 == -1) {
            j = paramContext.getInt(i2, -1);
          }
          break;
        case 13: 
          i4 = paramContext.getResourceId(i2, l);
          l = i4;
          if (i4 == -1) {
            l = paramContext.getInt(i2, -1);
          }
          break;
        case 12: 
          i4 = paramContext.getResourceId(i2, g);
          g = i4;
          if (i4 == -1) {
            g = paramContext.getInt(i2, -1);
          }
          break;
        case 11: 
          i4 = paramContext.getResourceId(i2, h);
          h = i4;
          if (i4 == -1) {
            h = paramContext.getInt(i2, -1);
          }
          break;
        case 10: 
          i4 = paramContext.getResourceId(i2, f);
          f = i4;
          if (i4 == -1) {
            f = paramContext.getInt(i2, -1);
          }
          break;
        case 9: 
          i4 = paramContext.getResourceId(i2, e);
          e = i4;
          if (i4 == -1) {
            e = paramContext.getInt(i2, -1);
          }
          break;
        case 8: 
          i4 = paramContext.getResourceId(i2, d);
          d = i4;
          if (i4 == -1) {
            d = paramContext.getInt(i2, -1);
          }
          break;
        case 7: 
          c = paramContext.getFloat(i2, c);
          break;
        case 6: 
          p = paramContext.getDimensionPixelOffset(i2, p);
          break;
        case 5: 
          o = paramContext.getDimensionPixelOffset(i2, o);
          break;
        case 4: 
          f1 = paramContext.getFloat(i2, m) % 360.0F;
          m = f1;
          if (f1 < 0.0F) {
            m = ((360.0F - f1) % 360.0F);
          }
          break;
        case 3: 
          n = paramContext.getDimensionPixelSize(i2, n);
          break;
        case 2: 
          i4 = paramContext.getResourceId(i2, min);
          min = i4;
          if (i4 == -1) {
            min = paramContext.getInt(i2, -1);
          }
          break;
        case 1: 
          id = paramContext.getInt(i2, id);
        }
        i1 += 1;
      }
      paramContext.recycle();
      add();
    }
    
    public a(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public void add()
    {
      alignment = false;
      height = true;
      bottom = true;
      if ((width == -2) && (w))
      {
        height = false;
        if (top == 0) {
          top = 1;
        }
      }
      if ((height == -2) && (z))
      {
        bottom = false;
        if (left == 0) {
          left = 1;
        }
      }
      int i1 = width;
      if ((i1 == 0) || (i1 == -1))
      {
        height = false;
        if ((width == 0) && (top == 1))
        {
          width = -2;
          w = true;
        }
      }
      i1 = height;
      if ((i1 == 0) || (i1 == -1))
      {
        bottom = false;
        if ((height == 0) && (left == 1))
        {
          height = -2;
          z = true;
        }
      }
      if ((c != -1.0F) || (o != -1) || (p != -1))
      {
        alignment = true;
        height = true;
        bottom = true;
        if (!(a instanceof i)) {
          a = new i();
        }
        ((i)a).a(id);
      }
    }
    
    public void resolveLayoutDirection(int paramInt)
    {
      int i1 = leftMargin;
      int i2 = rightMargin;
      super.resolveLayoutDirection(paramInt);
      if (1 == getLayoutDirection()) {
        paramInt = 1;
      } else {
        paramInt = 0;
      }
      position = -1;
      width = -1;
      length = -1;
      offset = -1;
      mCurrentPage = -1;
      mNextPage = -1;
      mCurrentPage = v;
      mNextPage = u;
      step = y;
      range = o;
      code = p;
      value = c;
      if (paramInt != 0)
      {
        paramInt = 0;
        int i3 = b;
        if (i3 != -1)
        {
          position = i3;
          paramInt = 1;
        }
        else
        {
          i3 = color;
          if (i3 != -1)
          {
            width = i3;
            paramInt = 1;
          }
        }
        i3 = size;
        if (i3 != -1)
        {
          offset = i3;
          paramInt = 1;
        }
        i3 = index;
        if (i3 != -1)
        {
          length = i3;
          paramInt = 1;
        }
        i3 = x;
        if (i3 != -1) {
          mNextPage = i3;
        }
        i3 = q;
        if (i3 != -1) {
          mCurrentPage = i3;
        }
        if (paramInt != 0) {
          step = (1.0F - y);
        }
        if ((alignment) && (id == 1))
        {
          float f1 = c;
          if (f1 != -1.0F)
          {
            value = (1.0F - f1);
            range = -1;
            code = -1;
          }
          else
          {
            paramInt = o;
            if (paramInt != -1)
            {
              code = paramInt;
              range = -1;
              value = -1.0F;
            }
            else
            {
              paramInt = p;
              if (paramInt != -1)
              {
                range = paramInt;
                code = -1;
                value = -1.0F;
              }
            }
          }
        }
      }
      else
      {
        paramInt = b;
        if (paramInt != -1) {
          offset = paramInt;
        }
        paramInt = color;
        if (paramInt != -1) {
          length = paramInt;
        }
        paramInt = size;
        if (paramInt != -1) {
          position = paramInt;
        }
        paramInt = index;
        if (paramInt != -1) {
          width = paramInt;
        }
        paramInt = x;
        if (paramInt != -1) {
          mCurrentPage = paramInt;
        }
        paramInt = q;
        if (paramInt != -1) {
          mNextPage = paramInt;
        }
      }
      if ((size == -1) && (index == -1) && (color == -1) && (b == -1))
      {
        paramInt = f;
        if (paramInt != -1)
        {
          position = paramInt;
          if ((rightMargin <= 0) && (i2 > 0)) {
            rightMargin = i2;
          }
        }
        else
        {
          paramInt = h;
          if (paramInt != -1)
          {
            width = paramInt;
            if ((rightMargin <= 0) && (i2 > 0)) {
              rightMargin = i2;
            }
          }
        }
        paramInt = d;
        if (paramInt != -1)
        {
          length = paramInt;
          if ((leftMargin <= 0) && (i1 > 0)) {
            leftMargin = i1;
          }
        }
        else
        {
          paramInt = e;
          if (paramInt != -1)
          {
            offset = paramInt;
            if ((leftMargin <= 0) && (i1 > 0)) {
              leftMargin = i1;
            }
          }
        }
      }
    }
    
    public static class a
    {
      public static final SparseIntArray subdomains;
      
      static
      {
        SparseIntArray localSparseIntArray = new SparseIntArray();
        subdomains = localSparseIntArray;
        localSparseIntArray.append(IpAddress.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintCircle, 2);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        subdomains.append(IpAddress.ConstraintLayout_Layout_android_orientation, 1);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        subdomains.append(IpAddress.ConstraintLayout_Layout_layout_constraintTag, 51);
      }
    }
  }
  
  public class b
    implements org.codehaus.asm.asm.asm.Item
  {
    public int a;
    public int c;
    public ConstraintLayout d;
    public int e;
    public int f;
    public int j;
    public int l;
    
    public b(ConstraintLayout paramConstraintLayout)
    {
      d = paramConstraintLayout;
    }
    
    public final void a(f paramF, a paramA)
    {
      if (paramF == null) {
        return;
      }
      if ((paramF.length() == 8) && (!paramF.hasVisibleItems()))
      {
        j = 0;
        k = 0;
        l = 0;
        return;
      }
      Object localObject1 = b;
      Object localObject2 = a;
      int k = c;
      int i3 = i;
      int i = 0;
      int i1 = 0;
      int i4 = j + l;
      int i2 = c;
      int m = 0;
      int n = 0;
      View localView = (View)paramF.getUserData();
      int i5 = ((Enum)localObject1).ordinal();
      if (i5 != 0)
      {
        if (i5 != 1)
        {
          if (i5 != 2)
          {
            if (i5 == 3)
            {
              i = ViewGroup.getChildMeasureSpec(a, paramF.findItem() + i2, -1);
              FILL[2] = -1;
            }
          }
          else
          {
            i2 = ViewGroup.getChildMeasureSpec(a, i2, -2);
            m = 1;
            if (k == 1) {
              i = 1;
            } else {
              i = 0;
            }
            localObject3 = FILL;
            localObject3[2] = 0;
            if (h)
            {
              if (((i != 0) && (localObject3[3] != 0) && (localObject3[0] != paramF.getValue())) || ((localView instanceof org.codehaus.ui.MethodWriter))) {
                k = 1;
              } else {
                k = 0;
              }
              if ((i == 0) || (k != 0))
              {
                i = paramF.getValue();
                m = 0;
                i = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
                break label332;
              }
            }
            i = i2;
          }
        }
        else
        {
          i = ViewGroup.getChildMeasureSpec(a, i2, -2);
          m = 1;
          FILL[2] = -2;
        }
      }
      else
      {
        i = View.MeasureSpec.makeMeasureSpec(k, 1073741824);
        FILL[2] = k;
      }
      label332:
      k = ((Enum)localObject2).ordinal();
      if (k != 0)
      {
        if (k != 1)
        {
          if (k != 2)
          {
            if (k != 3)
            {
              k = i1;
            }
            else
            {
              k = ViewGroup.getChildMeasureSpec(f, paramF.accept() + i4, -1);
              FILL[3] = -1;
            }
          }
          else
          {
            i2 = ViewGroup.getChildMeasureSpec(f, i4, -2);
            n = 1;
            if (h == 1) {
              k = 1;
            } else {
              k = 0;
            }
            localObject3 = FILL;
            localObject3[3] = 0;
            if (h)
            {
              if (((k != 0) && (localObject3[2] != 0) && (localObject3[1] != paramF.size())) || ((localView instanceof org.codehaus.ui.MethodWriter))) {
                i1 = 1;
              } else {
                i1 = 0;
              }
              if (k != 0)
              {
                k = i2;
                if (i1 == 0) {}
              }
              else
              {
                k = View.MeasureSpec.makeMeasureSpec(paramF.size(), 1073741824);
                n = 0;
              }
            }
            else
            {
              k = i2;
            }
          }
        }
        else
        {
          k = ViewGroup.getChildMeasureSpec(f, i4, -2);
          n = 1;
          FILL[3] = -2;
        }
      }
      else
      {
        k = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
        FILL[3] = i3;
      }
      Object localObject3 = (org.codehaus.asm.asm.MethodWriter)paramF.l();
      if ((localObject3 != null) && (Frame.b(ConstraintLayout.b(ConstraintLayout.this), 256)) && (localView.getMeasuredWidth() == paramF.getValue()) && (localView.getMeasuredWidth() < ((f)localObject3).getValue()) && (localView.getMeasuredHeight() == paramF.size()) && (localView.getMeasuredHeight() < ((f)localObject3).size()) && (localView.getBaseline() == paramF.newClass()) && (!paramF.next()))
      {
        if ((measure(paramF.getVisibleItems(), i, paramF.getValue())) && (measure(paramF.getOrdering(), k, paramF.size()))) {
          i1 = 1;
        } else {
          i1 = 0;
        }
        if (i1 != 0)
        {
          j = paramF.getValue();
          k = paramF.size();
          l = paramF.newClass();
          return;
        }
      }
      if (localObject1 == XLayoutStyle.a) {
        i1 = 1;
      } else {
        i1 = 0;
      }
      if (localObject2 == XLayoutStyle.a) {
        i2 = 1;
      } else {
        i2 = 0;
      }
      if ((localObject2 != XLayoutStyle.r) && (localObject2 != XLayoutStyle.b)) {
        i3 = 0;
      } else {
        i3 = 1;
      }
      if ((localObject1 != XLayoutStyle.r) && (localObject1 != XLayoutStyle.b)) {
        i4 = 0;
      } else {
        i4 = 1;
      }
      if ((i1 != 0) && (E > 0.0F)) {
        i5 = 1;
      } else {
        i5 = 0;
      }
      int i6;
      if ((i2 != 0) && (E > 0.0F)) {
        i6 = 1;
      } else {
        i6 = 0;
      }
      localObject1 = (ConstraintLayout.a)localView.getLayoutParams();
      if ((!h) && (i1 != 0) && (k == 0) && (i2 != 0) && (h == 0))
      {
        i = 0;
        n = 0;
        k = 0;
      }
      else
      {
        if (((localView instanceof ActionMenuItemView)) && ((paramF instanceof Type)))
        {
          localObject2 = (Type)paramF;
          ((ActionMenuItemView)localView).setTitle();
        }
        else
        {
          localView.measure(i, k);
          paramF.close(i, k);
        }
        int i8 = localView.getMeasuredWidth();
        int i7 = localView.getMeasuredHeight();
        int i9 = localView.getBaseline();
        if (m != 0)
        {
          localObject2 = FILL;
          localObject2[0] = i8;
          localObject2[2] = i7;
        }
        else
        {
          localObject2 = FILL;
          localObject2[0] = 0;
          localObject2[2] = 0;
        }
        if (n != 0)
        {
          localObject2 = FILL;
          localObject2[1] = i7;
          localObject2[3] = i8;
        }
        else
        {
          localObject2 = FILL;
          localObject2[1] = 0;
          localObject2[3] = 0;
        }
        m = l;
        if (m > 0) {
          n = Math.max(m, i8);
        } else {
          n = i8;
        }
        i1 = o;
        m = n;
        if (i1 > 0) {
          m = Math.min(i1, n);
        }
        n = m;
        if (n > 0) {
          n = Math.max(n, i7);
        } else {
          n = i7;
        }
        i2 = p;
        i1 = n;
        if (i2 > 0) {
          i1 = Math.min(i2, n);
        }
        n = i1;
        i2 = m;
        if (!Frame.b(ConstraintLayout.b(ConstraintLayout.this), 1))
        {
          float f1;
          if ((i5 != 0) && (i3 != 0))
          {
            f1 = E;
            i2 = (int)(i1 * f1 + 0.5F);
            n = i1;
          }
          else
          {
            n = i1;
            i2 = m;
            if (i6 != 0)
            {
              n = i1;
              i2 = m;
              if (i4 != 0)
              {
                f1 = E;
                n = (int)(m / f1 + 0.5F);
                i2 = m;
              }
            }
          }
        }
        if ((i8 == i2) && (i7 == n))
        {
          i = i2;
          k = i9;
        }
        else
        {
          if (i8 != i2) {
            i = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
          }
          if (i7 != n) {
            k = View.MeasureSpec.makeMeasureSpec(n, 1073741824);
          }
          localView.measure(i, k);
          paramF.close(i, k);
          i = localView.getMeasuredWidth();
          n = localView.getMeasuredHeight();
          k = localView.getBaseline();
        }
      }
      boolean bool1;
      if (k != -1) {
        bool1 = true;
      } else {
        bool1 = false;
      }
      boolean bool2;
      if ((i == c) && (n == i)) {
        bool2 = false;
      } else {
        bool2 = true;
      }
      o = bool2;
      if (K) {
        bool1 = true;
      }
      if ((bool1) && (k != -1) && (paramF.newClass() != k)) {
        o = true;
      }
      j = i;
      k = n;
      p = bool1;
      l = k;
    }
    
    public final void b()
    {
      int k = d.getChildCount();
      int i = 0;
      while (i < k)
      {
        View localView = d.getChildAt(i);
        if ((localView instanceof org.codehaus.ui.MethodWriter)) {
          ((org.codehaus.ui.MethodWriter)localView).a();
        }
        i += 1;
      }
      k = ConstraintLayout.k(d).size();
      if (k > 0)
      {
        i = 0;
        while (i < k)
        {
          ((org.codehaus.ui.Label)ConstraintLayout.k(d).get(i)).setAllCaps();
          i += 1;
        }
      }
    }
    
    public void b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
    {
      j = paramInt3;
      l = paramInt4;
      c = paramInt5;
      e = paramInt6;
      a = paramInt1;
      f = paramInt2;
    }
    
    public final boolean measure(int paramInt1, int paramInt2, int paramInt3)
    {
      if (paramInt1 == paramInt2) {
        return true;
      }
      int i = View.MeasureSpec.getMode(paramInt1);
      View.MeasureSpec.getSize(paramInt1);
      paramInt1 = View.MeasureSpec.getMode(paramInt2);
      paramInt2 = View.MeasureSpec.getSize(paramInt2);
      return (paramInt1 == 1073741824) && ((i == Integer.MIN_VALUE) || (i == 0)) && (paramInt3 == paramInt2);
    }
  }
}
