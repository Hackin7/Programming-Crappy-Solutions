package androidx.activity;

import android.app.Activity;
import android.view.inputmethod.InputMethodManager;
import java.lang.reflect.Field;
import org.util.MenuItem;

public final class ImmLeaksCleaner
  implements MenuItem
{
  public static Field d;
  public static Field e;
  public static int h = 0;
  public static Field i;
  public Activity a;
  
  public ImmLeaksCleaner(Activity paramActivity)
  {
    a = paramActivity;
  }
  
  public static void init()
  {
    h = 2;
    try
    {
      Field localField = InputMethodManager.class.getDeclaredField("mServedView");
      i = localField;
      localField.setAccessible(true);
      localField = InputMethodManager.class.getDeclaredField("mNextServedView");
      e = localField;
      localField.setAccessible(true);
      localField = InputMethodManager.class.getDeclaredField("mH");
      d = localField;
      localField.setAccessible(true);
      h = 1;
      return;
    }
    catch (NoSuchFieldException localNoSuchFieldException) {}
  }
  
  /* Error */
  public void b(org.util.d paramD, org.util.Scope paramScope)
  {
    // Byte code:
    //   0: aload_2
    //   1: getstatic 68	org/util/Scope:ON_DESTROY	Lorg/util/Scope;
    //   4: if_acmpeq +4 -> 8
    //   7: return
    //   8: getstatic 18	androidx/activity/ImmLeaksCleaner:h	I
    //   11: ifne +6 -> 17
    //   14: invokestatic 70	androidx/activity/ImmLeaksCleaner:init	()V
    //   17: getstatic 18	androidx/activity/ImmLeaksCleaner:h	I
    //   20: iconst_1
    //   21: if_icmpne +104 -> 125
    //   24: aload_0
    //   25: getfield 25	androidx/activity/ImmLeaksCleaner:a	Landroid/app/Activity;
    //   28: ldc 72
    //   30: invokevirtual 78	android/app/Activity:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   33: checkcast 30	android/view/inputmethod/InputMethodManager
    //   36: astore_2
    //   37: getstatic 54	androidx/activity/ImmLeaksCleaner:d	Ljava/lang/reflect/Field;
    //   40: astore_1
    //   41: aload_1
    //   42: aload_2
    //   43: invokevirtual 82	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   46: astore_1
    //   47: aload_1
    //   48: ifnonnull +4 -> 52
    //   51: return
    //   52: aload_1
    //   53: monitorenter
    //   54: getstatic 40	androidx/activity/ImmLeaksCleaner:i	Ljava/lang/reflect/Field;
    //   57: astore_3
    //   58: aload_3
    //   59: aload_2
    //   60: invokevirtual 82	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   63: astore_3
    //   64: aload_3
    //   65: checkcast 84	android/view/View
    //   68: astore_3
    //   69: aload_3
    //   70: ifnonnull +6 -> 76
    //   73: aload_1
    //   74: monitorexit
    //   75: return
    //   76: aload_3
    //   77: invokevirtual 88	android/view/View:isAttachedToWindow	()Z
    //   80: ifeq +6 -> 86
    //   83: aload_1
    //   84: monitorexit
    //   85: return
    //   86: getstatic 50	androidx/activity/ImmLeaksCleaner:e	Ljava/lang/reflect/Field;
    //   89: astore_3
    //   90: aload_3
    //   91: aload_2
    //   92: aconst_null
    //   93: invokevirtual 92	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   96: aload_1
    //   97: monitorexit
    //   98: aload_2
    //   99: invokevirtual 95	android/view/inputmethod/InputMethodManager:isActive	()Z
    //   102: pop
    //   103: return
    //   104: astore_2
    //   105: aload_1
    //   106: monitorexit
    //   107: return
    //   108: astore_2
    //   109: goto +11 -> 120
    //   112: astore_2
    //   113: aload_1
    //   114: monitorexit
    //   115: return
    //   116: astore_2
    //   117: aload_1
    //   118: monitorexit
    //   119: return
    //   120: aload_1
    //   121: monitorexit
    //   122: aload_2
    //   123: athrow
    //   124: astore_1
    //   125: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	126	0	this	ImmLeaksCleaner
    //   0	126	1	paramD	org.util.d
    //   0	126	2	paramScope	org.util.Scope
    //   57	34	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   90	96	104	java/lang/IllegalAccessException
    //   54	58	108	java/lang/Throwable
    //   58	64	108	java/lang/Throwable
    //   64	69	108	java/lang/Throwable
    //   73	75	108	java/lang/Throwable
    //   76	85	108	java/lang/Throwable
    //   90	96	108	java/lang/Throwable
    //   96	98	108	java/lang/Throwable
    //   105	107	108	java/lang/Throwable
    //   113	115	108	java/lang/Throwable
    //   117	119	108	java/lang/Throwable
    //   120	122	108	java/lang/Throwable
    //   58	64	112	java/lang/ClassCastException
    //   64	69	112	java/lang/ClassCastException
    //   58	64	116	java/lang/IllegalAccessException
    //   41	47	124	java/lang/IllegalAccessException
  }
}
