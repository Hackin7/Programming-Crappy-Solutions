package commons.httpclient.cookie.params;

public abstract class e
{
  public int e;
  public byte[] f;
  
  public e() {}
}
