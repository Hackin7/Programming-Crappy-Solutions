package commons.httpclient.cookie.params;

public class g
  extends e
{
  public static final byte[] a = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
  public static final byte[] d = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
  public final byte[] b;
  public int c;
  public final boolean e;
  public final boolean f;
  public final byte[] g;
  public final boolean h;
  public int i;
  
  public g(int paramInt, byte[] paramArrayOfByte)
  {
    super(null);
    f = paramArrayOfByte;
    boolean bool2 = true;
    boolean bool1;
    if ((paramInt & 0x1) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    e = bool1;
    if ((paramInt & 0x2) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    }
    f = bool1;
    if ((paramInt & 0x4) != 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    }
    h = bool1;
    if ((paramInt & 0x8) == 0) {
      paramArrayOfByte = d;
    } else {
      paramArrayOfByte = a;
    }
    g = paramArrayOfByte;
    b = new byte[2];
    c = 0;
    if (f) {
      paramInt = 19;
    } else {
      paramInt = -1;
    }
    i = paramInt;
  }
  
  public void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    byte[] arrayOfByte1 = g;
    byte[] arrayOfByte2 = f;
    int k = 0;
    int i1 = i;
    int j = paramInt1;
    int i2 = paramInt2 + paramInt1;
    int m = -1;
    paramInt2 = c;
    if (paramInt2 != 1)
    {
      if ((paramInt2 == 2) && (paramInt1 + 1 <= i2))
      {
        byte[] arrayOfByte3 = b;
        paramInt2 = arrayOfByte3[0];
        m = (arrayOfByte3[1] & 0xFF) << 8 | (paramInt2 & 0xFF) << 16 | paramArrayOfByte[paramInt1] & 0xFF;
        c = 0;
        j = paramInt1 + 1;
      }
    }
    else if (paramInt1 + 2 <= i2)
    {
      j = b[0];
      paramInt2 = paramInt1 + 1;
      m = (paramArrayOfByte[paramInt1] & 0xFF) << 8 | (j & 0xFF) << 16 | paramArrayOfByte[paramInt2] & 0xFF;
      c = 0;
      j = paramInt2 + 1;
    }
    paramInt1 = k;
    paramInt2 = i1;
    k = j;
    int n;
    if (m != -1)
    {
      paramInt2 = 0 + 1;
      arrayOfByte2[0] = arrayOfByte1[(m >> 18 & 0x3F)];
      paramInt1 = paramInt2 + 1;
      arrayOfByte2[paramInt2] = arrayOfByte1[(m >> 12 & 0x3F)];
      paramInt2 = paramInt1 + 1;
      arrayOfByte2[paramInt1] = arrayOfByte1[(m >> 6 & 0x3F)];
      n = paramInt2 + 1;
      arrayOfByte2[paramInt2] = arrayOfByte1[(m & 0x3F)];
      m = i1 - 1;
      paramInt1 = n;
      paramInt2 = m;
      k = j;
      if (m == 0)
      {
        paramInt1 = n;
        if (h)
        {
          arrayOfByte2[n] = 13;
          paramInt1 = n + 1;
        }
        arrayOfByte2[paramInt1] = 10;
        paramInt2 = 19;
        paramInt1 += 1;
        k = j;
      }
    }
    while (k + 3 <= i2)
    {
      j = (paramArrayOfByte[k] & 0xFF) << 16 | (paramArrayOfByte[(k + 1)] & 0xFF) << 8 | paramArrayOfByte[(k + 2)] & 0xFF;
      arrayOfByte2[paramInt1] = arrayOfByte1[(j >> 18 & 0x3F)];
      arrayOfByte2[(paramInt1 + 1)] = arrayOfByte1[(j >> 12 & 0x3F)];
      arrayOfByte2[(paramInt1 + 2)] = arrayOfByte1[(j >> 6 & 0x3F)];
      arrayOfByte2[(paramInt1 + 3)] = arrayOfByte1[(j & 0x3F)];
      m = k + 3;
      j = paramInt1 + 4;
      n = paramInt2 - 1;
      paramInt1 = j;
      paramInt2 = n;
      k = m;
      if (n == 0)
      {
        paramInt1 = j;
        if (h)
        {
          arrayOfByte2[j] = 13;
          paramInt1 = j + 1;
        }
        arrayOfByte2[paramInt1] = 10;
        paramInt2 = 19;
        paramInt1 += 1;
        k = m;
      }
    }
    if (paramBoolean)
    {
      m = c;
      if (k - m == i2 - 1)
      {
        j = 0;
        if (m > 0)
        {
          k = b[0];
          j = 0 + 1;
        }
        else
        {
          k = paramArrayOfByte[k];
        }
        k = (k & 0xFF) << 4;
        c -= j;
        m = paramInt1 + 1;
        arrayOfByte2[paramInt1] = arrayOfByte1[(k >> 6 & 0x3F)];
        j = m + 1;
        arrayOfByte2[m] = arrayOfByte1[(k & 0x3F)];
        paramInt1 = j;
        if (e)
        {
          k = j + 1;
          arrayOfByte2[j] = 61;
          paramInt1 = k + 1;
          arrayOfByte2[k] = 61;
        }
        j = paramInt1;
        if (f)
        {
          j = paramInt1;
          if (h)
          {
            arrayOfByte2[paramInt1] = 13;
            j = paramInt1 + 1;
          }
          arrayOfByte2[j] = 10;
          j += 1;
        }
      }
      else if (k - m == i2 - 2)
      {
        j = 0;
        if (m > 1)
        {
          n = b[0];
          j = 0 + 1;
          m = k;
          k = n;
        }
        else
        {
          m = paramArrayOfByte[k];
          n = k + 1;
          k = m;
          m = n;
        }
        if (c > 0)
        {
          m = b[j];
          j += 1;
        }
        else
        {
          m = paramArrayOfByte[m];
        }
        k = (k & 0xFF) << 10 | (m & 0xFF) << 2;
        c -= j;
        j = paramInt1 + 1;
        arrayOfByte2[paramInt1] = arrayOfByte1[(k >> 12 & 0x3F)];
        paramInt1 = j + 1;
        arrayOfByte2[j] = arrayOfByte1[(k >> 6 & 0x3F)];
        j = paramInt1 + 1;
        arrayOfByte2[paramInt1] = arrayOfByte1[(k & 0x3F)];
        paramInt1 = j;
        if (e)
        {
          arrayOfByte2[j] = 61;
          paramInt1 = j + 1;
        }
        j = paramInt1;
        if (f)
        {
          j = paramInt1;
          if (h)
          {
            arrayOfByte2[paramInt1] = 13;
            j = paramInt1 + 1;
          }
          arrayOfByte2[j] = 10;
          j += 1;
        }
      }
      else
      {
        j = paramInt1;
        if (f)
        {
          j = paramInt1;
          if (paramInt1 > 0)
          {
            j = paramInt1;
            if (paramInt2 != 19)
            {
              j = paramInt1;
              if (h)
              {
                arrayOfByte2[paramInt1] = 13;
                j = paramInt1 + 1;
              }
              arrayOfByte2[j] = 10;
              j += 1;
            }
          }
        }
      }
    }
    else if (k == i2 - 1)
    {
      arrayOfByte1 = b;
      j = c;
      c = (j + 1);
      arrayOfByte1[j] = paramArrayOfByte[k];
      j = paramInt1;
    }
    else
    {
      j = paramInt1;
      if (k == i2 - 2)
      {
        arrayOfByte1 = b;
        j = c;
        m = j + 1;
        c = m;
        arrayOfByte1[j] = paramArrayOfByte[k];
        c = (m + 1);
        arrayOfByte1[m] = paramArrayOfByte[(k + 1)];
        j = paramInt1;
      }
    }
    e = j;
    i = paramInt2;
  }
}
