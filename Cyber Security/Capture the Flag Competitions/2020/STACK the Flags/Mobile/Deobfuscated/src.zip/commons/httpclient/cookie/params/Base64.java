package commons.httpclient.cookie.params;

import java.io.UnsupportedEncodingException;

public class Base64
{
  public static byte[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    g localG = new g(paramInt3, null);
    int i = paramInt2 / 3 * 4;
    boolean bool = e;
    int j = 2;
    if (bool)
    {
      paramInt3 = i;
      if (paramInt2 % 3 > 0) {
        paramInt3 = i + 4;
      }
    }
    else
    {
      paramInt3 = paramInt2 % 3;
      if (paramInt3 != 1)
      {
        if (paramInt3 != 2) {
          paramInt3 = i;
        } else {
          paramInt3 = i + 3;
        }
      }
      else {
        paramInt3 = i + 2;
      }
    }
    i = paramInt3;
    if (f)
    {
      i = paramInt3;
      if (paramInt2 > 0)
      {
        int k = (paramInt2 - 1) / 57;
        if (h) {
          i = j;
        } else {
          i = 1;
        }
        i = paramInt3 + (k + 1) * i;
      }
    }
    f = new byte[i];
    localG.a(paramArrayOfByte, paramInt1, paramInt2, true);
    return f;
  }
  
  public static byte[] decode(String paramString, int paramInt)
  {
    return decode(paramString.getBytes(), paramInt);
  }
  
  public static byte[] decode(byte[] paramArrayOfByte, int paramInt)
  {
    return decode(paramArrayOfByte, 0, paramArrayOfByte.length, paramInt);
  }
  
  public static byte[] decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    Object localObject = new l(paramInt3, new byte[paramInt2 * 3 / 4]);
    if (((l)localObject).a(paramArrayOfByte, paramInt1, paramInt2, true))
    {
      paramInt1 = e;
      paramArrayOfByte = f;
      if (paramInt1 == paramArrayOfByte.length) {
        return paramArrayOfByte;
      }
      localObject = new byte[paramInt1];
      System.arraycopy(paramArrayOfByte, 0, localObject, 0, paramInt1);
      return localObject;
    }
    throw new IllegalArgumentException("bad base-64");
  }
  
  public static String encode(byte[] paramArrayOfByte, int paramInt)
  {
    try
    {
      paramArrayOfByte = new String(encodeBase64(paramArrayOfByte, paramInt), "US-ASCII");
      return paramArrayOfByte;
    }
    catch (UnsupportedEncodingException paramArrayOfByte)
    {
      throw new AssertionError(paramArrayOfByte);
    }
  }
  
  public static byte[] encodeBase64(byte[] paramArrayOfByte, int paramInt)
  {
    return a(paramArrayOfByte, 0, paramArrayOfByte.length, paramInt);
  }
}
