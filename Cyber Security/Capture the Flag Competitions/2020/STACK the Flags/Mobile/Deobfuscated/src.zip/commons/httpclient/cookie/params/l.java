package commons.httpclient.cookie.params;

public class l
  extends e
{
  public static final int[] a = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
  public static final int[] b = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
  public final int[] c;
  public int e;
  public int i;
  
  public l(int paramInt, byte[] paramArrayOfByte)
  {
    super(null);
    f = paramArrayOfByte;
    if ((paramInt & 0x8) == 0) {
      paramArrayOfByte = a;
    } else {
      paramArrayOfByte = b;
    }
    c = paramArrayOfByte;
    i = 0;
    e = 0;
  }
  
  public boolean a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (i == 6) {
      return false;
    }
    int k = paramInt1;
    int i2 = paramInt2 + paramInt1;
    int n = i;
    paramInt2 = e;
    paramInt1 = 0;
    byte[] arrayOfByte = f;
    int[] arrayOfInt = c;
    int m;
    int j;
    for (;;)
    {
      m = paramInt2;
      j = paramInt1;
      if (k >= i2) {
        break;
      }
      int i1 = k;
      m = paramInt2;
      j = paramInt1;
      if (n == 0)
      {
        while (k + 4 <= i2)
        {
          m = arrayOfInt[(paramArrayOfByte[k] & 0xFF)] << 18 | arrayOfInt[(paramArrayOfByte[(k + 1)] & 0xFF)] << 12 | arrayOfInt[(paramArrayOfByte[(k + 2)] & 0xFF)] << 6 | arrayOfInt[(paramArrayOfByte[(k + 3)] & 0xFF)];
          j = m;
          paramInt2 = j;
          if (m < 0) {
            break;
          }
          arrayOfByte[(paramInt1 + 2)] = ((byte)m);
          arrayOfByte[(paramInt1 + 1)] = ((byte)(m >> 8));
          arrayOfByte[paramInt1] = ((byte)(m >> 16));
          paramInt1 += 3;
          k += 4;
          paramInt2 = j;
        }
        i1 = k;
        m = paramInt2;
        j = paramInt1;
        if (k >= i2)
        {
          m = paramInt2;
          j = paramInt1;
          break;
        }
      }
      k = arrayOfInt[(paramArrayOfByte[i1] & 0xFF)];
      if (n != 0)
      {
        if (n != 1)
        {
          if (n != 2)
          {
            if (n != 3)
            {
              if (n != 4)
              {
                if (n != 5)
                {
                  paramInt1 = n;
                  paramInt2 = m;
                }
                else
                {
                  paramInt1 = n;
                  paramInt2 = m;
                  if (k != -1)
                  {
                    i = 6;
                    return false;
                  }
                }
              }
              else if (k == -2)
              {
                paramInt1 = n + 1;
                paramInt2 = m;
              }
              else
              {
                paramInt1 = n;
                paramInt2 = m;
                if (k != -1)
                {
                  i = 6;
                  return false;
                }
              }
            }
            else if (k >= 0)
            {
              paramInt2 = m << 6 | k;
              arrayOfByte[(j + 2)] = ((byte)paramInt2);
              arrayOfByte[(j + 1)] = ((byte)(paramInt2 >> 8));
              arrayOfByte[j] = ((byte)(paramInt2 >> 16));
              j += 3;
              paramInt1 = 0;
            }
            else if (k == -2)
            {
              arrayOfByte[(j + 1)] = ((byte)(m >> 2));
              arrayOfByte[j] = ((byte)(m >> 10));
              j += 2;
              paramInt1 = 5;
              paramInt2 = m;
            }
            else
            {
              paramInt1 = n;
              paramInt2 = m;
              if (k != -1)
              {
                i = 6;
                return false;
              }
            }
          }
          else if (k >= 0)
          {
            paramInt2 = m << 6 | k;
            paramInt1 = n + 1;
          }
          else if (k == -2)
          {
            arrayOfByte[j] = ((byte)(m >> 4));
            paramInt1 = 4;
            j += 1;
            paramInt2 = m;
          }
          else
          {
            paramInt1 = n;
            paramInt2 = m;
            if (k != -1)
            {
              i = 6;
              return false;
            }
          }
        }
        else if (k >= 0)
        {
          paramInt2 = m << 6 | k;
          paramInt1 = n + 1;
        }
        else
        {
          paramInt1 = n;
          paramInt2 = m;
          if (k != -1)
          {
            i = 6;
            return false;
          }
        }
      }
      else if (k >= 0)
      {
        paramInt2 = k;
        paramInt1 = n + 1;
      }
      else
      {
        paramInt1 = n;
        paramInt2 = m;
        if (k != -1)
        {
          i = 6;
          return false;
        }
      }
      k = i1 + 1;
      n = paramInt1;
      paramInt1 = j;
    }
    if (!paramBoolean)
    {
      i = n;
      e = m;
      e = j;
      return true;
    }
    if (n != 1)
    {
      if (n != 2)
      {
        if (n != 3)
        {
          if (n == 4)
          {
            i = 6;
            return false;
          }
        }
        else
        {
          paramInt1 = j + 1;
          arrayOfByte[j] = ((byte)(m >> 10));
          j = paramInt1 + 1;
          arrayOfByte[paramInt1] = ((byte)(m >> 2));
        }
      }
      else
      {
        arrayOfByte[j] = ((byte)(m >> 4));
        j += 1;
      }
      i = n;
      e = j;
      return true;
    }
    i = 6;
    return false;
  }
}
