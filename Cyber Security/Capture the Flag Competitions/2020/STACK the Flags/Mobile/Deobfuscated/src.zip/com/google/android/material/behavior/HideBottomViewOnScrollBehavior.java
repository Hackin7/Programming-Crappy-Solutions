package com.google.android.material.behavior;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.c;
import apache.org.org.core.util.AnimationUtils;

public class HideBottomViewOnScrollBehavior<V extends View>
  extends CoordinatorLayout.c<V>
{
  public ViewPropertyAnimator animator;
  public int visibility = 2;
  public int x = 0;
  
  public HideBottomViewOnScrollBehavior() {}
  
  public HideBottomViewOnScrollBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public final void close(View paramView, int paramInt, long paramLong, TimeInterpolator paramTimeInterpolator)
  {
    animator = paramView.animate().translationY(paramInt).setInterpolator(paramTimeInterpolator).setDuration(paramLong).setListener(new a());
  }
  
  public void hide(View paramView)
  {
    ViewPropertyAnimator localViewPropertyAnimator = animator;
    if (localViewPropertyAnimator != null)
    {
      localViewPropertyAnimator.cancel();
      paramView.clearAnimation();
    }
    visibility = 2;
    close(paramView, 0, 225L, AnimationUtils.y);
  }
  
  public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt)
  {
    x = paramView.getMeasuredHeight();
    super.onLayoutChild(paramCoordinatorLayout, paramView, paramInt);
    return false;
  }
  
  public void onNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((visibility != 1) && (paramInt2 > 0))
    {
      show(paramView1);
      return;
    }
    if ((visibility != 2) && (paramInt2 < 0)) {
      hide(paramView1);
    }
  }
  
  public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, View paramView3, int paramInt)
  {
    return paramInt == 2;
  }
  
  public void show(View paramView)
  {
    ViewPropertyAnimator localViewPropertyAnimator = animator;
    if (localViewPropertyAnimator != null)
    {
      localViewPropertyAnimator.cancel();
      paramView.clearAnimation();
    }
    visibility = 1;
    close(paramView, x, 175L, AnimationUtils.x);
  }
  
  public class a
    extends AnimatorListenerAdapter
  {
    public a() {}
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      HideBottomViewOnScrollBehavior.access$setRunningAnimation(HideBottomViewOnScrollBehavior.this, null);
    }
  }
}
