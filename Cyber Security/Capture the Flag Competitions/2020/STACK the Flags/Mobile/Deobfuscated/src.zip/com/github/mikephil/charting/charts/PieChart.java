package com.github.mikephil.charting.charts;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import apache.github.mikephil.charting.buffer.PieRadarChartBase;
import apache.github.mikephil.charting.charts.CandleEntry;
import apache.github.mikephil.charting.charts.ChartData;
import apache.github.mikephil.charting.charts.PieData;
import apache.github.mikephil.charting.components.XAxis;
import apache.github.mikephil.charting.data.PointF;
import apache.github.mikephil.charting.data.Utils;
import apache.github.mikephil.charting.exception.listener.IDataSet;
import apache.github.mikephil.charting.exception.listener.IPieDataSet;
import apache.github.mikephil.charting.highlight.ChartAnimator;
import apache.github.mikephil.charting.listener.BubbleChartRenderer;
import apache.github.mikephil.charting.listener.Highlight;
import apache.github.mikephil.charting.renderer.DataRenderer;
import apache.github.mikephil.charting.renderer.PagerSlidingTabStrip;
import apache.github.mikephil.charting.renderer.PieChartRenderer;
import b.c.a.a.b.b;
import b.c.a.a.d.f;
import java.util.List;

public class PieChart
  extends b<f>
{
  public float[] mAbsoluteAngles = new float[1];
  public CharSequence mCenterText = "";
  public float mCenterTextRadiusPercent = 100.0F;
  public RectF mCircleBox = new RectF();
  public float[] mDrawAngles = new float[1];
  public boolean mDrawCenterText = true;
  public boolean mDrawHole = true;
  public boolean mDrawRoundedSlices = false;
  public boolean mDrawSlicesUnderHole = false;
  public boolean mDrawXLabels = true;
  public float mHoleRadiusPercent = 50.0F;
  public float mMaxAngle = 360.0F;
  public PointF mTempPoint = PointF.getPosition(0.0F, 0.0F);
  public float mTransparentCircleRadiusPercent = 55.0F;
  public boolean mUsePercentValues = false;
  public float x = 0.0F;
  
  public PieChart(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public final float calcAngle(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 / paramFloat2 * mMaxAngle;
  }
  
  public void calcMinMax()
  {
    drawValues();
  }
  
  public void calculateOffsets()
  {
    super.calculateOffsets();
    if (mData == null) {
      return;
    }
    float f1 = getDiameter() / 2.0F;
    PointF localPointF = getCenterOffsets();
    float f2 = ((PieData)mData).getDataSet().getSelectionShift();
    RectF localRectF = mCircleBox;
    float f3 = x;
    float f4 = y;
    localRectF.set(f3 - f1 + f2, f4 - f1 + f2, f3 + f1 - f2, f4 + f1 - f2);
    PointF.getPosition(localPointF);
  }
  
  public final void drawValues()
  {
    int n = ((PieData)mData).getPosition();
    int i;
    if (mDrawAngles.length != n)
    {
      mDrawAngles = new float[n];
    }
    else
    {
      i = 0;
      while (i < n)
      {
        mDrawAngles[i] = 0.0F;
        i += 1;
      }
    }
    if (mAbsoluteAngles.length != n)
    {
      mAbsoluteAngles = new float[n];
    }
    else
    {
      i = 0;
      while (i < n)
      {
        mAbsoluteAngles[i] = 0.0F;
        i += 1;
      }
    }
    float f5 = ((PieData)mData).getYValueSum();
    Object localObject = ((PieData)mData).getDataSets();
    float f1 = x;
    if ((f1 != 0.0F) && (n * f1 <= mMaxAngle)) {
      i = 1;
    } else {
      i = 0;
    }
    float[] arrayOfFloat1 = new float[n];
    int k = 0;
    float f2 = 0.0F;
    f1 = 0.0F;
    int j = 0;
    while (j < ((PieData)mData).getDataSetCount())
    {
      IPieDataSet localIPieDataSet = (IPieDataSet)((List)localObject).get(j);
      int m = 0;
      while (m < localIPieDataSet.size())
      {
        float f6 = calcAngle(Math.abs(((CandleEntry)localIPieDataSet.getEntryForIndex(m)).getVal()), f5);
        float f3 = f2;
        float f4 = f1;
        if (i != 0)
        {
          f3 = x;
          f4 = f6 - f3;
          if (f4 <= 0.0F)
          {
            arrayOfFloat1[k] = f3;
            f3 = f2 + -f4;
            f4 = f1;
          }
          else
          {
            arrayOfFloat1[k] = f6;
            f4 = f1 + f4;
            f3 = f2;
          }
        }
        float[] arrayOfFloat2 = mDrawAngles;
        arrayOfFloat2[k] = f6;
        if (k == 0)
        {
          mAbsoluteAngles[k] = arrayOfFloat2[k];
        }
        else
        {
          float[] arrayOfFloat3 = mAbsoluteAngles;
          arrayOfFloat3[k] = (arrayOfFloat3[(k - 1)] + arrayOfFloat2[k]);
        }
        k += 1;
        m += 1;
        f2 = f3;
        f1 = f4;
      }
      j += 1;
    }
    if (i != 0)
    {
      i = 0;
      while (i < n)
      {
        arrayOfFloat1[i] -= (arrayOfFloat1[i] - x) / f1 * f2;
        if (i == 0)
        {
          mAbsoluteAngles[0] = arrayOfFloat1[0];
        }
        else
        {
          localObject = mAbsoluteAngles;
          localObject[i] = (localObject[(i - 1)] + arrayOfFloat1[i]);
        }
        i += 1;
      }
      mDrawAngles = arrayOfFloat1;
    }
  }
  
  public float[] getAbsoluteAngles()
  {
    return mAbsoluteAngles;
  }
  
  public PointF getCenterCircleBox()
  {
    return PointF.getPosition(mCircleBox.centerX(), mCircleBox.centerY());
  }
  
  public CharSequence getCenterText()
  {
    return mCenterText;
  }
  
  public PointF getCenterTextOffset()
  {
    PointF localPointF = mTempPoint;
    return PointF.getPosition(x, y);
  }
  
  public float getCenterTextRadiusPercent()
  {
    return mCenterTextRadiusPercent;
  }
  
  public RectF getCircleBox()
  {
    return mCircleBox;
  }
  
  public float[] getDrawAngles()
  {
    return mDrawAngles;
  }
  
  public float getHoleRadius()
  {
    return mHoleRadiusPercent;
  }
  
  public int getIndexForAngle(float paramFloat)
  {
    paramFloat = Utils.getNormalizedAngle(paramFloat - getRotationAngle());
    int i = 0;
    for (;;)
    {
      float[] arrayOfFloat = mAbsoluteAngles;
      if (i >= arrayOfFloat.length) {
        break;
      }
      if (arrayOfFloat[i] > paramFloat) {
        return i;
      }
      i += 1;
    }
    return -1;
  }
  
  public float[] getMarkerPosition(Highlight paramHighlight)
  {
    PointF localPointF = getCenterCircleBox();
    float f2 = getRadius();
    float f1 = f2 / 10.0F * 3.6F;
    if (isDrawHoleEnabled()) {
      f1 = (f2 - f2 / 100.0F * getHoleRadius()) / 2.0F;
    }
    f2 -= f1;
    float f3 = getRotationAngle();
    int i = (int)paramHighlight.getXIndex();
    float f4 = mDrawAngles[i] / 2.0F;
    f1 = (float)(f2 * Math.cos(Math.toRadians((mAbsoluteAngles[i] + f3 - f4) * mAnimator.getPhaseY())) + x);
    f2 = (float)(f2 * Math.sin(Math.toRadians((mAbsoluteAngles[i] + f3 - f4) * mAnimator.getPhaseY())) + y);
    PointF.getPosition(localPointF);
    return new float[] { f1, f2 };
  }
  
  public float getMaxAngle()
  {
    return mMaxAngle;
  }
  
  public float getMinAngleForSlices()
  {
    return x;
  }
  
  public float getRadius()
  {
    RectF localRectF = mCircleBox;
    if (localRectF == null) {
      return 0.0F;
    }
    return Math.min(localRectF.width() / 2.0F, mCircleBox.height() / 2.0F);
  }
  
  public float getRequiredBaseOffset()
  {
    return 0.0F;
  }
  
  public float getRequiredLegendOffset()
  {
    return mLegendRenderer.getLabelPaint().getTextSize() * 2.0F;
  }
  
  public float getTransparentCircleRadius()
  {
    return mTransparentCircleRadiusPercent;
  }
  
  public XAxis getXAxis()
  {
    throw new RuntimeException("PieChart has no XAxis");
  }
  
  public void init()
  {
    super.init();
    mRenderer = new PieChartRenderer(this, mAnimator, mViewPortHandler);
    mXAxis = null;
    mHighlighter = new BubbleChartRenderer(this);
  }
  
  public boolean isDrawCenterTextEnabled()
  {
    return mDrawCenterText;
  }
  
  public boolean isDrawHoleEnabled()
  {
    return mDrawHole;
  }
  
  public boolean isDrawRoundedSlicesEnabled()
  {
    return mDrawRoundedSlices;
  }
  
  public boolean isDrawSliceTextEnabled()
  {
    return mDrawXLabels;
  }
  
  public boolean isDrawSlicesUnderHoleEnabled()
  {
    return mDrawSlicesUnderHole;
  }
  
  public boolean isUsePercentValuesEnabled()
  {
    return mUsePercentValues;
  }
  
  public boolean needsHighlight(int paramInt)
  {
    if (!valuesToHighlight()) {
      return false;
    }
    int i = 0;
    for (;;)
    {
      Highlight[] arrayOfHighlight = mIndicesToHighlight;
      if (i >= arrayOfHighlight.length) {
        break;
      }
      if ((int)arrayOfHighlight[i].getXIndex() == paramInt) {
        return true;
      }
      i += 1;
    }
    return false;
  }
  
  public void onDetachedFromWindow()
  {
    DataRenderer localDataRenderer = mRenderer;
    if ((localDataRenderer != null) && ((localDataRenderer instanceof PieChartRenderer))) {
      ((PieChartRenderer)localDataRenderer).releaseBitmap();
    }
    super.onDetachedFromWindow();
  }
  
  public void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if (mData == null) {
      return;
    }
    mRenderer.drawData(paramCanvas);
    if (valuesToHighlight()) {
      mRenderer.drawHighlighted(paramCanvas, mIndicesToHighlight);
    }
    mRenderer.drawExtras(paramCanvas);
    mRenderer.drawValues(paramCanvas);
    mLegendRenderer.a(paramCanvas);
    init(paramCanvas);
    drawMarkers(paramCanvas);
  }
  
  public void setCenterText(CharSequence paramCharSequence)
  {
    if (paramCharSequence == null)
    {
      mCenterText = "";
      return;
    }
    mCenterText = paramCharSequence;
  }
  
  public void setCenterTextColor(int paramInt)
  {
    ((PieChartRenderer)mRenderer).getPaintCenterText().setColor(paramInt);
  }
  
  public void setCenterTextRadiusPercent(float paramFloat)
  {
    mCenterTextRadiusPercent = paramFloat;
  }
  
  public void setCenterTextSize(float paramFloat)
  {
    ((PieChartRenderer)mRenderer).getPaintCenterText().setTextSize(Utils.convertDpToPixel(paramFloat));
  }
  
  public void setCenterTextSizePixels(float paramFloat)
  {
    ((PieChartRenderer)mRenderer).getPaintCenterText().setTextSize(paramFloat);
  }
  
  public void setCenterTextTypeface(Typeface paramTypeface)
  {
    ((PieChartRenderer)mRenderer).getPaintCenterText().setTypeface(paramTypeface);
  }
  
  public void setDrawCenterText(boolean paramBoolean)
  {
    mDrawCenterText = paramBoolean;
  }
  
  public void setDrawEntryLabels(boolean paramBoolean)
  {
    mDrawXLabels = paramBoolean;
  }
  
  public void setDrawHoleEnabled(boolean paramBoolean)
  {
    mDrawHole = paramBoolean;
  }
  
  public void setDrawRoundedSlices(boolean paramBoolean)
  {
    mDrawSlicesUnderHole = paramBoolean;
  }
  
  public void setDrawSliceText(boolean paramBoolean)
  {
    mDrawXLabels = paramBoolean;
  }
  
  public void setDrawSlicesUnderHole(boolean paramBoolean)
  {
    mUsePercentValues = paramBoolean;
  }
  
  public void setEntryLabelColor(int paramInt)
  {
    ((PieChartRenderer)mRenderer).getPaint().setColor(paramInt);
  }
  
  public void setEntryLabelTextSize(float paramFloat)
  {
    ((PieChartRenderer)mRenderer).getPaint().setTextSize(Utils.convertDpToPixel(paramFloat));
  }
  
  public void setEntryLabelTypeface(Typeface paramTypeface)
  {
    ((PieChartRenderer)mRenderer).getPaint().setTypeface(paramTypeface);
  }
  
  public void setHoleColor(int paramInt)
  {
    ((PieChartRenderer)mRenderer).getPaintHole().setColor(paramInt);
  }
  
  public void setHoleRadius(float paramFloat)
  {
    mHoleRadiusPercent = paramFloat;
  }
  
  public void setMaxAngle(float paramFloat)
  {
    float f = paramFloat;
    if (paramFloat > 360.0F) {
      f = 360.0F;
    }
    paramFloat = f;
    if (f < 90.0F) {
      paramFloat = 90.0F;
    }
    mMaxAngle = paramFloat;
  }
  
  public void setMinAngleForSlices(float paramFloat)
  {
    float f = mMaxAngle;
    if (paramFloat > f / 2.0F)
    {
      f /= 2.0F;
    }
    else
    {
      f = paramFloat;
      if (paramFloat < 0.0F) {
        f = 0.0F;
      }
    }
    x = f;
  }
  
  public void setTransparentCircleAlpha(int paramInt)
  {
    ((PieChartRenderer)mRenderer).getPaintTransparentCircle().setAlpha(paramInt);
  }
  
  public void setTransparentCircleColor(int paramInt)
  {
    Paint localPaint = ((PieChartRenderer)mRenderer).getPaintTransparentCircle();
    int i = localPaint.getAlpha();
    localPaint.setColor(paramInt);
    localPaint.setAlpha(i);
  }
  
  public void setTransparentCircleRadius(float paramFloat)
  {
    mTransparentCircleRadiusPercent = paramFloat;
  }
  
  public void setUsePercentValues(boolean paramBoolean)
  {
    mDrawRoundedSlices = paramBoolean;
  }
}
