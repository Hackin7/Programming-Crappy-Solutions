package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public abstract class ExpandableTransformationBehavior
  extends ExpandableBehavior
{
  public AnimatorSet animator;
  
  public ExpandableTransformationBehavior() {}
  
  public ExpandableTransformationBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public abstract AnimatorSet b(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2);
  
  public boolean start(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool;
    if (animator != null) {
      bool = true;
    } else {
      bool = false;
    }
    if (bool) {
      animator.cancel();
    }
    paramView1 = b(paramView1, paramView2, paramBoolean1, bool);
    animator = paramView1;
    paramView1.addListener(new a());
    animator.start();
    if (!paramBoolean2) {
      animator.end();
    }
    return true;
  }
  
  public class a
    extends AnimatorListenerAdapter
  {
    public a() {}
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      ExpandableTransformationBehavior.access$setRunningAnimation(ExpandableTransformationBehavior.this, null);
    }
  }
}
