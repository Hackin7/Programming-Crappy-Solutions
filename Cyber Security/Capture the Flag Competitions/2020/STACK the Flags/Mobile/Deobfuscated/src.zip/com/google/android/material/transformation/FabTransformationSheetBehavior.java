package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.f;
import apache.org.org.core.TransactionOutputChanges;
import apache.org.org.core.util.Frame;
import apache.org.org.core.util.d;
import java.util.HashMap;
import java.util.Map;
import org.core.view.ViewCompat;

public class FabTransformationSheetBehavior
  extends FabTransformationBehavior
{
  public Map<View, Integer> exceptions;
  
  public FabTransformationSheetBehavior() {}
  
  public FabTransformationSheetBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public FabTransformationBehavior.e a(Context paramContext, boolean paramBoolean)
  {
    int i;
    if (paramBoolean) {
      i = TransactionOutputChanges.mtrl_fab_transformation_sheet_expand_spec;
    } else {
      i = TransactionOutputChanges.mtrl_fab_transformation_sheet_collapse_spec;
    }
    FabTransformationBehavior.e localE = new FabTransformationBehavior.e();
    b = Frame.start(paramContext, i);
    a = new d(17, 0.0F, 0.0F);
    return localE;
  }
  
  public final void init(View paramView, boolean paramBoolean)
  {
    Object localObject = paramView.getParent();
    if (!(localObject instanceof CoordinatorLayout)) {
      return;
    }
    localObject = (CoordinatorLayout)localObject;
    int k = ((ViewGroup)localObject).getChildCount();
    if (paramBoolean) {
      exceptions = new HashMap(k);
    }
    int i = 0;
    while (i < k)
    {
      View localView = ((ViewGroup)localObject).getChildAt(i);
      int j;
      if (((localView.getLayoutParams() instanceof CoordinatorLayout.f)) && ((((CoordinatorLayout.f)localView.getLayoutParams()).getBehavior() instanceof FabTransformationScrimBehavior))) {
        j = 1;
      } else {
        j = 0;
      }
      if ((localView != paramView) && (j == 0)) {
        if (!paramBoolean)
        {
          Map localMap = exceptions;
          if ((localMap != null) && (localMap.containsKey(localView))) {
            ViewCompat.put(localView, ((Integer)exceptions.get(localView)).intValue());
          }
        }
        else
        {
          exceptions.put(localView, Integer.valueOf(localView.getImportantForAccessibility()));
          ViewCompat.put(localView, 4);
        }
      }
      i += 1;
    }
    if (!paramBoolean) {
      exceptions = null;
    }
  }
  
  public boolean start(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2)
  {
    init(paramView2, paramBoolean1);
    super.start(paramView1, paramView2, paramBoolean1, paramBoolean2);
    return true;
  }
}
