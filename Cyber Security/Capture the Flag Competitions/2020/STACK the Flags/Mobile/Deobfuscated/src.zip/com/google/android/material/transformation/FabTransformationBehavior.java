package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.f;
import apache.org.org.core.R.id;
import apache.org.org.core.asm.Attribute;
import apache.org.org.core.asm.c;
import apache.org.org.core.util.AnimationUtils;
import apache.org.org.core.util.ClassWriter;
import apache.org.org.core.util.Contact;
import apache.org.org.core.util.Frame;
import apache.org.org.core.util.Type;
import apache.org.org.core.util.a;
import apache.org.org.core.util.d;
import apache.org.org.core.z.MAX_CODE_SIZE_MASK;
import apache.org.org.core.z.blockMode;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import org.core.view.ViewCompat;

public abstract class FabTransformationBehavior
  extends ExpandableTransformationBehavior
{
  public final RectF a = new RectF();
  public final RectF b = new RectF();
  public final int[] o = new int[2];
  public final Rect z = new Rect();
  
  public FabTransformationBehavior() {}
  
  public FabTransformationBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public final float a(View paramView1, View paramView2, d paramD)
  {
    RectF localRectF1 = b;
    RectF localRectF2 = a;
    a(paramView1, localRectF1);
    a(paramView2, localRectF2);
    localRectF2.offset(-draw(paramView1, paramView2, paramD), 0.0F);
    return localRectF1.centerX() - left;
  }
  
  public abstract e a(Context paramContext, boolean paramBoolean);
  
  public final void a(View paramView, long paramLong, int paramInt1, int paramInt2, float paramFloat, List paramList)
  {
    if (paramLong > 0L)
    {
      paramView = ViewAnimationUtils.createCircularReveal(paramView, paramInt1, paramInt2, paramFloat, paramFloat);
      paramView.setStartDelay(0L);
      paramView.setDuration(paramLong);
      paramList.add(paramView);
    }
  }
  
  public final void a(View paramView, long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, float paramFloat, List paramList)
  {
    if (paramLong1 + paramLong2 < paramLong3)
    {
      paramView = ViewAnimationUtils.createCircularReveal(paramView, paramInt1, paramInt2, paramFloat, paramFloat);
      paramView.setStartDelay(paramLong1 + paramLong2);
      paramView.setDuration(paramLong3 - (paramLong1 + paramLong2));
      paramList.add(paramView);
    }
  }
  
  public final void a(View paramView, RectF paramRectF)
  {
    paramRectF.set(0.0F, 0.0F, paramView.getWidth(), paramView.getHeight());
    int[] arrayOfInt = o;
    paramView.getLocationInWindow(arrayOfInt);
    paramRectF.offsetTo(arrayOfInt[0], arrayOfInt[1]);
    paramRectF.offset((int)-paramView.getTranslationX(), (int)-paramView.getTranslationY());
  }
  
  public final void a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e paramE, float paramFloat1, float paramFloat2, List paramList1, List paramList2)
  {
    if (!(paramView2 instanceof c)) {
      return;
    }
    final c localC = (c)paramView2;
    float f2 = a(paramView1, paramView2, a);
    float f3 = b(paramView1, paramView2, a);
    ((FloatingActionButton)paramView1).add(z);
    float f1 = z.width() / 2.0F;
    apache.org.org.core.util.Label localLabel = b.a("expansion");
    if (paramBoolean1)
    {
      if (!paramBoolean2) {
        localC.setRevealInfo(new apache.org.org.core.asm.Label(f2, f3, f1));
      }
      if (paramBoolean2) {
        f1 = getRevealInfof;
      }
      paramView1 = apache.org.org.core.asm.ClassReader.a(localC, f2, f3, apache.org.org.core.transform.ClassReader.a(f2, f3, 0.0F, 0.0F, paramFloat1, paramFloat2));
      paramView1.addListener(new d(localC));
      a(paramView2, localLabel.length(), (int)f2, (int)f3, f1, paramList1);
    }
    else
    {
      paramFloat1 = getRevealInfof;
      paramView1 = apache.org.org.core.asm.ClassReader.a(localC, f2, f3, f1);
      a(paramView2, localLabel.length(), (int)f2, (int)f3, paramFloat1, paramList1);
      a(paramView2, localLabel.length(), localLabel.getValue(), b.a(), (int)f2, (int)f3, f1, paramList1);
    }
    localLabel.show(paramView1);
    paramList1.add(paramView1);
    paramList2.add(apache.org.org.core.asm.ClassReader.a(localC));
  }
  
  public final void a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e paramE, List paramList)
  {
    float f = ViewCompat.getElevation(paramView2) - ViewCompat.getElevation(paramView1);
    if (paramBoolean1)
    {
      if (!paramBoolean2) {
        paramView2.setTranslationZ(-f);
      }
      paramView1 = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Z, new float[] { 0.0F });
    }
    else
    {
      paramView1 = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Z, new float[] { -f });
    }
    b.a("elevation").show(paramView1);
    paramList.add(paramView1);
  }
  
  public final void a(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e paramE, List paramList, RectF paramRectF)
  {
    float f1 = draw(paramView1, paramView2, a);
    float f2 = c(paramView1, paramView2, a);
    apache.org.org.core.util.Label localLabel;
    if ((f1 != 0.0F) && (f2 != 0.0F))
    {
      if (((paramBoolean1) && (f2 < 0.0F)) || ((!paramBoolean1) && (f2 > 0.0F)))
      {
        paramView1 = b.a("translationXCurveUpwards");
        localLabel = b.a("translationYCurveUpwards");
      }
      else
      {
        paramView1 = b.a("translationXCurveDownwards");
        localLabel = b.a("translationYCurveDownwards");
      }
    }
    else
    {
      paramView1 = b.a("translationXLinear");
      localLabel = b.a("translationYLinear");
    }
    if (paramBoolean1)
    {
      if (!paramBoolean2)
      {
        paramView2.setTranslationX(-f1);
        paramView2.setTranslationY(-f2);
      }
      ObjectAnimator localObjectAnimator2 = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_X, new float[] { 0.0F });
      ObjectAnimator localObjectAnimator1 = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Y, new float[] { 0.0F });
      a(paramView2, paramE, paramView1, localLabel, -f1, -f2, 0.0F, 0.0F, paramRectF);
      paramView2 = localObjectAnimator2;
      paramE = localObjectAnimator1;
    }
    else
    {
      paramRectF = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_X, new float[] { -f1 });
      paramE = ObjectAnimator.ofFloat(paramView2, View.TRANSLATION_Y, new float[] { -f2 });
      paramView2 = paramRectF;
    }
    paramView1.show(paramView2);
    localLabel.show(paramE);
    paramList.add(paramView2);
    paramList.add(paramE);
  }
  
  public final void a(View paramView1, final View paramView2, boolean paramBoolean1, boolean paramBoolean2, e paramE, List paramList1, List paramList2)
  {
    if ((paramView2 instanceof c))
    {
      if (!(paramView1 instanceof ImageView)) {
        return;
      }
      final c localC = (c)paramView2;
      final Drawable localDrawable = ((ImageView)paramView1).getDrawable();
      if (localDrawable == null) {
        return;
      }
      localDrawable.mutate();
      if (paramBoolean1)
      {
        if (!paramBoolean2) {
          localDrawable.setAlpha(255);
        }
        paramView1 = ObjectAnimator.ofInt(localDrawable, ClassWriter.i, new int[] { 0 });
      }
      else
      {
        paramView1 = ObjectAnimator.ofInt(localDrawable, ClassWriter.i, new int[] { 255 });
      }
      paramView1.addUpdateListener(new b(paramView2));
      b.a("iconFade").show(paramView1);
      paramList1.add(paramView1);
      paramList2.add(new c(localC, localDrawable));
    }
  }
  
  public final void a(View paramView, e paramE, apache.org.org.core.util.Label paramLabel1, apache.org.org.core.util.Label paramLabel2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, RectF paramRectF)
  {
    paramFloat1 = draw(paramE, paramLabel1, paramFloat1, paramFloat3);
    paramFloat2 = draw(paramE, paramLabel2, paramFloat2, paramFloat4);
    paramLabel1 = z;
    paramView.getWindowVisibleDisplayFrame(paramLabel1);
    paramE = b;
    paramE.set(paramLabel1);
    paramLabel1 = a;
    a(paramView, paramLabel1);
    paramLabel1.offset(paramFloat1, paramFloat2);
    paramLabel1.intersect(paramE);
    paramRectF.set(paramLabel1);
  }
  
  public final void a(View paramView, boolean paramBoolean1, boolean paramBoolean2, e paramE, List paramList)
  {
    if (!(paramView instanceof ViewGroup)) {
      return;
    }
    if ((paramView instanceof c)) {}
    paramView = b(paramView);
    if (paramView == null) {
      return;
    }
    if (paramBoolean1)
    {
      if (!paramBoolean2) {
        Contact.v.set(paramView, Float.valueOf(0.0F));
      }
      paramView = ObjectAnimator.ofFloat(paramView, Contact.v, new float[] { 1.0F });
    }
    else
    {
      paramView = ObjectAnimator.ofFloat(paramView, Contact.v, new float[] { 0.0F });
    }
    b.a("contentFade").show(paramView);
    paramList.add(paramView);
  }
  
  public final float b(View paramView1, View paramView2, d paramD)
  {
    RectF localRectF1 = b;
    RectF localRectF2 = a;
    a(paramView1, localRectF1);
    a(paramView2, localRectF2);
    localRectF2.offset(0.0F, -c(paramView1, paramView2, paramD));
    return localRectF1.centerY() - top;
  }
  
  public AnimatorSet b(final View paramView1, final View paramView2, final boolean paramBoolean1, boolean paramBoolean2)
  {
    Object localObject = a(paramView2.getContext(), paramBoolean1);
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, (e)localObject, localArrayList1);
    RectF localRectF = b;
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, (e)localObject, localArrayList1, localRectF);
    float f1 = localRectF.width();
    float f2 = localRectF.height();
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, (e)localObject, localArrayList1, localArrayList2);
    a(paramView1, paramView2, paramBoolean1, paramBoolean2, (e)localObject, f1, f2, localArrayList1, localArrayList2);
    write(paramView1, paramView2, paramBoolean1, paramBoolean2, (e)localObject, localArrayList1);
    a(paramView2, paramBoolean1, paramBoolean2, (e)localObject, localArrayList1);
    localObject = new AnimatorSet();
    a.show((AnimatorSet)localObject, localArrayList1);
    ((Animator)localObject).addListener(new a(paramBoolean1, paramView2, paramView1));
    int i = 0;
    int j = localArrayList2.size();
    while (i < j)
    {
      ((Animator)localObject).addListener((Animator.AnimatorListener)localArrayList2.get(i));
      i += 1;
    }
    return localObject;
  }
  
  public final ViewGroup b(View paramView)
  {
    View localView = paramView.findViewById(R.id.mtrl_child_content_container);
    if (localView != null) {
      return createView(localView);
    }
    if ((!(paramView instanceof blockMode)) && (!(paramView instanceof MAX_CODE_SIZE_MASK))) {
      return createView(paramView);
    }
    return createView(((ViewGroup)paramView).getChildAt(0));
  }
  
  public void b(CoordinatorLayout.f paramF)
  {
    if (top == 0) {
      top = 80;
    }
  }
  
  public final float c(View paramView1, View paramView2, d paramD)
  {
    RectF localRectF1 = b;
    RectF localRectF2 = a;
    a(paramView1, localRectF1);
    a(paramView2, localRectF2);
    float f = 0.0F;
    int i = i & 0x70;
    if (i != 16)
    {
      if (i != 48)
      {
        if (i == 80) {
          f = bottom - bottom;
        }
      }
      else {
        f = top - top;
      }
    }
    else {
      f = localRectF2.centerY() - localRectF1.centerY();
    }
    return f + b;
  }
  
  public final ViewGroup createView(View paramView)
  {
    if ((paramView instanceof ViewGroup)) {
      return (ViewGroup)paramView;
    }
    return null;
  }
  
  public final float draw(View paramView1, View paramView2, d paramD)
  {
    RectF localRectF1 = b;
    RectF localRectF2 = a;
    a(paramView1, localRectF1);
    a(paramView2, localRectF2);
    float f = 0.0F;
    int i = i & 0x7;
    if (i != 1)
    {
      if (i != 3)
      {
        if (i == 5) {
          f = right - right;
        }
      }
      else {
        f = left - left;
      }
    }
    else {
      f = localRectF2.centerX() - localRectF1.centerX();
    }
    return f + a;
  }
  
  public final float draw(e paramE, apache.org.org.core.util.Label paramLabel, float paramFloat1, float paramFloat2)
  {
    long l1 = paramLabel.length();
    long l2 = paramLabel.getValue();
    paramE = b.a("expansion");
    float f = (float)(paramE.length() + paramE.getValue() + 17L - l1) / (float)l2;
    return AnimationUtils.lerp(paramFloat1, paramFloat2, paramLabel.get().getInterpolation(f));
  }
  
  public boolean get(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
  {
    if (paramView1.getVisibility() != 8)
    {
      if ((paramView2 instanceof FloatingActionButton))
      {
        int i = ((FloatingActionButton)paramView2).getExpandedComponentIdHint();
        if ((i == 0) || (i == paramView1.getId())) {
          return true;
        }
      }
      else
      {
        return false;
      }
    }
    else {
      throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
    }
    return false;
  }
  
  public final int init(View paramView)
  {
    ColorStateList localColorStateList = ViewCompat.getBackgroundTintList(paramView);
    if (localColorStateList != null) {
      return localColorStateList.getColorForState(paramView.getDrawableState(), localColorStateList.getDefaultColor());
    }
    return 0;
  }
  
  public final void write(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2, e paramE, List paramList)
  {
    if (!(paramView2 instanceof c)) {
      return;
    }
    paramView2 = (c)paramView2;
    int i = init(paramView1);
    if (paramBoolean1)
    {
      if (!paramBoolean2) {
        paramView2.setCircularRevealScrimColor(i);
      }
      paramView1 = ObjectAnimator.ofInt(paramView2, Attribute.b, new int[] { 0xFFFFFF & i });
    }
    else
    {
      paramView1 = ObjectAnimator.ofInt(paramView2, Attribute.b, new int[] { i });
    }
    paramView1.setEvaluator(Type.getType());
    b.a("color").show(paramView1);
    paramList.add(paramView1);
  }
  
  public class a
    extends AnimatorListenerAdapter
  {
    public a(boolean paramBoolean, View paramView1, View paramView2) {}
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      if (!paramBoolean1)
      {
        paramView2.setVisibility(4);
        paramView1.setAlpha(1.0F);
        paramView1.setVisibility(0);
      }
    }
    
    public void onAnimationStart(Animator paramAnimator)
    {
      if (paramBoolean1)
      {
        paramView2.setVisibility(0);
        paramView1.setAlpha(0.0F);
        paramView1.setVisibility(4);
      }
    }
  }
  
  public class b
    implements ValueAnimator.AnimatorUpdateListener
  {
    public b(View paramView) {}
    
    public void onAnimationUpdate(ValueAnimator paramValueAnimator)
    {
      paramView2.invalidate();
    }
  }
  
  public class c
    extends AnimatorListenerAdapter
  {
    public c(c paramC, Drawable paramDrawable) {}
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      localC.setCircularRevealOverlayDrawable(null);
    }
    
    public void onAnimationStart(Animator paramAnimator)
    {
      localC.setCircularRevealOverlayDrawable(localDrawable);
    }
  }
  
  public class d
    extends AnimatorListenerAdapter
  {
    public d(c paramC) {}
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      paramAnimator = localC.getRevealInfo();
      f = Float.MAX_VALUE;
      localC.setRevealInfo(paramAnimator);
    }
  }
  
  public static class e
  {
    public d a;
    public Frame b;
    
    public e() {}
  }
}
