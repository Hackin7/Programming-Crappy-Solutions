package com.google.android.material.snackbar;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import apache.org.org.core.R.dimen;
import apache.org.org.core.R.id;
import apache.org.org.core.R.styleable;
import org.core.view.ViewCompat;

public class SnackbarContentLayout
  extends LinearLayout
{
  public Button mActionView;
  public int mMaxInlineActionWidth;
  public int mMaxWidth;
  public TextView mMessageView;
  
  public SnackbarContentLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.SnackbarLayout);
    mMaxWidth = paramContext.getDimensionPixelSize(R.styleable.SnackbarLayout_android_maxWidth, -1);
    mMaxInlineActionWidth = paramContext.getDimensionPixelSize(R.styleable.SnackbarLayout_maxActionInlineWidth, -1);
    paramContext.recycle();
  }
  
  public static void updateTopBottomPadding(View paramView, int paramInt1, int paramInt2)
  {
    if (ViewCompat.isPaddingRelative(paramView))
    {
      ViewCompat.setPaddingRelative(paramView, ViewCompat.getPaddingStart(paramView), paramInt1, ViewCompat.getPaddingEnd(paramView), paramInt2);
      return;
    }
    paramView.setPadding(paramView.getPaddingLeft(), paramInt1, paramView.getPaddingRight(), paramInt2);
  }
  
  public Button getActionView()
  {
    return mActionView;
  }
  
  public TextView getMessageView()
  {
    return mMessageView;
  }
  
  public void onFinishInflate()
  {
    super.onFinishInflate();
    mMessageView = ((TextView)findViewById(R.id.snackbar_text));
    mActionView = ((Button)findViewById(R.id.snackbar_action));
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    int i = paramInt1;
    if (mMaxWidth > 0)
    {
      j = getMeasuredWidth();
      k = mMaxWidth;
      i = paramInt1;
      if (j > k)
      {
        paramInt1 = View.MeasureSpec.makeMeasureSpec(k, 1073741824);
        i = paramInt1;
        super.onMeasure(paramInt1, paramInt2);
      }
    }
    int j = getResources().getDimensionPixelSize(R.dimen.design_snackbar_padding_vertical_2lines);
    int k = getResources().getDimensionPixelSize(R.dimen.design_snackbar_padding_vertical);
    if (mMessageView.getLayout().getLineCount() > 1) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    }
    int m = 0;
    if ((paramInt1 != 0) && (mMaxInlineActionWidth > 0) && (mActionView.getMeasuredWidth() > mMaxInlineActionWidth))
    {
      paramInt1 = m;
      if (updateViewsWithinLayout(1, j, j - k)) {
        paramInt1 = 1;
      }
    }
    else
    {
      if (paramInt1 == 0) {
        j = k;
      }
      paramInt1 = m;
      if (updateViewsWithinLayout(0, j, j)) {
        paramInt1 = 1;
      }
    }
    if (paramInt1 != 0) {
      super.onMeasure(i, paramInt2);
    }
  }
  
  public final boolean updateViewsWithinLayout(int paramInt1, int paramInt2, int paramInt3)
  {
    boolean bool = false;
    if (paramInt1 != getOrientation())
    {
      setOrientation(paramInt1);
      bool = true;
    }
    if ((mMessageView.getPaddingTop() != paramInt2) || (mMessageView.getPaddingBottom() != paramInt3))
    {
      updateTopBottomPadding(mMessageView, paramInt2, paramInt3);
      return true;
    }
    return bool;
  }
}
