package com.google.android.material.internal;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.widget.Checkable;
import android.widget.ImageView;
import org.core.view.AccessibilityDelegateCompat;
import org.core.view.ViewCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat;
import org.v7.R.attr;
import org.v7.widget.AppCompatImageButton;

public class CheckableImageButton
  extends AppCompatImageButton
  implements Checkable
{
  public static final int[] CHECKED_STATE_SET = { 16842912 };
  public boolean isChecked;
  
  public CheckableImageButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.imageButtonStyle);
  }
  
  public CheckableImageButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    ViewCompat.setAccessibilityDelegate(this, new a());
  }
  
  public boolean isChecked()
  {
    return isChecked;
  }
  
  public int[] onCreateDrawableState(int paramInt)
  {
    if (isChecked) {
      return View.mergeDrawableStates(super.onCreateDrawableState(CHECKED_STATE_SET.length + paramInt), CHECKED_STATE_SET);
    }
    return super.onCreateDrawableState(paramInt);
  }
  
  public void setChecked(boolean paramBoolean)
  {
    if (isChecked != paramBoolean)
    {
      isChecked = paramBoolean;
      refreshDrawableState();
      sendAccessibilityEvent(2048);
    }
  }
  
  public void toggle()
  {
    setChecked(isChecked ^ true);
  }
  
  public class a
    extends AccessibilityDelegateCompat
  {
    public a() {}
    
    public void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      super.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
      paramAccessibilityEvent.setChecked(isChecked());
    }
    
    public void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      super.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat);
      paramAccessibilityNodeInfoCompat.setText(true);
      paramAccessibilityNodeInfoCompat.setSelected(isChecked());
    }
  }
}
