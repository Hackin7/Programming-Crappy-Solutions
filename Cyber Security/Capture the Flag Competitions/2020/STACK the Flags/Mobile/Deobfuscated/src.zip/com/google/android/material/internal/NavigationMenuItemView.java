package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import android.widget.TextView;
import apache.org.org.core.R.dimen;
import apache.org.org.core.R.drawable;
import apache.org.org.core.R.id;
import apache.org.org.core.R.layout;
import apache.org.org.core.internal.ForegroundLinearLayout;
import org.core.asm.signature.DrawableCompat;
import org.core.fonts.data.ClassWriter;
import org.core.view.AccessibilityDelegateCompat;
import org.core.view.ViewCompat;
import org.core.view.tree.AccessibilityNodeInfoCompat;
import org.core.widget.Label;
import org.v7.R.attr;
import org.v7.view.menu.MenuView.ItemView;
import org.v7.widget.LinearLayoutCompat;
import org.v7.widget.i0.a;

public class NavigationMenuItemView
  extends ForegroundLinearLayout
  implements MenuView.ItemView
{
  public static final int[] CHECKED_STATE_SET = { 16842912 };
  public FrameLayout mActionArea;
  public boolean mForceShowIcon;
  public Drawable mIcon;
  public final int mIconSize;
  public ColorStateList mIconTintList;
  public org.v7.view.menu.MenuItemImpl mItemData;
  public boolean mLogo;
  public final CheckedTextView mTextView;
  public boolean s;
  public final AccessibilityDelegateCompat this$0 = new a();
  
  public NavigationMenuItemView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public NavigationMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setOrientation(0);
    LayoutInflater.from(paramContext).inflate(R.layout.design_navigation_menu_item, this, true);
    mIconSize = paramContext.getResources().getDimensionPixelSize(R.dimen.design_navigation_icon_size);
    paramContext = (CheckedTextView)findViewById(R.id.design_menu_item_text);
    mTextView = paramContext;
    paramContext.setDuplicateParentStateEnabled(true);
    ViewCompat.setAccessibilityDelegate(mTextView, this$0);
  }
  
  private void setActionView(View paramView)
  {
    if (paramView != null)
    {
      if (mActionArea == null) {
        mActionArea = ((FrameLayout)((ViewStub)findViewById(R.id.design_menu_item_action_area_stub)).inflate());
      }
      mActionArea.removeAllViews();
      mActionArea.addView(paramView);
    }
  }
  
  public final StateListDrawable createDefaultBackground()
  {
    TypedValue localTypedValue = new TypedValue();
    if (getContext().getTheme().resolveAttribute(R.attr.colorControlHighlight, localTypedValue, true))
    {
      StateListDrawable localStateListDrawable = new StateListDrawable();
      localStateListDrawable.addState(CHECKED_STATE_SET, new ColorDrawable(data));
      localStateListDrawable.addState(View.EMPTY_STATE_SET, new ColorDrawable(0));
      return localStateListDrawable;
    }
    return null;
  }
  
  public org.v7.view.menu.MenuItemImpl getItemData()
  {
    return mItemData;
  }
  
  public void initialize(org.v7.view.menu.MenuItemImpl paramMenuItemImpl, int paramInt)
  {
    mItemData = paramMenuItemImpl;
    if (paramMenuItemImpl.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    }
    setVisibility(paramInt);
    if (getBackground() == null) {
      ViewCompat.setBackgroundDrawable(this, createDefaultBackground());
    }
    setCheckable(paramMenuItemImpl.isCheckable());
    setChecked(paramMenuItemImpl.isChecked());
    setEnabled(paramMenuItemImpl.isEnabled());
    setTitle(paramMenuItemImpl.getTitle());
    setIcon(paramMenuItemImpl.getIcon());
    setActionView(paramMenuItemImpl.getActionView());
    setContentDescription(paramMenuItemImpl.getContentDescription());
    org.v7.widget.MenuItemImpl.setText(this, paramMenuItemImpl.getTooltipText());
    onBindViewHolder();
  }
  
  public final void onBindViewHolder()
  {
    Object localObject;
    if (setIcon())
    {
      mTextView.setVisibility(8);
      localObject = mActionArea;
      if (localObject != null)
      {
        localObject = (i0.a)((View)localObject).getLayoutParams();
        width = -1;
        mActionArea.setLayoutParams((ViewGroup.LayoutParams)localObject);
      }
    }
    else
    {
      mTextView.setVisibility(0);
      localObject = mActionArea;
      if (localObject != null)
      {
        localObject = (i0.a)((View)localObject).getLayoutParams();
        width = -2;
        mActionArea.setLayoutParams((ViewGroup.LayoutParams)localObject);
      }
    }
  }
  
  public int[] onCreateDrawableState(int paramInt)
  {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    org.v7.view.menu.MenuItemImpl localMenuItemImpl = mItemData;
    if ((localMenuItemImpl != null) && (localMenuItemImpl.isCheckable()) && (mItemData.isChecked())) {
      View.mergeDrawableStates(arrayOfInt, CHECKED_STATE_SET);
    }
    return arrayOfInt;
  }
  
  public boolean prefersCondensedTitle()
  {
    return false;
  }
  
  public void setCheckable(boolean paramBoolean)
  {
    refreshDrawableState();
    if (s != paramBoolean)
    {
      s = paramBoolean;
      this$0.sendAccessibilityEvent(mTextView, 2048);
    }
  }
  
  public void setChecked(boolean paramBoolean)
  {
    refreshDrawableState();
    mTextView.setChecked(paramBoolean);
  }
  
  public void setHorizontalPadding(int paramInt)
  {
    setPadding(paramInt, 0, paramInt, 0);
  }
  
  public void setIcon(Drawable paramDrawable)
  {
    int i;
    if (paramDrawable != null)
    {
      Object localObject = paramDrawable;
      if (mForceShowIcon)
      {
        localObject = paramDrawable.getConstantState();
        if (localObject != null) {
          paramDrawable = ((Drawable.ConstantState)localObject).newDrawable();
        }
        paramDrawable = DrawableCompat.wrap(paramDrawable).mutate();
        localObject = paramDrawable;
        DrawableCompat.setTintList(paramDrawable, mIconTintList);
      }
      i = mIconSize;
      ((Drawable)localObject).setBounds(0, 0, i, i);
      paramDrawable = (Drawable)localObject;
    }
    else if (mLogo)
    {
      if (mIcon == null)
      {
        paramDrawable = ClassWriter.getDrawable(getResources(), R.drawable.navigation_empty_icon, getContext().getTheme());
        mIcon = paramDrawable;
        if (paramDrawable != null)
        {
          i = mIconSize;
          paramDrawable.setBounds(0, 0, i, i);
        }
      }
      paramDrawable = mIcon;
    }
    Label.setCompoundDrawablesRelative(mTextView, paramDrawable, null, null, null);
  }
  
  public final boolean setIcon()
  {
    return (mItemData.getTitle() == null) && (mItemData.getIcon() == null) && (mItemData.getActionView() != null);
  }
  
  public void setIconPadding(int paramInt)
  {
    mTextView.setCompoundDrawablePadding(paramInt);
  }
  
  public void setIconTintList(ColorStateList paramColorStateList)
  {
    mIconTintList = paramColorStateList;
    boolean bool;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    }
    mForceShowIcon = bool;
    paramColorStateList = mItemData;
    if (paramColorStateList != null) {
      setIcon(paramColorStateList.getIcon());
    }
  }
  
  public void setNeedsEmptyIcon(boolean paramBoolean)
  {
    mLogo = paramBoolean;
  }
  
  public void setTextAppearance(int paramInt)
  {
    Label.setTextAppearance(mTextView, paramInt);
  }
  
  public void setTextColor(ColorStateList paramColorStateList)
  {
    mTextView.setTextColor(paramColorStateList);
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    mTextView.setText(paramCharSequence);
  }
  
  public class a
    extends AccessibilityDelegateCompat
  {
    public a() {}
    
    public void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
    {
      super.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat);
      paramAccessibilityNodeInfoCompat.setText(s);
    }
  }
}
