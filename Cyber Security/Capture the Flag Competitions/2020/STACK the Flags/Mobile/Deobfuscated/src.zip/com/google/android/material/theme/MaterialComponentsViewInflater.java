package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Keep;
import apache.org.org.core.model.FloatingActionButton;
import org.v7.app.AppCompatViewInflater;
import org.v7.widget.AppCompatButton;

@Keep
public class MaterialComponentsViewInflater
  extends AppCompatViewInflater
{
  public MaterialComponentsViewInflater() {}
  
  public AppCompatButton createButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    return new FloatingActionButton(paramContext, paramAttributeSet);
  }
}
