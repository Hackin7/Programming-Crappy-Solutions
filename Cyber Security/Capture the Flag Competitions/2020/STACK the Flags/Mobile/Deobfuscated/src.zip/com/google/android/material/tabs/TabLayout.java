package com.google.android.material.tabs;

import a.b.k.a.c;
import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build.VERSION;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityRecord;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.e;
import androidx.viewpager.widget.ViewPager.i;
import androidx.viewpager.widget.ViewPager.j;
import apache.org.org.core.R.attr;
import apache.org.org.core.R.dimen;
import apache.org.org.core.R.layout;
import apache.org.org.core.R.style;
import apache.org.org.core.codec.TabItem;
import apache.org.org.core.internal.f;
import apache.org.org.core.pattern.ResourcesCompat;
import apache.org.org.core.spi.TintManager;
import apache.org.org.core.util.AnimationUtils;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import org.core.data.LruCache;
import org.core.data.Session;
import org.core.view.MarginLayoutParamsCompat;
import org.core.view.ViewCompat;
import org.core.widget.Label;
import org.sufficientlysecure.rootcommands.PagerAdapter;
import org.v7.widget.MenuItemImpl;

@ViewPager.e
public class TabLayout
  extends HorizontalScrollView
{
  public static final a.h.l.e<f> context = new Session(16);
  public final ArrayList<c> a = new ArrayList();
  public boolean active;
  public g adapter;
  public float f;
  public boolean g;
  public int h;
  public Drawable image;
  public int mContentInsetStart;
  public PorterDuff.Mode mContext;
  public ColorStateList mId;
  public int mImpl;
  public b mListener;
  public int mMode;
  public c mOnTabSelectedListener;
  public PagerAdapter mPagerAdapter;
  public DataSetObserver mPagerAdapterObserver;
  public final int mRequestedTabMaxWidth;
  public final int mRequestedTabMinWidth;
  public ValueAnimator mScrollAnimator;
  public final int mScrollableTabMinWidth;
  public f mSelectedTab;
  public boolean mStartPlaying;
  public final int mTabBackgroundResId;
  public int mTabGravity;
  public int mTabMaxWidth = Integer.MAX_VALUE;
  public int mTabPaddingBottom;
  public int mTabPaddingEnd;
  public int mTabPaddingStart;
  public int mTabPaddingTop;
  public final e mTabStrip;
  public final RectF mTabTextAppearance = new RectF();
  public ColorStateList mTabTextColors;
  public final a.h.l.e<h> mTabViewPool = new LruCache(12);
  public final ArrayList<f> mTabs = new ArrayList();
  public int mViewHeight;
  public ViewPager mViewPager;
  public boolean p;
  public float size;
  public ColorStateList tint;
  public c toolbar;
  
  public TabLayout(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.tabStyle);
  }
  
  public TabLayout(android.content.Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setHorizontalScrollBarEnabled(false);
    Object localObject = new e(paramContext);
    mTabStrip = ((e)localObject);
    super.addView((View)localObject, 0, new FrameLayout.LayoutParams(-2, -1));
    localObject = f.obtainStyledAttributes(paramContext, paramAttributeSet, apache.org.org.core.R.styleable.TabLayout, paramInt, R.style.Widget_Design_TabLayout, new int[] { apache.org.org.core.R.styleable.TabLayout_tabTextAppearance });
    mTabStrip.setSelectedIndicatorHeight(((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabIndicatorHeight, -1));
    mTabStrip.setSelectedIndicatorColor(((TypedArray)localObject).getColor(apache.org.org.core.R.styleable.TabLayout_tabIndicatorColor, 0));
    setSelectedTabIndicator(ResourcesCompat.getDrawable(paramContext, (TypedArray)localObject, apache.org.org.core.R.styleable.TabLayout_tabIndicator));
    setSelectedTabIndicatorGravity(((TypedArray)localObject).getInt(apache.org.org.core.R.styleable.TabLayout_tabIndicatorGravity, 0));
    setTabIndicatorFullWidth(((TypedArray)localObject).getBoolean(apache.org.org.core.R.styleable.TabLayout_tabIndicatorFullWidth, true));
    paramInt = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabPadding, 0);
    mTabPaddingBottom = paramInt;
    mTabPaddingEnd = paramInt;
    mTabPaddingTop = paramInt;
    mTabPaddingStart = paramInt;
    mTabPaddingStart = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabPaddingStart, paramInt);
    mTabPaddingTop = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabPaddingTop, mTabPaddingTop);
    mTabPaddingEnd = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabPaddingEnd, mTabPaddingEnd);
    mTabPaddingBottom = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabPaddingBottom, mTabPaddingBottom);
    paramInt = ((TypedArray)localObject).getResourceId(apache.org.org.core.R.styleable.TabLayout_tabTextAppearance, R.style.TextAppearance_Design_Tab);
    h = paramInt;
    paramAttributeSet = paramContext.obtainStyledAttributes(paramInt, org.v7.R.styleable.TextAppearance);
    try
    {
      size = paramAttributeSet.getDimensionPixelSize(org.v7.R.styleable.TextAppearance_android_textSize, 0);
      mTabTextColors = ResourcesCompat.getString(paramContext, paramAttributeSet, org.v7.R.styleable.TextAppearance_android_textColor);
      paramAttributeSet.recycle();
      if (((TypedArray)localObject).hasValue(apache.org.org.core.R.styleable.TabLayout_tabTextColor)) {
        mTabTextColors = ResourcesCompat.getString(paramContext, (TypedArray)localObject, apache.org.org.core.R.styleable.TabLayout_tabTextColor);
      }
      if (((TypedArray)localObject).hasValue(apache.org.org.core.R.styleable.TabLayout_tabSelectedTextColor))
      {
        paramInt = ((TypedArray)localObject).getColor(apache.org.org.core.R.styleable.TabLayout_tabSelectedTextColor, 0);
        mTabTextColors = createColorStateList(mTabTextColors.getDefaultColor(), paramInt);
      }
      tint = ResourcesCompat.getString(paramContext, (TypedArray)localObject, apache.org.org.core.R.styleable.TabLayout_tabIconTint);
      mContext = apache.org.org.core.internal.DrawableCompat.parseTintMode(((TypedArray)localObject).getInt(apache.org.org.core.R.styleable.TabLayout_tabIconTintMode, -1), null);
      mId = ResourcesCompat.getString(paramContext, (TypedArray)localObject, apache.org.org.core.R.styleable.TabLayout_tabRippleColor);
      mImpl = ((TypedArray)localObject).getInt(apache.org.org.core.R.styleable.TabLayout_tabIndicatorAnimationDuration, 300);
      mRequestedTabMinWidth = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabMinWidth, -1);
      mRequestedTabMaxWidth = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabMaxWidth, -1);
      mTabBackgroundResId = ((TypedArray)localObject).getResourceId(apache.org.org.core.R.styleable.TabLayout_tabBackground, 0);
      mContentInsetStart = ((TypedArray)localObject).getDimensionPixelSize(apache.org.org.core.R.styleable.TabLayout_tabContentStart, 0);
      mMode = ((TypedArray)localObject).getInt(apache.org.org.core.R.styleable.TabLayout_tabMode, 1);
      mTabGravity = ((TypedArray)localObject).getInt(apache.org.org.core.R.styleable.TabLayout_tabGravity, 0);
      p = ((TypedArray)localObject).getBoolean(apache.org.org.core.R.styleable.TabLayout_tabInlineLabel, false);
      g = ((TypedArray)localObject).getBoolean(apache.org.org.core.R.styleable.TabLayout_tabUnboundedRipple, false);
      ((TypedArray)localObject).recycle();
      paramContext = getResources();
      f = paramContext.getDimensionPixelSize(R.dimen.design_tab_text_size_2line);
      mScrollableTabMinWidth = paramContext.getDimensionPixelSize(R.dimen.design_tab_scrollable_min_width);
      applyModeAndGravity();
      return;
    }
    catch (Throwable paramContext)
    {
      paramAttributeSet.recycle();
      throw paramContext;
    }
  }
  
  public static ColorStateList createColorStateList(int paramInt1, int paramInt2)
  {
    int[][] arrayOfInt = new int[2][];
    int[] arrayOfInt1 = new int[2];
    arrayOfInt[0] = View.SELECTED_STATE_SET;
    arrayOfInt1[0] = paramInt2;
    paramInt2 = 0 + 1;
    arrayOfInt[paramInt2] = View.EMPTY_STATE_SET;
    arrayOfInt1[paramInt2] = paramInt1;
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
  
  private int getDefaultHeight()
  {
    int k = 0;
    int i = 0;
    int m = mTabs.size();
    int j;
    for (;;)
    {
      j = k;
      if (i >= m) {
        break;
      }
      f localF = (f)mTabs.get(i);
      if ((localF != null) && (localF.getIcon() != null) && (!TextUtils.isEmpty(localF.getText())))
      {
        j = 1;
        break;
      }
      i += 1;
    }
    if ((j != 0) && (!p)) {
      return 72;
    }
    return 48;
  }
  
  private int getTabMinWidth()
  {
    int i = mRequestedTabMinWidth;
    if (i != -1) {
      return i;
    }
    if (mMode == 0) {
      return mScrollableTabMinWidth;
    }
    return 0;
  }
  
  private int getTabScrollRange()
  {
    return Math.max(0, mTabStrip.getWidth() - getWidth() - getPaddingLeft() - getPaddingRight());
  }
  
  private void setSelectedTabView(int paramInt)
  {
    int j = mTabStrip.getChildCount();
    if (paramInt < j)
    {
      int i = 0;
      while (i < j)
      {
        View localView = mTabStrip.getChildAt(i);
        boolean bool2 = false;
        if (i == paramInt) {
          bool1 = true;
        } else {
          bool1 = false;
        }
        localView.setSelected(bool1);
        boolean bool1 = bool2;
        if (i == paramInt) {
          bool1 = true;
        }
        localView.setActivated(bool1);
        i += 1;
      }
    }
  }
  
  public void addTab(c paramC)
  {
    if (!a.contains(paramC)) {
      a.add(paramC);
    }
  }
  
  public void addTab(f paramF)
  {
    addTab(paramF, mTabs.isEmpty());
  }
  
  public void addTab(f paramF, int paramInt, boolean paramBoolean)
  {
    if (mParent == this)
    {
      configureTab(paramF, paramInt);
      addTabView(paramF);
      if (paramBoolean) {
        paramF.select();
      }
    }
    else
    {
      throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
    }
  }
  
  public void addTab(f paramF, boolean paramBoolean)
  {
    addTab(paramF, mTabs.size(), paramBoolean);
  }
  
  public final void addTabFromItemView(TabItem paramTabItem)
  {
    f localF = newTab();
    Object localObject = mText;
    if (localObject != null) {
      localF.setText((CharSequence)localObject);
    }
    localObject = mIcon;
    if (localObject != null) {
      localF.setIcon((Drawable)localObject);
    }
    int i = mCustomLayout;
    if (i != 0) {
      localF.setCustomView(i);
    }
    if (!TextUtils.isEmpty(paramTabItem.getContentDescription())) {
      localF.setContentDescription(paramTabItem.getContentDescription());
    }
    addTab(localF);
  }
  
  public final void addTabView(f paramF)
  {
    h localH = mView;
    mTabStrip.addView(localH, paramF.getPosition(), createLayoutParamsForTabs());
  }
  
  public void addView(View paramView)
  {
    addViewInternal(paramView);
  }
  
  public void addView(View paramView, int paramInt)
  {
    addViewInternal(paramView);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    addViewInternal(paramView);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    addViewInternal(paramView);
  }
  
  public void addView(c paramC)
  {
    a.remove(paramC);
  }
  
  public final void addViewInternal(View paramView)
  {
    if ((paramView instanceof TabItem))
    {
      addTabFromItemView((TabItem)paramView);
      return;
    }
    throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
  }
  
  public final void animateToTab()
  {
    if (mScrollAnimator == null)
    {
      ValueAnimator localValueAnimator = new ValueAnimator();
      mScrollAnimator = localValueAnimator;
      localValueAnimator.setInterpolator(AnimationUtils.a);
      mScrollAnimator.setDuration(mImpl);
      mScrollAnimator.addUpdateListener(new a());
    }
  }
  
  public final void animateToTab(int paramInt)
  {
    if (paramInt == -1) {
      return;
    }
    if ((getWindowToken() != null) && (ViewCompat.get(this)) && (!mTabStrip.childrenNeedLayout()))
    {
      int i = getScrollX();
      int j = calculateScrollXForTab(paramInt, 0.0F);
      if (i != j)
      {
        animateToTab();
        mScrollAnimator.setIntValues(new int[] { i, j });
        mScrollAnimator.start();
      }
      mTabStrip.update(paramInt, mImpl);
      return;
    }
    setScrollPosition(paramInt, 0.0F, true);
  }
  
  public final void applyModeAndGravity()
  {
    int i = 0;
    if (mMode == 0) {
      i = Math.max(0, mContentInsetStart - mTabPaddingStart);
    }
    ViewCompat.setPaddingRelative(mTabStrip, i, 0, 0, 0);
    i = mMode;
    if (i != 0)
    {
      if (i == 1) {
        mTabStrip.setGravity(1);
      }
    }
    else {
      mTabStrip.setGravity(8388611);
    }
    updateTabViews(true);
  }
  
  public final void c(f paramF)
  {
    int i = a.size() - 1;
    while (i >= 0)
    {
      ((c)a.get(i)).b(paramF);
      i -= 1;
    }
  }
  
  public final int calculateScrollXForTab(int paramInt, float paramFloat)
  {
    int j = mMode;
    int i = 0;
    if (j == 0)
    {
      View localView2 = mTabStrip.getChildAt(paramInt);
      View localView1;
      if (paramInt + 1 < mTabStrip.getChildCount()) {
        localView1 = mTabStrip.getChildAt(paramInt + 1);
      } else {
        localView1 = null;
      }
      if (localView2 != null) {
        paramInt = localView2.getWidth();
      } else {
        paramInt = 0;
      }
      if (localView1 != null) {
        i = localView1.getWidth();
      }
      j = localView2.getLeft() + paramInt / 2 - getWidth() / 2;
      paramInt = (int)((paramInt + i) * 0.5F * paramFloat);
      if (ViewCompat.getLayoutDirection(this) == 0) {
        return j + paramInt;
      }
      return j - paramInt;
    }
    return 0;
  }
  
  public final void configureTab(f paramF, int paramInt)
  {
    paramF.setPosition(paramInt);
    mTabs.add(paramInt, paramF);
    int i = mTabs.size();
    paramInt += 1;
    while (paramInt < i)
    {
      ((f)mTabs.get(paramInt)).setPosition(paramInt);
      paramInt += 1;
    }
  }
  
  public final LinearLayout.LayoutParams createLayoutParamsForTabs()
  {
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -1);
    updateTabViewLayoutParams(localLayoutParams);
    return localLayoutParams;
  }
  
  public final h createTabView(f paramF)
  {
    Object localObject1 = mTabViewPool;
    if (localObject1 != null) {
      localObject1 = (h)((org.core.data.Context)localObject1).get();
    } else {
      localObject1 = null;
    }
    Object localObject2 = localObject1;
    if (localObject1 == null) {
      localObject2 = new h(getContext());
    }
    ((h)localObject2).setTab(paramF);
    ((View)localObject2).setFocusable(true);
    ((View)localObject2).setMinimumWidth(getTabMinWidth());
    if (TextUtils.isEmpty(f.getContentDescription(paramF)))
    {
      ((View)localObject2).setContentDescription(f.getText(paramF));
      return localObject2;
    }
    ((View)localObject2).setContentDescription(f.getContentDescription(paramF));
    return localObject2;
  }
  
  public int dpToPx(int paramInt)
  {
    return Math.round(getResourcesgetDisplayMetricsdensity * paramInt);
  }
  
  public FrameLayout.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return generateDefaultLayoutParams();
  }
  
  public int getSelectedTabPosition()
  {
    f localF = mSelectedTab;
    if (localF != null) {
      return localF.getPosition();
    }
    return -1;
  }
  
  public f getTabAt(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < getTabCount())) {
      return (f)mTabs.get(paramInt);
    }
    return null;
  }
  
  public int getTabCount()
  {
    return mTabs.size();
  }
  
  public int getTabGravity()
  {
    return mTabGravity;
  }
  
  public ColorStateList getTabIconTint()
  {
    return tint;
  }
  
  public int getTabIndicatorGravity()
  {
    return mViewHeight;
  }
  
  public int getTabMaxWidth()
  {
    return mTabMaxWidth;
  }
  
  public int getTabMode()
  {
    return mMode;
  }
  
  public ColorStateList getTabRippleColor()
  {
    return mId;
  }
  
  public Drawable getTabSelectedIndicator()
  {
    return image;
  }
  
  public ColorStateList getTabTextColors()
  {
    return mTabTextColors;
  }
  
  public final void init(ViewPager paramViewPager, boolean paramBoolean1, boolean paramBoolean2)
  {
    Object localObject = mViewPager;
    if (localObject != null)
    {
      g localG = adapter;
      if (localG != null) {
        ((ViewPager)localObject).removeOnPageChangeListener(localG);
      }
      localObject = mListener;
      if (localObject != null) {
        mViewPager.setAdapter((ViewPager.i)localObject);
      }
    }
    localObject = toolbar;
    if (localObject != null)
    {
      addView((c)localObject);
      toolbar = null;
    }
    if (paramViewPager != null)
    {
      mViewPager = paramViewPager;
      if (adapter == null) {
        adapter = new g(this);
      }
      adapter.reset();
      paramViewPager.setAdapter(adapter);
      localObject = new i(paramViewPager);
      toolbar = ((c)localObject);
      addTab((c)localObject);
      localObject = paramViewPager.getAdapter();
      if (localObject != null) {
        setPagerAdapter((PagerAdapter)localObject, paramBoolean1);
      }
      if (mListener == null) {
        mListener = new b();
      }
      mListener.update(paramBoolean1);
      paramViewPager.addOnPageChangeListener(mListener);
      setScrollPosition(paramViewPager.getCurrentItem(), 0.0F, true);
    }
    else
    {
      mViewPager = null;
      setPagerAdapter(null, false);
    }
    active = paramBoolean2;
  }
  
  public f newTab()
  {
    f localF = setContent();
    mParent = this;
    mView = createTabView(localF);
    return localF;
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    if (mViewPager == null)
    {
      ViewParent localViewParent = getParent();
      if ((localViewParent instanceof ViewPager)) {
        init((ViewPager)localViewParent, true, true);
      }
    }
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (active)
    {
      setupWithViewPager(null);
      active = false;
    }
  }
  
  public void onDraw(Canvas paramCanvas)
  {
    int i = 0;
    while (i < mTabStrip.getChildCount())
    {
      View localView = mTabStrip.getChildAt(i);
      if ((localView instanceof h)) {
        h.draw((h)localView, paramCanvas);
      }
      i += 1;
    }
    super.onDraw(paramCanvas);
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    int i = dpToPx(getDefaultHeight()) + getPaddingTop() + getPaddingBottom();
    int j = View.MeasureSpec.getMode(paramInt2);
    if (j != Integer.MIN_VALUE)
    {
      if (j == 0) {
        paramInt2 = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
      }
    }
    else {
      paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(i, View.MeasureSpec.getSize(paramInt2)), 1073741824);
    }
    j = View.MeasureSpec.getSize(paramInt1);
    if (View.MeasureSpec.getMode(paramInt1) != 0)
    {
      i = mRequestedTabMaxWidth;
      if (i <= 0) {
        i = j - dpToPx(56);
      }
      mTabMaxWidth = i;
    }
    super.onMeasure(paramInt1, paramInt2);
    j = getChildCount();
    i = 1;
    paramInt1 = 1;
    if (j == 1)
    {
      View localView = getChildAt(0);
      j = 0;
      int k = mMode;
      if (k != 0)
      {
        if (k != 1) {
          paramInt1 = j;
        } else if (localView.getMeasuredWidth() == getMeasuredWidth()) {
          paramInt1 = 0;
        }
      }
      else if (localView.getMeasuredWidth() < getMeasuredWidth()) {
        paramInt1 = i;
      } else {
        paramInt1 = 0;
      }
      if (paramInt1 != 0)
      {
        paramInt1 = ViewGroup.getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom(), getLayoutParamsheight);
        localView.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), paramInt1);
      }
    }
  }
  
  public final void onRender(f paramF)
  {
    int i = a.size() - 1;
    while (i >= 0)
    {
      ((c)a.get(i)).setCurrentPage(paramF);
      i -= 1;
    }
  }
  
  public void populateFromPagerAdapter()
  {
    removeAllTabs();
    Object localObject = mPagerAdapter;
    if (localObject != null)
    {
      int j = ((PagerAdapter)localObject).getCount();
      int i = 0;
      while (i < j)
      {
        localObject = newTab();
        ((f)localObject).setText(mPagerAdapter.getPageTitle(i));
        addTab((f)localObject, false);
        i += 1;
      }
      localObject = mViewPager;
      if ((localObject != null) && (j > 0))
      {
        i = ((ViewPager)localObject).getCurrentItem();
        if ((i != getSelectedTabPosition()) && (i < getTabCount())) {
          selectTab(getTabAt(i));
        }
      }
    }
  }
  
  public boolean remove(f paramF)
  {
    return context.get(paramF);
  }
  
  public void removeAllTabs()
  {
    int i = mTabStrip.getChildCount() - 1;
    while (i >= 0)
    {
      removeTabViewAt(i);
      i -= 1;
    }
    Iterator localIterator = mTabs.iterator();
    while (localIterator.hasNext())
    {
      f localF = (f)localIterator.next();
      localIterator.remove();
      localF.removeAllTabs();
      remove(localF);
    }
    mSelectedTab = null;
  }
  
  public final void removeTabViewAt(int paramInt)
  {
    h localH = (h)mTabStrip.getChildAt(paramInt);
    mTabStrip.removeViewAt(paramInt);
    if (localH != null)
    {
      localH.reset();
      mTabViewPool.get(localH);
    }
    requestLayout();
  }
  
  public void selectTab(ViewPager paramViewPager, boolean paramBoolean)
  {
    init(paramViewPager, paramBoolean, false);
  }
  
  public void selectTab(f paramF)
  {
    selectTab(paramF, true);
  }
  
  public void selectTab(f paramF, boolean paramBoolean)
  {
    f localF = mSelectedTab;
    if (localF == paramF)
    {
      if (localF != null)
      {
        visit(paramF);
        animateToTab(paramF.getPosition());
      }
    }
    else
    {
      int i;
      if (paramF != null) {
        i = paramF.getPosition();
      } else {
        i = -1;
      }
      if (paramBoolean)
      {
        if (((localF == null) || (localF.getPosition() == -1)) && (i != -1)) {
          setScrollPosition(i, 0.0F, true);
        } else {
          animateToTab(i);
        }
        if (i != -1) {
          setSelectedTabView(i);
        }
      }
      mSelectedTab = paramF;
      if (localF != null) {
        c(localF);
      }
      if (paramF != null) {
        onRender(paramF);
      }
    }
  }
  
  public f setContent()
  {
    f localF2 = (f)context.get();
    f localF1 = localF2;
    if (localF2 == null) {
      localF1 = new f();
    }
    return localF1;
  }
  
  public void setInlineLabel(boolean paramBoolean)
  {
    if (p != paramBoolean)
    {
      p = paramBoolean;
      int i = 0;
      while (i < mTabStrip.getChildCount())
      {
        View localView = mTabStrip.getChildAt(i);
        if ((localView instanceof h)) {
          ((h)localView).onCreate();
        }
        i += 1;
      }
      applyModeAndGravity();
    }
  }
  
  public void setInlineLabelResource(int paramInt)
  {
    setInlineLabel(getResources().getBoolean(paramInt));
  }
  
  public void setOnTabSelectedListener(c paramC)
  {
    c localC = mOnTabSelectedListener;
    if (localC != null) {
      addView(localC);
    }
    mOnTabSelectedListener = paramC;
    if (paramC != null) {
      addTab(paramC);
    }
  }
  
  public void setPagerAdapter(PagerAdapter paramPagerAdapter, boolean paramBoolean)
  {
    PagerAdapter localPagerAdapter = mPagerAdapter;
    if (localPagerAdapter != null)
    {
      DataSetObserver localDataSetObserver = mPagerAdapterObserver;
      if (localDataSetObserver != null) {
        localPagerAdapter.unregisterDataSetObserver(localDataSetObserver);
      }
    }
    mPagerAdapter = paramPagerAdapter;
    if ((paramBoolean) && (paramPagerAdapter != null))
    {
      if (mPagerAdapterObserver == null) {
        mPagerAdapterObserver = new d();
      }
      paramPagerAdapter.registerDataSetObserver(mPagerAdapterObserver);
    }
    populateFromPagerAdapter();
  }
  
  public void setScrollAnimatorListener(Animator.AnimatorListener paramAnimatorListener)
  {
    animateToTab();
    mScrollAnimator.addListener(paramAnimatorListener);
  }
  
  public void setScrollPosition(int paramInt, float paramFloat, boolean paramBoolean)
  {
    setScrollPosition(paramInt, paramFloat, paramBoolean, true);
  }
  
  public void setScrollPosition(int paramInt, float paramFloat, boolean paramBoolean1, boolean paramBoolean2)
  {
    int i = Math.round(paramInt + paramFloat);
    if (i >= 0)
    {
      if (i >= mTabStrip.getChildCount()) {
        return;
      }
      if (paramBoolean2) {
        mTabStrip.setScrollPosition(paramInt, paramFloat);
      }
      ValueAnimator localValueAnimator = mScrollAnimator;
      if ((localValueAnimator != null) && (localValueAnimator.isRunning())) {
        mScrollAnimator.cancel();
      }
      scrollTo(calculateScrollXForTab(paramInt, paramFloat), 0);
      if (paramBoolean1) {
        setSelectedTabView(i);
      }
    }
  }
  
  public void setSelectedTabIndicator(int paramInt)
  {
    if (paramInt != 0)
    {
      setSelectedTabIndicator(org.v7.internal.util.Resources.getDrawable(getContext(), paramInt));
      return;
    }
    setSelectedTabIndicator(null);
  }
  
  public void setSelectedTabIndicator(Drawable paramDrawable)
  {
    if (image != paramDrawable)
    {
      image = paramDrawable;
      ViewCompat.postInvalidateOnAnimation(mTabStrip);
    }
  }
  
  public void setSelectedTabIndicatorColor(int paramInt)
  {
    mTabStrip.setSelectedIndicatorColor(paramInt);
  }
  
  public void setSelectedTabIndicatorGravity(int paramInt)
  {
    if (mViewHeight != paramInt)
    {
      mViewHeight = paramInt;
      ViewCompat.postInvalidateOnAnimation(mTabStrip);
    }
  }
  
  public void setSelectedTabIndicatorHeight(int paramInt)
  {
    mTabStrip.setSelectedIndicatorHeight(paramInt);
  }
  
  public void setTabGravity(int paramInt)
  {
    if (mTabGravity != paramInt)
    {
      mTabGravity = paramInt;
      applyModeAndGravity();
    }
  }
  
  public void setTabIconTint(ColorStateList paramColorStateList)
  {
    if (tint != paramColorStateList)
    {
      tint = paramColorStateList;
      updateAllTabs();
    }
  }
  
  public void setTabIconTintResource(int paramInt)
  {
    setTabIconTint(org.v7.internal.util.Resources.onCreateView(getContext(), paramInt));
  }
  
  public void setTabIndicatorFullWidth(boolean paramBoolean)
  {
    mStartPlaying = paramBoolean;
    ViewCompat.postInvalidateOnAnimation(mTabStrip);
  }
  
  public void setTabMode(int paramInt)
  {
    if (paramInt != mMode)
    {
      mMode = paramInt;
      applyModeAndGravity();
    }
  }
  
  public void setTabRippleColor(ColorStateList paramColorStateList)
  {
    if (mId != paramColorStateList)
    {
      mId = paramColorStateList;
      int i = 0;
      while (i < mTabStrip.getChildCount())
      {
        paramColorStateList = mTabStrip.getChildAt(i);
        if ((paramColorStateList instanceof h)) {
          h.setBackgroundDrawable((h)paramColorStateList, getContext());
        }
        i += 1;
      }
    }
  }
  
  public void setTabRippleColorResource(int paramInt)
  {
    setTabRippleColor(org.v7.internal.util.Resources.onCreateView(getContext(), paramInt));
  }
  
  public void setTabTextColors(ColorStateList paramColorStateList)
  {
    if (mTabTextColors != paramColorStateList)
    {
      mTabTextColors = paramColorStateList;
      updateAllTabs();
    }
  }
  
  public void setTabsFromPagerAdapter(PagerAdapter paramPagerAdapter)
  {
    setPagerAdapter(paramPagerAdapter, false);
  }
  
  public void setUnboundedRipple(boolean paramBoolean)
  {
    if (g != paramBoolean)
    {
      g = paramBoolean;
      int i = 0;
      while (i < mTabStrip.getChildCount())
      {
        View localView = mTabStrip.getChildAt(i);
        if ((localView instanceof h)) {
          h.setBackgroundDrawable((h)localView, getContext());
        }
        i += 1;
      }
    }
  }
  
  public void setUnboundedRippleResource(int paramInt)
  {
    setUnboundedRipple(getResources().getBoolean(paramInt));
  }
  
  public void setupWithViewPager(ViewPager paramViewPager)
  {
    selectTab(paramViewPager, true);
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return getTabScrollRange() > 0;
  }
  
  public final void updateAllTabs()
  {
    int i = 0;
    int j = mTabs.size();
    while (i < j)
    {
      ((f)mTabs.get(i)).updateTab();
      i += 1;
    }
  }
  
  public final void updateTabViewLayoutParams(LinearLayout.LayoutParams paramLayoutParams)
  {
    if ((mMode == 1) && (mTabGravity == 0))
    {
      width = 0;
      weight = 1.0F;
      return;
    }
    width = -2;
    weight = 0.0F;
  }
  
  public void updateTabViews(boolean paramBoolean)
  {
    int i = 0;
    while (i < mTabStrip.getChildCount())
    {
      View localView = mTabStrip.getChildAt(i);
      localView.setMinimumWidth(getTabMinWidth());
      updateTabViewLayoutParams((LinearLayout.LayoutParams)localView.getLayoutParams());
      if (paramBoolean) {
        localView.requestLayout();
      }
      i += 1;
    }
  }
  
  public final void visit(f paramF)
  {
    int i = a.size() - 1;
    while (i >= 0)
    {
      ((c)a.get(i)).setChild(paramF);
      i -= 1;
    }
  }
  
  public class a
    implements ValueAnimator.AnimatorUpdateListener
  {
    public a() {}
    
    public void onAnimationUpdate(ValueAnimator paramValueAnimator)
    {
      scrollTo(((Integer)paramValueAnimator.getAnimatedValue()).intValue(), 0);
    }
  }
  
  public class b
    implements ViewPager.i
  {
    public boolean mDivider;
    
    public b() {}
    
    public void setAdapter(ViewPager paramViewPager, PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2)
    {
      paramPagerAdapter1 = TabLayout.this;
      if (mViewPager == paramViewPager) {
        paramPagerAdapter1.setPagerAdapter(paramPagerAdapter2, mDivider);
      }
    }
    
    public void update(boolean paramBoolean)
    {
      mDivider = paramBoolean;
    }
  }
  
  public static abstract interface c<T extends TabLayout.f>
  {
    public abstract void b(TabLayout.f paramF);
    
    public abstract void setChild(TabLayout.f paramF);
    
    public abstract void setCurrentPage(TabLayout.f paramF);
  }
  
  public class d
    extends DataSetObserver
  {
    public d() {}
    
    public void onChanged()
    {
      populateFromPagerAdapter();
    }
    
    public void onInvalidated()
    {
      populateFromPagerAdapter();
    }
  }
  
  public class e
    extends LinearLayout
  {
    public int disabled;
    public final GradientDrawable drawable;
    public int i = -1;
    public int k = -1;
    public final Paint mBackgroundPaint;
    public ValueAnimator mImpl;
    public float r;
    public int right = -1;
    public int top = -1;
    
    public e(android.content.Context paramContext)
    {
      super();
      setWillNotDraw(false);
      mBackgroundPaint = new Paint();
      drawable = new GradientDrawable();
    }
    
    public void add(int paramInt1, int paramInt2)
    {
      if ((paramInt1 != top) || (paramInt2 != right))
      {
        top = paramInt1;
        right = paramInt2;
        ViewCompat.postInvalidateOnAnimation(this);
      }
    }
    
    public boolean childrenNeedLayout()
    {
      int j = 0;
      int m = getChildCount();
      while (j < m)
      {
        if (getChildAt(j).getWidth() <= 0) {
          return true;
        }
        j += 1;
      }
      return false;
    }
    
    public void draw(Canvas paramCanvas)
    {
      int j = 0;
      Object localObject = image;
      if (localObject != null) {
        j = ((Drawable)localObject).getIntrinsicHeight();
      }
      if (disabled >= 0) {
        j = disabled;
      }
      int n = 0;
      int m = 0;
      int i1 = mViewHeight;
      if (i1 != 0)
      {
        if (i1 != 1)
        {
          if (i1 != 2)
          {
            if (i1 != 3)
            {
              j = n;
            }
            else
            {
              j = 0;
              m = getHeight();
            }
          }
          else
          {
            n = 0;
            m = j;
            j = n;
          }
        }
        else
        {
          m = (getHeight() - j) / 2;
          n = (getHeight() + j) / 2;
          j = m;
          m = n;
        }
      }
      else
      {
        j = getHeight() - j;
        m = getHeight();
      }
      n = top;
      if ((n >= 0) && (right > n))
      {
        localObject = image;
        if (localObject == null) {
          localObject = drawable;
        }
        localObject = org.core.asm.signature.DrawableCompat.wrap((Drawable)localObject);
        ((Drawable)localObject).setBounds(top, j, right, m);
        Paint localPaint = mBackgroundPaint;
        if (localPaint != null) {
          if (Build.VERSION.SDK_INT == 21) {
            ((Drawable)localObject).setColorFilter(localPaint.getColor(), PorterDuff.Mode.SRC_IN);
          } else {
            org.core.asm.signature.DrawableCompat.setTint((Drawable)localObject, localPaint.getColor());
          }
        }
        ((Drawable)localObject).draw(paramCanvas);
      }
      super.draw(paramCanvas);
    }
    
    public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      ValueAnimator localValueAnimator = mImpl;
      if ((localValueAnimator != null) && (localValueAnimator.isRunning()))
      {
        mImpl.cancel();
        long l = mImpl.getDuration();
        update(i, Math.round((1.0F - mImpl.getAnimatedFraction()) * (float)l));
        return;
      }
      update();
    }
    
    public void onMeasure(int paramInt1, int paramInt2)
    {
      super.onMeasure(paramInt1, paramInt2);
      if (View.MeasureSpec.getMode(paramInt1) != 1073741824) {
        return;
      }
      Object localObject = TabLayout.this;
      if ((mMode == 1) && (mTabGravity == 1))
      {
        int i1 = getChildCount();
        int m = 0;
        int j = 0;
        while (j < i1)
        {
          localObject = getChildAt(j);
          n = m;
          if (((View)localObject).getVisibility() == 0) {
            n = Math.max(m, ((View)localObject).getMeasuredWidth());
          }
          j += 1;
          m = n;
        }
        if (m <= 0) {
          return;
        }
        int n = dpToPx(16);
        j = 0;
        if (m * i1 <= getMeasuredWidth() - n * 2)
        {
          n = 0;
          while (n < i1)
          {
            localObject = (LinearLayout.LayoutParams)getChildAt(n).getLayoutParams();
            if ((width != m) || (weight != 0.0F))
            {
              width = m;
              weight = 0.0F;
              j = 1;
            }
            n += 1;
          }
        }
        else
        {
          localObject = TabLayout.this;
          mTabGravity = 0;
          ((TabLayout)localObject).updateTabViews(false);
          j = 1;
        }
        if (j != 0) {
          super.onMeasure(paramInt1, paramInt2);
        }
      }
    }
    
    public void onRtlPropertiesChanged(int paramInt)
    {
      super.onRtlPropertiesChanged(paramInt);
      if ((Build.VERSION.SDK_INT < 23) && (k != paramInt))
      {
        requestLayout();
        k = paramInt;
      }
    }
    
    public void setScrollPosition(int paramInt, float paramFloat)
    {
      ValueAnimator localValueAnimator = mImpl;
      if ((localValueAnimator != null) && (localValueAnimator.isRunning())) {
        mImpl.cancel();
      }
      i = paramInt;
      r = paramFloat;
      update();
    }
    
    public void setSelectedIndicatorColor(int paramInt)
    {
      if (mBackgroundPaint.getColor() != paramInt)
      {
        mBackgroundPaint.setColor(paramInt);
        ViewCompat.postInvalidateOnAnimation(this);
      }
    }
    
    public void setSelectedIndicatorHeight(int paramInt)
    {
      if (disabled != paramInt)
      {
        disabled = paramInt;
        ViewCompat.postInvalidateOnAnimation(this);
      }
    }
    
    public final void update()
    {
      View localView = getChildAt(i);
      int n;
      int i1;
      if ((localView != null) && (localView.getWidth() > 0))
      {
        n = localView.getLeft();
        i1 = localView.getRight();
        TabLayout localTabLayout = TabLayout.this;
        int m = n;
        int j = i1;
        if (!mStartPlaying)
        {
          m = n;
          j = i1;
          if ((localView instanceof TabLayout.h))
          {
            update((TabLayout.h)localView, TabLayout.access$getMTabTextAppearance(localTabLayout));
            m = (int)access$getMTabTextAppearanceleft;
            j = (int)access$getMTabTextAppearanceright;
          }
        }
        n = m;
        i1 = j;
        if (r > 0.0F)
        {
          n = m;
          i1 = j;
          if (i < getChildCount() - 1)
          {
            localView = getChildAt(i + 1);
            int i2 = localView.getLeft();
            int i3 = localView.getRight();
            localTabLayout = TabLayout.this;
            i1 = i2;
            n = i3;
            if (!mStartPlaying)
            {
              i1 = i2;
              n = i3;
              if ((localView instanceof TabLayout.h))
              {
                update((TabLayout.h)localView, TabLayout.access$getMTabTextAppearance(localTabLayout));
                i1 = (int)access$getMTabTextAppearanceleft;
                n = (int)access$getMTabTextAppearanceright;
              }
            }
            float f = r;
            m = (int)(i1 * f + (1.0F - f) * m);
            i1 = (int)(n * f + (1.0F - f) * j);
            n = m;
          }
        }
      }
      else
      {
        n = -1;
        i1 = -1;
      }
      add(n, i1);
    }
    
    public void update(final int paramInt1, int paramInt2)
    {
      Object localObject = mImpl;
      if ((localObject != null) && (((ValueAnimator)localObject).isRunning())) {
        mImpl.cancel();
      }
      localObject = getChildAt(paramInt1);
      if (localObject == null)
      {
        update();
        return;
      }
      final int j = ((View)localObject).getLeft();
      final int m = ((View)localObject).getRight();
      TabLayout localTabLayout = TabLayout.this;
      if ((!mStartPlaying) && ((localObject instanceof TabLayout.h)))
      {
        update((TabLayout.h)localObject, TabLayout.access$getMTabTextAppearance(localTabLayout));
        j = (int)access$getMTabTextAppearanceleft;
        m = (int)access$getMTabTextAppearanceright;
      }
      final int n = top;
      final int i1 = right;
      if ((n == j) && (i1 == m)) {
        return;
      }
      localObject = new ValueAnimator();
      mImpl = ((ValueAnimator)localObject);
      ((ValueAnimator)localObject).setInterpolator(AnimationUtils.a);
      ((ValueAnimator)localObject).setDuration(paramInt2);
      ((ValueAnimator)localObject).setFloatValues(new float[] { 0.0F, 1.0F });
      ((ValueAnimator)localObject).addUpdateListener(new a(n, j, i1, m));
      ((Animator)localObject).addListener(new b(paramInt1));
      ((ValueAnimator)localObject).start();
    }
    
    public final void update(TabLayout.h paramH, RectF paramRectF)
    {
      int m = TabLayout.h.calculate(paramH);
      int j = m;
      if (m < dpToPx(24)) {
        j = dpToPx(24);
      }
      m = (paramH.getLeft() + paramH.getRight()) / 2;
      int n = j / 2;
      j /= 2;
      paramRectF.set(m - n, 0.0F, j + m, 0.0F);
    }
    
    public class a
      implements ValueAnimator.AnimatorUpdateListener
    {
      public a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
      
      public void onAnimationUpdate(ValueAnimator paramValueAnimator)
      {
        float f = paramValueAnimator.getAnimatedFraction();
        add(AnimationUtils.lerp(n, j, f), AnimationUtils.lerp(i1, m, f));
      }
    }
    
    public class b
      extends AnimatorListenerAdapter
    {
      public b(int paramInt) {}
      
      public void onAnimationEnd(Animator paramAnimator)
      {
        paramAnimator = TabLayout.e.this;
        i = paramInt1;
        r = 0.0F;
      }
    }
  }
  
  public static class f
  {
    public CharSequence mContentDesc;
    public View mCustomView;
    public Drawable mIcon;
    public TabLayout mParent;
    public int mPosition = -1;
    public CharSequence mText;
    public TabLayout.h mView;
    
    public f() {}
    
    public View getCustomView()
    {
      return mCustomView;
    }
    
    public Drawable getIcon()
    {
      return mIcon;
    }
    
    public int getPosition()
    {
      return mPosition;
    }
    
    public CharSequence getText()
    {
      return mText;
    }
    
    public boolean isSelected()
    {
      TabLayout localTabLayout = mParent;
      if (localTabLayout != null) {
        return localTabLayout.getSelectedTabPosition() == mPosition;
      }
      throw new IllegalArgumentException("Tab not attached to a TabLayout");
    }
    
    public void removeAllTabs()
    {
      mParent = null;
      mView = null;
      mIcon = null;
      mText = null;
      mContentDesc = null;
      mPosition = -1;
      mCustomView = null;
    }
    
    public void select()
    {
      TabLayout localTabLayout = mParent;
      if (localTabLayout != null)
      {
        localTabLayout.selectTab(this);
        return;
      }
      throw new IllegalArgumentException("Tab not attached to a TabLayout");
    }
    
    public f setContentDescription(CharSequence paramCharSequence)
    {
      mContentDesc = paramCharSequence;
      updateTab();
      return this;
    }
    
    public f setCustomView(int paramInt)
    {
      setCustomView(LayoutInflater.from(mView.getContext()).inflate(paramInt, mView, false));
      return this;
    }
    
    public f setCustomView(View paramView)
    {
      mCustomView = paramView;
      updateTab();
      return this;
    }
    
    public f setIcon(Drawable paramDrawable)
    {
      mIcon = paramDrawable;
      updateTab();
      return this;
    }
    
    public void setPosition(int paramInt)
    {
      mPosition = paramInt;
    }
    
    public f setText(CharSequence paramCharSequence)
    {
      if ((TextUtils.isEmpty(mContentDesc)) && (!TextUtils.isEmpty(paramCharSequence))) {
        mView.setContentDescription(paramCharSequence);
      }
      mText = paramCharSequence;
      updateTab();
      return this;
    }
    
    public void updateTab()
    {
      TabLayout.h localH = mView;
      if (localH != null) {
        localH.update();
      }
    }
  }
  
  public static class g
    implements ViewPager.j
  {
    public int mPreviousScrollState;
    public int mScrollState;
    public final WeakReference<TabLayout> mTabLayoutRef;
    
    public g(TabLayout paramTabLayout)
    {
      mTabLayoutRef = new WeakReference(paramTabLayout);
    }
    
    public void onPageScrollStateChanged(int paramInt)
    {
      mPreviousScrollState = mScrollState;
      mScrollState = paramInt;
    }
    
    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
    {
      TabLayout localTabLayout = (TabLayout)mTabLayoutRef.get();
      if (localTabLayout != null)
      {
        paramInt2 = mScrollState;
        boolean bool2 = false;
        boolean bool1;
        if ((paramInt2 == 2) && (mPreviousScrollState != 1)) {
          bool1 = false;
        } else {
          bool1 = true;
        }
        if ((mScrollState != 2) || (mPreviousScrollState != 0)) {
          bool2 = true;
        }
        localTabLayout.setScrollPosition(paramInt1, paramFloat, bool1, bool2);
      }
    }
    
    public void onPageSelected(int paramInt)
    {
      TabLayout localTabLayout = (TabLayout)mTabLayoutRef.get();
      if ((localTabLayout != null) && (localTabLayout.getSelectedTabPosition() != paramInt) && (paramInt < localTabLayout.getTabCount()))
      {
        int i = mScrollState;
        boolean bool;
        if ((i != 0) && ((i != 2) || (mPreviousScrollState != 0))) {
          bool = false;
        } else {
          bool = true;
        }
        localTabLayout.selectTab(localTabLayout.getTabAt(paramInt), bool);
      }
    }
    
    public void reset()
    {
      mScrollState = 0;
      mPreviousScrollState = 0;
    }
  }
  
  public class h
    extends LinearLayout
  {
    public ImageView mCustomIconView;
    public TextView mCustomTextView;
    public View mCustomView;
    public int mDefaultMaxLines = 2;
    public ImageView mIconView;
    public Drawable mShadowDrawable;
    public TabLayout.f mTab;
    public TextView mTextView;
    
    public h(android.content.Context paramContext)
    {
      super();
      setBackgroundDrawable(paramContext);
      ViewCompat.setPaddingRelative(this, mTabPaddingStart, mTabPaddingTop, mTabPaddingEnd, mTabPaddingBottom);
      setGravity(17);
      setOrientation(p ^ true);
      setClickable(true);
      ViewCompat.a(this, org.core.view.e.a(getContext(), 1002));
    }
    
    public final float approximateLineWidth(Layout paramLayout, int paramInt, float paramFloat)
    {
      return paramLayout.getLineWidth(paramInt) * (paramFloat / paramLayout.getPaint().getTextSize());
    }
    
    public final int calculate()
    {
      int m = 0;
      int n = 0;
      int k = 0;
      TextView localTextView = mTextView;
      int j = 0;
      ImageView localImageView = mIconView;
      View localView1 = mCustomView;
      while (j < 3)
      {
        View localView2 = new View[] { localTextView, localImageView, localView1 }[j];
        int i2 = m;
        int i1 = n;
        int i = k;
        if (localView2 != null)
        {
          i2 = m;
          i1 = n;
          i = k;
          if (localView2.getVisibility() == 0)
          {
            i1 = localView2.getLeft();
            i = i1;
            if (m != 0) {
              i = Math.min(n, i1);
            }
            n = i;
            i1 = localView2.getRight();
            i = i1;
            if (m != 0) {
              i = Math.max(k, i1);
            }
            i2 = 1;
            i1 = n;
          }
        }
        j += 1;
        m = i2;
        n = i1;
        k = i;
      }
      return k - n;
    }
    
    public void drawableStateChanged()
    {
      super.drawableStateChanged();
      boolean bool2 = false;
      int[] arrayOfInt = getDrawableState();
      Drawable localDrawable = mShadowDrawable;
      boolean bool1 = bool2;
      if (localDrawable != null)
      {
        bool1 = bool2;
        if (localDrawable.isStateful()) {
          bool1 = false | mShadowDrawable.setState(arrayOfInt);
        }
      }
      if (bool1)
      {
        invalidate();
        invalidate();
      }
    }
    
    public final void onCreate()
    {
      setOrientation(p ^ true);
      if ((mCustomTextView == null) && (mCustomIconView == null))
      {
        updateTextAndIcon(mTextView, mIconView);
        return;
      }
      updateTextAndIcon(mCustomTextView, mCustomIconView);
    }
    
    public final void onDrawOver(Canvas paramCanvas)
    {
      Drawable localDrawable = mShadowDrawable;
      if (localDrawable != null)
      {
        localDrawable.setBounds(getLeft(), getTop(), getRight(), getBottom());
        mShadowDrawable.draw(paramCanvas);
      }
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
    {
      super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(a.c.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
    {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setClassName(a.c.class.getName());
    }
    
    public void onMeasure(int paramInt1, int paramInt2)
    {
      int j = View.MeasureSpec.getSize(paramInt1);
      int k = View.MeasureSpec.getMode(paramInt1);
      int m = getTabMaxWidth();
      int i = paramInt1;
      if (m > 0) {
        if (k != 0)
        {
          i = paramInt1;
          if (j <= m) {}
        }
        else
        {
          i = View.MeasureSpec.makeMeasureSpec(mTabMaxWidth, Integer.MIN_VALUE);
        }
      }
      super.onMeasure(i, paramInt2);
      if (mTextView != null)
      {
        float f2 = size;
        j = mDefaultMaxLines;
        Object localObject = mIconView;
        float f1;
        if ((localObject != null) && (((View)localObject).getVisibility() == 0))
        {
          paramInt1 = 1;
          f1 = f2;
        }
        else
        {
          localObject = mTextView;
          paramInt1 = j;
          f1 = f2;
          if (localObject != null)
          {
            paramInt1 = j;
            f1 = f2;
            if (((TextView)localObject).getLineCount() > 1)
            {
              f1 = f;
              paramInt1 = j;
            }
          }
        }
        f2 = mTextView.getTextSize();
        m = mTextView.getLineCount();
        j = Label.getMaxLines(mTextView);
        if ((f1 != f2) || ((j >= 0) && (paramInt1 != j)))
        {
          k = 1;
          j = k;
          if (mMode == 1)
          {
            j = k;
            if (f1 > f2)
            {
              j = k;
              if (m == 1)
              {
                localObject = mTextView.getLayout();
                if (localObject != null)
                {
                  j = k;
                  if (approximateLineWidth((Layout)localObject, 0, f1) <= getMeasuredWidth() - getPaddingLeft() - getPaddingRight()) {}
                }
                else
                {
                  j = 0;
                }
              }
            }
          }
          if (j != 0)
          {
            mTextView.setTextSize(0, f1);
            mTextView.setMaxLines(paramInt1);
            super.onMeasure(i, paramInt2);
          }
        }
      }
    }
    
    public boolean performClick()
    {
      boolean bool = super.performClick();
      if (mTab != null)
      {
        if (!bool) {
          playSoundEffect(0);
        }
        mTab.select();
        return true;
      }
      return bool;
    }
    
    public void reset()
    {
      setTab(null);
      setSelected(false);
    }
    
    public final void setBackgroundDrawable(android.content.Context paramContext)
    {
      int i = mTabBackgroundResId;
      Object localObject = null;
      if (i != 0)
      {
        paramContext = org.v7.internal.util.Resources.getDrawable(paramContext, i);
        mShadowDrawable = paramContext;
        if ((paramContext != null) && (paramContext.isStateful())) {
          mShadowDrawable.setState(getDrawableState());
        }
      }
      else
      {
        mShadowDrawable = null;
      }
      paramContext = new GradientDrawable();
      paramContext.setColor(0);
      if (mId != null)
      {
        GradientDrawable localGradientDrawable = new GradientDrawable();
        localGradientDrawable.setCornerRadius(1.0E-5F);
        localGradientDrawable.setColor(-1);
        ColorStateList localColorStateList = TintManager.valueOf(mId);
        if (g) {
          paramContext = null;
        }
        if (!g) {
          localObject = localGradientDrawable;
        }
        paramContext = new RippleDrawable(localColorStateList, paramContext, localObject);
      }
      ViewCompat.setBackgroundDrawable(this, paramContext);
      invalidate();
    }
    
    public void setSelected(boolean paramBoolean)
    {
      int i;
      if (isSelected() != paramBoolean) {
        i = 1;
      } else {
        i = 0;
      }
      super.setSelected(paramBoolean);
      if ((i != 0) && (paramBoolean)) {}
      Object localObject = mTextView;
      if (localObject != null) {
        ((TextView)localObject).setSelected(paramBoolean);
      }
      localObject = mIconView;
      if (localObject != null) {
        ((ImageView)localObject).setSelected(paramBoolean);
      }
      localObject = mCustomView;
      if (localObject != null) {
        ((View)localObject).setSelected(paramBoolean);
      }
    }
    
    public void setTab(TabLayout.f paramF)
    {
      if (paramF != mTab)
      {
        mTab = paramF;
        update();
      }
    }
    
    public final void update()
    {
      TabLayout.f localF = mTab;
      PorterDuff.Mode localMode = null;
      if (localF != null) {
        localObject1 = localF.getCustomView();
      } else {
        localObject1 = null;
      }
      if (localObject1 != null)
      {
        Object localObject2 = ((View)localObject1).getParent();
        if (localObject2 != this)
        {
          if (localObject2 != null) {
            ((ViewGroup)localObject2).removeView((View)localObject1);
          }
          addView((View)localObject1);
        }
        mCustomView = ((View)localObject1);
        localObject2 = mTextView;
        if (localObject2 != null) {
          ((View)localObject2).setVisibility(8);
        }
        localObject2 = mIconView;
        if (localObject2 != null)
        {
          ((ImageView)localObject2).setVisibility(8);
          mIconView.setImageDrawable(null);
        }
        localObject2 = (TextView)((View)localObject1).findViewById(16908308);
        mCustomTextView = ((TextView)localObject2);
        if (localObject2 != null) {
          mDefaultMaxLines = Label.getMaxLines((TextView)localObject2);
        }
        mCustomIconView = ((ImageView)((View)localObject1).findViewById(16908294));
      }
      else
      {
        localObject1 = mCustomView;
        if (localObject1 != null)
        {
          removeView((View)localObject1);
          mCustomView = null;
        }
        mCustomTextView = null;
        mCustomIconView = null;
      }
      Object localObject1 = mCustomView;
      boolean bool2 = false;
      if (localObject1 == null)
      {
        if (mIconView == null)
        {
          localObject1 = (ImageView)LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_icon, this, false);
          addView((View)localObject1, 0);
          mIconView = ((ImageView)localObject1);
        }
        localObject1 = localMode;
        if (localF != null)
        {
          localObject1 = localMode;
          if (localF.getIcon() != null) {
            localObject1 = org.core.asm.signature.DrawableCompat.wrap(localF.getIcon()).mutate();
          }
        }
        if (localObject1 != null)
        {
          org.core.asm.signature.DrawableCompat.setTintList((Drawable)localObject1, tint);
          localMode = mContext;
          if (localMode != null) {
            org.core.asm.signature.DrawableCompat.setTintMode((Drawable)localObject1, localMode);
          }
        }
        if (mTextView == null)
        {
          localObject1 = (TextView)LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_text, this, false);
          addView((View)localObject1);
          mTextView = ((TextView)localObject1);
          mDefaultMaxLines = Label.getMaxLines((TextView)localObject1);
        }
        Label.setTextAppearance(mTextView, h);
        localObject1 = mTabTextColors;
        if (localObject1 != null) {
          mTextView.setTextColor((ColorStateList)localObject1);
        }
        updateTextAndIcon(mTextView, mIconView);
      }
      else if ((mCustomTextView != null) || (mCustomIconView != null))
      {
        updateTextAndIcon(mCustomTextView, mCustomIconView);
      }
      if ((localF != null) && (!TextUtils.isEmpty(TabLayout.f.getContentDescription(localF)))) {
        setContentDescription(TabLayout.f.getContentDescription(localF));
      }
      boolean bool1 = bool2;
      if (localF != null)
      {
        bool1 = bool2;
        if (localF.isSelected()) {
          bool1 = true;
        }
      }
      setSelected(bool1);
    }
    
    public final void updateTextAndIcon(TextView paramTextView, ImageView paramImageView)
    {
      Object localObject1 = mTab;
      Object localObject3 = null;
      if ((localObject1 != null) && (((TabLayout.f)localObject1).getIcon() != null)) {
        localObject1 = org.core.asm.signature.DrawableCompat.wrap(mTab.getIcon()).mutate();
      } else {
        localObject1 = null;
      }
      Object localObject2 = mTab;
      if (localObject2 != null) {
        localObject2 = ((TabLayout.f)localObject2).getText();
      } else {
        localObject2 = null;
      }
      if (paramImageView != null) {
        if (localObject1 != null)
        {
          paramImageView.setImageDrawable((Drawable)localObject1);
          paramImageView.setVisibility(0);
          setVisibility(0);
        }
        else
        {
          paramImageView.setVisibility(8);
          paramImageView.setImageDrawable(null);
        }
      }
      boolean bool = TextUtils.isEmpty((CharSequence)localObject2) ^ true;
      if (paramTextView != null) {
        if (bool)
        {
          paramTextView.setText((CharSequence)localObject2);
          paramTextView.setVisibility(0);
          setVisibility(0);
        }
        else
        {
          paramTextView.setVisibility(8);
          paramTextView.setText(null);
        }
      }
      if (paramImageView != null)
      {
        paramTextView = (ViewGroup.MarginLayoutParams)paramImageView.getLayoutParams();
        int j = 0;
        int i = j;
        if (bool)
        {
          i = j;
          if (paramImageView.getVisibility() == 0) {
            i = dpToPx(8);
          }
        }
        if (p)
        {
          if (i != MarginLayoutParamsCompat.getMarginEnd(paramTextView))
          {
            MarginLayoutParamsCompat.setMarginEnd(paramTextView, i);
            bottomMargin = 0;
            paramImageView.setLayoutParams(paramTextView);
            paramImageView.requestLayout();
          }
        }
        else if (i != bottomMargin)
        {
          bottomMargin = i;
          MarginLayoutParamsCompat.setMarginEnd(paramTextView, 0);
          paramImageView.setLayoutParams(paramTextView);
          paramImageView.requestLayout();
        }
      }
      paramTextView = mTab;
      if (paramTextView != null) {
        paramTextView = TabLayout.f.getContentDescription(paramTextView);
      } else {
        paramTextView = null;
      }
      if (bool) {
        paramTextView = localObject3;
      }
      MenuItemImpl.setText(this, paramTextView);
    }
  }
  
  public static class i
    implements TabLayout.c
  {
    public final ViewPager mViewPager;
    
    public i(ViewPager paramViewPager)
    {
      mViewPager = paramViewPager;
    }
    
    public void b(TabLayout.f paramF) {}
    
    public void setChild(TabLayout.f paramF) {}
    
    public void setCurrentPage(TabLayout.f paramF)
    {
      mViewPager.setCurrentItem(paramF.getPosition());
    }
  }
}
