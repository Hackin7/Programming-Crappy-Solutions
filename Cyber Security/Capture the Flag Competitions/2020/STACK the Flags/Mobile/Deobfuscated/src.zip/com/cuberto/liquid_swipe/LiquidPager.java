package com.cuberto.liquid_swipe;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnDrawListener;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.j;
import apache.tools.ui.R.drawable;
import apache.tools.ui.R.styleable;
import apache.tools.ui.i;
import apache.tools.ui.manager.ClassWriter;
import apache.tools.ui.manager.f;
import core.fonts.data.Log;
import org.core.view.ImageLoader;
import org.core.view.ViewCompat;
import org.sufficientlysecure.rootcommands.PagerAdapter;

public final class LiquidPager
  extends ViewPager
  implements ViewTreeObserver.OnDrawListener, apache.tools.ui.h
{
  public apache.tools.ui.manager.h b;
  public f d;
  public int h = R.drawable.ic_button;
  public boolean z;
  
  public LiquidPager(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setWillNotDraw(false);
    getViewTreeObserver().addOnDrawListener(this);
    setAdapter(new b(this));
    if ((ViewCompat.get(this)) && (!isLayoutRequested()))
    {
      invalidate();
      Object localObject = a(this);
      if (localObject != null) {
        ((f)localObject).a(getCurrentItem());
      }
      localObject = b(this);
      if (localObject != null) {
        ((apache.tools.ui.manager.h)localObject).a(getCurrentItem());
      }
    }
    else
    {
      addOnLayoutChangeListener(new a(this));
    }
    h = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.LiquidPager).getResourceId(R.styleable.LiquidPager_button_drawable, R.drawable.ic_button);
  }
  
  public void a(int paramInt)
  {
    ClassWriter.b.get();
    int i = getCurrentItem();
    if (paramInt == 0) {
      paramInt = i + 1;
    } else {
      paramInt = i - 1;
    }
    setCurrentItem(paramInt, false);
  }
  
  public Bitmap b(int paramInt)
  {
    ClassWriter.b.get();
    if (paramInt == 0) {
      return get(getCurrentItem() - 1);
    }
    return get(getCurrentItem() + 1);
  }
  
  public void b()
  {
    invalidate();
  }
  
  public void b(boolean paramBoolean)
  {
    z = paramBoolean;
  }
  
  public void dispatchDraw(Canvas paramCanvas)
  {
    super.dispatchDraw(paramCanvas);
    Object localObject = d;
    if (localObject != null) {
      ((f)localObject).b(paramCanvas);
    }
    localObject = b;
    if (localObject != null) {
      ((apache.tools.ui.manager.h)localObject).c(paramCanvas);
    }
  }
  
  public Bitmap get(int paramInt)
  {
    View localView = getChildAt(paramInt);
    if (localView != null) {
      return ImageLoader.get(localView, null, 1);
    }
    return null;
  }
  
  public int getCount()
  {
    PagerAdapter localPagerAdapter = getAdapter();
    if (localPagerAdapter != null) {
      return localPagerAdapter.getCount();
    }
    return 0;
  }
  
  public void onDraw()
  {
    Object localObject = d;
    if ((localObject == null) || (((i)localObject).add() != true))
    {
      localObject = b;
      if ((localObject != null) && (((i)localObject).add() == true)) {
        return;
      }
      localObject = d;
      if (localObject != null) {
        ((f)localObject).a(getCurrentItem());
      }
      localObject = b;
      if (localObject != null) {
        ((apache.tools.ui.manager.h)localObject).a(getCurrentItem());
      }
    }
  }
  
  public void onDrawForeground(Canvas paramCanvas)
  {
    super.onDrawForeground(paramCanvas);
    Object localObject = d;
    if (localObject != null) {
      ((f)localObject).b(paramCanvas);
    }
    localObject = b;
    if (localObject != null) {
      ((apache.tools.ui.manager.h)localObject).c(paramCanvas);
    }
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    Object localObject = getResources();
    Log.add(localObject, "resources");
    float f = getDisplayMetricsdensity;
    d = new f(paramInt1, paramInt2, 0.0F, f, this);
    localObject = new apache.tools.ui.manager.h(paramInt1, paramInt2, 0.0F, f, this);
    b = ((apache.tools.ui.manager.h)localObject);
    if (localObject != null) {
      ((apache.tools.ui.manager.h)localObject).a(getResources().getDrawable(h, null));
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    Log.append(paramMotionEvent, "ev");
    if (!z)
    {
      int i = paramMotionEvent.getAction();
      Object localObject;
      boolean bool1;
      boolean bool2;
      if (i != 0)
      {
        if (i != 1)
        {
          if (i == 2)
          {
            localObject = d;
            if (localObject != null) {
              bool1 = ((f)localObject).d(paramMotionEvent);
            } else {
              bool1 = false;
            }
            localObject = b;
            if (localObject != null) {
              bool2 = ((apache.tools.ui.manager.h)localObject).c(paramMotionEvent);
            } else {
              bool2 = false;
            }
            if ((bool1) || (bool2)) {
              return true;
            }
          }
        }
        else
        {
          localObject = d;
          if (localObject != null)
          {
            ((f)localObject).b(paramMotionEvent);
            i = 1;
          }
          else
          {
            i = 0;
          }
          localObject = b;
          int j;
          if (localObject != null)
          {
            ((apache.tools.ui.manager.h)localObject).b(paramMotionEvent);
            j = 1;
          }
          else
          {
            j = 0;
          }
          if ((i != 0) || (j != 0)) {
            return true;
          }
        }
      }
      else
      {
        localObject = d;
        if (localObject != null) {
          bool1 = ((f)localObject).a(paramMotionEvent);
        } else {
          bool1 = false;
        }
        localObject = b;
        if (localObject != null) {
          bool2 = ((apache.tools.ui.manager.h)localObject).a(paramMotionEvent);
        } else {
          bool2 = false;
        }
        if ((bool1) || (bool2)) {
          return true;
        }
      }
    }
    return false;
  }
  
  public void setAdapter(PagerAdapter paramPagerAdapter)
  {
    super.setAdapter(paramPagerAdapter);
    setOffscreenPageLimit(getCount());
  }
  
  public final void setButtonDrawable(int paramInt)
  {
    h = paramInt;
    apache.tools.ui.manager.h localH = b;
    if (localH != null) {
      localH.a(getResources().getDrawable(h, null));
    }
  }
  
  public void setOffscreenPageLimit(int paramInt)
  {
    super.setOffscreenPageLimit(getCount());
  }
  
  public static final class a
    implements View.OnLayoutChangeListener
  {
    public a(LiquidPager paramLiquidPager) {}
    
    public void onLayoutChange(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
    {
      Log.append(paramView, "view");
      paramView.removeOnLayoutChangeListener(this);
      mViewPager.invalidate();
      paramView = LiquidPager.a(mViewPager);
      if (paramView != null) {
        paramView.a(mViewPager.getCurrentItem());
      }
      paramView = LiquidPager.b(mViewPager);
      if (paramView != null) {
        paramView.a(mViewPager.getCurrentItem());
      }
    }
  }
  
  public static final class b
    implements ViewPager.j
  {
    public b(LiquidPager paramLiquidPager) {}
    
    public void onPageScrollStateChanged(int paramInt) {}
    
    public void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {}
    
    public void onPageSelected(int paramInt)
    {
      a.invalidate();
      Object localObject = LiquidPager.a(a);
      if (localObject != null) {
        ((f)localObject).a(paramInt);
      }
      localObject = LiquidPager.b(a);
      if (localObject != null) {
        ((apache.tools.ui.manager.h)localObject).a(paramInt);
      }
    }
  }
}
