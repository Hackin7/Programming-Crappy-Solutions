package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.c;
import apache.org.org.core.util.Label;
import apache.org.org.core.util.a;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class FabTransformationScrimBehavior
  extends ExpandableTransformationBehavior
{
  public final Label mView = new Label(0L, 150L);
  public final Label this$0 = new Label(75L, 150L);
  
  public FabTransformationScrimBehavior() {}
  
  public FabTransformationScrimBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public AnimatorSet b(View paramView1, final View paramView2, final boolean paramBoolean1, boolean paramBoolean2)
  {
    paramView1 = new ArrayList();
    new ArrayList();
    show(paramView2, paramBoolean1, paramBoolean2, paramView1);
    AnimatorSet localAnimatorSet = new AnimatorSet();
    a.show(localAnimatorSet, paramView1);
    localAnimatorSet.addListener(new a(paramBoolean1, paramView2));
    return localAnimatorSet;
  }
  
  public boolean get(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
  {
    return paramView2 instanceof FloatingActionButton;
  }
  
  public boolean onTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
  {
    super.onTouchEvent(paramCoordinatorLayout, paramView, paramMotionEvent);
    return false;
  }
  
  public final void show(View paramView, boolean paramBoolean1, boolean paramBoolean2, List paramList)
  {
    Label localLabel;
    if (paramBoolean1) {
      localLabel = this$0;
    } else {
      localLabel = mView;
    }
    if (paramBoolean1)
    {
      if (!paramBoolean2) {
        paramView.setAlpha(0.0F);
      }
      paramView = ObjectAnimator.ofFloat(paramView, View.ALPHA, new float[] { 1.0F });
    }
    else
    {
      paramView = ObjectAnimator.ofFloat(paramView, View.ALPHA, new float[] { 0.0F });
    }
    localLabel.show(paramView);
    paramList.add(paramView);
  }
  
  public class a
    extends AnimatorListenerAdapter
  {
    public a(boolean paramBoolean, View paramView) {}
    
    public void onAnimationEnd(Animator paramAnimator)
    {
      if (!paramBoolean1) {
        paramView2.setVisibility(4);
      }
    }
    
    public void onAnimationStart(Animator paramAnimator)
    {
      if (paramBoolean1) {
        paramView2.setVisibility(0);
      }
    }
  }
}
