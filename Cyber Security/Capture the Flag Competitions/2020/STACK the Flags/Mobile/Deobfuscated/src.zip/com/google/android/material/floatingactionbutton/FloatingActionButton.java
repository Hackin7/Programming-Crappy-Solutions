package com.google.android.material.floatingactionbutton;

import android.animation.Animator.AnimatorListener;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.c;
import androidx.coordinatorlayout.widget.CoordinatorLayout.d;
import androidx.coordinatorlayout.widget.CoordinatorLayout.f;
import apache.org.org.core.'annotation'.ShadowViewDelegate;
import apache.org.org.core.R.attr;
import apache.org.org.core.R.dimen;
import apache.org.org.core.R.style;
import apache.org.org.core.R.styleable;
import apache.org.org.core.internal.ViewGroupUtilsHoneycomb;
import apache.org.org.core.internal.VisibilityAwareImageButton;
import apache.org.org.core.pattern.ResourcesCompat;
import apache.org.org.core.tree.Label;
import apache.org.org.core.util.Frame;
import apache.org.org.core.widget.FloatingActionButtonImpl;
import apache.org.org.core.widget.FloatingActionButtonImpl.InternalVisibilityChangedListener;
import apache.org.org.core.widget.FloatingActionButtonLollipop;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.util.List;
import org.client.params.Item;
import org.core.view.ViewCompat;
import org.v7.widget.AppCompatImageHelper;

@CoordinatorLayout.d(Behavior.class)
public class FloatingActionButton
  extends VisibilityAwareImageButton
  implements apache.org.org.core.map.FloatingActionButton
{
  public final Rect TAG = new Rect();
  public final apache.org.org.core.map.f d;
  public int h;
  public ColorStateList mBackgroundTint;
  public PorterDuff.Mode mBackgroundTintMode;
  public int mBorderWidth;
  public int mColor;
  public boolean mCompatPadding;
  public int mContentPadding;
  public final AppCompatImageHelper mImageHelper;
  public FloatingActionButtonImpl mImpl;
  public ColorStateList mRippleColor;
  public int mSize;
  public ColorStateList mTextColor;
  public PorterDuff.Mode mType;
  public final Rect this$0 = new Rect();
  
  public FloatingActionButton(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.floatingActionButtonStyle);
  }
  
  public FloatingActionButton(android.content.Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    Object localObject = apache.org.org.core.internal.f.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.FloatingActionButton, paramInt, R.style.Widget_Design_FloatingActionButton, new int[0]);
    mBackgroundTint = ResourcesCompat.getString(paramContext, (TypedArray)localObject, R.styleable.FloatingActionButton_backgroundTint);
    mBackgroundTintMode = apache.org.org.core.internal.DrawableCompat.parseTintMode(((TypedArray)localObject).getInt(R.styleable.FloatingActionButton_backgroundTintMode, -1), null);
    mRippleColor = ResourcesCompat.getString(paramContext, (TypedArray)localObject, R.styleable.FloatingActionButton_rippleColor);
    mSize = ((TypedArray)localObject).getInt(R.styleable.FloatingActionButton_fabSize, -1);
    mColor = ((TypedArray)localObject).getDimensionPixelSize(R.styleable.FloatingActionButton_fabCustomSize, 0);
    mBorderWidth = ((TypedArray)localObject).getDimensionPixelSize(R.styleable.FloatingActionButton_borderWidth, 0);
    float f1 = ((TypedArray)localObject).getDimension(R.styleable.FloatingActionButton_elevation, 0.0F);
    float f2 = ((TypedArray)localObject).getDimension(R.styleable.FloatingActionButton_hoveredFocusedTranslationZ, 0.0F);
    float f3 = ((TypedArray)localObject).getDimension(R.styleable.FloatingActionButton_pressedTranslationZ, 0.0F);
    mCompatPadding = ((TypedArray)localObject).getBoolean(R.styleable.FloatingActionButton_useCompatPadding, false);
    h = ((TypedArray)localObject).getDimensionPixelSize(R.styleable.FloatingActionButton_maxImageSize, 0);
    Frame localFrame = Frame.init(paramContext, (TypedArray)localObject, R.styleable.FloatingActionButton_showMotionSpec);
    paramContext = Frame.init(paramContext, (TypedArray)localObject, R.styleable.FloatingActionButton_hideMotionSpec);
    ((TypedArray)localObject).recycle();
    localObject = new AppCompatImageHelper(this);
    mImageHelper = ((AppCompatImageHelper)localObject);
    ((AppCompatImageHelper)localObject).loadFromAttributes(paramAttributeSet, paramInt);
    d = new apache.org.org.core.map.f(this);
    getImpl().setBackgroundDrawable(mBackgroundTint, mBackgroundTintMode, mRippleColor, mBorderWidth);
    getImpl().setElevation(f1);
    getImpl().setPressedTranslationZ(f2);
    getImpl().setBackgroundDrawable(f3);
    getImpl().setBackgroundDrawable(h);
    getImpl().setBackgroundDrawable(localFrame);
    getImpl().setElevation(paramContext);
    setScaleType(ImageView.ScaleType.MATRIX);
  }
  
  private FloatingActionButtonImpl getImpl()
  {
    if (mImpl == null) {
      mImpl = createImpl();
    }
    return mImpl;
  }
  
  public static int getLength(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE)
    {
      if (i != 0)
      {
        if (i == 1073741824) {
          return paramInt2;
        }
        throw new IllegalArgumentException();
      }
      return paramInt1;
    }
    return Math.min(paramInt1, paramInt2);
  }
  
  public boolean add(Rect paramRect)
  {
    if (ViewCompat.get(this))
    {
      paramRect.set(0, 0, getWidth(), getHeight());
      resize(paramRect);
      return true;
    }
    return false;
  }
  
  public final FloatingActionButtonImpl createImpl()
  {
    return new FloatingActionButtonLollipop(this, new c());
  }
  
  public boolean d()
  {
    return d.b();
  }
  
  public void drawableStateChanged()
  {
    super.drawableStateChanged();
    getImpl().setElevation(getDrawableState());
  }
  
  public ColorStateList getBackgroundTintList()
  {
    return mBackgroundTint;
  }
  
  public PorterDuff.Mode getBackgroundTintMode()
  {
    return mBackgroundTintMode;
  }
  
  public float getCompatElevation()
  {
    return getImpl().getElevation();
  }
  
  public float getCompatHoveredFocusedTranslationZ()
  {
    return getImpl().setElevation();
  }
  
  public float getCompatPressedTranslationZ()
  {
    return getImpl().getPadding();
  }
  
  public Drawable getContentBackground()
  {
    return getImpl().getContentBackground();
  }
  
  public int getCustomSize()
  {
    return mColor;
  }
  
  public int getExpandedComponentIdHint()
  {
    return d.c();
  }
  
  public Frame getHideMotionSpec()
  {
    return getImpl().setRippleColor();
  }
  
  public int getRippleColor()
  {
    ColorStateList localColorStateList = mRippleColor;
    if (localColorStateList != null) {
      return localColorStateList.getDefaultColor();
    }
    return 0;
  }
  
  public ColorStateList getRippleColorStateList()
  {
    return mRippleColor;
  }
  
  public Frame getShowMotionSpec()
  {
    return getImpl().setBackgroundTintList();
  }
  
  public int getSize()
  {
    return mSize;
  }
  
  public int getSizeDimension()
  {
    return init(mSize);
  }
  
  public ColorStateList getSupportBackgroundTintList()
  {
    return getBackgroundTintList();
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode()
  {
    return getBackgroundTintMode();
  }
  
  public ColorStateList getSupportImageTintList()
  {
    return mTextColor;
  }
  
  public PorterDuff.Mode getSupportImageTintMode()
  {
    return mType;
  }
  
  public boolean getUseCompatPadding()
  {
    return mCompatPadding;
  }
  
  public void hide(Animator.AnimatorListener paramAnimatorListener)
  {
    getImpl().hide(paramAnimatorListener);
  }
  
  public void hide(b paramB, boolean paramBoolean)
  {
    getImpl().start(wrapOnVisibilityChangedListener(paramB), paramBoolean);
  }
  
  public final int init(int paramInt)
  {
    int i = mColor;
    if (i != 0) {
      return i;
    }
    Resources localResources = getResources();
    if (paramInt != -1)
    {
      if (paramInt != 1) {
        return localResources.getDimensionPixelSize(R.dimen.design_fab_size_normal);
      }
      return localResources.getDimensionPixelSize(R.dimen.design_fab_size_mini);
    }
    if (Math.max(getConfigurationscreenWidthDp, getConfigurationscreenHeightDp) < 470) {
      return init(1);
    }
    return init(0);
  }
  
  public final void init()
  {
    Drawable localDrawable = getDrawable();
    if (localDrawable == null) {
      return;
    }
    Object localObject = mTextColor;
    if (localObject == null)
    {
      org.core.asm.signature.DrawableCompat.canSafelyMutateDrawable(localDrawable);
      return;
    }
    int i = ((ColorStateList)localObject).getColorForState(getDrawableState(), 0);
    PorterDuff.Mode localMode = mType;
    localObject = localMode;
    if (localMode == null) {
      localObject = PorterDuff.Mode.SRC_IN;
    }
    localDrawable.mutate().setColorFilter(org.v7.widget.Context.get(i, (PorterDuff.Mode)localObject));
  }
  
  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    getImpl().jumpDrawableToCurrentState();
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    getImpl().onAttachedToWindow();
  }
  
  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    getImpl().onDetachedFromWindow();
  }
  
  public void onMeasure(int paramInt1, int paramInt2)
  {
    int i = getSizeDimension();
    mContentPadding = ((i - h) / 2);
    getImpl().updatePadding();
    paramInt1 = Math.min(getLength(i, paramInt1), getLength(i, paramInt2));
    Rect localRect = this$0;
    setMeasuredDimension(left + paramInt1 + right, top + paramInt1 + bottom);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof Label))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (Label)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.next());
    d.b((Bundle)a.get("expandableWidgetHelper"));
  }
  
  public Parcelable onSaveInstanceState()
  {
    Label localLabel = new Label(super.onSaveInstanceState());
    a.put("expandableWidgetHelper", d.a());
    return localLabel;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if ((paramMotionEvent.getAction() == 0) && (add(TAG)) && (!TAG.contains((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()))) {
      return false;
    }
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public final void resize(Rect paramRect)
  {
    int i = left;
    Rect localRect = this$0;
    left = (i + left);
    top += top;
    right -= right;
    bottom -= bottom;
  }
  
  public void scrollTo(Rect paramRect)
  {
    paramRect.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
    resize(paramRect);
  }
  
  public void setBackgroundColor(int paramInt)
  {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundDrawable(Animator.AnimatorListener paramAnimatorListener)
  {
    getImpl().setBackgroundDrawable(paramAnimatorListener);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundResource(int paramInt)
  {
    Log.i("FloatingActionButton", "Setting a custom background is not supported.");
  }
  
  public void setBackgroundTintList(ColorStateList paramColorStateList)
  {
    if (mBackgroundTint != paramColorStateList)
    {
      mBackgroundTint = paramColorStateList;
      getImpl().setBackgroundTintList(paramColorStateList);
    }
  }
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    if (mBackgroundTintMode != paramMode)
    {
      mBackgroundTintMode = paramMode;
      getImpl().setBackgroundTintMode(paramMode);
    }
  }
  
  public void setCompatElevation(float paramFloat)
  {
    getImpl().setElevation(paramFloat);
  }
  
  public void setCompatElevationResource(int paramInt)
  {
    setCompatElevation(getResources().getDimension(paramInt));
  }
  
  public void setCompatHoveredFocusedTranslationZ(float paramFloat)
  {
    getImpl().setPressedTranslationZ(paramFloat);
  }
  
  public void setCompatHoveredFocusedTranslationZResource(int paramInt)
  {
    setCompatHoveredFocusedTranslationZ(getResources().getDimension(paramInt));
  }
  
  public void setCompatPressedTranslationZ(float paramFloat)
  {
    getImpl().setBackgroundDrawable(paramFloat);
  }
  
  public void setCompatPressedTranslationZResource(int paramInt)
  {
    setCompatPressedTranslationZ(getResources().getDimension(paramInt));
  }
  
  public void setCustomSize(int paramInt)
  {
    if (paramInt >= 0)
    {
      mColor = paramInt;
      return;
    }
    throw new IllegalArgumentException("Custom size must be non-negative");
  }
  
  public void setExpandedComponentIdHint(int paramInt)
  {
    d.c(paramInt);
  }
  
  public void setHideMotionSpec(Frame paramFrame)
  {
    getImpl().setElevation(paramFrame);
  }
  
  public void setHideMotionSpecResource(int paramInt)
  {
    setHideMotionSpec(Frame.start(getContext(), paramInt));
  }
  
  public void setImageDrawable(Drawable paramDrawable)
  {
    super.setImageDrawable(paramDrawable);
    getImpl().setBackgroundDrawable();
  }
  
  public void setImageResource(int paramInt)
  {
    mImageHelper.setImageResource(paramInt);
  }
  
  public void setRippleColor(int paramInt)
  {
    setRippleColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setRippleColor(ColorStateList paramColorStateList)
  {
    if (mRippleColor != paramColorStateList)
    {
      mRippleColor = paramColorStateList;
      getImpl().setRippleColor(mRippleColor);
    }
  }
  
  public void setShowMotionSpec(Frame paramFrame)
  {
    getImpl().setBackgroundDrawable(paramFrame);
  }
  
  public void setShowMotionSpecResource(int paramInt)
  {
    setShowMotionSpec(Frame.start(getContext(), paramInt));
  }
  
  public void setSize(int paramInt)
  {
    mColor = 0;
    if (paramInt != mSize)
    {
      mSize = paramInt;
      requestLayout();
    }
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList)
  {
    setBackgroundTintList(paramColorStateList);
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode)
  {
    setBackgroundTintMode(paramMode);
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList)
  {
    if (mTextColor != paramColorStateList)
    {
      mTextColor = paramColorStateList;
      init();
    }
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode)
  {
    if (mType != paramMode)
    {
      mType = paramMode;
      init();
    }
  }
  
  public void setUseCompatPadding(boolean paramBoolean)
  {
    if (mCompatPadding != paramBoolean)
    {
      mCompatPadding = paramBoolean;
      getImpl().onCompatShadowChanged();
    }
  }
  
  public void show(Animator.AnimatorListener paramAnimatorListener)
  {
    getImpl().onAnimationEnd(paramAnimatorListener);
  }
  
  public void show(b paramB, boolean paramBoolean)
  {
    getImpl().show(wrapOnVisibilityChangedListener(paramB), paramBoolean);
  }
  
  public boolean show()
  {
    return getImpl().show();
  }
  
  public void toggle(Animator.AnimatorListener paramAnimatorListener)
  {
    getImpl().show(paramAnimatorListener);
  }
  
  public final FloatingActionButtonImpl.InternalVisibilityChangedListener wrapOnVisibilityChangedListener(b paramB)
  {
    if (paramB == null) {
      return null;
    }
    return new a();
  }
  
  public static class BaseBehavior<T extends FloatingActionButton>
    extends CoordinatorLayout.c<T>
  {
    public boolean mNotificationsEnabled;
    public Rect mTmpRect;
    
    public BaseBehavior()
    {
      mNotificationsEnabled = true;
    }
    
    public BaseBehavior(android.content.Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.FloatingActionButton_Behavior_Layout);
      mNotificationsEnabled = paramContext.getBoolean(R.styleable.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
      paramContext.recycle();
    }
    
    public static boolean updateOffset(View paramView)
    {
      paramView = paramView.getLayoutParams();
      if ((paramView instanceof CoordinatorLayout.f)) {
        return ((CoordinatorLayout.f)paramView).getBehavior() instanceof BottomSheetBehavior;
      }
      return false;
    }
    
    public void b(CoordinatorLayout.f paramF)
    {
      if (top == 0) {
        top = 80;
      }
    }
    
    public final void offsetIfNeeded(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton)
    {
      Rect localRect = this$0;
      if ((localRect != null) && (localRect.centerX() > 0) && (localRect.centerY() > 0))
      {
        CoordinatorLayout.f localF = (CoordinatorLayout.f)paramFloatingActionButton.getLayoutParams();
        int j = 0;
        int i = 0;
        if (paramFloatingActionButton.getRight() >= paramCoordinatorLayout.getWidth() - rightMargin) {
          i = right;
        } else if (paramFloatingActionButton.getLeft() <= leftMargin) {
          i = -left;
        }
        if (paramFloatingActionButton.getBottom() >= paramCoordinatorLayout.getHeight() - bottomMargin) {
          j = bottom;
        } else if (paramFloatingActionButton.getTop() <= topMargin) {
          j = -top;
        }
        if (j != 0) {
          ViewCompat.offsetTopAndBottom(paramFloatingActionButton, j);
        }
        if (i != 0) {
          ViewCompat.offsetLeftAndRight(paramFloatingActionButton, i);
        }
      }
    }
    
    public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton, View paramView)
    {
      if ((paramView instanceof AppBarLayout)) {
        updateFabVisibility(paramCoordinatorLayout, (AppBarLayout)paramView, paramFloatingActionButton);
      } else if (updateOffset(paramView)) {
        onLayoutChild(paramView, paramFloatingActionButton);
      }
      return false;
    }
    
    public boolean onDependentViewChanged(FloatingActionButton paramFloatingActionButton, Rect paramRect)
    {
      Rect localRect = this$0;
      paramRect.set(paramFloatingActionButton.getLeft() + left, paramFloatingActionButton.getTop() + top, paramFloatingActionButton.getRight() - right, paramFloatingActionButton.getBottom() - bottom);
      return true;
    }
    
    public final boolean onLayoutChild(View paramView, FloatingActionButton paramFloatingActionButton)
    {
      if (!updateFabVisibility(paramView, paramFloatingActionButton)) {
        return false;
      }
      CoordinatorLayout.f localF = (CoordinatorLayout.f)paramFloatingActionButton.getLayoutParams();
      if (paramView.getTop() < paramFloatingActionButton.getHeight() / 2 + topMargin) {
        paramFloatingActionButton.hide(null, false);
      } else {
        paramFloatingActionButton.show(null, false);
      }
      return true;
    }
    
    public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, FloatingActionButton paramFloatingActionButton, int paramInt)
    {
      List localList = paramCoordinatorLayout.getDependencies(paramFloatingActionButton);
      int i = 0;
      int j = localList.size();
      while (i < j)
      {
        View localView = (View)localList.get(i);
        if ((localView instanceof AppBarLayout) ? !updateFabVisibility(paramCoordinatorLayout, (AppBarLayout)localView, paramFloatingActionButton) : (updateOffset(localView)) && (onLayoutChild(localView, paramFloatingActionButton))) {
          break;
        }
        i += 1;
      }
      paramCoordinatorLayout.onLayoutChild(paramFloatingActionButton, paramInt);
      offsetIfNeeded(paramCoordinatorLayout, paramFloatingActionButton);
      return true;
    }
    
    public final boolean updateFabVisibility(View paramView, FloatingActionButton paramFloatingActionButton)
    {
      CoordinatorLayout.f localF = (CoordinatorLayout.f)paramFloatingActionButton.getLayoutParams();
      if (!mNotificationsEnabled) {
        return false;
      }
      if (localF.getAnchorId() != paramView.getId()) {
        return false;
      }
      return paramFloatingActionButton.getUserSetVisibility() == 0;
    }
    
    public final boolean updateFabVisibility(CoordinatorLayout paramCoordinatorLayout, AppBarLayout paramAppBarLayout, FloatingActionButton paramFloatingActionButton)
    {
      if (!updateFabVisibility(paramAppBarLayout, paramFloatingActionButton)) {
        return false;
      }
      if (mTmpRect == null) {
        mTmpRect = new Rect();
      }
      Rect localRect = mTmpRect;
      ViewGroupUtilsHoneycomb.getDescendantRect(paramCoordinatorLayout, paramAppBarLayout, localRect);
      if (bottom <= paramAppBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
        paramFloatingActionButton.hide(null, false);
      } else {
        paramFloatingActionButton.show(null, false);
      }
      return true;
    }
  }
  
  public static class Behavior
    extends FloatingActionButton.BaseBehavior<FloatingActionButton>
  {
    public Behavior() {}
    
    public Behavior(android.content.Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
  }
  
  public class a
    implements FloatingActionButtonImpl.InternalVisibilityChangedListener
  {
    public a() {}
    
    public void getSimpleName()
    {
      throw new NullPointerException("Null throw statement replaced by Soot");
    }
    
    public void invoke()
    {
      throw new NullPointerException("Null throw statement replaced by Soot");
    }
  }
  
  public static abstract class b {}
  
  public class c
    implements ShadowViewDelegate
  {
    public c() {}
    
    public float getRadius()
    {
      return getSizeDimension() / 2.0F;
    }
    
    public void setBackgroundDrawable(Drawable paramDrawable)
    {
      FloatingActionButton.access$getSetBackgroundDrawable(FloatingActionButton.this, paramDrawable);
    }
    
    public boolean setBackgroundDrawable()
    {
      return mCompatPadding;
    }
    
    public void setShadowPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      this$0.set(paramInt1, paramInt2, paramInt3, paramInt4);
      FloatingActionButton localFloatingActionButton = FloatingActionButton.this;
      localFloatingActionButton.setPadding(FloatingActionButton.access$getMContentPadding(localFloatingActionButton) + paramInt1, FloatingActionButton.access$getMContentPadding(FloatingActionButton.this) + paramInt2, FloatingActionButton.access$getMContentPadding(FloatingActionButton.this) + paramInt3, FloatingActionButton.access$getMContentPadding(FloatingActionButton.this) + paramInt4);
    }
  }
}
