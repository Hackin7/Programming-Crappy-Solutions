package com.airbnb.lottie;

import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.AbsSavedState;
import android.view.View;
import android.view.View.BaseSavedState;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import apache.codehaus.asm.AnnotationVisitor;
import apache.codehaus.asm.Attribute;
import apache.codehaus.asm.Button;
import apache.codehaus.asm.Channel;
import apache.codehaus.asm.ClassWriter;
import apache.codehaus.asm.MethodVisitor;
import apache.codehaus.asm.Plot.RenderMode;
import apache.codehaus.asm.R.styleable;
import apache.codehaus.asm.f;
import apache.codehaus.asm.l;
import apache.codehaus.asm.o;
import apache.codehaus.asm.util.Log;
import apache.codehaus.asm.util.i;
import b.a.a.j;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.core.view.ViewCompat;
import org.v7.widget.AppCompatImageView;

public class LottieAnimationView
  extends AppCompatImageView
{
  public static final String FLOAT = LottieAnimationView.class.getSimpleName();
  public static final b.a.a.h<Throwable> gui = new a();
  public Set<j> B = new HashSet();
  public apache.codehaus.asm.h a;
  public String b;
  public int beta = 0;
  public final apache.codehaus.asm.Label d = new apache.codehaus.asm.Label();
  public boolean h = true;
  public int i;
  public Plot.RenderMode k = Plot.RenderMode.USE_BACKGROUND_THREAD;
  public boolean l;
  public final b.a.a.h<Throwable> mContext = new c();
  public b.a.a.h<Throwable> mLog;
  public int mProgress = 0;
  public final b.a.a.h<b.a.a.d> nativePtr = new b();
  public boolean p = false;
  public boolean r = false;
  public boolean s = false;
  public boolean t = false;
  public b.a.a.m<b.a.a.d> this$0;
  
  public LottieAnimationView(android.content.Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramAttributeSet);
  }
  
  private void setCompositionTask(Channel paramChannel)
  {
    visitMaxs();
    init();
    paramChannel.close(nativePtr);
    paramChannel.write(mContext);
    this$0 = paramChannel;
  }
  
  public void a()
  {
    p = false;
    r = false;
    t = false;
    s = false;
    d.setColor();
    b();
  }
  
  public final void a(AttributeSet paramAttributeSet)
  {
    paramAttributeSet = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.LottieAnimationView);
    boolean bool2 = isInEditMode();
    boolean bool1 = false;
    int j;
    Object localObject1;
    if (!bool2)
    {
      h = paramAttributeSet.getBoolean(R.styleable.LottieAnimationView_lottie_cacheComposition, true);
      bool2 = paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_rawRes);
      boolean bool3 = paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_fileName);
      boolean bool4 = paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_url);
      if ((bool2) && (bool3)) {
        throw new IllegalArgumentException("lottie_rawRes and lottie_fileName cannot be used at the same time. Please use only one at once.");
      }
      if (bool2)
      {
        j = paramAttributeSet.getResourceId(R.styleable.LottieAnimationView_lottie_rawRes, 0);
        if (j != 0) {
          setAnimation(j);
        }
      }
      else if (bool3)
      {
        localObject1 = paramAttributeSet.getString(R.styleable.LottieAnimationView_lottie_fileName);
        if (localObject1 != null) {
          setAnimation((String)localObject1);
        }
      }
      else if (bool4)
      {
        localObject1 = paramAttributeSet.getString(R.styleable.LottieAnimationView_lottie_url);
        if (localObject1 != null) {
          setAnimationFromUrl((String)localObject1);
        }
      }
      setFallbackResource(paramAttributeSet.getResourceId(R.styleable.LottieAnimationView_lottie_fallbackRes, 0));
    }
    if (paramAttributeSet.getBoolean(R.styleable.LottieAnimationView_lottie_autoPlay, false))
    {
      r = true;
      p = true;
    }
    if (paramAttributeSet.getBoolean(R.styleable.LottieAnimationView_lottie_loop, false)) {
      d.setColor(-1);
    }
    if (paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_repeatMode)) {
      setRepeatMode(paramAttributeSet.getInt(R.styleable.LottieAnimationView_lottie_repeatMode, 1));
    }
    if (paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_repeatCount)) {
      setRepeatCount(paramAttributeSet.getInt(R.styleable.LottieAnimationView_lottie_repeatCount, -1));
    }
    if (paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_speed)) {
      setSpeed(paramAttributeSet.getFloat(R.styleable.LottieAnimationView_lottie_speed, 1.0F));
    }
    setImageAssetsFolder(paramAttributeSet.getString(R.styleable.LottieAnimationView_lottie_imageAssetsFolder));
    setProgress(paramAttributeSet.getFloat(R.styleable.LottieAnimationView_lottie_progress, 0.0F));
    b(paramAttributeSet.getBoolean(R.styleable.LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove, false));
    if (paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_colorFilter))
    {
      Object localObject2 = new o(paramAttributeSet.getColor(R.styleable.LottieAnimationView_lottie_colorFilter, 0));
      localObject1 = new apache.codehaus.asm.params.Label(new String[] { "**" });
      localObject2 = new apache.codehaus.asm.manager.d(localObject2);
      a((apache.codehaus.asm.params.Label)localObject1, ClassWriter.C, (apache.codehaus.asm.manager.d)localObject2);
    }
    if (paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_scale)) {
      d.setText(paramAttributeSet.getFloat(R.styleable.LottieAnimationView_lottie_scale, 1.0F));
    }
    if (paramAttributeSet.hasValue(R.styleable.LottieAnimationView_lottie_renderMode))
    {
      j = R.styleable.LottieAnimationView_lottie_renderMode;
      localObject1 = Plot.RenderMode.USE_BACKGROUND_THREAD;
      int m = paramAttributeSet.getInt(j, 0);
      j = m;
      if (m >= Plot.RenderMode.values().length)
      {
        localObject1 = Plot.RenderMode.USE_BACKGROUND_THREAD;
        j = 0;
      }
      setRenderMode(Plot.RenderMode.values()[j]);
    }
    if (getScaleType() != null) {
      d.b(getScaleType());
    }
    paramAttributeSet.recycle();
    paramAttributeSet = d;
    if (i.get(getContext()) != 0.0F) {
      bool1 = true;
    }
    paramAttributeSet.a(Boolean.valueOf(bool1));
    b();
    l = true;
  }
  
  public void a(apache.codehaus.asm.params.Label paramLabel, Object paramObject, apache.codehaus.asm.manager.d paramD)
  {
    d.a(paramLabel, paramObject, paramD);
  }
  
  public final void b()
  {
    int j = 1;
    int n = k.ordinal();
    int m = 2;
    if (n != 0)
    {
      if (n != 1)
      {
        if (n == 2) {
          j = 1;
        }
      }
      else {
        j = 2;
      }
    }
    else
    {
      n = 1;
      apache.codehaus.asm.h localH = a;
      if ((localH != null) && (localH.k()) && (Build.VERSION.SDK_INT < 28))
      {
        j = 0;
      }
      else
      {
        localH = a;
        j = n;
        if (localH != null)
        {
          j = n;
          if (localH.l() > 4) {
            j = 0;
          }
        }
      }
      if (j != 0) {
        j = m;
      } else {
        j = 1;
      }
    }
    if (j != getLayerType()) {
      setLayerType(j, null);
    }
  }
  
  public void b(boolean paramBoolean)
  {
    d.a(paramBoolean);
  }
  
  public void buildDrawingCache(boolean paramBoolean)
  {
    l.append("buildDrawingCache");
    beta += 1;
    super.buildDrawingCache(paramBoolean);
    if ((beta == 1) && (getWidth() > 0) && (getHeight() > 0) && (getLayerType() == 1) && (getDrawingCache(paramBoolean) == null)) {
      setRenderMode(Plot.RenderMode.USE_MAIN_THREAD);
    }
    beta -= 1;
    l.a("buildDrawingCache");
  }
  
  public void close(InputStream paramInputStream, String paramString)
  {
    setCompositionTask(f.add(paramInputStream, paramString));
  }
  
  public void d()
  {
    r = false;
    t = false;
    s = false;
    d.show();
    b();
  }
  
  public boolean draw()
  {
    return d.equals();
  }
  
  public void e()
  {
    if (isShown())
    {
      d.set();
      b();
      return;
    }
    s = true;
  }
  
  public apache.codehaus.asm.h getComposition()
  {
    return a;
  }
  
  public long getDuration()
  {
    apache.codehaus.asm.h localH = a;
    if (localH != null) {
      return localH.get();
    }
    return 0L;
  }
  
  public int getFrame()
  {
    return d.getCount();
  }
  
  public String getImageAssetsFolder()
  {
    return d.getColor();
  }
  
  public float getMaxFrame()
  {
    return d.put();
  }
  
  public float getMinFrame()
  {
    return d.setText();
  }
  
  public apache.codehaus.asm.m getPerformanceTracker()
  {
    return d.c();
  }
  
  public float getProgress()
  {
    return d.add();
  }
  
  public int getRepeatCount()
  {
    return d.getText();
  }
  
  public int getRepeatMode()
  {
    return d.getRepeatMode();
  }
  
  public float getScale()
  {
    return d.getValue();
  }
  
  public float getSpeed()
  {
    return d.get();
  }
  
  public final void init()
  {
    Channel localChannel = this$0;
    if (localChannel != null)
    {
      localChannel.open(nativePtr);
      this$0.read(mContext);
    }
  }
  
  public void invalidateDrawable(Drawable paramDrawable)
  {
    Drawable localDrawable = getDrawable();
    apache.codehaus.asm.Label localLabel = d;
    if (localDrawable == localLabel)
    {
      super.invalidateDrawable(localLabel);
      return;
    }
    super.invalidateDrawable(paramDrawable);
  }
  
  public void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    if ((p) || (r))
    {
      e();
      p = false;
      r = false;
    }
    if (Build.VERSION.SDK_INT < 23) {
      onVisibilityChanged(this, getVisibility());
    }
  }
  
  public void onDetachedFromWindow()
  {
    if (draw())
    {
      d();
      r = true;
    }
    super.onDetachedFromWindow();
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof d))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (d)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    String str = c;
    b = str;
    if (!TextUtils.isEmpty(str)) {
      setAnimation(b);
    }
    int j = a;
    i = j;
    if (j != 0) {
      setAnimation(j);
    }
    setProgress(b);
    if (e) {
      e();
    }
    d.setText(d);
    setRepeatMode(rimColor);
    setRepeatCount(circleRadius);
  }
  
  public Parcelable onSaveInstanceState()
  {
    d localD = new d(super.onSaveInstanceState());
    c = b;
    a = i;
    b = d.add();
    boolean bool;
    if ((!d.equals()) && ((ViewCompat.isAttachedToWindow(this)) || (!r))) {
      bool = false;
    } else {
      bool = true;
    }
    e = bool;
    d = d.getColor();
    rimColor = d.getRepeatMode();
    circleRadius = d.getText();
    return localD;
  }
  
  public void onVisibilityChanged(View paramView, int paramInt)
  {
    if (!l) {
      return;
    }
    if (isShown())
    {
      if (t) {
        p();
      } else if (s) {
        e();
      }
      t = false;
      s = false;
      return;
    }
    if (draw())
    {
      a();
      t = true;
    }
  }
  
  public void p()
  {
    if (isShown())
    {
      d.a();
      b();
      return;
    }
    s = false;
    t = true;
  }
  
  public void putRemoteFile(String paramString1, String paramString2)
  {
    close(new ByteArrayInputStream(paramString1.getBytes()), paramString2);
  }
  
  public void setAnimation(int paramInt)
  {
    i = paramInt;
    b = null;
    Channel localChannel;
    if (h) {
      localChannel = f.a(getContext(), paramInt);
    } else {
      localChannel = f.a(getContext(), paramInt, null);
    }
    setCompositionTask(localChannel);
  }
  
  public void setAnimation(String paramString)
  {
    b = paramString;
    i = 0;
    if (h) {
      paramString = f.a(getContext(), paramString);
    } else {
      paramString = f.b(getContext(), paramString, null);
    }
    setCompositionTask(paramString);
  }
  
  public void setAnimationFromJson(String paramString)
  {
    putRemoteFile(paramString, null);
  }
  
  public void setAnimationFromUrl(String paramString)
  {
    if (h) {
      paramString = f.d(getContext(), paramString);
    } else {
      paramString = f.d(getContext(), paramString, null);
    }
    setCompositionTask(paramString);
  }
  
  public void setApplyingOpacityToLayersEnabled(boolean paramBoolean)
  {
    d.setText(paramBoolean);
  }
  
  public void setCacheComposition(boolean paramBoolean)
  {
    h = paramBoolean;
  }
  
  public void setComposition(apache.codehaus.asm.h paramH)
  {
    d.setCallback(this);
    a = paramH;
    boolean bool = d.a(paramH);
    b();
    if ((getDrawable() == d) && (!bool)) {
      return;
    }
    onVisibilityChanged(this, getVisibility());
    requestLayout();
    Iterator localIterator = B.iterator();
    while (localIterator.hasNext()) {
      ((AnnotationVisitor)localIterator.next()).visit(paramH);
    }
  }
  
  public void setFailureListener(apache.codehaus.asm.Context paramContext)
  {
    mLog = paramContext;
  }
  
  public void setFallbackResource(int paramInt)
  {
    mProgress = paramInt;
  }
  
  public void setFontAssetDelegate(Button paramButton)
  {
    d.a(paramButton);
  }
  
  public void setFrame(int paramInt)
  {
    d.add(paramInt);
  }
  
  public void setImageAssetDelegate(MethodVisitor paramMethodVisitor)
  {
    d.b(paramMethodVisitor);
  }
  
  public void setImageAssetsFolder(String paramString)
  {
    d.setText(paramString);
  }
  
  public void setImageBitmap(Bitmap paramBitmap)
  {
    init();
    super.setImageBitmap(paramBitmap);
  }
  
  public void setImageDrawable(Drawable paramDrawable)
  {
    init();
    super.setImageDrawable(paramDrawable);
  }
  
  public void setImageResource(int paramInt)
  {
    init();
    super.setImageResource(paramInt);
  }
  
  public void setMaxFrame(int paramInt)
  {
    d.a(paramInt);
  }
  
  public void setMaxFrame(String paramString)
  {
    d.b(paramString);
  }
  
  public void setMaxProgress(float paramFloat)
  {
    d.b(paramFloat);
  }
  
  public void setMinAndMaxFrame(String paramString)
  {
    d.a(paramString);
  }
  
  public void setMinFrame(int paramInt)
  {
    d.put(paramInt);
  }
  
  public void setMinFrame(String paramString)
  {
    d.add(paramString);
  }
  
  public void setMinProgress(float paramFloat)
  {
    d.set(paramFloat);
  }
  
  public void setPerformanceTrackingEnabled(boolean paramBoolean)
  {
    d.b(paramBoolean);
  }
  
  public void setProgress(float paramFloat)
  {
    d.a(paramFloat);
  }
  
  public void setRenderMode(Plot.RenderMode paramRenderMode)
  {
    k = paramRenderMode;
    b();
  }
  
  public void setRepeatCount(int paramInt)
  {
    d.setColor(paramInt);
  }
  
  public void setRepeatMode(int paramInt)
  {
    d.setText(paramInt);
  }
  
  public void setSafeMode(boolean paramBoolean)
  {
    d.setColor(paramBoolean);
  }
  
  public void setScale(float paramFloat)
  {
    d.setText(paramFloat);
    if (getDrawable() == d)
    {
      setImageDrawable(null);
      setImageDrawable(d);
    }
  }
  
  public void setScaleType(ImageView.ScaleType paramScaleType)
  {
    super.setScaleType(paramScaleType);
    apache.codehaus.asm.Label localLabel = d;
    if (localLabel != null) {
      localLabel.b(paramScaleType);
    }
  }
  
  public void setSpeed(float paramFloat)
  {
    d.put(paramFloat);
  }
  
  public void setTextDelegate(Attribute paramAttribute)
  {
    d.b(paramAttribute);
  }
  
  public final void visitMaxs()
  {
    a = null;
    d.onCreate();
  }
  
  public class a
    implements b.a.a.h<Throwable>
  {
    public a() {}
    
    public void d(Throwable paramThrowable)
    {
      if (i.b(paramThrowable))
      {
        Log.d("Unable to load composition.", paramThrowable);
        return;
      }
      throw new IllegalStateException("Unable to parse composition", paramThrowable);
    }
  }
  
  public class b
    implements b.a.a.h<b.a.a.d>
  {
    public b() {}
    
    public void c(apache.codehaus.asm.h paramH)
    {
      setComposition(paramH);
    }
  }
  
  public class c
    implements b.a.a.h<Throwable>
  {
    public c() {}
    
    public void onPostExecute(Throwable paramThrowable)
    {
      Object localObject;
      if (LottieAnimationView.access$getMProgress(LottieAnimationView.this) != 0)
      {
        localObject = LottieAnimationView.this;
        ((LottieAnimationView)localObject).setImageResource(LottieAnimationView.access$getMProgress((LottieAnimationView)localObject));
      }
      if (LottieAnimationView.access$getMLog(LottieAnimationView.this) == null) {
        localObject = LottieAnimationView.access$getGui();
      } else {
        localObject = LottieAnimationView.access$getMLog(LottieAnimationView.this);
      }
      ((apache.codehaus.asm.Context)localObject).d(paramThrowable);
    }
  }
  
  public static class d
    extends View.BaseSavedState
  {
    public static final Parcelable.Creator<d> CREATOR = new a();
    public int a;
    public float b;
    public String c;
    public int circleRadius;
    public String d;
    public boolean e;
    public int rimColor;
    
    public d(Parcel paramParcel)
    {
      super();
      c = paramParcel.readString();
      b = paramParcel.readFloat();
      int i = paramParcel.readInt();
      boolean bool = true;
      if (i != 1) {
        bool = false;
      }
      e = bool;
      d = paramParcel.readString();
      rimColor = paramParcel.readInt();
      circleRadius = paramParcel.readInt();
    }
    
    public d(Parcelable paramParcelable)
    {
      super();
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      throw new Runtime("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\n");
    }
    
    public class a
      implements Parcelable.Creator<LottieAnimationView.d>
    {
      public a() {}
      
      public LottieAnimationView.d[] a(int paramInt)
      {
        return new LottieAnimationView.d[paramInt];
      }
      
      public LottieAnimationView.d readDate(Parcel paramParcel)
      {
        return new LottieAnimationView.d(paramParcel, null);
      }
    }
  }
}
