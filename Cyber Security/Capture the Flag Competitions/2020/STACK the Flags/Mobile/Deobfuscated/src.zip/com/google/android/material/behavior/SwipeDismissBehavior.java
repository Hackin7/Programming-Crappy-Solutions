package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.c;
import org.client.widget.ViewDragHelper;
import org.client.widget.ViewDragHelper.Callback;
import org.core.view.ViewCompat;

public class SwipeDismissBehavior<V extends View>
  extends CoordinatorLayout.c<V>
{
  public float mAlphaEndSwipeDistance = 0.5F;
  public float mAlphaStartSwipeDistance = 0.0F;
  public final ViewDragHelper.Callback mDragCallback = new a();
  public float mDragDismissThreshold = 0.5F;
  public boolean mIgnoreEvents;
  public float mSensitivity = 0.0F;
  public int mSwipeDirection = 2;
  public ViewDragHelper mViewDragHelper;
  public b this$0;
  
  public SwipeDismissBehavior() {}
  
  public static int access$400(int paramInt1, int paramInt2, int paramInt3)
  {
    return Math.min(Math.max(paramInt1, paramInt2), paramInt3);
  }
  
  public static float clamp(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return Math.min(Math.max(paramFloat1, paramFloat2), paramFloat3);
  }
  
  public static float fraction(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return (paramFloat3 - paramFloat1) / (paramFloat2 - paramFloat1);
  }
  
  public boolean b(View paramView)
  {
    return true;
  }
  
  public final void ensureViewDragHelper(ViewGroup paramViewGroup)
  {
    if (mViewDragHelper == null) {
      mViewDragHelper = ViewDragHelper.create(paramViewGroup, mDragCallback);
    }
  }
  
  public boolean onInterceptTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
  {
    boolean bool = mIgnoreEvents;
    int i = paramMotionEvent.getActionMasked();
    if (i != 0)
    {
      if ((i == 1) || (i == 3)) {
        mIgnoreEvents = false;
      }
    }
    else
    {
      mIgnoreEvents = paramCoordinatorLayout.isPointInChildBounds(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      bool = mIgnoreEvents;
    }
    if (bool)
    {
      ensureViewDragHelper(paramCoordinatorLayout);
      return mViewDragHelper.shouldInterceptTouchEvent(paramMotionEvent);
    }
    return false;
  }
  
  public boolean onTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
  {
    paramCoordinatorLayout = mViewDragHelper;
    if (paramCoordinatorLayout != null)
    {
      paramCoordinatorLayout.processTouchEvent(paramMotionEvent);
      return true;
    }
    return false;
  }
  
  public void setEndAlphaSwipeDistance(float paramFloat)
  {
    mAlphaEndSwipeDistance = clamp(0.0F, paramFloat, 1.0F);
  }
  
  public void setListener(int paramInt)
  {
    mSwipeDirection = paramInt;
  }
  
  public void setStartAlphaSwipeDistance(float paramFloat)
  {
    mAlphaStartSwipeDistance = clamp(0.0F, paramFloat, 1.0F);
  }
  
  public class a
    extends ViewDragHelper.Callback
  {
    public int mActivePointerId = -1;
    public int mOriginalCapturedViewLeft;
    
    public a() {}
    
    public int clampViewPositionHorizontal(View paramView, int paramInt1, int paramInt2)
    {
      if (ViewCompat.getLayoutDirection(paramView) == 1) {
        paramInt2 = 1;
      } else {
        paramInt2 = 0;
      }
      int i = mSwipeDirection;
      if (i == 0)
      {
        if (paramInt2 != 0)
        {
          i = mOriginalCapturedViewLeft - paramView.getWidth();
          paramInt2 = mOriginalCapturedViewLeft;
        }
        else
        {
          i = mOriginalCapturedViewLeft;
          paramInt2 = mOriginalCapturedViewLeft + paramView.getWidth();
        }
      }
      else if (i == 1)
      {
        if (paramInt2 != 0)
        {
          i = mOriginalCapturedViewLeft;
          paramInt2 = mOriginalCapturedViewLeft + paramView.getWidth();
        }
        else
        {
          i = mOriginalCapturedViewLeft - paramView.getWidth();
          paramInt2 = mOriginalCapturedViewLeft;
        }
      }
      else
      {
        i = mOriginalCapturedViewLeft - paramView.getWidth();
        paramInt2 = mOriginalCapturedViewLeft + paramView.getWidth();
      }
      return SwipeDismissBehavior.access$400(i, paramInt1, paramInt2);
    }
    
    public int clampViewPositionVertical(View paramView, int paramInt1, int paramInt2)
    {
      return paramView.getTop();
    }
    
    public int getViewHorizontalDragRange(View paramView)
    {
      return paramView.getWidth();
    }
    
    public void onViewCaptured(View paramView, int paramInt)
    {
      mActivePointerId = paramInt;
      mOriginalCapturedViewLeft = paramView.getLeft();
      paramView = paramView.getParent();
      if (paramView != null) {
        paramView.requestDisallowInterceptTouchEvent(true);
      }
    }
    
    public void onViewDragStateChanged(int paramInt)
    {
      SwipeDismissBehavior.b localB = this$0;
      if (localB != null) {
        localB.setVisibility(paramInt);
      }
    }
    
    public void onViewPositionChanged(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      float f1 = mOriginalCapturedViewLeft + paramView.getWidth() * mAlphaStartSwipeDistance;
      float f2 = mOriginalCapturedViewLeft + paramView.getWidth() * mAlphaEndSwipeDistance;
      if (paramInt1 <= f1)
      {
        paramView.setAlpha(1.0F);
        return;
      }
      if (paramInt1 >= f2)
      {
        paramView.setAlpha(0.0F);
        return;
      }
      paramView.setAlpha(SwipeDismissBehavior.clamp(0.0F, 1.0F - SwipeDismissBehavior.fraction(f1, f2, paramInt1), 1.0F));
    }
    
    public void onViewReleased(View paramView, float paramFloat1, float paramFloat2)
    {
      mActivePointerId = -1;
      int i = paramView.getWidth();
      boolean bool = false;
      if (shouldDismiss(paramView, paramFloat1))
      {
        int j = paramView.getLeft();
        int k = mOriginalCapturedViewLeft;
        if (j < k) {
          i = k - i;
        } else {
          i = k + i;
        }
        bool = true;
      }
      else
      {
        i = mOriginalCapturedViewLeft;
      }
      if (mViewDragHelper.settleCapturedViewAt(i, paramView.getTop()))
      {
        ViewCompat.postOnAnimation(paramView, new SwipeDismissBehavior.c(SwipeDismissBehavior.this, paramView, bool));
        return;
      }
      if (bool)
      {
        SwipeDismissBehavior.b localB = this$0;
        if (localB != null) {
          localB.postOnAnimation(paramView);
        }
      }
    }
    
    public final boolean shouldDismiss(View paramView, float paramFloat)
    {
      int i;
      int j;
      if (paramFloat != 0.0F)
      {
        if (ViewCompat.getLayoutDirection(paramView) == 1) {
          i = 1;
        } else {
          i = 0;
        }
        j = mSwipeDirection;
        if (j == 2) {
          return true;
        }
        if (j == 0)
        {
          if (i != 0 ? paramFloat < 0.0F : paramFloat > 0.0F) {
            return true;
          }
        }
        else if (j == 1)
        {
          if (i != 0 ? paramFloat > 0.0F : paramFloat < 0.0F) {
            return true;
          }
        }
        else {
          return false;
        }
      }
      else
      {
        i = paramView.getLeft();
        j = mOriginalCapturedViewLeft;
        int k = Math.round(paramView.getWidth() * mDragDismissThreshold);
        if (Math.abs(i - j) >= k) {
          return true;
        }
      }
      return false;
    }
    
    public boolean tryCaptureView(View paramView, int paramInt)
    {
      return (mActivePointerId == -1) && (b(paramView));
    }
  }
  
  public static abstract interface b
  {
    public abstract void postOnAnimation(View paramView);
    
    public abstract void setVisibility(int paramInt);
  }
  
  public class c
    implements Runnable
  {
    public final View r;
    public final boolean s;
    
    public c(View paramView, boolean paramBoolean)
    {
      r = paramView;
      s = paramBoolean;
    }
    
    public void run()
    {
      Object localObject = mViewDragHelper;
      if ((localObject != null) && (((ViewDragHelper)localObject).continueSettling(true)))
      {
        ViewCompat.postOnAnimation(r, this);
        return;
      }
      if (s)
      {
        localObject = this$0;
        if (localObject != null) {
          ((SwipeDismissBehavior.b)localObject).postOnAnimation(r);
        }
      }
    }
  }
}
