package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.c;
import apache.org.org.core.map.FloatingActionButton;
import java.util.List;
import org.core.view.ViewCompat;

public abstract class ExpandableBehavior
  extends CoordinatorLayout.c<View>
{
  public int mState = 0;
  
  public ExpandableBehavior() {}
  
  public ExpandableBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }
  
  public final boolean get(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      int i = mState;
      if ((i == 0) || (i == 2)) {
        return true;
      }
    }
    else if (mState == 1)
    {
      return true;
    }
    return false;
  }
  
  public boolean onDependentViewChanged(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2)
  {
    paramCoordinatorLayout = (FloatingActionButton)paramView2;
    if (get(paramCoordinatorLayout.d()))
    {
      int i;
      if (paramCoordinatorLayout.d()) {
        i = 1;
      } else {
        i = 2;
      }
      mState = i;
      return start((View)paramCoordinatorLayout, paramView1, paramCoordinatorLayout.d(), true);
    }
    return false;
  }
  
  public FloatingActionButton onLayoutChild(CoordinatorLayout paramCoordinatorLayout, View paramView)
  {
    List localList = paramCoordinatorLayout.getDependencies(paramView);
    int i = 0;
    int j = localList.size();
    while (i < j)
    {
      View localView = (View)localList.get(i);
      if (get(paramCoordinatorLayout, paramView, localView)) {
        return (FloatingActionButton)localView;
      }
      i += 1;
    }
    return null;
  }
  
  public boolean onLayoutChild(final CoordinatorLayout paramCoordinatorLayout, final View paramView, final int paramInt)
  {
    if (!ViewCompat.get(paramView))
    {
      paramCoordinatorLayout = onLayoutChild(paramCoordinatorLayout, paramView);
      if ((paramCoordinatorLayout != null) && (get(paramCoordinatorLayout.d())))
      {
        if (paramCoordinatorLayout.d()) {
          paramInt = 1;
        } else {
          paramInt = 2;
        }
        mState = paramInt;
        paramInt = mState;
        paramView.getViewTreeObserver().addOnPreDrawListener(new a(paramView, paramInt, paramCoordinatorLayout));
      }
    }
    return false;
  }
  
  public abstract boolean start(View paramView1, View paramView2, boolean paramBoolean1, boolean paramBoolean2);
  
  public class a
    implements ViewTreeObserver.OnPreDrawListener
  {
    public a(View paramView, int paramInt, FloatingActionButton paramFloatingActionButton) {}
    
    public boolean onPreDraw()
    {
      paramView.getViewTreeObserver().removeOnPreDrawListener(this);
      if (ExpandableBehavior.state(ExpandableBehavior.this) == paramInt)
      {
        ExpandableBehavior localExpandableBehavior = ExpandableBehavior.this;
        FloatingActionButton localFloatingActionButton = paramCoordinatorLayout;
        localExpandableBehavior.start((View)localFloatingActionButton, paramView, localFloatingActionButton.d(), false);
      }
      return false;
    }
  }
}
