package com.google.android.material.bottomsheet;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout.c;
import androidx.coordinatorlayout.widget.CoordinatorLayout.f;
import apache.org.org.core.R.dimen;
import apache.org.org.core.R.styleable;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import org.client.params.Item;
import org.client.widget.ViewDragHelper;
import org.client.widget.ViewDragHelper.Callback;
import org.core.encodings.MathUtils;
import org.core.view.ViewCompat;

public class BottomSheetBehavior<V extends View>
  extends CoordinatorLayout.c<V>
{
  public int bottom;
  public int left;
  public int mActivePointerId;
  public c mCallback;
  public final ViewDragHelper.Callback mDragCallback = new b();
  public boolean mHideable = true;
  public boolean mIgnoreEvents;
  public int mInitialY;
  public int mLastNestedScrollDy;
  public int mMaxOffset;
  public float mMaximumVelocity;
  public int mMinOffset;
  public boolean mNestedScrolled;
  public WeakReference<View> mNestedScrollingChildRef;
  public boolean mNoCrossFade;
  public int mParentHeight;
  public int mPeekHeight;
  public int mState = 4;
  public boolean mTouchingScrollingChild;
  public VelocityTracker mVelocityTracker;
  public ViewDragHelper mViewDragHelper;
  public WeakReference<V> mViewRef;
  public int right;
  public Map<View, Integer> state;
  public boolean this$0;
  public boolean top;
  
  public BottomSheetBehavior() {}
  
  public BottomSheetBehavior(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.BottomSheetBehavior_Layout);
    TypedValue localTypedValue = paramAttributeSet.peekValue(R.styleable.BottomSheetBehavior_Layout_behavior_peekHeight);
    if (localTypedValue != null)
    {
      int i = data;
      if (i == -1)
      {
        onLayoutChild(i);
        break label82;
      }
    }
    onLayoutChild(paramAttributeSet.getDimensionPixelSize(R.styleable.BottomSheetBehavior_Layout_behavior_peekHeight, -1));
    label82:
    put(paramAttributeSet.getBoolean(R.styleable.BottomSheetBehavior_Layout_behavior_hideable, false));
    setState(paramAttributeSet.getBoolean(R.styleable.BottomSheetBehavior_Layout_behavior_fitToContents, true));
    setHideable(paramAttributeSet.getBoolean(R.styleable.BottomSheetBehavior_Layout_behavior_skipCollapsed, false));
    paramAttributeSet.recycle();
    mMaximumVelocity = ViewConfiguration.get(paramContext).getScaledMaximumFlingVelocity();
  }
  
  public static BottomSheetBehavior from(View paramView)
  {
    paramView = paramView.getLayoutParams();
    if ((paramView instanceof CoordinatorLayout.f))
    {
      paramView = ((CoordinatorLayout.f)paramView).getBehavior();
      if ((paramView instanceof BottomSheetBehavior)) {
        return (BottomSheetBehavior)paramView;
      }
      throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
    }
    throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
  }
  
  public final void apply(boolean paramBoolean)
  {
    Object localObject = mViewRef;
    if (localObject == null) {
      return;
    }
    localObject = ((View)((WeakReference)localObject).get()).getParent();
    if (!(localObject instanceof CoordinatorLayout)) {
      return;
    }
    localObject = (CoordinatorLayout)localObject;
    int j = ((ViewGroup)localObject).getChildCount();
    if (paramBoolean) {
      if (state == null) {
        state = new HashMap(j);
      } else {
        return;
      }
    }
    int i = 0;
    while (i < j)
    {
      View localView = ((ViewGroup)localObject).getChildAt(i);
      if (localView != mViewRef.get()) {
        if (!paramBoolean)
        {
          Map localMap = state;
          if ((localMap != null) && (localMap.containsKey(localView))) {
            ViewCompat.put(localView, ((Integer)state.get(localView)).intValue());
          }
        }
        else
        {
          state.put(localView, Integer.valueOf(localView.getImportantForAccessibility()));
          ViewCompat.put(localView, 4);
        }
      }
      i += 1;
    }
    if (!paramBoolean) {
      state = null;
    }
  }
  
  public void dispatchOnSlide(int paramInt)
  {
    View localView = (View)mViewRef.get();
    if (localView != null)
    {
      c localC = mCallback;
      if (localC != null)
      {
        int i = mMaxOffset;
        if (paramInt > i)
        {
          localC.onSlide(localView, (i - paramInt) / (mParentHeight - i));
          return;
        }
        localC.onSlide(localView, (i - paramInt) / (i - get()));
      }
    }
  }
  
  public View findScrollingChild(View paramView)
  {
    if (ViewCompat.isNestedScrollingEnabled(paramView)) {
      return paramView;
    }
    if ((paramView instanceof ViewGroup))
    {
      paramView = (ViewGroup)paramView;
      int i = 0;
      int j = paramView.getChildCount();
      while (i < j)
      {
        View localView = findScrollingChild(paramView.getChildAt(i));
        if (localView != null) {
          return localView;
        }
        i += 1;
      }
    }
    return null;
  }
  
  public final int get()
  {
    if (mHideable) {
      return left;
    }
    return 0;
  }
  
  public final int getState()
  {
    return mState;
  }
  
  public final float getYVelocity()
  {
    VelocityTracker localVelocityTracker = mVelocityTracker;
    if (localVelocityTracker == null) {
      return 0.0F;
    }
    localVelocityTracker.computeCurrentVelocity(1000, mMaximumVelocity);
    return mVelocityTracker.getYVelocity(mActivePointerId);
  }
  
  public boolean onInterceptTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
  {
    if (!paramView.isShown())
    {
      mIgnoreEvents = true;
      return false;
    }
    int i = paramMotionEvent.getActionMasked();
    if (i == 0) {
      reset();
    }
    if (mVelocityTracker == null) {
      mVelocityTracker = VelocityTracker.obtain();
    }
    mVelocityTracker.addMovement(paramMotionEvent);
    Object localObject2 = null;
    if (i != 0)
    {
      if ((i == 1) || (i == 3))
      {
        mTouchingScrollingChild = false;
        mActivePointerId = -1;
        if (mIgnoreEvents)
        {
          mIgnoreEvents = false;
          return false;
        }
      }
    }
    else
    {
      int j = (int)paramMotionEvent.getX();
      mInitialY = ((int)paramMotionEvent.getY());
      localObject1 = mNestedScrollingChildRef;
      if (localObject1 != null) {
        localObject1 = (View)((WeakReference)localObject1).get();
      } else {
        localObject1 = null;
      }
      if ((localObject1 != null) && (paramCoordinatorLayout.isPointInChildBounds((View)localObject1, j, mInitialY)))
      {
        mActivePointerId = paramMotionEvent.getPointerId(paramMotionEvent.getActionIndex());
        mTouchingScrollingChild = true;
      }
      boolean bool;
      if ((mActivePointerId == -1) && (!paramCoordinatorLayout.isPointInChildBounds(paramView, j, mInitialY))) {
        bool = true;
      } else {
        bool = false;
      }
      mIgnoreEvents = bool;
    }
    if (!mIgnoreEvents)
    {
      paramView = mViewDragHelper;
      if ((paramView != null) && (paramView.shouldInterceptTouchEvent(paramMotionEvent))) {
        return true;
      }
    }
    Object localObject1 = mNestedScrollingChildRef;
    paramView = localObject2;
    if (localObject1 != null) {
      paramView = (View)((WeakReference)localObject1).get();
    }
    return (i == 2) && (paramView != null) && (!mIgnoreEvents) && (mState != 1) && (!paramCoordinatorLayout.isPointInChildBounds(paramView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY())) && (mViewDragHelper != null) && (Math.abs(mInitialY - paramMotionEvent.getY()) > mViewDragHelper.getTouchSlop());
  }
  
  public final void onLayoutChild()
  {
    if (mHideable)
    {
      mMaxOffset = Math.max(mParentHeight - bottom, left);
      return;
    }
    mMaxOffset = (mParentHeight - bottom);
  }
  
  public final void onLayoutChild(int paramInt)
  {
    int i = 0;
    if (paramInt == -1)
    {
      if (!top)
      {
        top = true;
        i = 1;
      }
    }
    else if ((top) || (mPeekHeight != paramInt))
    {
      top = false;
      mPeekHeight = Math.max(0, paramInt);
      mMaxOffset = (mParentHeight - paramInt);
      i = 1;
    }
    if ((i != 0) && (mState == 4))
    {
      Object localObject = mViewRef;
      if (localObject != null)
      {
        localObject = (View)((WeakReference)localObject).get();
        if (localObject != null) {
          ((View)localObject).requestLayout();
        }
      }
    }
  }
  
  public boolean onLayoutChild(CoordinatorLayout paramCoordinatorLayout, View paramView, int paramInt)
  {
    if ((ViewCompat.getFitsSystemWindows(paramCoordinatorLayout)) && (!ViewCompat.getFitsSystemWindows(paramView))) {
      paramView.setFitsSystemWindows(true);
    }
    int i = paramView.getTop();
    paramCoordinatorLayout.onLayoutChild(paramView, paramInt);
    mParentHeight = paramCoordinatorLayout.getHeight();
    if (top)
    {
      if (right == 0) {
        right = paramCoordinatorLayout.getResources().getDimensionPixelSize(R.dimen.design_bottom_sheet_peek_height_min);
      }
      bottom = Math.max(right, mParentHeight - paramCoordinatorLayout.getWidth() * 9 / 16);
    }
    else
    {
      bottom = mPeekHeight;
    }
    left = Math.max(0, mParentHeight - paramView.getHeight());
    mMinOffset = (mParentHeight / 2);
    onLayoutChild();
    paramInt = mState;
    if (paramInt == 3)
    {
      ViewCompat.offsetTopAndBottom(paramView, get());
    }
    else if (paramInt == 6)
    {
      ViewCompat.offsetTopAndBottom(paramView, mMinOffset);
    }
    else if ((this$0) && (paramInt == 5))
    {
      ViewCompat.offsetTopAndBottom(paramView, mParentHeight);
    }
    else
    {
      paramInt = mState;
      if (paramInt == 4) {
        ViewCompat.offsetTopAndBottom(paramView, mMaxOffset);
      } else if ((paramInt == 1) || (paramInt == 2)) {
        ViewCompat.offsetTopAndBottom(paramView, i - paramView.getTop());
      }
    }
    if (mViewDragHelper == null) {
      mViewDragHelper = ViewDragHelper.create(paramCoordinatorLayout, mDragCallback);
    }
    mViewRef = new WeakReference(paramView);
    mNestedScrollingChildRef = new WeakReference(findScrollingChild(paramView));
    return true;
  }
  
  public boolean onNestedPreFling(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, float paramFloat1, float paramFloat2)
  {
    if (paramView2 == mNestedScrollingChildRef.get()) {
      if (mState == 3) {
        super.onNestedPreFling(paramCoordinatorLayout, paramView1, paramView2, paramFloat1, paramFloat2);
      } else {
        return true;
      }
    }
    return false;
  }
  
  public void onNestedPreScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    if (paramInt3 == 1) {
      return;
    }
    if (paramView2 != (View)mNestedScrollingChildRef.get()) {
      return;
    }
    paramInt1 = paramView1.getTop();
    paramInt3 = paramInt1 - paramInt2;
    if (paramInt2 > 0)
    {
      if (paramInt3 < get())
      {
        paramArrayOfInt[1] = (paramInt1 - get());
        ViewCompat.offsetTopAndBottom(paramView1, -paramArrayOfInt[1]);
        setState(3);
      }
      else
      {
        paramArrayOfInt[1] = paramInt2;
        ViewCompat.offsetTopAndBottom(paramView1, -paramInt2);
        setState(1);
      }
    }
    else if ((paramInt2 < 0) && (!paramView2.canScrollVertically(-1)))
    {
      int i = mMaxOffset;
      if ((paramInt3 > i) && (!this$0))
      {
        paramArrayOfInt[1] = (paramInt1 - i);
        ViewCompat.offsetTopAndBottom(paramView1, -paramArrayOfInt[1]);
        setState(4);
      }
      else
      {
        paramArrayOfInt[1] = paramInt2;
        ViewCompat.offsetTopAndBottom(paramView1, -paramInt2);
        setState(1);
      }
    }
    dispatchOnSlide(paramView1.getTop());
    mLastNestedScrollDy = paramInt2;
    mNestedScrolled = true;
  }
  
  public void onRestoreInstanceState(CoordinatorLayout paramCoordinatorLayout, View paramView, Parcelable paramParcelable)
  {
    paramParcelable = (d)paramParcelable;
    super.onRestoreInstanceState(paramCoordinatorLayout, paramView, paramParcelable.next());
    int i = state;
    if ((i != 1) && (i != 2))
    {
      mState = i;
      return;
    }
    mState = 4;
  }
  
  public Parcelable onSaveInstanceState(CoordinatorLayout paramCoordinatorLayout, View paramView)
  {
    return new d(super.onSaveInstanceState(paramCoordinatorLayout, paramView), mState);
  }
  
  public boolean onStartNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, View paramView3, int paramInt1, int paramInt2)
  {
    mLastNestedScrollDy = 0;
    mNestedScrolled = false;
    return (paramInt1 & 0x2) != 0;
  }
  
  public void onStopNestedScroll(CoordinatorLayout paramCoordinatorLayout, View paramView1, View paramView2, int paramInt)
  {
    if (paramView1.getTop() == get())
    {
      setState(3);
      return;
    }
    if (paramView2 == mNestedScrollingChildRef.get())
    {
      if (!mNestedScrolled) {
        return;
      }
      int i;
      if (mLastNestedScrollDy > 0)
      {
        i = get();
        paramInt = 3;
      }
      else if ((this$0) && (shouldHide(paramView1, getYVelocity())))
      {
        i = mParentHeight;
        paramInt = 5;
      }
      else if (mLastNestedScrollDy == 0)
      {
        paramInt = paramView1.getTop();
        if (mHideable)
        {
          if (Math.abs(paramInt - left) < Math.abs(paramInt - mMaxOffset))
          {
            i = left;
            paramInt = 3;
          }
          else
          {
            i = mMaxOffset;
            paramInt = 4;
          }
        }
        else
        {
          i = mMinOffset;
          if (paramInt < i)
          {
            if (paramInt < Math.abs(paramInt - mMaxOffset))
            {
              i = 0;
              paramInt = 3;
            }
            else
            {
              i = mMinOffset;
              paramInt = 6;
            }
          }
          else if (Math.abs(paramInt - i) < Math.abs(paramInt - mMaxOffset))
          {
            i = mMinOffset;
            paramInt = 6;
          }
          else
          {
            i = mMaxOffset;
            paramInt = 4;
          }
        }
      }
      else
      {
        i = mMaxOffset;
        paramInt = 4;
      }
      if (mViewDragHelper.smoothSlideViewTo(paramView1, paramView1.getLeft(), i))
      {
        setState(2);
        ViewCompat.postOnAnimation(paramView1, new e(paramView1, paramInt));
      }
      else
      {
        setState(paramInt);
      }
      mNestedScrolled = false;
    }
  }
  
  public boolean onTouchEvent(CoordinatorLayout paramCoordinatorLayout, View paramView, MotionEvent paramMotionEvent)
  {
    if (!paramView.isShown()) {
      return false;
    }
    int i = paramMotionEvent.getActionMasked();
    if ((mState == 1) && (i == 0)) {
      return true;
    }
    paramCoordinatorLayout = mViewDragHelper;
    if (paramCoordinatorLayout != null) {
      paramCoordinatorLayout.processTouchEvent(paramMotionEvent);
    }
    if (i == 0) {
      reset();
    }
    if (mVelocityTracker == null) {
      mVelocityTracker = VelocityTracker.obtain();
    }
    mVelocityTracker.addMovement(paramMotionEvent);
    if ((i == 2) && (!mIgnoreEvents) && (Math.abs(mInitialY - paramMotionEvent.getY()) > mViewDragHelper.getTouchSlop())) {
      mViewDragHelper.captureChildView(paramView, paramMotionEvent.getPointerId(paramMotionEvent.getActionIndex()));
    }
    return mIgnoreEvents ^ true;
  }
  
  public void put(boolean paramBoolean)
  {
    this$0 = paramBoolean;
  }
  
  public final void reset()
  {
    mActivePointerId = -1;
    VelocityTracker localVelocityTracker = mVelocityTracker;
    if (localVelocityTracker != null)
    {
      localVelocityTracker.recycle();
      mVelocityTracker = null;
    }
  }
  
  public void setBottomSheetCallback(c paramC)
  {
    mCallback = paramC;
  }
  
  public void setHideable(boolean paramBoolean)
  {
    mNoCrossFade = paramBoolean;
  }
  
  public void setState(int paramInt)
  {
    if (mState == paramInt) {
      return;
    }
    mState = paramInt;
    if ((paramInt != 6) && (paramInt != 3))
    {
      if ((paramInt == 5) || (paramInt == 4)) {
        apply(false);
      }
    }
    else {
      apply(true);
    }
    View localView = (View)mViewRef.get();
    if (localView != null)
    {
      c localC = mCallback;
      if (localC != null) {
        localC.a(localView, paramInt);
      }
    }
  }
  
  public void setState(View paramView, int paramInt)
  {
    int i;
    int j;
    if (paramInt == 4)
    {
      i = mMaxOffset;
      j = paramInt;
    }
    else if (paramInt == 6)
    {
      int k = mMinOffset;
      i = k;
      j = paramInt;
      if (mHideable)
      {
        i = k;
        j = paramInt;
        if (k <= left)
        {
          j = 3;
          i = left;
        }
      }
    }
    else if (paramInt == 3)
    {
      i = get();
      j = paramInt;
    }
    else
    {
      if ((!this$0) || (paramInt != 5)) {
        break label147;
      }
      i = mParentHeight;
      j = paramInt;
    }
    if (mViewDragHelper.smoothSlideViewTo(paramView, paramView.getLeft(), i))
    {
      setState(2);
      ViewCompat.postOnAnimation(paramView, new e(paramView, j));
      return;
    }
    setState(j);
    return;
    label147:
    paramView = new StringBuilder();
    paramView.append("Illegal state argument: ");
    paramView.append(paramInt);
    throw new IllegalArgumentException(paramView.toString());
  }
  
  public void setState(boolean paramBoolean)
  {
    if (mHideable == paramBoolean) {
      return;
    }
    mHideable = paramBoolean;
    if (mViewRef != null) {
      onLayoutChild();
    }
    int i;
    if ((mHideable) && (mState == 6)) {
      i = 3;
    } else {
      i = mState;
    }
    setState(i);
  }
  
  public boolean shouldHide(View paramView, float paramFloat)
  {
    if (mNoCrossFade) {
      return true;
    }
    if (paramView.getTop() < mMaxOffset) {
      return false;
    }
    return Math.abs(paramView.getTop() + 0.1F * paramFloat - mMaxOffset) / mPeekHeight > 0.5F;
  }
  
  public final void show(final int paramInt)
  {
    if (paramInt == mState) {
      return;
    }
    Object localObject = mViewRef;
    if (localObject == null)
    {
      if ((paramInt == 4) || (paramInt == 3) || (paramInt == 6) || ((this$0) && (paramInt == 5))) {
        mState = paramInt;
      }
    }
    else
    {
      localObject = (View)((WeakReference)localObject).get();
      if (localObject == null) {
        return;
      }
      ViewParent localViewParent = ((View)localObject).getParent();
      if ((localViewParent != null) && (localViewParent.isLayoutRequested()) && (ViewCompat.isAttachedToWindow((View)localObject)))
      {
        ((View)localObject).post(new a((View)localObject, paramInt));
        return;
      }
      setState((View)localObject, paramInt);
    }
  }
  
  public class a
    implements Runnable
  {
    public a(View paramView, int paramInt) {}
    
    public void run()
    {
      setState(bluetoothDevice, paramInt);
    }
  }
  
  public class b
    extends ViewDragHelper.Callback
  {
    public b() {}
    
    public int clampViewPositionHorizontal(View paramView, int paramInt1, int paramInt2)
    {
      return paramView.getLeft();
    }
    
    public int clampViewPositionVertical(View paramView, int paramInt1, int paramInt2)
    {
      int i = BottomSheetBehavior.access$getMMinOffset(BottomSheetBehavior.this);
      paramView = BottomSheetBehavior.this;
      if (this$0) {
        paramInt2 = mParentHeight;
      } else {
        paramInt2 = mMaxOffset;
      }
      return MathUtils.constrain(paramInt1, i, paramInt2);
    }
    
    public int getViewVerticalDragRange(View paramView)
    {
      paramView = BottomSheetBehavior.this;
      if (this$0) {
        return mParentHeight;
      }
      return mMaxOffset;
    }
    
    public void onViewDragStateChanged(int paramInt)
    {
      if (paramInt == 1) {
        setState(1);
      }
    }
    
    public void onViewPositionChanged(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      dispatchOnSlide(paramInt2);
    }
    
    public void onViewReleased(View paramView, float paramFloat1, float paramFloat2)
    {
      int j;
      int i;
      BottomSheetBehavior localBottomSheetBehavior;
      if (paramFloat2 < 0.0F)
      {
        if (BottomSheetBehavior.access$getMHideable(BottomSheetBehavior.this))
        {
          j = left;
          i = 3;
        }
        else
        {
          i = paramView.getTop();
          localBottomSheetBehavior = BottomSheetBehavior.this;
          if (i > mMinOffset)
          {
            j = mMinOffset;
            i = 6;
          }
          else
          {
            j = 0;
            i = 3;
          }
        }
      }
      else
      {
        localBottomSheetBehavior = BottomSheetBehavior.this;
        if ((this$0) && (localBottomSheetBehavior.shouldHide(paramView, paramFloat2)) && ((paramView.getTop() > mMaxOffset) || (Math.abs(paramFloat1) < Math.abs(paramFloat2))))
        {
          j = mParentHeight;
          i = 5;
        }
        else if ((paramFloat2 != 0.0F) && (Math.abs(paramFloat1) <= Math.abs(paramFloat2)))
        {
          j = mMaxOffset;
          i = 4;
        }
        else
        {
          i = paramView.getTop();
          if (BottomSheetBehavior.access$getMHideable(BottomSheetBehavior.this))
          {
            if (Math.abs(i - left) < Math.abs(i - mMaxOffset))
            {
              j = left;
              i = 3;
            }
            else
            {
              j = mMaxOffset;
              i = 4;
            }
          }
          else
          {
            localBottomSheetBehavior = BottomSheetBehavior.this;
            j = mMinOffset;
            if (i < j)
            {
              if (i < Math.abs(i - mMaxOffset))
              {
                j = 0;
                i = 3;
              }
              else
              {
                j = mMinOffset;
                i = 6;
              }
            }
            else if (Math.abs(i - j) < Math.abs(i - mMaxOffset))
            {
              j = mMinOffset;
              i = 6;
            }
            else
            {
              j = mMaxOffset;
              i = 4;
            }
          }
        }
      }
      if (mViewDragHelper.settleCapturedViewAt(paramView.getLeft(), j))
      {
        setState(2);
        ViewCompat.postOnAnimation(paramView, new BottomSheetBehavior.e(BottomSheetBehavior.this, paramView, i));
        return;
      }
      setState(i);
    }
    
    public boolean tryCaptureView(View paramView, int paramInt)
    {
      Object localObject = BottomSheetBehavior.this;
      int i = mState;
      if (i == 1) {
        return false;
      }
      if (mTouchingScrollingChild) {
        return false;
      }
      if ((i == 3) && (mActivePointerId == paramInt))
      {
        localObject = (View)mNestedScrollingChildRef.get();
        if ((localObject != null) && (((View)localObject).canScrollVertically(-1))) {
          return false;
        }
      }
      localObject = mViewRef;
      return (localObject != null) && (((WeakReference)localObject).get() == paramView);
    }
  }
  
  public static abstract class c
  {
    public c() {}
    
    public abstract void a(View paramView, int paramInt);
    
    public abstract void onSlide(View paramView, float paramFloat);
  }
  
  public static class d
    extends Item
  {
    public static final Parcelable.Creator<d> CREATOR = new a();
    public final int state;
    
    public d(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(paramClassLoader);
      state = paramParcel.readInt();
    }
    
    public d(Parcelable paramParcelable, int paramInt)
    {
      super();
      state = paramInt;
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(state);
    }
    
    public static final class a
      implements Parcelable.ClassLoaderCreator<BottomSheetBehavior.d>
    {
      public a() {}
      
      public BottomSheetBehavior.d[] a(int paramInt)
      {
        return new BottomSheetBehavior.d[paramInt];
      }
      
      public BottomSheetBehavior.d readDate(Parcel paramParcel)
      {
        return new BottomSheetBehavior.d(paramParcel, null);
      }
      
      public BottomSheetBehavior.d readFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
      {
        return new BottomSheetBehavior.d(paramParcel, paramClassLoader);
      }
    }
  }
  
  public class e
    implements Runnable
  {
    public final View mLayout;
    public final int val$state;
    
    public e(View paramView, int paramInt)
    {
      mLayout = paramView;
      val$state = paramInt;
    }
    
    public void run()
    {
      ViewDragHelper localViewDragHelper = mViewDragHelper;
      if ((localViewDragHelper != null) && (localViewDragHelper.continueSettling(true)))
      {
        ViewCompat.postOnAnimation(mLayout, this);
        return;
      }
      setState(val$state);
    }
  }
}
