package androidx.lifecycle;

/* renamed from: androidx.lifecycle.R */
public final class C0214R {
    private C0214R() {
    }
}
