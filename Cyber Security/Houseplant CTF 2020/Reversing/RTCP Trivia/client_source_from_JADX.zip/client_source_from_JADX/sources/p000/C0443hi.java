package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

/* renamed from: hi */
public interface C0443hi {
    ColorStateList getSupportImageTintList();

    Mode getSupportImageTintMode();

    void setSupportImageTintList(ColorStateList colorStateList);

    void setSupportImageTintMode(Mode mode);
}
