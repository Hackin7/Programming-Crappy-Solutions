package p000;

/* renamed from: gm */
public interface C0392gm extends C0391gl {
    /* renamed from: a */
    void mo743a(int i, int i2);

    /* renamed from: a */
    void mo744a(int i, int i2, int[] iArr, int i3);

    /* renamed from: a */
    boolean mo745a(int i);

    /* renamed from: b */
    void mo751b(int i);

    /* renamed from: b */
    void mo752b(int i, int i2);
}
