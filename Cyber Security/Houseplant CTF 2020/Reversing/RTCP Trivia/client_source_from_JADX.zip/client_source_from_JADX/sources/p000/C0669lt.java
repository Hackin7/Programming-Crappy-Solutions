package p000;

/* renamed from: lt */
public interface C0669lt {
}
