package p000;

import android.graphics.drawable.Drawable;

/* renamed from: fp */
public interface C0347fp {
    /* renamed from: a */
    Drawable mo1712a();

    /* renamed from: a */
    void mo1713a(Drawable drawable);
}
