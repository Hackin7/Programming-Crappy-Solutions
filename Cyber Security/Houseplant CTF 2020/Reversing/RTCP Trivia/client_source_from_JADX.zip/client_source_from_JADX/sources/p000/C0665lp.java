package p000;

import javax.annotation.Nullable;

/* renamed from: lp */
public final class C0665lp extends C0625ko {
    @Nullable

    /* renamed from: a */
    private final String f2868a;

    /* renamed from: b */
    private final long f2869b;

    /* renamed from: c */
    private final C0761ne f2870c;

    public C0665lp(@Nullable String str, long j, C0761ne neVar) {
        this.f2868a = str;
        this.f2869b = j;
        this.f2870c = neVar;
    }

    /* renamed from: a */
    public final long mo2397a() {
        return this.f2869b;
    }

    /* renamed from: b */
    public final C0761ne mo2398b() {
        return this.f2870c;
    }
}
