package p000;

import java.nio.channels.WritableByteChannel;

/* renamed from: nd */
public interface C0760nd extends WritableByteChannel, C0777nr {
    /* renamed from: b */
    C0758nc mo2618b();

    /* renamed from: b */
    C0760nd mo2622b(String str);

    /* renamed from: b */
    C0760nd mo2623b(C0762nf nfVar);

    /* renamed from: c */
    C0760nd mo2626c();

    /* renamed from: c */
    C0760nd mo2627c(byte[] bArr);

    /* renamed from: c */
    C0760nd mo2628c(byte[] bArr, int i, int i2);

    /* renamed from: f */
    C0760nd mo2639f(int i);

    void flush();

    /* renamed from: g */
    C0760nd mo2641g(int i);

    /* renamed from: h */
    C0760nd mo2646h(int i);

    /* renamed from: j */
    C0760nd mo2651j(long j);

    /* renamed from: k */
    C0760nd mo2654k(long j);

    /* renamed from: s */
    C0760nd mo2663s();
}
