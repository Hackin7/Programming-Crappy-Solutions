package p000;

/* renamed from: gj */
public interface C0389gj extends C0388gi {
}
