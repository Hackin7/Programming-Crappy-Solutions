package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

/* renamed from: cp */
final class C0213cp {

    /* renamed from: a */
    public ColorStateList f1081a;

    /* renamed from: b */
    public Mode f1082b;

    /* renamed from: c */
    public boolean f1083c;

    /* renamed from: d */
    public boolean f1084d;

    C0213cp() {
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final void mo1310a() {
        this.f1081a = null;
        this.f1084d = false;
        this.f1082b = null;
        this.f1083c = false;
    }
}
