package p000;

import java.io.IOException;

/* renamed from: lv */
public final class C0677lv extends IOException {
}
