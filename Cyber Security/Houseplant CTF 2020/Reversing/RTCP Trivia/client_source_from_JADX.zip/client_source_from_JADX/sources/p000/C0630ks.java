package p000;

import javax.annotation.Nullable;

/* renamed from: ks */
public abstract class C0630ks {
    /* renamed from: a */
    public void mo2406a(int i, String str) {
    }

    /* renamed from: a */
    public void mo2407a(Throwable th, @Nullable C0623kn knVar) {
    }

    /* renamed from: a */
    public void mo2408a(C0629kr krVar, String str) {
    }

    /* renamed from: a */
    public void mo2409a(C0629kr krVar, C0623kn knVar) {
    }

    /* renamed from: b */
    public void mo2410b(int i, String str) {
    }
}
