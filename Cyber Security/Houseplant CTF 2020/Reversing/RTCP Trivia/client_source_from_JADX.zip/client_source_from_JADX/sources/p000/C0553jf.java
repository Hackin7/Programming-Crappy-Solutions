package p000;

/* renamed from: jf */
final class C0553jf {

    /* renamed from: a */
    static final int[] f2260a = {16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779};

    /* renamed from: b */
    static final int[] f2261b = {16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867};

    /* renamed from: c */
    static final int[] f2262c = {16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980, 16844062};

    /* renamed from: d */
    static final int[] f2263d = {16842755, 16843781};

    /* renamed from: e */
    static final int[] f2264e = {16843161};

    /* renamed from: f */
    static final int[] f2265f = {16842755, 16843213};

    /* renamed from: g */
    public static final int[] f2266g = {16843073, 16843160, 16843198, 16843199, 16843200, 16843486, 16843487, 16843488};

    /* renamed from: h */
    public static final int[] f2267h = {16843490};

    /* renamed from: i */
    public static final int[] f2268i = {16843486, 16843487, 16843488, 16843489};

    /* renamed from: j */
    public static final int[] f2269j = {16842788, 16843073, 16843488, 16843992};

    /* renamed from: k */
    public static final int[] f2270k = {16843489, 16843781, 16843892, 16843893};

    /* renamed from: l */
    public static final int[] f2271l = {16843772, 16843773, 16843774, 16843775, 16843781};
}
