package p000;

import android.view.ViewGroup;

/* renamed from: gn */
public final class C0393gn {

    /* renamed from: a */
    public int f1732a;

    /* renamed from: b */
    private final ViewGroup f1733b;

    public C0393gn(ViewGroup viewGroup) {
        this.f1733b = viewGroup;
    }
}
