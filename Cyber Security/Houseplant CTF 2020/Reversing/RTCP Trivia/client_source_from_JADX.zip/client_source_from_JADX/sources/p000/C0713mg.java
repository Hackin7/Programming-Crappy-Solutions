package p000;

/* renamed from: mg */
public interface C0713mg {

    /* renamed from: a */
    public static final C0713mg f3092a = new C0713mg() {
        /* renamed from: a */
        public final boolean mo2529a() {
            return true;
        }

        /* renamed from: a */
        public final boolean mo2530a(C0761ne neVar, int i) {
            neVar.mo2643g((long) i);
            return true;
        }

        /* renamed from: b */
        public final boolean mo2531b() {
            return true;
        }

        /* renamed from: c */
        public final void mo2532c() {
        }
    };

    /* renamed from: a */
    boolean mo2529a();

    /* renamed from: a */
    boolean mo2530a(C0761ne neVar, int i);

    /* renamed from: b */
    boolean mo2531b();

    /* renamed from: c */
    void mo2532c();
}
