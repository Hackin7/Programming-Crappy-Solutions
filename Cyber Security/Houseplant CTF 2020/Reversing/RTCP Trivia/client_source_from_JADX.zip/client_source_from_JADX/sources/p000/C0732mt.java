package p000;

import java.security.cert.Certificate;
import java.util.List;

/* renamed from: mt */
public abstract class C0732mt {
    /* renamed from: a */
    public abstract List<Certificate> mo2547a(List<Certificate> list, String str);
}
