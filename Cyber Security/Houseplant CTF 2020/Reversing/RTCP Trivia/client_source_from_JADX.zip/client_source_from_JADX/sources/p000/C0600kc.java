package p000;

/* renamed from: kc */
public abstract class C0600kc {

    /* renamed from: a */
    public static final C0600kc f2571a = new C0600kc() {
    };

    /* renamed from: kc$a */
    public interface C0603a {
        /* renamed from: a */
        C0600kc mo2319a();
    }

    /* renamed from: a */
    public static C0603a m1821a(C0600kc kcVar) {
        return new C0603a() {
            /* renamed from: a */
            public final C0600kc mo2319a() {
                return C0600kc.this;
            }
        };
    }

    /* renamed from: a */
    public static void m1822a() {
    }

    /* renamed from: b */
    public static void m1823b() {
    }

    /* renamed from: c */
    public static void m1824c() {
    }

    /* renamed from: d */
    public static void m1825d() {
    }

    /* renamed from: e */
    public static void m1826e() {
    }

    /* renamed from: f */
    public static void m1827f() {
    }

    /* renamed from: g */
    public static void m1828g() {
    }

    /* renamed from: h */
    public static void m1829h() {
    }

    /* renamed from: i */
    public static void m1830i() {
    }

    /* renamed from: j */
    public static void m1831j() {
    }

    /* renamed from: k */
    public static void m1832k() {
    }

    /* renamed from: l */
    public static void m1833l() {
    }

    /* renamed from: m */
    public static void m1834m() {
    }

    /* renamed from: n */
    public static void m1835n() {
    }

    /* renamed from: o */
    public static void m1836o() {
    }

    /* renamed from: p */
    public static void m1837p() {
    }

    /* renamed from: q */
    public static void m1838q() {
    }

    /* renamed from: r */
    public static void m1839r() {
    }

    /* renamed from: s */
    public static void m1840s() {
    }

    /* renamed from: t */
    public static void m1841t() {
    }
}
