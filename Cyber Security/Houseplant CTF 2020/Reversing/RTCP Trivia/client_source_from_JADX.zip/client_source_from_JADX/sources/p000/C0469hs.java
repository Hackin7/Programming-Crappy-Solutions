package p000;

/* renamed from: hs */
public final class C0469hs {

    /* renamed from: a */
    final C0470ht<?> f2036a;

    C0469hs(C0470ht<?> htVar) {
        this.f2036a = htVar;
    }

    /* renamed from: a */
    public final C0457hp mo1998a(String str) {
        return this.f2036a.f2041e.mo2005a(str);
    }

    /* renamed from: a */
    public final void mo1999a() {
        this.f2036a.f2041e.mo2026f();
    }

    /* renamed from: b */
    public final boolean mo2000b() {
        return this.f2036a.f2041e.mo2024d();
    }
}
