package p000;

/* renamed from: f */
public interface C0322f {
}
