package p000;

import java.io.Closeable;
import java.io.Flushable;

/* renamed from: jq */
public final class C0577jq implements Closeable, Flushable {

    /* renamed from: a */
    final C0645la f2371a;

    /* renamed from: b */
    final C0641kz f2372b;

    public final void close() {
        this.f2372b.close();
    }

    public final void flush() {
        this.f2372b.flush();
    }
}
