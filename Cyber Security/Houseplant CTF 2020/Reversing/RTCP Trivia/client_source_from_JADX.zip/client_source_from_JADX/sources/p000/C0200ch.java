package p000;

import android.view.MenuItem;

/* renamed from: ch */
public interface C0200ch {
    /* renamed from: a */
    void mo125a(C0019aj ajVar, MenuItem menuItem);

    /* renamed from: b */
    void mo126b(C0019aj ajVar, MenuItem menuItem);
}
