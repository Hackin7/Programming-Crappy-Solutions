package p000;

import wtf.riceteacatpanda.quiz.R;

/* renamed from: ep */
public final class C0302ep {

    /* renamed from: ep$a */
    public static final class C0303a {
        public static final int alpha = 2130837543;
        public static final int font = 2130837626;
        public static final int fontProviderAuthority = 2130837628;
        public static final int fontProviderCerts = 2130837629;
        public static final int fontProviderFetchStrategy = 2130837630;
        public static final int fontProviderFetchTimeout = 2130837631;
        public static final int fontProviderPackage = 2130837632;
        public static final int fontProviderQuery = 2130837633;
        public static final int fontStyle = 2130837634;
        public static final int fontVariationSettings = 2130837635;
        public static final int fontWeight = 2130837636;
        public static final int ttcIndex = 2130837820;
    }

    /* renamed from: ep$b */
    public static final class C0304b {
        public static final int action_container = 2131165197;
        public static final int action_divider = 2131165199;
        public static final int action_image = 2131165200;
        public static final int action_text = 2131165206;
        public static final int actions = 2131165207;
        public static final int async = 2131165213;
        public static final int blocking = 2131165216;
        public static final int chronometer = 2131165224;
        public static final int forever = 2131165247;
        public static final int icon = 2131165252;
        public static final int icon_group = 2131165253;
        public static final int info = 2131165257;
        public static final int italic = 2131165259;
        public static final int line1 = 2131165261;
        public static final int line3 = 2131165262;
        public static final int normal = 2131165271;
        public static final int notification_background = 2131165272;
        public static final int notification_main_column = 2131165273;
        public static final int notification_main_column_container = 2131165274;
        public static final int right_icon = 2131165289;
        public static final int right_side = 2131165290;
        public static final int tag_transition_group = 2131165322;
        public static final int tag_unhandled_key_event_manager = 2131165323;
        public static final int tag_unhandled_key_listeners = 2131165324;
        public static final int text = 2131165325;
        public static final int text2 = 2131165326;
        public static final int time = 2131165331;
        public static final int title = 2131165332;
    }

    /* renamed from: ep$c */
    public static final class C0305c {
        public static final int[] ColorStateListItem = {16843173, 16843551, R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
    }
}
