package p000;

/* renamed from: jb */
public interface C0543jb {
    /* renamed from: a */
    C0542ja mo1930a();
}
