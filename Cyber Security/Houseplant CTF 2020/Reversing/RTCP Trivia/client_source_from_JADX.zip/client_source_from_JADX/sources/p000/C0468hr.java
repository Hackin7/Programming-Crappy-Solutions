package p000;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

/* renamed from: hr */
public abstract class C0468hr {
    /* renamed from: a */
    public abstract View mo1965a(int i);

    /* renamed from: a */
    public C0457hp mo1966a(Context context, String str, Bundle bundle) {
        return C0457hp.m1427a(context, str, bundle);
    }

    /* renamed from: a */
    public abstract boolean mo1967a();
}
