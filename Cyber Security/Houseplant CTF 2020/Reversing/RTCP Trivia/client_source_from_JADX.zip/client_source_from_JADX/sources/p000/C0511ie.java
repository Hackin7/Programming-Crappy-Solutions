package p000;

import android.util.AndroidRuntimeException;

/* renamed from: ie */
final class C0511ie extends AndroidRuntimeException {
    public C0511ie(String str) {
        super(str);
    }
}
