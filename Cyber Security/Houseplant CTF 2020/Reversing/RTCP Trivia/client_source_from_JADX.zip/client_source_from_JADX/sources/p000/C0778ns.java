package p000;

import java.io.Closeable;

/* renamed from: ns */
public interface C0778ns extends Closeable {
    /* renamed from: a */
    long mo2414a(C0758nc ncVar, long j);

    /* renamed from: a */
    C0779nt mo2415a();

    void close();
}
