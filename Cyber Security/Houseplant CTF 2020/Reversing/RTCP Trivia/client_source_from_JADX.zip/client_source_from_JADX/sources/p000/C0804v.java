package p000;

/* renamed from: v */
public interface C0804v {
    /* renamed from: a */
    void mo311a();

    /* renamed from: b */
    void mo312b();
}
