package p000;

/* renamed from: la */
public interface C0645la {
    /* renamed from: a */
    C0623kn mo2422a();

    /* renamed from: b */
    C0638kx mo2423b();
}
