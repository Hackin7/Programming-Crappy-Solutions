package p000;

/* renamed from: il */
public interface C0520il {
}
