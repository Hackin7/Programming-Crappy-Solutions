package p000;

import android.view.View;

/* renamed from: go */
public interface C0394go {
    /* renamed from: a */
    C0409gx mo1816a(View view, C0409gx gxVar);
}
