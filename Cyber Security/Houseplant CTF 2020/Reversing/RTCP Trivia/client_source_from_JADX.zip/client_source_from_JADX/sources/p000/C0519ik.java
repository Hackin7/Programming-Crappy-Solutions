package p000;

/* renamed from: ik */
public interface C0519ik extends C0525io {
}
