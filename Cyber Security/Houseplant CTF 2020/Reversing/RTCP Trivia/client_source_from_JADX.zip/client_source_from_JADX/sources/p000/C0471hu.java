package p000;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

/* renamed from: hu */
public abstract class C0471hu {
    /* renamed from: a */
    public abstract void mo2001a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    /* renamed from: a */
    public abstract boolean mo2002a();

    /* renamed from: b */
    public abstract List<C0457hp> mo2003b();

    /* renamed from: c */
    public abstract boolean mo2004c();
}
