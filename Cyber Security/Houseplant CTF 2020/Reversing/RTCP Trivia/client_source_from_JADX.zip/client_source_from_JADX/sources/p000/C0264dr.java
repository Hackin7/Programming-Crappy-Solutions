package p000;

import java.util.ArrayList;

/* renamed from: dr */
public final class C0264dr {

    /* renamed from: A */
    public long f1253A;

    /* renamed from: B */
    public long f1254B;

    /* renamed from: C */
    public ArrayList<String> f1255C;

    /* renamed from: D */
    public long f1256D;

    /* renamed from: a */
    public long f1257a;

    /* renamed from: b */
    public long f1258b;

    /* renamed from: c */
    public long f1259c;

    /* renamed from: d */
    public long f1260d;

    /* renamed from: e */
    public long f1261e;

    /* renamed from: f */
    public long f1262f;

    /* renamed from: g */
    public long f1263g;

    /* renamed from: h */
    public long f1264h;

    /* renamed from: i */
    public long f1265i;

    /* renamed from: j */
    public long f1266j;

    /* renamed from: k */
    public long f1267k;

    /* renamed from: l */
    public long f1268l;

    /* renamed from: m */
    public long f1269m;

    /* renamed from: n */
    public long f1270n;

    /* renamed from: o */
    public long f1271o;

    /* renamed from: p */
    public long f1272p;

    /* renamed from: q */
    public long f1273q;

    /* renamed from: r */
    public long f1274r;

    /* renamed from: s */
    public long f1275s;

    /* renamed from: t */
    public long f1276t;

    /* renamed from: u */
    public long f1277u;

    /* renamed from: v */
    public long f1278v;

    /* renamed from: w */
    public long f1279w;

    /* renamed from: x */
    public long f1280x;

    /* renamed from: y */
    public long f1281y;

    /* renamed from: z */
    public long f1282z;

    public final String toString() {
        StringBuilder sb = new StringBuilder("\n*** Metrics ***\nmeasures: ");
        sb.append(this.f1257a);
        sb.append("\nadditionalMeasures: ");
        sb.append(this.f1258b);
        sb.append("\nresolutions passes: ");
        sb.append(this.f1259c);
        sb.append("\ntable increases: ");
        sb.append(this.f1260d);
        sb.append("\nmaxTableSize: ");
        sb.append(this.f1272p);
        sb.append("\nmaxVariables: ");
        sb.append(this.f1277u);
        sb.append("\nmaxRows: ");
        sb.append(this.f1278v);
        sb.append("\n\nminimize: ");
        sb.append(this.f1261e);
        sb.append("\nminimizeGoal: ");
        sb.append(this.f1276t);
        sb.append("\nconstraints: ");
        sb.append(this.f1262f);
        sb.append("\nsimpleconstraints: ");
        sb.append(this.f1263g);
        sb.append("\noptimize: ");
        sb.append(this.f1264h);
        sb.append("\niterations: ");
        sb.append(this.f1265i);
        sb.append("\npivots: ");
        sb.append(this.f1266j);
        sb.append("\nbfs: ");
        sb.append(this.f1267k);
        sb.append("\nvariables: ");
        sb.append(this.f1268l);
        sb.append("\nerrors: ");
        sb.append(this.f1269m);
        sb.append("\nslackvariables: ");
        sb.append(this.f1270n);
        sb.append("\nextravariables: ");
        sb.append(this.f1271o);
        sb.append("\nfullySolved: ");
        sb.append(this.f1273q);
        sb.append("\ngraphOptimizer: ");
        sb.append(this.f1274r);
        sb.append("\nresolvedWidgets: ");
        sb.append(this.f1275s);
        sb.append("\noldresolvedWidgets: ");
        sb.append(this.f1253A);
        sb.append("\nnonresolvedWidgets: ");
        sb.append(this.f1254B);
        sb.append("\ncenterConnectionResolved: ");
        sb.append(this.f1279w);
        sb.append("\nmatchConnectionResolved: ");
        sb.append(this.f1280x);
        sb.append("\nchainConnectionResolved: ");
        sb.append(this.f1281y);
        sb.append("\nbarrierConnectionResolved: ");
        sb.append(this.f1282z);
        sb.append("\nproblematicsLayouts: ");
        sb.append(this.f1255C);
        sb.append("\n");
        return sb.toString();
    }
}
