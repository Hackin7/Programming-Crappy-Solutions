package p000;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window.Callback;

/* renamed from: ca */
public interface C0180ca {
    /* renamed from: a */
    ViewGroup mo1128a();

    /* renamed from: a */
    C0402gt mo1129a(int i, long j);

    /* renamed from: a */
    void mo1130a(int i);

    /* renamed from: a */
    void mo1131a(Drawable drawable);

    /* renamed from: a */
    void mo1132a(Menu menu, C0102a aVar);

    /* renamed from: a */
    void mo1133a(Callback callback);

    /* renamed from: a */
    void mo1134a(C0102a aVar, C0020a aVar2);

    /* renamed from: a */
    void mo1135a(C0205cl clVar);

    /* renamed from: a */
    void mo1136a(CharSequence charSequence);

    /* renamed from: a */
    void mo1137a(boolean z);

    /* renamed from: b */
    Context mo1138b();

    /* renamed from: b */
    void mo1139b(int i);

    /* renamed from: c */
    void mo1140c(int i);

    /* renamed from: c */
    boolean mo1141c();

    /* renamed from: d */
    void mo1142d();

    /* renamed from: d */
    void mo1143d(int i);

    /* renamed from: e */
    CharSequence mo1144e();

    /* renamed from: f */
    void mo1145f();

    /* renamed from: g */
    void mo1146g();

    /* renamed from: h */
    boolean mo1147h();

    /* renamed from: i */
    boolean mo1148i();

    /* renamed from: j */
    boolean mo1149j();

    /* renamed from: k */
    boolean mo1150k();

    /* renamed from: l */
    boolean mo1151l();

    /* renamed from: m */
    void mo1152m();

    /* renamed from: n */
    void mo1153n();

    /* renamed from: o */
    int mo1154o();

    /* renamed from: p */
    int mo1155p();

    /* renamed from: q */
    Menu mo1156q();
}
