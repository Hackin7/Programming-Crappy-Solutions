package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

/* renamed from: gp */
public interface C0395gp {
    ColorStateList getSupportBackgroundTintList();

    Mode getSupportBackgroundTintMode();

    void setSupportBackgroundTintList(ColorStateList colorStateList);

    void setSupportBackgroundTintMode(Mode mode);
}
