package p000;

import android.graphics.drawable.Animatable;

/* renamed from: jg */
public interface C0554jg extends Animatable {
}
