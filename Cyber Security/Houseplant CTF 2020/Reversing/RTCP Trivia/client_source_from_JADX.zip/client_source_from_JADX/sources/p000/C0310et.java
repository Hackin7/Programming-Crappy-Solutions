package p000;

/* renamed from: et */
public abstract class C0310et {
}
