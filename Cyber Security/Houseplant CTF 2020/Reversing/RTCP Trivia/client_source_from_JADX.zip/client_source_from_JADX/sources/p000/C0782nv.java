package p000;

/* renamed from: nv */
public abstract class C0782nv implements Runnable {

    /* renamed from: d */
    public String f3310d;
}
