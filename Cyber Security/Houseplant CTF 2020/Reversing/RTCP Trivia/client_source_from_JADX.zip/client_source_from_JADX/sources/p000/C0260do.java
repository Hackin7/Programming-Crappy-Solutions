package p000;

/* renamed from: do */
public final class C0260do {

    /* renamed from: a */
    C0266a<C0259dn> f1232a = new C0267b();

    /* renamed from: b */
    C0266a<C0268dt> f1233b = new C0267b();

    /* renamed from: c */
    C0268dt[] f1234c = new C0268dt[32];
}
