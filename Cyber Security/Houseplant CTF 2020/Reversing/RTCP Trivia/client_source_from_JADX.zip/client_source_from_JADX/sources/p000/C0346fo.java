package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

/* renamed from: fo */
public interface C0346fo {
    void setTint(int i);

    void setTintList(ColorStateList colorStateList);

    void setTintMode(Mode mode);
}
