package p000;

/* renamed from: lq */
public final class C0666lq {
    /* renamed from: a */
    public static String m2067a(C0607kf kfVar) {
        String e = kfVar.mo2337e();
        String g = kfVar.mo2340g();
        if (g == null) {
            return e;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(e);
        sb.append('?');
        sb.append(g);
        return sb.toString();
    }
}
