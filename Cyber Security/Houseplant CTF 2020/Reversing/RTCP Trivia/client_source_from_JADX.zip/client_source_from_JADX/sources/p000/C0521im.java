package p000;

/* renamed from: im */
public interface C0521im extends C0525io {
    /* renamed from: a */
    void mo807a(C0526ip ipVar, C0523a aVar);
}
