package p000;

import java.util.HashMap;

/* renamed from: ja */
public final class C0542ja {

    /* renamed from: a */
    public final HashMap<String, C0538iy> f2237a = new HashMap<>();

    /* renamed from: a */
    public final void mo2138a() {
        for (C0538iy a : this.f2237a.values()) {
            a.mo2136a();
        }
        this.f2237a.clear();
    }
}
