package p000;

/* renamed from: kx */
public interface C0638kx {
    /* renamed from: a */
    C0777nr mo2417a();
}
