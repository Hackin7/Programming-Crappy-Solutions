package p000;

@Deprecated
/* renamed from: ir */
public interface C0530ir extends C0526ip {
    /* renamed from: a */
    C0527iq mo2127a();
}
