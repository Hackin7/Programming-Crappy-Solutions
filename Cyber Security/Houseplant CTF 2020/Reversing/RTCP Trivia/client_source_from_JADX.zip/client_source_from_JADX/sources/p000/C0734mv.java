package p000;

import java.security.cert.X509Certificate;

/* renamed from: mv */
public interface C0734mv {
    /* renamed from: a */
    X509Certificate mo2550a(X509Certificate x509Certificate);
}
