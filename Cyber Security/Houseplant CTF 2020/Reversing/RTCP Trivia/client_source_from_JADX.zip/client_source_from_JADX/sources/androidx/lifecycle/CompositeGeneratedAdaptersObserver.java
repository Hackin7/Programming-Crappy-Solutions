package androidx.lifecycle;

public class CompositeGeneratedAdaptersObserver implements C0521im {

    /* renamed from: a */
    private final C0520il[] f683a;

    public CompositeGeneratedAdaptersObserver(C0520il[] ilVarArr) {
        this.f683a = ilVarArr;
    }

    /* renamed from: a */
    public final void mo807a(C0526ip ipVar, C0523a aVar) {
        new C0532it();
    }
}
