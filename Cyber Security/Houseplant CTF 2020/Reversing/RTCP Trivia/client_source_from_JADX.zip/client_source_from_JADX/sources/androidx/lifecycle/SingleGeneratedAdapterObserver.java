package androidx.lifecycle;

public class SingleGeneratedAdapterObserver implements C0521im {

    /* renamed from: a */
    private final C0520il f705a;

    public SingleGeneratedAdapterObserver(C0520il ilVar) {
        this.f705a = ilVar;
    }

    /* renamed from: a */
    public final void mo807a(C0526ip ipVar, C0523a aVar) {
    }
}
